import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { useTheme } from "../contexts/ThemeContext";
import { useLanguage } from "../contexts/LanguageContext";
import { Button } from "../components/ui/button";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator
} from "../components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetTrigger } from "../components/ui/sheet";
import { Shield, Sun, Moon, Globe, Menu, LogOut, User, LayoutDashboard, GraduationCap, Home, BookOpen, Newspaper, Plus, Settings, Crosshair, Bell, ShieldAlert } from "lucide-react";
import axios from "axios";

const API = `${process.env.REACT_APP_BACKEND_URL}/api`;

export default function GamificationHeader() {
  const { user, logout, token } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const { lang, toggleLang, t } = useLanguage();
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const [notifications, setNotifications] = useState([]);
  const [showNotifs, setShowNotifs] = useState(false);

  // Fetch notifications periodically
  useState(() => {
    const fetchNotifs = async () => {
      try {
        const headers = token ? { Authorization: `Bearer ${token}` } : {};
        const res = await axios.get(`${API}/notifications`, { headers });
        setNotifications(res.data.notifications || []);
        setUnreadCount(res.data.unread_count || 0);
      } catch { /* ignore */ }
    };
    fetchNotifs();
    const interval = setInterval(fetchNotifs, 60000);
    return () => clearInterval(interval);
  }, [token]);

  const markAllRead = async () => {
    if (!token) return;
    try {
      await axios.post(`${API}/notifications/read`, { notification_ids: [] }, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setUnreadCount(0);
      setNotifications(prev => prev.map(n => ({ ...n, read: true })));
    } catch { /* ignore */ }
  };

  const navLinks = [
    { to: "/", label: t("nav_home"), icon: Home },
    { to: "/e-learning", label: t("nav_academy"), icon: GraduationCap },
    { to: "/simulation", label: lang === "fr" ? "Simulation" : "Simulation", icon: Crosshair },
    { to: "/resources", label: t("nav_resources"), icon: BookOpen },
    { to: "/news", label: t("nav_news"), icon: Newspaper },
    ...(user ? [
      { to: "/contribute", label: t("nav_contribute"), icon: Plus },
      { to: "/dashboard", label: t("nav_dashboard"), icon: LayoutDashboard },
    ] : []),
    ...(user?.is_admin ? [
      { to: "/admin", label: "Admin", icon: Settings },
    ] : []),
  ];

  const isActive = (path) => location.pathname === path;

  return (
    <header data-testid="gamification-header" className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex h-14 items-center justify-between">
          {/* Logo + Nav */}
          <div className="flex items-center gap-6">
            <Link to="/" className="flex items-center gap-2 group" data-testid="logo-link">
              <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center transition-transform group-hover:scale-110">
                <Shield className="w-4.5 h-4.5 text-primary-foreground" />
              </div>
              <span className="font-bold text-base tracking-tight hidden sm:block" style={{ fontFamily: 'Outfit' }}>
                SecureLink
              </span>
            </Link>

            <nav className="hidden md:flex items-center gap-1">
              {navLinks.map(link => (
                <Link key={link.to} to={link.to} data-testid={`nav-${link.label.toLowerCase()}`}>
                  <Button
                    variant={isActive(link.to) ? "secondary" : "ghost"}
                    size="sm"
                    className="gap-2 rounded-full text-sm h-8"
                  >
                    <link.icon className="w-3.5 h-3.5" />
                    {link.label}
                  </Button>
                </Link>
              ))}
            </nav>
          </div>

          {/* Right side: Controls */}
          <div className="flex items-center gap-2">
            {/* Notification Bell */}
            <div className="relative">
              <Button
                variant="ghost"
                size="icon"
                className="rounded-full w-8 h-8 relative"
                onClick={() => { setShowNotifs(!showNotifs); if (!showNotifs && unreadCount > 0) markAllRead(); }}
                data-testid="notification-bell"
              >
                <Bell className="w-4 h-4" />
                {unreadCount > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full bg-red-500 text-white text-[10px] font-bold flex items-center justify-center" data-testid="notification-count">
                    {unreadCount > 9 ? "9+" : unreadCount}
                  </span>
                )}
              </Button>
              {showNotifs && (
                <div className="absolute right-0 top-10 w-80 max-h-96 overflow-y-auto bg-popover border rounded-xl shadow-lg z-50" data-testid="notification-panel">
                  <div className="p-3 border-b">
                    <p className="text-sm font-bold">{lang === "fr" ? "Alertes" : "Alerts"}</p>
                  </div>
                  {notifications.length === 0 ? (
                    <div className="p-4 text-center text-sm text-muted-foreground">
                      {lang === "fr" ? "Aucune alerte." : "No alerts."}
                    </div>
                  ) : (
                    <div className="divide-y">
                      {notifications.map(n => (
                        <div key={n.id} className={`p-3 ${!n.read ? "bg-primary/5" : ""}`}>
                          <div className="flex items-start gap-2">
                            <div className={`w-2 h-2 rounded-full mt-1.5 flex-shrink-0 ${
                              n.severity === "high" ? "bg-red-500" : n.severity === "medium" ? "bg-amber-500" : "bg-blue-500"
                            }`} />
                            <div>
                              <p className="text-xs font-medium">{lang === "fr" ? n.title_fr : n.title_en}</p>
                              <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5">
                                {lang === "fr" ? n.description_fr : n.description_en}
                              </p>
                              <p className="text-[10px] text-muted-foreground mt-1">{n.date}</p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Language toggle */}
            <Button variant="ghost" size="icon" onClick={toggleLang} className="rounded-full w-8 h-8" data-testid="language-toggle" aria-label={t("language")}>
              <span className="text-xs font-bold uppercase">{lang === "fr" ? "EN" : "FR"}</span>
            </Button>

            {/* Theme toggle */}
            <Button variant="ghost" size="icon" onClick={toggleTheme} className="rounded-full w-8 h-8" data-testid="theme-toggle" aria-label={theme === "dark" ? t("light_mode") : t("dark_mode")}>
              {theme === "dark" ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </Button>

            {/* User menu */}
            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm" className="rounded-full h-8 gap-2 px-3" data-testid="user-menu-trigger">
                    <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center">
                      <span className="text-xs font-bold text-primary">{user.username?.charAt(0).toUpperCase()}</span>
                    </div>
                    <span className="hidden sm:inline text-sm">{user.username}</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  <div className="px-3 py-2">
                    <p className="text-sm font-semibold">{user.username}</p>
                    <p className="text-xs text-muted-foreground">{user.email}</p>
                  </div>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link to="/dashboard" className="flex items-center gap-2">
                      <LayoutDashboard className="w-4 h-4" /> {t("nav_dashboard")}
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={logout} className="text-destructive" data-testid="logout-btn">
                    <LogOut className="w-4 h-4 mr-2" /> {t("nav_logout")}
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Link to="/login">
                <Button size="sm" className="rounded-full gap-2 h-8 text-sm" data-testid="login-nav-btn">
                  <User className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">{t("nav_login")}</span>
                </Button>
              </Link>
            )}

            {/* Mobile menu */}
            <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
              <SheetTrigger asChild className="md:hidden">
                <Button variant="ghost" size="icon" className="rounded-full w-8 h-8" data-testid="mobile-menu-trigger">
                  <Menu className="w-4 h-4" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-64">
                <div className="flex flex-col gap-3 mt-8">
                  {navLinks.map(link => (
                    <Link key={link.to} to={link.to} onClick={() => setMobileOpen(false)}>
                      <Button variant={isActive(link.to) ? "secondary" : "ghost"} className="w-full justify-start gap-3 h-10">
                        <link.icon className="w-4 h-4" />
                        {link.label}
                      </Button>
                    </Link>
                  ))}
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  );
}
