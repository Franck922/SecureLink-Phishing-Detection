import { useState, useEffect, useRef } from "react";
import { useAuth } from "../contexts/AuthContext";
import { useLanguage } from "../contexts/LanguageContext";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import {
  MessageCircle, X, Send, Shield, AlertTriangle, CheckCircle,
  XCircle, Link2, Zap, Lightbulb, Mail, Lock, Eye, ScanLine
} from "lucide-react";
import axios from "axios";

const API = `${process.env.REACT_APP_BACKEND_URL}/api`;

const TOPIC_ICONS = { mail: Mail, alert: AlertTriangle, lock: Lock, eye: Eye, scan: ScanLine };

const VERDICT_STYLES = {
  dangereux: { icon: XCircle, color: "text-red-500", bg: "bg-red-500/10", border: "border-red-500/30" },
  suspect: { icon: AlertTriangle, color: "text-amber-500", bg: "bg-amber-500/10", border: "border-amber-500/30" },
  normal: { icon: CheckCircle, color: "text-emerald-500", bg: "bg-emerald-500/10", border: "border-emerald-500/30" },
};

function AnalysisCard({ analysis, lang }) {
  const vs = VERDICT_STYLES[analysis.verdict] || VERDICT_STYLES.suspect;
  const VIcon = vs.icon;
  return (
    <div className={`rounded-xl border ${vs.border} ${vs.bg} p-3.5 mt-2.5 space-y-3.5`} data-testid="analysis-card">
      <div className="flex items-center gap-2">
        <VIcon className={`w-4 h-4 ${vs.color}`} />
        <span className={`font-bold text-sm ${vs.color}`}>
          {analysis.verdict === "dangereux" ? "Dangereux" : analysis.verdict === "suspect" ? "Suspect" : "Normal"}
        </span>
      </div>

      {analysis.summary && (
        <p className="text-xs text-muted-foreground leading-relaxed">{analysis.summary}</p>
      )}

      {analysis.red_flags?.length > 0 && (
        <div className="space-y-2">
          <p className="text-[11px] font-semibold text-muted-foreground">{lang === "fr" ? "Signaux d'alerte" : "Red flags"}</p>
          {analysis.red_flags.map((f, i) => (
            <div key={i} className="flex items-start gap-2 text-xs leading-relaxed">
              <XCircle className="w-3 h-3 text-red-400 mt-0.5 flex-shrink-0" />
              <span>{f}</span>
            </div>
          ))}
        </div>
      )}

      {analysis.techniques_detected?.length > 0 && (
        <div className="space-y-1.5">
          <p className="text-[11px] font-semibold text-muted-foreground">{lang === "fr" ? "Techniques utilisees" : "Techniques used"}</p>
          <div className="flex flex-wrap gap-1.5">
            {analysis.techniques_detected.map((t, i) => (
              <Badge key={i} variant="secondary" className="text-[10px]">{t}</Badge>
            ))}
          </div>
        </div>
      )}

      {analysis.urls_found?.length > 0 && (
        <div className="space-y-1.5">
          <p className="text-[11px] font-semibold text-muted-foreground flex items-center gap-1">
            <Link2 className="w-3 h-3" />{lang === "fr" ? "Liens detectes" : "Links found"}
          </p>
          {analysis.urls_found.map((u, i) => (
            <div key={i} className="text-[10px] font-mono bg-background/50 p-2 rounded break-all">{u}</div>
          ))}
        </div>
      )}

      {analysis.immediate_actions?.length > 0 && (
        <div className="space-y-2">
          <p className="text-[11px] font-semibold flex items-center gap-1">
            <Zap className="w-3 h-3 text-primary" />{lang === "fr" ? "Que faire maintenant" : "What to do now"}
          </p>
          {analysis.immediate_actions.map((a, i) => (
            <div key={i} className="flex items-start gap-2.5 text-xs leading-relaxed">
              <span className="w-4 h-4 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 text-[10px] font-bold text-primary mt-0.5">{i + 1}</span>
              <span>{a}</span>
            </div>
          ))}
        </div>
      )}

      {analysis.educational_tip && (
        <div className="flex items-start gap-2 text-xs bg-violet-500/5 p-2.5 rounded-lg border border-violet-500/10 leading-relaxed">
          <Lightbulb className="w-3.5 h-3.5 text-violet-500 mt-0.5 flex-shrink-0" />
          <span className="text-muted-foreground">{analysis.educational_tip}</span>
        </div>
      )}
    </div>
  );
}

export default function ChatWidget() {
  const { token } = useAuth();
  const { lang } = useLanguage();
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [sessionId, setSessionId] = useState(null);
  const [topics, setTopics] = useState([]);
  const scrollRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    axios.get(`${API}/assistant/topics`).then(r => setTopics(r.data.topics)).catch(() => {});
  }, []);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages]);

  useEffect(() => {
    if (open && inputRef.current) inputRef.current.focus();
  }, [open]);

  const sendMessage = async (text) => {
    if (!text.trim() || sending) return;
    const userMsg = { role: "user", text: text.trim() };
    setMessages(prev => [...prev, userMsg]);
    setInput("");
    setSending(true);

    try {
      const headers = token ? { Authorization: `Bearer ${token}` } : {};
      const res = await axios.post(`${API}/assistant/chat`, { message: text.trim(), session_id: sessionId }, { headers });
      const data = res.data;
      if (!sessionId) setSessionId(data.session_id);
      const botMsg = { role: "bot", text: data.response.message, analysis: data.response.is_analysis ? data.response.analysis : null };
      setMessages(prev => [...prev, botMsg]);
    } catch {
      setMessages(prev => [...prev, { role: "bot", text: lang === "fr" ? "Desole, une erreur est survenue. Reessayez." : "Sorry, an error occurred. Try again." }]);
    }
    setSending(false);
  };

  const handleSubmit = (e) => { e.preventDefault(); sendMessage(input); };
  const handleTopic = (topic) => { sendMessage(lang === "fr" ? topic.label_fr : topic.label_en); };
  const handleNewChat = () => { setMessages([]); setSessionId(null); };

  return (
    <>
      {/* Floating button */}
      <button
        onClick={() => setOpen(!open)}
        className={`fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full shadow-lg flex items-center justify-center transition-all duration-300 hover:scale-105 active:scale-95 ${
          open ? "bg-muted-foreground/80 hover:bg-muted-foreground" : "bg-gradient-to-br from-primary to-violet-600 hover:shadow-primary/40 hover:shadow-xl"
        }`}
        data-testid="chat-widget-toggle"
      >
        {open ? <X className="w-6 h-6 text-background" /> : <MessageCircle className="w-6 h-6 text-white" />}
      </button>

      {/* Chat panel */}
      {open && (
        <div
          className="fixed bottom-24 right-6 z-50 w-[380px] max-h-[560px] bg-background border rounded-2xl shadow-2xl flex flex-col overflow-hidden animate-slide-up"
          data-testid="chat-widget-panel"
        >
          {/* Header */}
          <div className="px-4 py-3 border-b bg-gradient-to-r from-primary/5 to-violet-500/5 flex items-center justify-between flex-shrink-0">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-violet-600 flex items-center justify-center">
                <Shield className="w-4 h-4 text-white" />
              </div>
              <div>
                <p className="font-bold text-sm" style={{ fontFamily: 'Outfit' }}>SecureBot</p>
                <p className="text-[10px] text-muted-foreground flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block" />
                  {lang === "fr" ? "En ligne" : "Online"}
                </p>
              </div>
            </div>
            {messages.length > 0 && (
              <Button variant="ghost" size="sm" className="text-[10px] h-6 px-2 rounded-full" onClick={handleNewChat} data-testid="new-chat-btn">
                {lang === "fr" ? "Nouveau" : "New"}
              </Button>
            )}
          </div>

          {/* Messages */}
          <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 py-3 space-y-3 min-h-0" data-testid="chat-messages">
            {messages.length === 0 ? (
              <div className="space-y-4">
                <div className="text-center py-3">
                  <Shield className="w-10 h-10 text-primary/20 mx-auto mb-2" />
                  <p className="text-sm font-medium" style={{ fontFamily: 'Outfit' }}>
                    {lang === "fr" ? "Bonjour ! Je suis SecureBot" : "Hi! I'm SecureBot"}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {lang === "fr" ? "Posez-moi vos questions sur la cybersecurite ou collez un message suspect." : "Ask me about cybersecurity or paste a suspicious message."}
                  </p>
                </div>
                <div className="space-y-1.5" data-testid="suggested-topics">
                  {topics.map(topic => {
                    const TIcon = TOPIC_ICONS[topic.icon] || Shield;
                    return (
                      <button
                        key={topic.id}
                        onClick={() => handleTopic(topic)}
                        className="w-full text-left flex items-center gap-2.5 p-2.5 rounded-xl border hover:bg-muted/50 transition-colors group"
                        data-testid={`topic-${topic.id}`}
                      >
                        <div className="w-7 h-7 rounded-lg bg-primary/5 flex items-center justify-center group-hover:bg-primary/10 transition-colors">
                          <TIcon className="w-3.5 h-3.5 text-primary" />
                        </div>
                        <span className="text-xs">{lang === "fr" ? topic.label_fr : topic.label_en}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            ) : (
              messages.map((msg, i) => (
                <div key={i} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
                  <div className={`max-w-[85%] ${msg.role === "user"
                    ? "bg-primary text-primary-foreground rounded-2xl rounded-br-md px-3 py-2"
                    : "bg-muted rounded-2xl rounded-bl-md px-3 py-2"
                  }`} data-testid={`chat-msg-${i}`}>
                    <p className="text-sm whitespace-pre-wrap">{msg.text}</p>
                    {msg.analysis && <AnalysisCard analysis={msg.analysis} lang={lang} />}
                  </div>
                </div>
              ))
            )}
            {sending && (
              <div className="flex justify-start">
                <div className="bg-muted rounded-2xl rounded-bl-md px-4 py-3">
                  <div className="flex items-center gap-1.5">
                    <div className="w-2 h-2 rounded-full bg-primary/40 animate-bounce" style={{ animationDelay: "0ms" }} />
                    <div className="w-2 h-2 rounded-full bg-primary/40 animate-bounce" style={{ animationDelay: "150ms" }} />
                    <div className="w-2 h-2 rounded-full bg-primary/40 animate-bounce" style={{ animationDelay: "300ms" }} />
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Input */}
          <form onSubmit={handleSubmit} className="px-3 py-2.5 border-t flex-shrink-0 bg-background" data-testid="chat-input-form">
            <div className="flex items-end gap-2">
              <textarea
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); handleSubmit(e); } }}
                placeholder={lang === "fr" ? "Ecrivez votre message..." : "Type your message..."}
                rows={1}
                className="flex-1 bg-muted/30 border border-border rounded-xl px-3 py-2 text-sm resize-none focus:outline-none focus:ring-1 focus:ring-primary/30 max-h-24 overflow-y-auto"
                disabled={sending}
                data-testid="chat-input"
                style={{ minHeight: '36px' }}
              />
              <Button
                type="submit"
                size="sm"
                disabled={!input.trim() || sending}
                className="rounded-xl h-9 w-9 p-0 flex-shrink-0"
                data-testid="chat-send-btn"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </form>
        </div>
      )}
    </>
  );
}
