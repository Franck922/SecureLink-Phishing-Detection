import { useState } from "react";
import { useLanguage } from "../contexts/LanguageContext";
import { Button } from "./ui/button";
import { Shield, Search, MessageCircle, GraduationCap, ChevronRight, Sparkles } from "lucide-react";
import axios from "axios";

const API = `${process.env.REACT_APP_BACKEND_URL}/api`;

const STEPS = [
  {
    id: "welcome",
    icon: Shield,
    gradient: "from-primary via-violet-600 to-purple-700",
    title_fr: "Bienvenue sur SecureLink",
    title_en: "Welcome to SecureLink",
    subtitle_fr: "Vous avez recu un lien suspect ? On verifie pour vous.",
    subtitle_en: "Received a suspicious link? We'll check it for you.",
    description_fr: "SecureLink analyse les liens en quelques secondes et vous dit clairement s'ils sont fiables ou dangereux. Pas besoin d'etre un expert.",
    description_en: "SecureLink analyzes links in seconds and clearly tells you if they're safe or dangerous. No expertise needed.",
  },
  {
    id: "analyze",
    icon: Search,
    gradient: "from-emerald-600 via-teal-600 to-cyan-700",
    title_fr: "Collez, analysez, decidez",
    title_en: "Paste, analyze, decide",
    subtitle_fr: "Un verdict clair en quelques secondes",
    subtitle_en: "A clear verdict in seconds",
    description_fr: "Copiez-collez le lien suspect dans la barre d'analyse. Notre moteur combine intelligence artificielle, bases de donnees mondiales et verification en temps reel pour vous donner un verdict : Sur, Prudence ou Danger.",
    description_en: "Paste the suspicious link in the analysis bar. Our engine combines artificial intelligence, global databases, and real-time verification to give you a verdict: Safe, Caution, or Danger.",
  },
  {
    id: "chatbot",
    icon: MessageCircle,
    gradient: "from-blue-600 via-indigo-600 to-violet-700",
    title_fr: "Une question ? Demandez a SecureBot",
    title_en: "Got a question? Ask SecureBot",
    subtitle_fr: "Votre assistant IA en bas a droite de chaque page",
    subtitle_en: "Your AI assistant at the bottom right of every page",
    description_fr: "Vous ne comprenez pas un resultat ? Vous avez recu un email bizarre ? Cliquez sur la bulle et posez votre question. SecureBot vous repond simplement, sans jargon.",
    description_en: "Don't understand a result? Got a weird email? Click the bubble and ask your question. SecureBot answers simply, no jargon.",
  },
  {
    id: "learn",
    icon: GraduationCap,
    gradient: "from-amber-600 via-orange-600 to-red-600",
    title_fr: "Progressez a votre rythme",
    title_en: "Learn at your own pace",
    subtitle_fr: "Gagnez de l'experience, debloquez des badges",
    subtitle_en: "Earn experience, unlock badges",
    description_fr: "Chaque analyse vous rapporte de l'experience. Explorez les modules d'apprentissage, testez vos reflexes avec les simulations et devenez plus vigilant au quotidien.",
    description_en: "Every analysis earns you experience. Explore learning modules, test your reflexes with simulations, and become more vigilant every day.",
  },
];

export default function OnboardingModal({ token, onComplete }) {
  const { lang } = useLanguage();
  const [step, setStep] = useState(0);
  const [exiting, setExiting] = useState(false);
  const current = STEPS[step];
  const isLast = step === STEPS.length - 1;
  const Icon = current.icon;

  const handleNext = () => {
    if (isLast) {
      handleFinish();
    } else {
      setExiting(true);
      setTimeout(() => {
        setStep(s => s + 1);
        setExiting(false);
      }, 250);
    }
  };

  const handleSkip = () => handleFinish();

  const handleFinish = async () => {
    try {
      await axios.post(`${API}/user/onboarding/complete`, {}, { headers: { Authorization: `Bearer ${token}` } });
    } catch { /* ignore */ }
    onComplete();
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-background/95 backdrop-blur-sm" data-testid="onboarding-modal">
      <div className={`w-full max-w-lg mx-4 transition-all duration-300 ${exiting ? "opacity-0 translate-x-8" : "opacity-100 translate-x-0"}`}>

        {/* Card */}
        <div className="relative rounded-2xl overflow-hidden shadow-2xl border bg-background">
          {/* Gradient header */}
          <div className={`bg-gradient-to-br ${current.gradient} px-8 pt-12 pb-16 text-white`}>
            <div className="flex items-center justify-between mb-8">
              {/* Step indicators */}
              <div className="flex gap-1.5">
                {STEPS.map((_, i) => (
                  <div
                    key={i}
                    className={`h-1 rounded-full transition-all duration-300 ${i === step ? "w-8 bg-white" : i < step ? "w-4 bg-white/60" : "w-4 bg-white/20"}`}
                    data-testid={`step-indicator-${i}`}
                  />
                ))}
              </div>
              {!isLast && (
                <button onClick={handleSkip} className="text-white/60 text-xs hover:text-white transition-colors" data-testid="skip-btn">
                  {lang === "fr" ? "Passer" : "Skip"}
                </button>
              )}
            </div>

            <div className="w-14 h-14 rounded-2xl bg-white/10 backdrop-blur-sm flex items-center justify-center mb-5">
              <Icon className="w-7 h-7 text-white" />
            </div>

            <h2 className="text-2xl font-bold mb-2" style={{ fontFamily: 'Outfit' }} data-testid="onboarding-title">
              {lang === "fr" ? current.title_fr : current.title_en}
            </h2>
            <p className="text-white/80 text-sm">
              {lang === "fr" ? current.subtitle_fr : current.subtitle_en}
            </p>
          </div>

          {/* Content */}
          <div className="px-8 py-6">
            <p className="text-sm text-muted-foreground leading-relaxed mb-6" data-testid="onboarding-description">
              {lang === "fr" ? current.description_fr : current.description_en}
            </p>

            <Button
              onClick={handleNext}
              className="w-full rounded-full h-12 font-bold text-sm gap-2"
              data-testid="onboarding-next-btn"
            >
              {isLast ? (
                <>
                  <Sparkles className="w-4 h-4" />
                  {lang === "fr" ? "C'est parti !" : "Let's go!"}
                </>
              ) : (
                <>
                  {lang === "fr" ? "Suivant" : "Next"}
                  <ChevronRight className="w-4 h-4" />
                </>
              )}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
