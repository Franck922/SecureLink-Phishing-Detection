import "./App.css";
import { useState } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider, useAuth } from "./contexts/AuthContext";
import { ThemeProvider } from "./contexts/ThemeContext";
import { LanguageProvider } from "./contexts/LanguageContext";
import { Toaster } from "./components/ui/sonner";
import GamificationHeader from "./components/GamificationHeader";
import OnboardingModal from "./components/OnboardingModal";
import HomePage from "./pages/HomePage";
import ResultPage from "./pages/ResultPage";
import LoginPage from "./pages/LoginPage";
import DashboardPage from "./pages/DashboardPage";
import AcademyPage from "./pages/AcademyPage";
import LeaderboardPage from "./pages/LeaderboardPage";
import ResourcesPage from "./pages/ResourcesPage";
import NewsPage from "./pages/NewsPage";
import ContributePage from "./pages/ContributePage";
import AdminPage from "./pages/AdminPage";
import SimulationPage from "./pages/SimulationPage";
import ChatWidget from "./components/ChatWidget";

function AppContent() {
  const { user, token, refreshUser } = useAuth();
  const [onboardingDismissed, setOnboardingDismissed] = useState(false);
  const showOnboarding = user && token && !user.onboarding_completed && !onboardingDismissed;

  const handleOnboardingComplete = () => {
    setOnboardingDismissed(true);
    refreshUser();
  };

  return (
    <>
      <GamificationHeader />
      <main>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/result" element={<ResultPage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/dashboard" element={<DashboardPage />} />
          <Route path="/e-learning" element={<AcademyPage />} />
          <Route path="/leaderboard" element={<LeaderboardPage />} />
          <Route path="/resources" element={<ResourcesPage />} />
          <Route path="/news" element={<NewsPage />} />
          <Route path="/contribute" element={<ContributePage />} />
          <Route path="/admin" element={<AdminPage />} />
          <Route path="/simulation" element={<SimulationPage />} />
        </Routes>
      </main>
      <ChatWidget />
      {showOnboarding && <OnboardingModal token={token} onComplete={handleOnboardingComplete} />}
      <Toaster />
    </>
  );
}

function App() {
  return (
    <ThemeProvider>
      <LanguageProvider>
        <AuthProvider>
          <BrowserRouter>
            <div className="min-h-screen bg-background text-foreground transition-colors duration-300">
              <AppContent />
            </div>
          </BrowserRouter>
        </AuthProvider>
      </LanguageProvider>
    </ThemeProvider>
  );
}

export default App;
