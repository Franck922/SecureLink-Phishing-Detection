import { useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { useLanguage } from "../contexts/LanguageContext";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { Shield, Mail, Lock, User, ArrowRight, AlertCircle } from "lucide-react";

export default function LoginPage() {
  const { login, register } = useAuth();
  const { t, lang } = useLanguage();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [mode, setMode] = useState(searchParams.get("mode") === "register" ? "register" : "login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [username, setUsername] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      if (mode === "login") {
        await login(email, password);
      } else {
        await register(username, email, password, lang);
      }
      navigate("/dashboard");
    } catch (err) {
      const errData = err.response?.data;
      let errMsg = "";
      if (errData?.detail) {
        if (Array.isArray(errData.detail)) {
          errMsg = errData.detail.map(d => d.msg?.replace("Value error, ", "") || d.msg).join(". ");
        } else {
          errMsg = errData.detail;
        }
      } else {
        errMsg = mode === "login" ? t("login_error") : t("register_error");
      }
      setError(errMsg);
    }
    setLoading(false);
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center py-12 px-4" data-testid="login-page">
      <div className="w-full max-w-md animate-scale-pop">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-2xl bg-primary flex items-center justify-center mx-auto mb-4">
            <Shield className="w-8 h-8 text-primary-foreground" />
          </div>
          <h1 className="text-2xl font-bold" style={{ fontFamily: 'Outfit' }}>SecureLink</h1>
          <p className="text-sm text-muted-foreground mt-1">{t("tagline")}</p>
        </div>

        <Card className="rounded-2xl">
          <CardContent className="p-6 sm:p-8">
            <Tabs value={mode} onValueChange={setMode}>
              <TabsList className="grid w-full grid-cols-2 mb-6 rounded-full" data-testid="auth-tabs">
                <TabsTrigger value="login" className="rounded-full" data-testid="login-tab">{t("login_title")}</TabsTrigger>
                <TabsTrigger value="register" className="rounded-full" data-testid="register-tab">{t("register_title")}</TabsTrigger>
              </TabsList>

              <form onSubmit={handleSubmit}>
                <TabsContent value="register" className="space-y-4 mt-0">
                  <div>
                    <Label htmlFor="username" className="text-sm">{t("username_label")}</Label>
                    <div className="relative mt-1.5">
                      <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                      <Input id="username" value={username} onChange={(e) => setUsername(e.target.value)}
                        placeholder={lang === "fr" ? "Votre pseudo" : "Your username"}
                        className="pl-10 rounded-full" data-testid="register-username-input" />
                    </div>
                  </div>
                </TabsContent>

                <div className="space-y-4">
                  <div>
                    <Label htmlFor="email" className="text-sm">{t("email")}</Label>
                    <div className="relative mt-1.5">
                      <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                      <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)}
                        placeholder="nom@exemple.com" className="pl-10 rounded-full" data-testid="email-input" />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="password" className="text-sm">{t("password")}</Label>
                    <div className="relative mt-1.5">
                      <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                      <Input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)}
                        placeholder="********" className="pl-10 rounded-full" data-testid="password-input" />
                    </div>
                    {mode === "register" && (
                      <p className="text-[11px] text-muted-foreground mt-1.5 ml-1">
                        {lang === "fr" ? "8 caracteres min., 1 majuscule, 1 chiffre" : "8 chars min., 1 uppercase, 1 digit"}
                      </p>
                    )}
                  </div>
                </div>

                {error && (
                  <div className="flex items-center gap-2 text-destructive text-sm mt-4" data-testid="auth-error">
                    <AlertCircle className="w-4 h-4" /> {error}
                  </div>
                )}

                <Button type="submit" disabled={loading} className="w-full mt-6 rounded-full font-bold gap-2 h-12" data-testid="auth-submit-btn">
                  {loading ? (
                    <span className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
                  ) : (
                    <>
                      {mode === "login" ? t("login_btn") : t("register_btn")}
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </Button>
              </form>
            </Tabs>

            <p className="text-center text-sm text-muted-foreground mt-6">
              {mode === "login" ? t("no_account") : t("have_account")}
              <button onClick={() => setMode(mode === "login" ? "register" : "login")}
                className="text-primary hover:underline ml-1 font-medium" data-testid="toggle-auth-mode">
                {mode === "login" ? t("register_btn") : t("login_btn")}
              </button>
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
