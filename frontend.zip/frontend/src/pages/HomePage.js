import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useLanguage } from "../contexts/LanguageContext";
import { useAuth } from "../contexts/AuthContext";
import { Button } from "../components/ui/button";
import { Card, CardContent } from "../components/ui/card";
import { Input } from "../components/ui/input";
import { Shield, Search, ShieldCheck, ArrowRight, AlertTriangle, ChevronDown, Globe, Lock, Clock, CheckCircle, FileSearch } from "lucide-react";
import axios from "axios";

const API = `${process.env.REACT_APP_BACKEND_URL}/api`;

function AccordionItem({ step, title, description, icon: Icon, color, isOpen, onToggle, testId }) {
  return (
    <div className="border rounded-xl overflow-hidden transition-all" data-testid={testId}>
      <button
        onClick={onToggle}
        className="w-full flex items-center gap-4 p-5 text-left hover:bg-muted/50 transition-colors"
      >
        <div className={`w-10 h-10 rounded-xl ${color} flex items-center justify-center flex-shrink-0`}>
          <Icon className="w-5 h-5 text-white" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
              {step}
            </span>
          </div>
          <h3 className="text-sm font-bold mt-0.5" style={{ fontFamily: 'Outfit' }}>{title}</h3>
        </div>
        <ChevronDown className={`w-4 h-4 text-muted-foreground transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      {isOpen && (
        <div className="px-5 pb-5 pt-0">
          <div className="pl-14 space-y-2">
            {description.map((line, i) => (
              <div key={i} className="flex items-start gap-2.5">
                <CheckCircle className="w-3.5 h-3.5 text-primary flex-shrink-0 mt-0.5" />
                <p className="text-sm text-muted-foreground leading-relaxed">{line}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export default function HomePage() {
  const { t, lang } = useLanguage();
  const { user, token } = useAuth();
  const navigate = useNavigate();
  const [url, setUrl] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [openStep, setOpenStep] = useState(null);

  const handleAnalyze = async (e) => {
    e.preventDefault();
    if (!url.trim()) return;
    setLoading(true);
    setError("");
    try {
      const headers = token ? { Authorization: `Bearer ${token}` } : {};
      const res = await axios.post(`${API}/analyze`, { url: url.trim() }, { headers });
      navigate("/result", { state: { result: res.data, url: url.trim() } });
    } catch (err) {
      setError(err.response?.data?.detail || t("error"));
    } finally {
      setLoading(false);
    }
  };

  const steps = lang === "fr" ? [
    {
      step: "Etape 1",
      title: "Collez le lien suspect",
      icon: Search,
      color: "bg-primary",
      description: [
        "Copiez-collez simplement l'URL que vous souhaitez verifier dans la barre d'analyse ci-dessus.",
        "Aucune installation necessaire. Votre lien n'est jamais partage avec des tiers.",
      ],
    },
    {
      step: "Etape 2",
      title: "On verifie tout pour vous",
      icon: ShieldCheck,
      color: "bg-teal-500",
      description: [
        "Notre moteur croise plusieurs sources en temps reel : intelligence artificielle, bases de donnees de menaces, verification du certificat de securite et de l'identite du site.",
        "Si le site imite un site connu (par ex. « g00gle.com »), nous le detectons automatiquement et vous montrons la difference.",
      ],
    },
    {
      step: "Etape 3",
      title: "Vous recevez un verdict clair",
      icon: FileSearch,
      color: "bg-emerald-500",
      description: [
        "En quelques secondes, vous obtenez un resultat simple : Sur, Prudence ou Danger, avec une explication en langage courant.",
        "En cas de doute, SecureBot (notre assistant IA) est disponible pour vous aider a comprendre le resultat.",
      ],
    },
  ] : [
    {
      step: "Step 1",
      title: "Paste the suspicious link",
      icon: Search,
      color: "bg-primary",
      description: [
        "Simply copy and paste the URL you want to check into the analysis bar above.",
        "No installation needed. Your link is never shared with third parties.",
      ],
    },
    {
      step: "Step 2",
      title: "We check everything for you",
      icon: ShieldCheck,
      color: "bg-teal-500",
      description: [
        "Our engine cross-references multiple sources in real time: artificial intelligence, threat databases, security certificate and site identity verification.",
        "If the site mimics a known brand (e.g. 'g00gle.com'), we automatically detect it and show you the difference.",
      ],
    },
    {
      step: "Step 3",
      title: "You get a clear verdict",
      icon: FileSearch,
      color: "bg-emerald-500",
      description: [
        "In seconds, you get a simple result: Safe, Caution, or Danger, with a plain-language explanation.",
        "If in doubt, SecureBot (our AI assistant) is available to help you understand the result.",
      ],
    },
  ];

  return (
    <div className="min-h-[calc(100vh-4rem)]">
      {/* Hero Section */}
      <section className="relative overflow-hidden pt-16 pb-20 sm:pt-24 sm:pb-28" data-testid="hero-section">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-background to-background" />
        <div className="absolute top-20 right-10 w-64 h-64 rounded-full bg-primary/5 blur-3xl" />
        <div className="absolute bottom-10 left-10 w-48 h-48 rounded-full bg-safe/5 blur-3xl" />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-primary/10 text-primary text-sm font-medium mb-8 animate-scale-pop">
              <Shield className="w-4 h-4" />
              {t("tagline")}
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight mb-6 animate-slide-up" style={{ fontFamily: 'Outfit' }} data-testid="hero-title">
              {t("hero_title")}
            </h1>

            <p className="text-base sm:text-lg text-muted-foreground mb-10 max-w-2xl mx-auto animate-slide-up stagger-1" data-testid="hero-subtitle">
              {t("hero_subtitle")}
            </p>

            {/* URL Analysis Form */}
            <form onSubmit={handleAnalyze} className="max-w-2xl mx-auto animate-slide-up stagger-2" data-testid="url-analysis-form">
              <div className="flex gap-3">
                <div className="relative flex-1">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    data-testid="url-input"
                    value={url}
                    onChange={(e) => setUrl(e.target.value)}
                    placeholder={t("url_placeholder")}
                    className="pl-12 h-14 rounded-full border-2 text-base font-mono focus:border-primary focus:ring-4 focus:ring-primary/20"
                  />
                </div>
                <Button
                  type="submit"
                  disabled={loading || !url.trim()}
                  className="h-14 px-8 rounded-full font-bold text-base transition-all hover:scale-105 active:scale-95"
                  data-testid="analyze-btn"
                >
                  {loading ? (
                    <span className="flex items-center gap-2">
                      <span className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
                      {t("analyzing")}
                    </span>
                  ) : (
                    <span className="flex items-center gap-2">
                      <Shield className="w-5 h-5" />
                      {t("analyze_btn")}
                    </span>
                  )}
                </Button>
              </div>
              {error && (
                <p className="text-destructive text-sm mt-3 flex items-center gap-2" data-testid="analysis-error">
                  <AlertTriangle className="w-4 h-4" /> {error}
                </p>
              )}
            </form>

            <p className="text-sm text-muted-foreground mt-4 animate-slide-up stagger-3">
              {t("no_account_needed")}
            </p>
          </div>
        </div>
      </section>

      {/* How it Works — Accordion */}
      <section className="py-16 sm:py-20" data-testid="features-section">
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl sm:text-3xl font-bold text-center mb-4" style={{ fontFamily: 'Outfit' }}>
            {t("features_title")}
          </h2>
          <p className="text-center text-muted-foreground text-sm mb-10 max-w-lg mx-auto">
            {lang === "fr"
              ? "Découvrez en détail comment SecureLink analyse et vérifie chaque lien pour votre sécurité."
              : "Discover in detail how SecureLink analyzes and verifies each link for your security."}
          </p>

          <div className="space-y-3">
            {steps.map((step, i) => (
              <AccordionItem
                key={i}
                step={step.step}
                title={step.title}
                description={step.description}
                icon={step.icon}
                color={step.color}
                isOpen={openStep === i}
                onToggle={() => setOpenStep(openStep === i ? null : i)}
                testId={`accordion-step-${i}`}
              />
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      {!user && (
        <section className="py-16 sm:py-20" data-testid="cta-section">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <Card className="rounded-2xl border-primary/20 overflow-hidden">
              <CardContent className="p-8 sm:p-12 text-center">
                <h2 className="text-xl sm:text-2xl font-bold mb-3" style={{ fontFamily: 'Outfit' }}>
                  {lang === "fr" ? "Créez un compte pour sauvegarder vos analyses" : "Create an account to save your analyses"}
                </h2>
                <p className="text-muted-foreground mb-6 max-w-xl mx-auto text-sm">
                  {lang === "fr"
                    ? "Gardez un historique de vos vérifications et apprenez à reconnaître le phishing à votre rythme."
                    : "Keep track of your checks and learn to recognize phishing at your own pace."}
                </p>
                <Button onClick={() => navigate("/login?mode=register")} className="rounded-full gap-2 font-bold" data-testid="cta-register-btn">
                  {t("register_btn")} <ArrowRight className="w-4 h-4" />
                </Button>
              </CardContent>
            </Card>
          </div>
        </section>
      )}
    </div>
  );
}
