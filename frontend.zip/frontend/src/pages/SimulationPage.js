import { useState, useEffect, useCallback } from "react";
import { useLanguage } from "../contexts/LanguageContext";
import { useAuth } from "../contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { Progress } from "../components/ui/progress";
import {
  Mail, ShieldCheck, ShieldX, AlertTriangle, CheckCircle, XCircle,
  ArrowRight, RotateCcw, Trophy, Zap, User, ChevronDown, ChevronUp
} from "lucide-react";
import axios from "axios";

const API = `${process.env.REACT_APP_BACKEND_URL}/api`;

export default function SimulationPage() {
  const { lang } = useLanguage();
  const { token } = useAuth();
  const [scenarios, setScenarios] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answer, setAnswer] = useState(null); // null = not answered, object = result
  const [score, setScore] = useState({ correct: 0, total: 0 });
  const [loading, setLoading] = useState(true);
  const [showBody, setShowBody] = useState(true);
  const [difficulty, setDifficulty] = useState(null);
  const [gameOver, setGameOver] = useState(false);
  const [stats, setStats] = useState(null);

  const fetchScenarios = useCallback(async () => {
    setLoading(true);
    setGameOver(false);
    setCurrentIndex(0);
    setScore({ correct: 0, total: 0 });
    setAnswer(null);
    try {
      const params = difficulty ? `?count=5&difficulty=${difficulty}` : "?count=5";
      const res = await axios.get(`${API}/simulation/scenarios${params}`);
      setScenarios(res.data.scenarios || []);
    } catch { /* ignore */ }
    setLoading(false);
  }, [difficulty]);

  const fetchStats = useCallback(async () => {
    if (!token) return;
    try {
      const res = await axios.get(`${API}/simulation/stats`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setStats(res.data);
    } catch { /* ignore */ }
  }, [token]);

  useEffect(() => { fetchScenarios(); fetchStats(); }, [fetchScenarios, fetchStats]);

  const handleAnswer = async (userThinks) => {
    const scenario = scenarios[currentIndex];
    try {
      const headers = token ? { Authorization: `Bearer ${token}` } : {};
      const res = await axios.post(`${API}/simulation/answer`, {
        scenario_id: scenario.id,
        user_answer: userThinks,
      }, { headers });
      setAnswer(res.data);
      setScore(prev => ({
        correct: prev.correct + (res.data.correct ? 1 : 0),
        total: prev.total + 1,
      }));
    } catch { /* ignore */ }
  };

  const nextScenario = () => {
    if (currentIndex + 1 >= scenarios.length) {
      setGameOver(true);
    } else {
      setCurrentIndex(prev => prev + 1);
      setAnswer(null);
      setShowBody(true);
    }
  };

  const current = scenarios[currentIndex];

  if (loading) return (
    <div className="flex items-center justify-center min-h-[50vh]">
      <div className="w-8 h-8 border-4 border-primary/30 border-t-primary rounded-full animate-spin" />
    </div>
  );

  return (
    <div className="min-h-[calc(100vh-4rem)] py-8 sm:py-12" data-testid="simulation-page">
      <div className="max-w-3xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6 animate-slide-up">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold" style={{ fontFamily: 'Outfit' }} data-testid="simulation-title">
              {lang === "fr" ? "Simulation Phishing" : "Phishing Simulation"}
            </h1>
            <p className="text-muted-foreground text-sm mt-1">
              {lang === "fr"
                ? "Identifiez les faux emails parmi les vrais"
                : "Identify fake emails among real ones"}
            </p>
          </div>
          {stats && (
            <div className="text-right">
              <p className="text-lg font-bold">{stats.accuracy}%</p>
              <p className="text-xs text-muted-foreground">{stats.total_attempts} {lang === "fr" ? "essais" : "attempts"}</p>
            </div>
          )}
        </div>

        {/* Difficulty selector */}
        <div className="flex gap-2 mb-6 animate-slide-up stagger-1">
          {[
            { val: null, label: lang === "fr" ? "Tous" : "All" },
            { val: 1, label: lang === "fr" ? "Facile" : "Easy" },
            { val: 2, label: lang === "fr" ? "Moyen" : "Medium" },
            { val: 3, label: lang === "fr" ? "Difficile" : "Hard" },
          ].map(d => (
            <Button
              key={String(d.val)}
              variant={difficulty === d.val ? "secondary" : "ghost"}
              size="sm"
              className="rounded-full text-xs"
              onClick={() => setDifficulty(d.val)}
              data-testid={`difficulty-${d.val || "all"}`}
            >
              {d.label}
            </Button>
          ))}
        </div>

        {gameOver ? (
          /* Game Over Screen */
          <Card className="rounded-2xl border-2 animate-scale-pop" data-testid="game-over-card">
            <CardContent className="p-8 sm:p-10 text-center">
              <Trophy className="w-16 h-16 text-amber-500 mx-auto mb-4" />
              <h2 className="text-2xl font-bold mb-2" style={{ fontFamily: 'Outfit' }}>
                {lang === "fr" ? "Session terminee !" : "Session complete!"}
              </h2>
              <p className="text-4xl font-bold text-primary mb-2">
                {score.correct}/{score.total}
              </p>
              <p className="text-muted-foreground mb-6">
                {score.correct === score.total
                  ? (lang === "fr" ? "Score parfait ! Vous etes un expert !" : "Perfect score! You're an expert!")
                  : score.correct >= score.total * 0.6
                    ? (lang === "fr" ? "Bien joue ! Continuez a vous entrainer." : "Well done! Keep practicing.")
                    : (lang === "fr" ? "Continuez a apprendre, vous allez progresser !" : "Keep learning, you'll improve!")}
              </p>
              <Button onClick={fetchScenarios} className="rounded-full gap-2" data-testid="restart-simulation-btn">
                <RotateCcw className="w-4 h-4" />
                {lang === "fr" ? "Rejouer" : "Play again"}
              </Button>
            </CardContent>
          </Card>
        ) : current ? (
          <>
            {/* Progress */}
            <div className="mb-4 animate-slide-up stagger-2">
              <div className="flex items-center justify-between text-xs text-muted-foreground mb-1">
                <span>Email {currentIndex + 1}/{scenarios.length}</span>
                <span>{score.correct} {lang === "fr" ? "correct(s)" : "correct"}</span>
              </div>
              <Progress value={((currentIndex + (answer ? 1 : 0)) / scenarios.length) * 100} className="h-1.5" />
            </div>

            {/* Email Card */}
            <Card className="rounded-2xl border-2 mb-4 animate-slide-up stagger-3" data-testid="email-card">
              <CardHeader className="pb-3 border-b">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center flex-shrink-0">
                    <User className="w-5 h-5 text-muted-foreground" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className="text-sm font-bold">{current.sender_name}</span>
                      <Badge variant="outline" className="text-xs">
                        {lang === "fr" ? `Niveau ${current.difficulty}` : `Level ${current.difficulty}`}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground font-mono truncate" data-testid="email-sender">
                      {current.sender_email}
                    </p>
                    <p className="text-sm font-medium mt-2" data-testid="email-subject">
                      {lang === "fr" ? current.subject_fr : current.subject_en}
                    </p>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-4">
                <button
                  className="flex items-center gap-2 text-xs text-muted-foreground mb-3 hover:text-foreground transition-colors"
                  onClick={() => setShowBody(!showBody)}
                >
                  {showBody ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                  {showBody ? (lang === "fr" ? "Masquer le contenu" : "Hide content") : (lang === "fr" ? "Afficher le contenu" : "Show content")}
                </button>
                {showBody && (
                  <div className="text-sm whitespace-pre-line bg-muted/50 rounded-xl p-4 font-mono text-xs leading-relaxed" data-testid="email-body">
                    {lang === "fr" ? current.body_fr : current.body_en}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Answer Buttons or Result */}
            {!answer ? (
              <div className="flex gap-3 animate-slide-up stagger-4" data-testid="answer-buttons">
                <Button
                  onClick={() => handleAnswer(true)}
                  variant="outline"
                  className="flex-1 h-14 rounded-xl gap-2 border-2 border-red-200 dark:border-red-800 hover:bg-red-50 dark:hover:bg-red-950/30 text-red-700 dark:text-red-400"
                  data-testid="answer-phishing-btn"
                >
                  <ShieldX className="w-5 h-5" />
                  <span className="font-bold">{lang === "fr" ? "Phishing !" : "Phishing!"}</span>
                </Button>
                <Button
                  onClick={() => handleAnswer(false)}
                  variant="outline"
                  className="flex-1 h-14 rounded-xl gap-2 border-2 border-emerald-200 dark:border-emerald-800 hover:bg-emerald-50 dark:hover:bg-emerald-950/30 text-emerald-700 dark:text-emerald-400"
                  data-testid="answer-legit-btn"
                >
                  <ShieldCheck className="w-5 h-5" />
                  <span className="font-bold">{lang === "fr" ? "Legitime" : "Legitimate"}</span>
                </Button>
              </div>
            ) : (
              <div className="space-y-4 animate-scale-pop" data-testid="answer-result">
                {/* Result banner */}
                <Card className={`rounded-xl border-2 ${answer.correct
                  ? "border-emerald-200 dark:border-emerald-800 bg-emerald-50 dark:bg-emerald-950/30"
                  : "border-red-200 dark:border-red-800 bg-red-50 dark:bg-red-950/30"
                }`}>
                  <CardContent className="p-5 flex items-center gap-4">
                    {answer.correct
                      ? <CheckCircle className="w-8 h-8 text-emerald-500 flex-shrink-0" />
                      : <XCircle className="w-8 h-8 text-red-500 flex-shrink-0" />
                    }
                    <div>
                      <p className={`font-bold ${answer.correct ? "text-emerald-700 dark:text-emerald-400" : "text-red-700 dark:text-red-400"}`}>
                        {answer.correct
                          ? (lang === "fr" ? "Bonne reponse !" : "Correct!")
                          : (lang === "fr" ? "Mauvaise reponse" : "Incorrect")
                        }
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {lang === "fr"
                          ? `Cet email est ${answer.is_phishing ? "un phishing" : "legitime"}.`
                          : `This email is ${answer.is_phishing ? "phishing" : "legitimate"}.`
                        }
                      </p>
                      {answer.xp_earned && (
                        <p className="text-xs text-xp mt-1 flex items-center gap-1">
                          <Zap className="w-3 h-3" /> +{answer.xp_earned} XP
                        </p>
                      )}
                    </div>
                  </CardContent>
                </Card>

                {/* Indicators */}
                <Card className="rounded-xl">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm flex items-center gap-2" style={{ fontFamily: 'Outfit' }}>
                      <AlertTriangle className="w-4 h-4 text-amber-500" />
                      {lang === "fr" ? "Indices a reperer" : "Clues to spot"}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    {(lang === "fr" ? answer.indicators_fr : answer.indicators_en)?.map((indicator, i) => (
                      <div key={i} className="flex items-start gap-3 p-2.5 rounded-lg bg-muted/50">
                        <div className="w-5 h-5 rounded-full bg-primary/10 text-primary flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5">
                          {i + 1}
                        </div>
                        <p className="text-sm">{indicator}</p>
                      </div>
                    ))}
                  </CardContent>
                </Card>

                {/* Next button */}
                <Button onClick={nextScenario} className="w-full rounded-full gap-2 h-12" data-testid="next-scenario-btn">
                  {currentIndex + 1 >= scenarios.length
                    ? (lang === "fr" ? "Voir les resultats" : "See results")
                    : (lang === "fr" ? "Email suivant" : "Next email")
                  }
                  <ArrowRight className="w-4 h-4" />
                </Button>
              </div>
            )}
          </>
        ) : (
          <Card className="rounded-xl">
            <CardContent className="p-8 text-center">
              <Mail className="w-8 h-8 text-muted-foreground mx-auto mb-3" />
              <p className="text-muted-foreground text-sm">
                {lang === "fr" ? "Aucun scenario disponible." : "No scenarios available."}
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
