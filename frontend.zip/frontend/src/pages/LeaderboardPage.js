import { useState, useEffect } from "react";
import { useLanguage } from "../contexts/LanguageContext";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Trophy, Flame, Zap, Medal, Crown, Award, Shield, BarChart3 } from "lucide-react";
import axios from "axios";

const API = `${process.env.REACT_APP_BACKEND_URL}/api`;

export default function LeaderboardPage() {
  const { t, lang } = useLanguage();
  const [leaderboard, setLeaderboard] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axios.get(`${API}/gamification/leaderboard`)
      .then(res => setLeaderboard(res.data.leaderboard))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="flex items-center justify-center min-h-[50vh]"><div className="w-8 h-8 border-4 border-primary/30 border-t-primary rounded-full animate-spin" /></div>;

  const rankIcon = (rank) => {
    if (rank === 1) return <Crown className="w-5 h-5 text-yellow-500" />;
    if (rank === 2) return <Medal className="w-5 h-5 text-gray-400" />;
    if (rank === 3) return <Medal className="w-5 h-5 text-amber-600" />;
    return <span className="w-5 text-center font-bold text-muted-foreground">{rank}</span>;
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] py-8 sm:py-12" data-testid="leaderboard-page">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 animate-slide-up">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-warning/10 text-warning text-sm font-medium mb-4">
            <Trophy className="w-4 h-4" /> {t("leaderboard_title")}
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold mb-3" style={{ fontFamily: 'Outfit' }} data-testid="leaderboard-title">
            {t("leaderboard_title")}
          </h1>
          <p className="text-muted-foreground">{t("leaderboard_subtitle")}</p>
        </div>

        {leaderboard.length === 0 ? (
          <Card className="rounded-xl">
            <CardContent className="p-12 text-center">
              <Shield className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">
                {lang === "fr" ? "Aucun utilisateur pour le moment. Soyez le premier!" : "No users yet. Be the first!"}
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-3">
            {/* Top 3 podium */}
            {leaderboard.length >= 3 && (
              <div className="grid grid-cols-3 gap-4 mb-8 animate-slide-up stagger-1">
                {[leaderboard[1], leaderboard[0], leaderboard[2]].map((user, i) => {
                  const isFirst = i === 1;
                  return (
                    <Card key={user.rank} className={`rounded-xl text-center ${isFirst ? 'border-2 border-yellow-500/30 bg-yellow-500/5 -mt-4' : ''}`}
                      data-testid={`podium-${user.rank}`}>
                      <CardContent className="p-5">
                        <div className={`w-12 h-12 rounded-full mx-auto mb-3 flex items-center justify-center ${isFirst ? 'bg-yellow-500/20' : 'bg-muted'}`}>
                          {rankIcon(user.rank)}
                        </div>
                        <p className="font-bold text-sm truncate">{user.username}</p>
                        <div className="flex items-center justify-center gap-1 mt-1">
                          <Zap className="w-3 h-3 text-xp" />
                          <span className="text-sm font-bold text-xp">{user.xp}</span>
                        </div>
                        <p className="text-xs text-muted-foreground mt-1">
                          {lang === "fr" ? user.level.name_fr : user.level.name_en}
                        </p>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}

            {/* Rest of leaderboard */}
            <Card className="rounded-xl animate-slide-up stagger-2" data-testid="leaderboard-list">
              <CardContent className="p-0">
                {leaderboard.map((user, i) => (
                  <div key={user.rank}
                    className={`flex items-center gap-4 px-6 py-4 ${i < leaderboard.length - 1 ? 'border-b' : ''} hover:bg-muted/30 transition-colors`}
                    data-testid={`leaderboard-row-${user.rank}`}>
                    <div className="w-8 flex-shrink-0 flex justify-center">{rankIcon(user.rank)}</div>
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-sm truncate">{user.username}</p>
                      <p className="text-xs text-muted-foreground">
                        {lang === "fr" ? user.level.name_fr : user.level.name_en}
                      </p>
                    </div>
                    <div className="flex items-center gap-4 flex-shrink-0">
                      <div className="flex items-center gap-1 text-sm">
                        <Flame className="w-3 h-3 text-streak" />
                        <span className="font-medium">{user.streak}</span>
                      </div>
                      <div className="flex items-center gap-1 text-sm">
                        <BarChart3 className="w-3 h-3 text-primary" />
                        <span className="font-medium">{user.analyses_count}</span>
                      </div>
                      <div className="flex items-center gap-1 text-sm min-w-[60px] justify-end">
                        <Zap className="w-3 h-3 text-xp" />
                        <span className="font-bold text-xp">{user.xp}</span>
                      </div>
                      <Badge variant="outline" className="text-xs">{user.badges_count}</Badge>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
