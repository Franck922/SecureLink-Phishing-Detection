import { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { useLanguage } from "../contexts/LanguageContext";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { Progress } from "../components/ui/progress";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator
} from "../components/ui/dropdown-menu";
import {
  BarChart3, Users, ShieldCheck, ShieldAlert, ShieldX, Clock, CheckCircle,
  XCircle, RefreshCw, Brain, Database, FileText, AlertTriangle, ChevronLeft, ChevronRight,
  Download, Zap, TrendingUp, Activity, Target, UserPlus
} from "lucide-react";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, AreaChart, Area, Legend
} from "recharts";
import axios from "axios";

const API = `${process.env.REACT_APP_BACKEND_URL}/api`;

export default function AdminPage() {
  const { user, token } = useAuth();
  const { lang } = useLanguage();
  const navigate = useNavigate();
  const [stats, setStats] = useState(null);
  const [users, setUsers] = useState({ users: [], total: 0, page: 1, pages: 1 });
  const [contributions, setContributions] = useState({ contributions: [], total: 0, page: 1, pages: 1 });
  const [analyses, setAnalyses] = useState({ analyses: [], total: 0, page: 1, pages: 1 });
  const [feedback, setFeedback] = useState({ feedback: [], total: 0 });
  const [loading, setLoading] = useState(true);
  const [retraining, setRetraining] = useState(false);
  const [retrainResult, setRetrainResult] = useState(null);
  const [forceRetrain, setForceRetrain] = useState(false);
  const [contribFilter, setContribFilter] = useState("pending");
  const [analysisFilter, setAnalysisFilter] = useState("");
  const [datasetStats, setDatasetStats] = useState(null);
  const [fetching, setFetching] = useState(false);
  const [fetchResult, setFetchResult] = useState(null);
  const [fetchAndTraining, setFetchAndTraining] = useState(false);
  const [fetchAndTrainResult, setFetchAndTrainResult] = useState(null);
  const [analytics, setAnalytics] = useState(null);
  const [weeklyReports, setWeeklyReports] = useState([]);
  const [generatingReport, setGeneratingReport] = useState(false);

  const headers = { Authorization: `Bearer ${token}` };

  useEffect(() => {
    if (!token || !user?.is_admin) { navigate("/"); return; }
    fetchAll();
  }, [token, user]);

  const fetchAll = async () => {
    try {
      const [statsR, usersR, contribR, analysesR, feedbackR, dsR, analyticsR, reportsR] = await Promise.allSettled([
        axios.get(`${API}/admin/stats`, { headers }),
        axios.get(`${API}/admin/users`, { headers }),
        axios.get(`${API}/admin/contributions?status_filter=pending`, { headers }),
        axios.get(`${API}/admin/analyses?limit=20`, { headers }),
        axios.get(`${API}/admin/feedback`, { headers }),
        axios.get(`${API}/admin/dataset/stats`, { headers }),
        axios.get(`${API}/admin/analytics`, { headers }),
        axios.get(`${API}/admin/reports`, { headers }),
      ]);
      if (statsR.status === "fulfilled") setStats(statsR.value.data);
      if (usersR.status === "fulfilled") setUsers(usersR.value.data);
      if (contribR.status === "fulfilled") setContributions(contribR.value.data);
      if (analysesR.status === "fulfilled") setAnalyses(analysesR.value.data);
      if (feedbackR.status === "fulfilled") setFeedback(feedbackR.value.data);
      if (dsR.status === "fulfilled") setDatasetStats(dsR.value.data);
      if (analyticsR.status === "fulfilled") setAnalytics(analyticsR.value.data);
      if (reportsR.status === "fulfilled") setWeeklyReports(reportsR.value.data.reports || []);
    } catch { /* ignore */ }
    setLoading(false);
  };

  const fetchContributions = async (filter, page = 1) => {
    try {
      const res = await axios.get(`${API}/admin/contributions?status_filter=${filter}&page=${page}`, { headers });
      setContributions(res.data);
      setContribFilter(filter);
    } catch { /* ignore */ }
  };

  const fetchAnalyses = async (filter, page = 1) => {
    try {
      const url = filter ? `${API}/admin/analyses?risk_filter=${filter}&page=${page}` : `${API}/admin/analyses?page=${page}`;
      const res = await axios.get(url, { headers });
      setAnalyses(res.data);
      setAnalysisFilter(filter);
    } catch { /* ignore */ }
  };

  const validateContribution = async (id, status, isPhishing) => {
    try {
      await axios.post(`${API}/admin/contributions/validate`,
        { contribution_id: id, status, is_phishing: isPhishing }, { headers });
      fetchContributions(contribFilter);
      const sR = await axios.get(`${API}/admin/stats`, { headers });
      setStats(sR.data);
    } catch { /* ignore */ }
  };

  const handleRetrain = async (force = false) => {
    setRetraining(true);
    setRetrainResult(null);
    try {
      const res = await axios.post(`${API}/admin/retrain`, { force }, { headers });
      setRetrainResult(res.data);
      if (res.data.blocked) {
        setForceRetrain(true);
      } else {
        setForceRetrain(false);
      }
      const [sR, dsR] = await Promise.allSettled([
        axios.get(`${API}/admin/stats`, { headers }),
        axios.get(`${API}/admin/dataset/stats`, { headers }),
      ]);
      if (sR.status === "fulfilled") setStats(sR.value.data);
      if (dsR.status === "fulfilled") setDatasetStats(dsR.value.data);
    } catch (e) {
      setRetrainResult({ message: e.response?.data?.detail || "Error" });
    }
    setRetraining(false);
  };

  const handleFetchDataset = async () => {
    setFetching(true);
    setFetchResult(null);
    try {
      const res = await axios.post(`${API}/admin/dataset/fetch`, {}, { headers });
      setFetchResult(res.data);
      const dsR = await axios.get(`${API}/admin/dataset/stats`, { headers });
      setDatasetStats(dsR.data);
    } catch (e) {
      setFetchResult({ error: e.response?.data?.detail || "Error" });
    }
    setFetching(false);
  };

  const handleFetchAndTrain = async () => {
    setFetchAndTraining(true);
    setFetchAndTrainResult(null);
    try {
      const res = await axios.post(`${API}/admin/dataset/fetch-and-train`, {}, { headers });
      setFetchAndTrainResult(res.data);
      const [sR, dsR] = await Promise.allSettled([
        axios.get(`${API}/admin/stats`, { headers }),
        axios.get(`${API}/admin/dataset/stats`, { headers }),
      ]);
      if (sR.status === "fulfilled") setStats(sR.value.data);
      if (dsR.status === "fulfilled") setDatasetStats(dsR.value.data);
    } catch (e) {
      setFetchAndTrainResult({ error: e.response?.data?.detail || "Error" });
    }
    setFetchAndTraining(false);
  };

  const handleAdminExport = (type) => {
    fetch(`${API}/admin/export/${type}`, { headers })
      .then(res => res.blob())
      .then(blob => {
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        const ext = type.endsWith("pdf") ? "pdf" : "csv";
        a.download = `securelink_${type.replace(/\//g, "_")}.${ext}`;
        a.click();
        window.URL.revokeObjectURL(url);
      }).catch(() => {});
  };

  const handleGenerateReport = async () => {
    setGeneratingReport(true);
    try {
      await axios.post(`${API}/admin/reports/generate`, {}, { headers });
      const res = await axios.get(`${API}/admin/reports`, { headers });
      setWeeklyReports(res.data.reports || []);
    } catch { /* ignore */ }
    setGeneratingReport(false);
  };

  const handleDownloadReport = (reportId) => {
    fetch(`${API}/admin/reports/${reportId}/pdf`, { headers })
      .then(res => res.blob())
      .then(blob => {
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `securelink_${reportId}.pdf`;
        a.click();
        window.URL.revokeObjectURL(url);
      }).catch(() => {});
  };

  const riskPastille = (rl) => {
    if (rl === "SAFE") return <div className="w-2.5 h-2.5 rounded-full bg-emerald-500" />;
    if (rl === "SUSPICIOUS") return <div className="w-2.5 h-2.5 rounded-full bg-amber-500" />;
    return <div className="w-2.5 h-2.5 rounded-full bg-red-500" />;
  };

  if (loading) return <div className="flex items-center justify-center min-h-[50vh]"><div className="w-8 h-8 border-4 border-primary/30 border-t-primary rounded-full animate-spin" /></div>;
  if (!user?.is_admin) return null;

  return (
    <div className="min-h-[calc(100vh-4rem)] py-6" data-testid="admin-page">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-6 animate-slide-up flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold" style={{ fontFamily: 'Outfit' }} data-testid="admin-title">
              {lang === "fr" ? "Administration" : "Administration"}
            </h1>
            <p className="text-sm text-muted-foreground">{lang === "fr" ? "Gestion de la plateforme SecureLink" : "SecureLink platform management"}</p>
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" className="rounded-full gap-2" data-testid="admin-export-btn">
                <Download className="w-3.5 h-3.5" />
                {lang === "fr" ? "Exporter" : "Export"}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-52">
              <DropdownMenuItem onClick={() => handleAdminExport("analyses/csv")} data-testid="admin-export-analyses-csv">
                <FileText className="w-4 h-4 mr-2" />
                {lang === "fr" ? "Analyses (CSV)" : "Analyses (CSV)"}
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleAdminExport("users/csv")} data-testid="admin-export-users-csv">
                <FileText className="w-4 h-4 mr-2" />
                {lang === "fr" ? "Utilisateurs (CSV)" : "Users (CSV)"}
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => handleAdminExport("report/pdf")} data-testid="admin-export-report-pdf">
                <FileText className="w-4 h-4 mr-2" />
                {lang === "fr" ? "Rapport complet (PDF)" : "Full report (PDF)"}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {/* Stats Overview */}
        {stats && (
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3 mb-6 animate-slide-up stagger-1">
            {[
              { label: lang === "fr" ? "Utilisateurs" : "Users", value: stats.total_users, icon: Users, color: "text-primary" },
              { label: lang === "fr" ? "Analyses" : "Analyses", value: stats.total_analyses, icon: BarChart3, color: "text-blue-500" },
              { label: lang === "fr" ? "Contributions" : "Contributions", value: stats.total_contributions, icon: Database, color: "text-violet-500" },
              { label: lang === "fr" ? "En attente" : "Pending", value: stats.pending_contributions, icon: Clock, color: "text-amber-500" },
              { label: lang === "fr" ? "Feedback" : "Feedback", value: stats.total_feedback, icon: FileText, color: "text-teal-500" },
              { label: lang === "fr" ? "Précision ML" : "ML Accuracy", value: `${stats.model_accuracy}%`, icon: Brain, color: "text-rose-500" },
            ].map((s, i) => (
              <Card key={i} className="rounded-xl" data-testid={`admin-stat-${i}`}>
                <CardContent className="p-4 flex items-center gap-3">
                  <s.icon className={`w-5 h-5 ${s.color} flex-shrink-0`} />
                  <div>
                    <p className="text-lg font-bold leading-tight">{s.value}</p>
                    <p className="text-xs text-muted-foreground">{s.label}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Risk Distribution */}
        {stats && (
          <Card className="rounded-xl mb-6 animate-slide-up stagger-2" data-testid="admin-risk-distribution">
            <CardContent className="p-5">
              <p className="text-sm font-medium mb-3">{lang === "fr" ? "Repartition des analyses" : "Analysis distribution"}</p>
              <div className="flex items-center gap-4">
                {[
                  { label: lang === "fr" ? "Surs" : "Safe", value: stats.analyses_by_risk.safe, color: "bg-emerald-500", dotColor: "bg-emerald-500" },
                  { label: lang === "fr" ? "Suspects" : "Suspicious", value: stats.analyses_by_risk.suspicious, color: "bg-amber-500", dotColor: "bg-amber-500" },
                  { label: lang === "fr" ? "Dangereux" : "Dangerous", value: stats.analyses_by_risk.dangerous, color: "bg-red-500", dotColor: "bg-red-500" },
                ].map((r) => {
                  const pct = stats.total_analyses ? Math.round((r.value / stats.total_analyses) * 100) : 0;
                  return (
                    <div key={r.label} className="flex-1">
                      <div className="flex justify-between text-xs mb-1">
                        <span className="flex items-center gap-1.5"><div className={`w-2 h-2 rounded-full ${r.dotColor}`} />{r.label}</span>
                        <span className="font-medium">{r.value} ({pct}%)</span>
                      </div>
                      <Progress value={pct} className={`h-1.5 [&>div]:${r.color}`} />
                    </div>
                  );
                })}
              </div>
              <div className="flex gap-4 mt-3 text-xs text-muted-foreground">
                <span>{lang === "fr" ? "Cette semaine" : "This week"}: {stats.weekly_analyses} {lang === "fr" ? "analyses" : "analyses"}</span>
                <span>{stats.weekly_active_users} {lang === "fr" ? "utilisateurs actifs" : "active users"}</span>
              </div>
            </CardContent>
          </Card>
        )}

        <Tabs defaultValue="metrics" className="animate-slide-up stagger-3">
          <TabsList className="grid w-full grid-cols-5 max-w-3xl rounded-full mb-6" data-testid="admin-tabs">
            <TabsTrigger value="metrics" className="rounded-full text-xs">
              {lang === "fr" ? "Métriques" : "Metrics"}
            </TabsTrigger>
            <TabsTrigger value="contributions" className="rounded-full text-xs">
              {lang === "fr" ? "Contributions" : "Contributions"}
              {stats?.pending_contributions > 0 && (
                <Badge className="ml-1.5 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs bg-amber-500">{stats.pending_contributions}</Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="analyses" className="rounded-full text-xs">{lang === "fr" ? "Analyses" : "Analyses"}</TabsTrigger>
            <TabsTrigger value="model" className="rounded-full text-xs">{lang === "fr" ? "Modèle ML" : "ML Model"}</TabsTrigger>
            <TabsTrigger value="users" className="rounded-full text-xs">{lang === "fr" ? "Utilisateurs" : "Users"}</TabsTrigger>
          </TabsList>

          {/* METRICS TAB */}
          <TabsContent value="metrics">
            {analytics ? (
              <div className="space-y-6">
                {/* Engagement KPI Cards */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3" data-testid="engagement-cards">
                  <Card className="rounded-xl">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <Activity className="w-4 h-4 text-blue-500" />
                        <span className="text-xs text-muted-foreground">{lang === "fr" ? "Analyses aujourd'hui" : "Analyses today"}</span>
                      </div>
                      <p className="text-2xl font-bold" data-testid="analyses-today">{analytics.engagement.analyses_today}</p>
                      <p className={`text-xs mt-1 ${analytics.engagement.analyses_trend >= 0 ? "text-emerald-500" : "text-red-500"}`}>
                        {analytics.engagement.analyses_trend >= 0 ? "+" : ""}{analytics.engagement.analyses_trend} {lang === "fr" ? "vs hier" : "vs yesterday"}
                      </p>
                    </CardContent>
                  </Card>
                  <Card className="rounded-xl">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <Target className="w-4 h-4 text-violet-500" />
                        <span className="text-xs text-muted-foreground">{lang === "fr" ? "Simulations" : "Simulations"}</span>
                      </div>
                      <p className="text-2xl font-bold" data-testid="total-simulations">{analytics.engagement.total_simulations}</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {analytics.engagement.simulation_accuracy}% {lang === "fr" ? "precision" : "accuracy"}
                      </p>
                    </CardContent>
                  </Card>
                  <Card className="rounded-xl">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <FileText className="w-4 h-4 text-teal-500" />
                        <span className="text-xs text-muted-foreground">Feedback</span>
                      </div>
                      <p className="text-2xl font-bold" data-testid="total-feedback">{analytics.engagement.total_feedback}</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {analytics.engagement.feedback_this_week} {lang === "fr" ? "cette semaine" : "this week"}
                      </p>
                    </CardContent>
                  </Card>
                  <Card className="rounded-xl">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <Users className="w-4 h-4 text-amber-500" />
                        <span className="text-xs text-muted-foreground">{lang === "fr" ? "Actifs aujourd'hui" : "Active today"}</span>
                      </div>
                      <p className="text-2xl font-bold" data-testid="active-users-today">{analytics.engagement.active_users_today}</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        / {analytics.user_totals.total} total
                      </p>
                    </CardContent>
                  </Card>
                </div>

                {/* 30-day analysis trend chart */}
                <Card className="rounded-xl" data-testid="analyses-trend-chart">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm flex items-center gap-2" style={{ fontFamily: 'Outfit' }}>
                      <TrendingUp className="w-4 h-4 text-primary" />
                      {lang === "fr" ? "Tendance des analyses — 30 jours" : "Analysis trend — 30 days"}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={analytics.daily_analyses} margin={{ top: 5, right: 5, bottom: 5, left: -20 }}>
                          <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                          <XAxis dataKey="date" tick={{ fontSize: 10 }} interval={4} />
                          <YAxis tick={{ fontSize: 10 }} allowDecimals={false} />
                          <Tooltip
                            contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid hsl(var(--border))", background: "hsl(var(--popover))", color: "hsl(var(--popover-foreground))" }}
                            labelStyle={{ fontWeight: 600, marginBottom: 4 }}
                          />
                          <Legend wrapperStyle={{ fontSize: 11 }} />
                          <Bar dataKey="safe" name={lang === "fr" ? "Surs" : "Safe"} stackId="a" fill="#10b981" radius={[0, 0, 0, 0]} />
                          <Bar dataKey="suspicious" name={lang === "fr" ? "Suspects" : "Suspicious"} stackId="a" fill="#f59e0b" />
                          <Bar dataKey="dangerous" name={lang === "fr" ? "Dangereux" : "Dangerous"} stackId="a" fill="#ef4444" radius={[3, 3, 0, 0]} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Detection rates donut */}
                  <Card className="rounded-xl" data-testid="detection-rates-chart">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm flex items-center gap-2" style={{ fontFamily: 'Outfit' }}>
                        <ShieldCheck className="w-4 h-4 text-emerald-500" />
                        {lang === "fr" ? "Taux de detection" : "Detection rates"}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="h-52 flex items-center">
                        <ResponsiveContainer width="100%" height="100%">
                          <PieChart>
                            <Pie
                              data={[
                                { name: lang === "fr" ? "Surs" : "Safe", value: analytics.detection_rates.safe, pct: analytics.detection_rates.safe_pct },
                                { name: lang === "fr" ? "Suspects" : "Suspicious", value: analytics.detection_rates.suspicious, pct: analytics.detection_rates.suspicious_pct },
                                { name: lang === "fr" ? "Dangereux" : "Dangerous", value: analytics.detection_rates.dangerous, pct: analytics.detection_rates.dangerous_pct },
                              ]}
                              cx="50%"
                              cy="50%"
                              innerRadius={55}
                              outerRadius={80}
                              paddingAngle={3}
                              dataKey="value"
                            >
                              <Cell fill="#10b981" />
                              <Cell fill="#f59e0b" />
                              <Cell fill="#ef4444" />
                            </Pie>
                            <Tooltip
                              formatter={(value, name, entry) => [`${value} (${entry.payload.pct}%)`, name]}
                              contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid hsl(var(--border))", background: "hsl(var(--popover))", color: "hsl(var(--popover-foreground))" }}
                            />
                            <Legend wrapperStyle={{ fontSize: 11 }} />
                          </PieChart>
                        </ResponsiveContainer>
                      </div>
                      <div className="text-center text-xs text-muted-foreground mt-1">
                        {analytics.detection_rates.total} {lang === "fr" ? "analyses au total" : "total analyses"}
                      </div>
                    </CardContent>
                  </Card>

                  {/* User growth chart */}
                  <Card className="rounded-xl" data-testid="user-growth-chart">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm flex items-center gap-2" style={{ fontFamily: 'Outfit' }}>
                        <UserPlus className="w-4 h-4 text-blue-500" />
                        {lang === "fr" ? "Croissance utilisateurs — 30 jours" : "User growth — 30 days"}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="h-52">
                        <ResponsiveContainer width="100%" height="100%">
                          <AreaChart data={analytics.user_growth} margin={{ top: 5, right: 5, bottom: 5, left: -20 }}>
                            <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                            <XAxis dataKey="date" tick={{ fontSize: 10 }} interval={6} />
                            <YAxis tick={{ fontSize: 10 }} allowDecimals={false} />
                            <Tooltip
                              contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid hsl(var(--border))", background: "hsl(var(--popover))", color: "hsl(var(--popover-foreground))" }}
                            />
                            <Area
                              type="monotone"
                              dataKey="new_users"
                              name={lang === "fr" ? "Nouveaux utilisateurs" : "New users"}
                              stroke="#3b82f6"
                              fill="#3b82f6"
                              fillOpacity={0.15}
                              strokeWidth={2}
                            />
                          </AreaChart>
                        </ResponsiveContainer>
                      </div>
                      <div className="flex gap-6 mt-3 text-xs text-muted-foreground justify-center">
                        <span>{lang === "fr" ? "7 derniers jours" : "Last 7 days"}: <strong className="text-foreground">{analytics.user_totals.last_7d}</strong></span>
                        <span>{lang === "fr" ? "30 derniers jours" : "Last 30 days"}: <strong className="text-foreground">{analytics.user_totals.last_30d}</strong></span>
                        <span>Total: <strong className="text-foreground">{analytics.user_totals.total}</strong></span>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Weekly Reports */}
                <Card className="rounded-xl" data-testid="weekly-reports-card">
                  <CardHeader className="pb-2">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-sm flex items-center gap-2" style={{ fontFamily: 'Outfit' }}>
                        <FileText className="w-4 h-4 text-amber-500" />
                        {lang === "fr" ? "Rapports hebdomadaires" : "Weekly Reports"}
                      </CardTitle>
                      <Button
                        variant="outline"
                        size="sm"
                        className="rounded-full gap-2 text-xs"
                        onClick={handleGenerateReport}
                        disabled={generatingReport}
                        data-testid="generate-report-btn"
                      >
                        <RefreshCw className={`w-3 h-3 ${generatingReport ? "animate-spin" : ""}`} />
                        {generatingReport
                          ? (lang === "fr" ? "Generation..." : "Generating...")
                          : (lang === "fr" ? "Generer" : "Generate")}
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    {weeklyReports.length === 0 ? (
                      <p className="text-sm text-muted-foreground text-center py-4">
                        {lang === "fr" ? "Aucun rapport. Cliquez sur 'Generer' pour creer le premier." : "No reports. Click 'Generate' to create the first one."}
                      </p>
                    ) : (
                      <div className="space-y-2">
                        {weeklyReports.map((r) => (
                          <div
                            key={r.id}
                            className="flex items-center justify-between p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors cursor-pointer"
                            onClick={() => handleDownloadReport(r.id)}
                            data-testid={`report-row-${r.id}`}
                          >
                            <div className="flex items-center gap-3">
                              <FileText className="w-4 h-4 text-muted-foreground" />
                              <div>
                                <p className="text-sm font-medium">
                                  {lang === "fr" ? "Semaine du" : "Week of"} {new Date(r.week_start).toLocaleDateString(lang === "fr" ? "fr-FR" : "en-US", { day: "numeric", month: "short" })}
                                  {" - "}
                                  {new Date(r.week_end).toLocaleDateString(lang === "fr" ? "fr-FR" : "en-US", { day: "numeric", month: "short" })}
                                </p>
                                <p className="text-xs text-muted-foreground">
                                  {r.stats?.analyses || 0} analyses | {r.stats?.new_users || 0} {lang === "fr" ? "nouveaux" : "new"} | {r.stats?.dangerous || 0} {lang === "fr" ? "dangereux" : "dangerous"}
                                </p>
                              </div>
                            </div>
                            <Download className="w-4 h-4 text-muted-foreground" />
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            ) : (
              <Card className="rounded-xl">
                <CardContent className="p-8 text-center text-sm text-muted-foreground">
                  {lang === "fr" ? "Chargement des metriques..." : "Loading metrics..."}
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* CONTRIBUTIONS TAB */}
          <TabsContent value="contributions">
            <div className="flex gap-2 mb-4">
              {["pending", "verified", ""].map(f => (
                <Button key={f} variant={contribFilter === f ? "secondary" : "ghost"} size="sm" className="rounded-full text-xs"
                  onClick={() => fetchContributions(f)} data-testid={`contrib-filter-${f || "all"}`}>
                  {f === "pending" ? (lang === "fr" ? "En attente" : "Pending") : f === "verified" ? (lang === "fr" ? "Validees" : "Validated") : (lang === "fr" ? "Toutes" : "All")}
                </Button>
              ))}
            </div>
            <Card className="rounded-xl" data-testid="admin-contributions-list">
              <CardContent className="p-0">
                {contributions.contributions.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-8">{lang === "fr" ? "Aucune contribution." : "No contributions."}</p>
                ) : (
                  <div className="divide-y">
                    {contributions.contributions.map((c) => (
                      <div key={c.id} className="px-5 py-3 flex items-center gap-3" data-testid={`contrib-row-${c.id}`}>
                        <div className={`w-2.5 h-2.5 rounded-full flex-shrink-0 ${c.category === "phishing" ? "bg-red-500" : c.category === "safe" ? "bg-emerald-500" : "bg-gray-400"}`} />
                        <div className="flex-1 min-w-0">
                          <p className="font-mono text-xs truncate">{c.url}</p>
                          <div className="flex items-center gap-2 text-xs text-muted-foreground mt-0.5">
                            <span>{c.submitted_by_name}</span>
                            <span>{c.category}</span>
                            {c.comment && <span className="truncate max-w-[200px]">"{c.comment}"</span>}
                          </div>
                        </div>
                        {!c.verified ? (
                          <div className="flex gap-1.5 flex-shrink-0">
                            <Button size="sm" variant="ghost" className="h-7 px-2 text-xs text-emerald-600 hover:bg-emerald-50"
                              onClick={() => validateContribution(c.id, "approved", c.category === "phishing")}
                              data-testid={`approve-${c.id}`}>
                              <CheckCircle className="w-3.5 h-3.5 mr-1" /> {lang === "fr" ? "Approuver" : "Approve"}
                            </Button>
                            <Button size="sm" variant="ghost" className="h-7 px-2 text-xs text-red-600 hover:bg-red-50"
                              onClick={() => validateContribution(c.id, "rejected", null)}
                              data-testid={`reject-${c.id}`}>
                              <XCircle className="w-3.5 h-3.5 mr-1" /> {lang === "fr" ? "Rejeter" : "Reject"}
                            </Button>
                          </div>
                        ) : (
                          <Badge variant="outline" className={`text-xs ${c.validation_status === "approved" ? "text-emerald-600 border-emerald-300" : "text-red-600 border-red-300"}`}>
                            {c.validation_status === "approved" ? (lang === "fr" ? "Approuvée" : "Approved") : (lang === "fr" ? "Rejetée" : "Rejected")}
                          </Badge>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
            {contributions.pages > 1 && (
              <div className="flex items-center justify-center gap-2 mt-4">
                <Button variant="ghost" size="sm" disabled={contributions.page <= 1}
                  onClick={() => fetchContributions(contribFilter, contributions.page - 1)}>
                  <ChevronLeft className="w-4 h-4" />
                </Button>
                <span className="text-sm text-muted-foreground">{contributions.page}/{contributions.pages}</span>
                <Button variant="ghost" size="sm" disabled={contributions.page >= contributions.pages}
                  onClick={() => fetchContributions(contribFilter, contributions.page + 1)}>
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            )}
          </TabsContent>

          {/* ANALYSES TAB */}
          <TabsContent value="analyses">
            <div className="flex gap-2 mb-4">
              {[
                { val: "", label: lang === "fr" ? "Toutes" : "All" },
                { val: "SAFE", label: lang === "fr" ? "Sures" : "Safe" },
                { val: "SUSPICIOUS", label: lang === "fr" ? "Suspectes" : "Suspicious" },
                { val: "DANGEROUS", label: lang === "fr" ? "Dangereuses" : "Dangerous" },
              ].map(f => (
                <Button key={f.val} variant={analysisFilter === f.val ? "secondary" : "ghost"} size="sm" className="rounded-full text-xs"
                  onClick={() => fetchAnalyses(f.val)} data-testid={`analysis-filter-${f.val || "all"}`}>
                  {f.label}
                </Button>
              ))}
            </div>
            <Card className="rounded-xl" data-testid="admin-analyses-list">
              <CardContent className="p-0">
                {analyses.analyses.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-8">{lang === "fr" ? "Aucune analyse." : "No analyses."}</p>
                ) : (
                  <div className="divide-y">
                    {analyses.analyses.map((a) => (
                      <div key={a.id} className="px-5 py-3 flex items-center gap-3" data-testid={`admin-analysis-${a.id}`}>
                        {riskPastille(a.risk_level)}
                        <span className="font-mono text-xs truncate flex-1">{a.url}</span>
                        <span className="text-xs text-muted-foreground">{a.user_id === "anonymous" ? "anon" : a.user_id?.slice(0, 8)}</span>
                        <span className="text-xs text-muted-foreground">
                          {new Date(a.analyzed_at).toLocaleDateString(lang === "fr" ? "fr-FR" : "en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}
                        </span>
                        <Badge variant="outline" className="text-xs">{a.final_score}</Badge>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
            {analyses.pages > 1 && (
              <div className="flex items-center justify-center gap-2 mt-4">
                <Button variant="ghost" size="sm" disabled={analyses.page <= 1}
                  onClick={() => fetchAnalyses(analysisFilter, analyses.page - 1)}>
                  <ChevronLeft className="w-4 h-4" />
                </Button>
                <span className="text-sm text-muted-foreground">{analyses.page}/{analyses.pages}</span>
                <Button variant="ghost" size="sm" disabled={analyses.page >= analyses.pages}
                  onClick={() => fetchAnalyses(analysisFilter, analyses.page + 1)}>
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            )}
          </TabsContent>

          {/* MODEL TAB */}
          <TabsContent value="model">
            {/* Dataset Management */}
            <Card className="rounded-xl mb-4" data-testid="dataset-card">
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2" style={{ fontFamily: 'Outfit' }}>
                  <Database className="w-5 h-5 text-violet-500" />
                  {lang === "fr" ? "Dataset réel" : "Real dataset"}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {datasetStats?.real_dataset?.fetched_at ? (
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <div className="p-3 rounded-lg bg-muted text-center">
                      <p className="text-lg font-bold">{datasetStats.real_dataset.total_phishing || 0}</p>
                      <p className="text-xs text-muted-foreground">{lang === "fr" ? "URLs phishing" : "Phishing URLs"}</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted text-center">
                      <p className="text-lg font-bold">{datasetStats.real_dataset.total_legit || 0}</p>
                      <p className="text-xs text-muted-foreground">{lang === "fr" ? "URLs légitimes" : "Legit URLs"}</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted text-center">
                      <p className="text-lg font-bold">{datasetStats.user_contributions || 0}</p>
                      <p className="text-xs text-muted-foreground">{lang === "fr" ? "Contrib. utilisateurs" : "User contributions"}</p>
                    </div>
                    <div className="p-3 rounded-lg bg-muted text-center">
                      <p className="text-lg font-bold">{datasetStats.total_training_samples || 0}</p>
                      <p className="text-xs text-muted-foreground">Total</p>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-4">
                    <Database className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                    <p className="text-sm text-muted-foreground">
                      {lang === "fr" ? "Aucun dataset réel chargé. Lancez un téléchargement." : "No real dataset loaded. Start a download."}
                    </p>
                  </div>
                )}

                {/* Balance gauge */}
                {datasetStats?.balance && datasetStats.balance.total_phishing + datasetStats.balance.total_legit > 0 && (
                  <div className="space-y-2 p-3 rounded-lg border" data-testid="balance-gauge">
                    <div className="flex items-center justify-between text-xs font-medium">
                      <span className="flex items-center gap-1.5">
                        <Target className="w-3.5 h-3.5" />
                        {lang === "fr" ? "Équilibre du dataset" : "Dataset balance"}
                      </span>
                      <Badge variant="outline" className={`text-[10px] ${datasetStats.balance.is_balanced
                        ? "border-emerald-300 text-emerald-600 dark:text-emerald-400 dark:border-emerald-700"
                        : "border-red-300 text-red-600 dark:text-red-400 dark:border-red-700"
                      }`}>
                        {datasetStats.balance.is_balanced
                          ? (lang === "fr" ? "Équilibré" : "Balanced")
                          : (lang === "fr" ? "Déséquilibré" : "Imbalanced")}
                      </Badge>
                    </div>
                    <div className="flex h-3 rounded-full overflow-hidden bg-muted">
                      <div
                        className="bg-red-500 transition-all"
                        style={{ width: `${datasetStats.balance.phishing_ratio}%` }}
                        title={`Phishing: ${datasetStats.balance.phishing_ratio}%`}
                      />
                      <div
                        className="bg-emerald-500 transition-all"
                        style={{ width: `${datasetStats.balance.legit_ratio}%` }}
                        title={`${lang === "fr" ? "Légitime" : "Legit"}: ${datasetStats.balance.legit_ratio}%`}
                      />
                    </div>
                    <div className="flex justify-between text-[10px] text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <span className="w-2 h-2 rounded-full bg-red-500 inline-block" />
                        Phishing: {datasetStats.balance.phishing_ratio}% ({datasetStats.balance.total_phishing})
                      </span>
                      <span className="flex items-center gap-1">
                        <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block" />
                        {lang === "fr" ? "Légitime" : "Legit"}: {datasetStats.balance.legit_ratio}% ({datasetStats.balance.total_legit})
                      </span>
                    </div>
                    {!datasetStats.balance.is_balanced && (
                      <div className="flex items-start gap-2 p-2 rounded-lg bg-amber-50 dark:bg-amber-950/30 text-amber-700 dark:text-amber-400 text-xs">
                        <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
                        <span>{lang === "fr"
                          ? `Attention : le dataset est déséquilibré (classe dominante à ${datasetStats.balance.max_ratio}%). Le seuil recommandé est 65/35. Un réentraînement pourrait biaiser le modèle.`
                          : `Warning: dataset is imbalanced (dominant class at ${datasetStats.balance.max_ratio}%). Recommended threshold is 65/35. Retraining could bias the model.`}
                        </span>
                      </div>
                    )}
                  </div>
                )}

                {datasetStats?.real_dataset?.sources && (
                  <div className="flex items-center gap-3 text-xs text-muted-foreground">
                    <span>PhishTank: {datasetStats.real_dataset.sources.phishtank || 0}</span>
                    <span>URLhaus: {datasetStats.real_dataset.sources.urlhaus || 0}</span>
                    <span>{lang === "fr" ? "Maj" : "Updated"}: {datasetStats.real_dataset.fetched_at ? new Date(datasetStats.real_dataset.fetched_at).toLocaleDateString(lang === "fr" ? "fr-FR" : "en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" }) : "-"}</span>
                  </div>
                )}

                <div className="flex gap-2">
                  <Button variant="outline" onClick={handleFetchDataset} disabled={fetching} className="rounded-full gap-2 flex-1" data-testid="fetch-dataset-btn">
                    <Download className={`w-4 h-4 ${fetching ? 'animate-bounce' : ''}`} />
                    {fetching ? (lang === "fr" ? "Téléchargement..." : "Downloading...") : (lang === "fr" ? "Télécharger dataset" : "Download dataset")}
                  </Button>
                  <Button onClick={handleFetchAndTrain} disabled={fetchAndTraining} className="rounded-full gap-2 flex-1" data-testid="fetch-and-train-btn">
                    <Zap className={`w-4 h-4 ${fetchAndTraining ? 'animate-spin' : ''}`} />
                    {fetchAndTraining ? (lang === "fr" ? "En cours..." : "Processing...") : (lang === "fr" ? "Télécharger + Entraîner" : "Download + Train")}
                  </Button>
                </div>

                {fetchResult && (
                  <div className={`text-sm p-3 rounded-lg ${fetchResult.error ? 'bg-red-50 dark:bg-red-950/30 text-red-700 dark:text-red-400' : 'bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-400'}`} data-testid="fetch-result">
                    {fetchResult.error ? <p>{fetchResult.error}</p> : (
                      <p>PhishTank: {fetchResult.sources?.phishtank || 0} | URLhaus: {fetchResult.sources?.urlhaus || 0} | {lang === "fr" ? "Légitimes" : "Legit"}: {fetchResult.total_legit || 0} | Total: {fetchResult.total || 0}</p>
                    )}
                  </div>
                )}
                {fetchAndTrainResult && (
                  <div className={`text-sm p-3 rounded-lg space-y-2 ${
                    fetchAndTrainResult.train?.blocked ? 'bg-amber-50 dark:bg-amber-950/30 text-amber-700 dark:text-amber-400' :
                    'bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-400'
                  }`} data-testid="fetch-train-result">
                    <p className="font-medium flex items-center gap-1.5">
                      {fetchAndTrainResult.train?.blocked && <AlertTriangle className="w-4 h-4 flex-shrink-0" />}
                      {lang === "fr" ? (fetchAndTrainResult.train?.message) : (fetchAndTrainResult.train?.message_en || fetchAndTrainResult.train?.message || "Done")}
                    </p>
                    {fetchAndTrainResult.train?.accuracy && (
                      <p className="text-xs">{lang === "fr" ? "Précision" : "Accuracy"}: {fetchAndTrainResult.train.accuracy}% | {fetchAndTrainResult.train.phishing_samples} phishing + {fetchAndTrainResult.train.legit_samples} {lang === "fr" ? "légitimes" : "legit"}</p>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card className="rounded-xl" data-testid="model-stats-card">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2" style={{ fontFamily: 'Outfit' }}>
                    <Brain className="w-5 h-5 text-primary" />
                    {lang === "fr" ? "Statistiques du modèle" : "Model statistics"}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">{lang === "fr" ? "Précision" : "Accuracy"}</span>
                    <span className="font-bold">{stats?.model_accuracy}%</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">{lang === "fr" ? "Feedback reçus" : "Feedback received"}</span>
                    <span className="font-bold">{stats?.total_feedback}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">{lang === "fr" ? "Total analyses" : "Total analyses"}</span>
                    <span className="font-bold">{stats?.total_analyses}</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="rounded-xl" data-testid="model-retrain-card">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center gap-2" style={{ fontFamily: 'Outfit' }}>
                    <RefreshCw className="w-5 h-5 text-primary" />
                    {lang === "fr" ? "Réentraînement seul" : "Retrain only"}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-muted-foreground">
                    {lang === "fr"
                      ? "Réentraîne avec le dataset existant + contributions + feedback."
                      : "Retrain with existing dataset + contributions + feedback."}
                  </p>
                  <Button variant="outline" onClick={() => handleRetrain(false)} disabled={retraining} className="rounded-full gap-2 w-full" data-testid="retrain-btn">
                    <RefreshCw className={`w-4 h-4 ${retraining ? 'animate-spin' : ''}`} />
                    {retraining ? (lang === "fr" ? "En cours..." : "Training...") : (lang === "fr" ? "Réentraîner" : "Retrain")}
                  </Button>
                  {retrainResult && (
                    <div className={`text-sm p-3 rounded-lg space-y-2 ${
                      retrainResult.blocked ? 'bg-amber-50 dark:bg-amber-950/30 text-amber-700 dark:text-amber-400' :
                      retrainResult.accuracy ? 'bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-400' :
                      'bg-amber-50 dark:bg-amber-950/30 text-amber-700 dark:text-amber-400'
                    }`} data-testid="retrain-result">
                      <p className="font-medium flex items-center gap-1.5">
                        {retrainResult.blocked && <AlertTriangle className="w-4 h-4 flex-shrink-0" />}
                        {lang === "fr" ? (retrainResult.message || retrainResult.message) : (retrainResult.message_en || retrainResult.message)}
                      </p>
                      {retrainResult.accuracy && (
                        <p className="text-xs">
                          {lang === "fr" ? "Précision" : "Accuracy"}: {retrainResult.accuracy}% | {retrainResult.phishing_samples} phishing + {retrainResult.legit_samples} {lang === "fr" ? "légitimes" : "legit"}
                          {retrainResult.forced && <Badge className="ml-2 text-[10px] bg-amber-500/15 text-amber-700 dark:text-amber-400 border-0">{lang === "fr" ? "Forcé" : "Forced"}</Badge>}
                        </p>
                      )}
                      {retrainResult.blocked && (
                        <Button
                          size="sm"
                          variant="destructive"
                          className="rounded-full gap-2 text-xs"
                          onClick={() => handleRetrain(true)}
                          disabled={retraining}
                          data-testid="force-retrain-btn"
                        >
                          <AlertTriangle className="w-3 h-3" />
                          {lang === "fr" ? "Forcer le réentraînement" : "Force retrain"}
                        </Button>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Feedback list */}
            <Card className="rounded-xl mt-4" data-testid="admin-feedback-list">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-muted-foreground" style={{ fontFamily: 'Outfit' }}>
                  {lang === "fr" ? "Derniers feedback utilisateurs" : "Latest user feedback"}
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                {feedback.feedback?.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-6">{lang === "fr" ? "Aucun feedback." : "No feedback."}</p>
                ) : (
                  <div className="divide-y">
                    {feedback.feedback?.slice(0, 15).map((f, i) => (
                      <div key={i} className="px-5 py-2.5 flex items-center gap-3 text-xs">
                        <div className={`w-2 h-2 rounded-full ${f.is_phishing ? "bg-red-500" : "bg-emerald-500"}`} />
                        <span className="font-mono truncate flex-1">{f.url}</span>
                        <span className="text-muted-foreground">{f.original_risk}</span>
                        <Badge variant="outline" className="text-xs">
                          {f.is_phishing ? "Phishing" : (lang === "fr" ? "Legitime" : "Legitimate")}
                        </Badge>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* USERS TAB */}
          <TabsContent value="users">
            <Card className="rounded-xl" data-testid="admin-users-list">
              <CardContent className="p-0">
                {users.users.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-8">{lang === "fr" ? "Aucun utilisateur." : "No users."}</p>
                ) : (
                  <div className="divide-y">
                    {users.users.map((u) => (
                      <div key={u.id} className="px-5 py-3 flex items-center gap-3" data-testid={`admin-user-${u.id}`}>
                        <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                          <span className="text-xs font-bold text-primary">{u.username?.charAt(0).toUpperCase()}</span>
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-medium">{u.username}</span>
                            {u.is_admin && <Badge className="text-xs bg-primary/10 text-primary">Admin</Badge>}
                          </div>
                          <span className="text-xs text-muted-foreground">{u.email}</span>
                        </div>
                        <div className="flex items-center gap-4 text-xs text-muted-foreground flex-shrink-0">
                          <span>{u.stats?.analyses_count || 0} {lang === "fr" ? "analyses" : "analyses"}</span>
                          <span>{u.xp} XP</span>
                          <span className="text-xs">{lang === "fr" ? u.level?.name_fr : u.level?.name_en}</span>
                          <span>{u.last_active_date || "-"}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
