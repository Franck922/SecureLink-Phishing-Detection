import { useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { useLanguage } from "../contexts/LanguageContext";
import { useAuth } from "../contexts/AuthContext";
import { Button } from "../components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import {
  ShieldCheck, ShieldAlert, ShieldX, ArrowLeft, ExternalLink, AlertTriangle,
  CheckCircle, XCircle, ThumbsUp, ThumbsDown, Info, ChevronDown, ChevronUp, Search,
  Globe, Lock, Clock, Server, Star, Zap, Lightbulb, FileSearch, Code, Shield, Bug, Fingerprint, Camera, Loader2,
  ShieldOff
} from "lucide-react";
import axios from "axios";

const API = `${process.env.REACT_APP_BACKEND_URL}/api`;

/* =========================================================================
   Build the detailed analysis sections from ALL backend data
   ========================================================================= */
function buildDetailSections(result, lang) {
  const fr = lang === "fr";
  const sections = [];
  const fd = result.feature_details || {};
  const nc = result.network_checks || {};
  const triggeredRules = result.triggered_rules || [];
  const safeIndicators = result.safe_indicators || [];

  // ── Section 1 : Structure de l'URL ──
  const urlItems = [];

  // HTTPS
  const sslValid = result.network_checks?.ssl?.valid;
  if (fd.has_https === 1) {
    urlItems.push({ ok: true, text: fr ? "L'adresse utilise le protocole HTTPS : vos données sont chiffrées pendant la transmission." : "The address uses HTTPS protocol: your data is encrypted during transmission.", tip: fr ? "HTTPS est un bon signe, mais ne garantit pas à lui seul que le site est légitime." : "HTTPS is a good sign, but doesn't guarantee the site is legitimate on its own." });
  } else if (fd.has_https === 0 && sslValid) {
    urlItems.push({ ok: "warn", text: fr ? "L'URL a été saisie en HTTP, mais le site propose bien une connexion HTTPS sécurisée." : "The URL was entered as HTTP, but the site does offer a secure HTTPS connection.", tip: fr ? "Pensez à toujours taper https:// devant l'adresse pour forcer la connexion chiffrée." : "Always type https:// before the address to force the encrypted connection." });
  } else if (fd.has_https === 0) {
    urlItems.push({ ok: false, text: fr ? "L'adresse utilise HTTP (non sécurisé). Vos données pourraient être interceptées." : "The address uses HTTP (unsecured). Your data could be intercepted.", tip: fr ? "Les sites fiables utilisent presque toujours HTTPS. Ne saisissez jamais de mot de passe sur un site HTTP." : "Reliable sites almost always use HTTPS. Never enter a password on an HTTP site." });
  }

  // URL length
  if (fd.url_length > 75) {
    urlItems.push({ ok: false, text: fr ? `L'URL est inhabituellement longue (${fd.url_length} caractères). Les liens de phishing cachent souvent la vraie destination dans une adresse à rallonge.` : `The URL is unusually long (${fd.url_length} characters). Phishing links often hide the real destination in an overly long address.`, tip: fr ? "Vérifiez le début de l'URL : le vrai domaine se situe juste avant le premier « / »." : "Check the beginning of the URL: the real domain is just before the first '/'." });
  } else if (fd.url_length < 40) {
    urlItems.push({ ok: true, text: fr ? "L'URL est courte et lisible, ce qui est rassurant." : "The URL is short and readable, which is reassuring." });
  }

  // IP address
  if (fd.has_ip === 1) {
    urlItems.push({ ok: false, text: fr ? "L'URL contient une adresse IP (ex: 192.168.1.1) au lieu d'un nom de domaine. Les sites légitimes n'utilisent quasiment jamais cette pratique." : "The URL contains an IP address (e.g., 192.168.1.1) instead of a domain name. Legitimate sites almost never use this.", tip: fr ? "Un vrai site utilise toujours un nom lisible comme google.com, jamais une suite de chiffres." : "A real site always uses a readable name like google.com, never a sequence of numbers." });
  }

  // Suspicious TLD
  if (fd.suspicious_tld === 1) {
    urlItems.push({ ok: false, text: fr ? "L'extension du domaine (.xyz, .top, .tk, .ml...) est fréquemment utilisée par des sites frauduleux car elle est gratuite ou très bon marché." : "The domain extension (.xyz, .top, .tk, .ml...) is frequently used by fraudulent sites as it's free or very cheap.", tip: fr ? "Les sites officiels utilisent généralement .com, .fr, .org, .gouv.fr..." : "Official sites generally use .com, .fr, .org, .gov..." });
  }

  // Suspicious keywords
  if (fd.suspicious_keywords === 1) {
    urlItems.push({ ok: false, text: fr ? "L'URL contient des mots-clés suspects comme « login », « verify », « secure », « account », « bank » ou « password »." : "The URL contains suspicious keywords like 'login', 'verify', 'secure', 'account', 'bank' or 'password'.", tip: fr ? "Les liens de phishing utilisent ces mots pour créer un faux sentiment d'urgence ou de sécurité." : "Phishing links use these words to create a false sense of urgency or security." });
  }

  // @ symbol
  if (fd.has_at === 1) {
    urlItems.push({ ok: false, text: fr ? "L'URL contient un caractère « @ » qui peut être utilisé pour masquer la vraie destination du lien." : "The URL contains an '@' character which can be used to mask the real link destination.", tip: fr ? "Le navigateur ignore tout ce qui précède le @ : l'adresse réelle est après." : "The browser ignores everything before the @: the real address is after it." });
  }

  // Shortened URL
  if (fd.shortened_url === 1) {
    urlItems.push({ ok: false, text: fr ? "C'est une URL raccourcie (type bit.ly, tinyurl). La destination réelle est masquée." : "This is a shortened URL (like bit.ly, tinyurl). The real destination is hidden.", tip: fr ? "Utilisez un outil de prévisualisation (unshorten.it) pour voir la vraie URL avant de cliquer." : "Use a preview tool (unshorten.it) to see the real URL before clicking." });
  }

  // Redirect pattern
  if (fd.has_redirect === 1) {
    urlItems.push({ ok: false, text: fr ? "L'URL contient un schéma de redirection (« // » dans le chemin). Vous pourriez être envoyé vers un site différent de celui affiché." : "The URL contains a redirect pattern ('//' in the path). You could be sent to a different site than displayed.", tip: fr ? "Les redirections cachées sont une technique fréquente de phishing." : "Hidden redirects are a common phishing technique." });
  }

  // Many subdomains
  if (fd.subdomain_count >= 2) {
    urlItems.push({ ok: false, text: fr ? `L'URL contient ${fd.subdomain_count} sous-domaines. Les faux sites ajoutent souvent des sous-domaines pour paraître légitimes (ex: google.secure.fake.com).` : `The URL contains ${fd.subdomain_count} subdomains. Fake sites often add subdomains to appear legitimate (e.g., google.secure.fake.com).`, tip: fr ? "Regardez la partie juste avant l'extension (.com, .fr) : c'est le vrai domaine." : "Look at the part just before the extension (.com, .fr): that's the real domain." });
  }

  // High entropy (random-looking domain)
  if (fd.domain_entropy > 3.5) {
    urlItems.push({ ok: false, text: fr ? "Le nom de domaine semble aléatoire et incompréhensible (suite de lettres et chiffres sans sens)." : "The domain name appears random and incomprehensible (meaningless sequence of letters and numbers).", tip: fr ? "Un domaine avec des caractères aléatoires est probablement généré automatiquement par un robot." : "A domain with random characters was probably auto-generated by a bot." });
  }

  // Digits in domain
  if (fd.digits_in_domain >= 2) {
    urlItems.push({ ok: false, text: fr ? `Le nom de domaine contient ${fd.digits_in_domain} chiffres. Les arnaqueurs remplacent souvent des lettres par des chiffres similaires (g00gle, paypa1).` : `The domain name contains ${fd.digits_in_domain} digits. Scammers often replace letters with similar-looking digits (g00gle, paypa1).`, tip: fr ? "Vérifiez lettre par lettre que le nom de domaine est bien orthographié." : "Check letter by letter that the domain name is spelled correctly." });
  }

  // Special characters
  if (fd.special_chars > 5) {
    urlItems.push({ ok: false, text: fr ? `L'URL contient ${fd.special_chars} caractères spéciaux, ce qui est inhabituel. Les URLs normales sont généralement simples et lisibles.` : `The URL contains ${fd.special_chars} special characters, which is unusual. Normal URLs are generally simple and readable.` });
  }

  // Non-standard port
  if (fd.has_port === 1) {
    urlItems.push({ ok: false, text: fr ? "L'URL utilise un port non standard (un numéro après le domaine, ex: :8080). Les sites normaux n'affichent pas de numéro de port." : "The URL uses a non-standard port (a number after the domain, e.g., :8080). Normal sites don't display port numbers.", tip: fr ? "Seuls les sites en développement ou les serveurs internes utilisent des ports personnalisés." : "Only development sites or internal servers use custom ports." });
  }

  // Many dots
  if (fd.num_dots > 4) {
    urlItems.push({ ok: false, text: fr ? `L'URL contient beaucoup de points (${fd.num_dots}), ce qui peut indiquer une structure de domaine complexe destinée à masquer l'adresse réelle.` : `The URL contains many dots (${fd.num_dots}), which may indicate a complex domain structure intended to mask the real address.` });
  }

  // Many hyphens
  if (fd.num_hyphens > 3) {
    urlItems.push({ ok: false, text: fr ? `L'URL contient ${fd.num_hyphens} tirets. Les noms de domaine avec beaucoup de tirets sont souvent des imitations de sites connus.` : `The URL contains ${fd.num_hyphens} hyphens. Domain names with many hyphens are often imitations of known sites.` });
  }

  // Long path
  if (fd.path_length > 80) {
    urlItems.push({ ok: false, text: fr ? "Le chemin de l'URL est anormalement long, ce qui peut servir à dissimuler du contenu malveillant." : "The URL path is abnormally long, which can be used to conceal malicious content." });
  }

  // Long query
  if (fd.query_length > 50) {
    urlItems.push({ ok: false, text: fr ? "L'URL contient de nombreux paramètres (après le « ? »). Cela peut servir à transmettre vos données à un tiers." : "The URL contains many parameters (after the '?'). This can be used to transmit your data to a third party." });
  }

  // Digits in path
  if (fd.digits_in_path > 8) {
    urlItems.push({ ok: false, text: fr ? "Le chemin de l'URL contient beaucoup de chiffres, ce qui est fréquent dans les liens de phishing générés automatiquement." : "The URL path contains many digits, which is common in automatically generated phishing links." });
  }

  // If no issues found, add a positive note
  if (urlItems.filter(i => i.ok === false).length === 0) {
    urlItems.push({ ok: true, text: fr ? "La structure de l'URL ne présente aucune anomalie. Le format est conforme aux standards des sites légitimes." : "The URL structure shows no anomalies. The format conforms to legitimate site standards." });
  }

  sections.push({
    title: fr ? "Structure de l'URL" : "URL structure",
    icon: Globe,
    items: urlItems,
  });

  // ── Section 2 : Certificat et connexion ──
  const sslItems = [];
  if (nc.ssl) {
    if (nc.ssl.valid) {
      let desc = fr
        ? `La connexion est sécurisée par un certificat SSL valide`
        : `The connection is secured by a valid SSL certificate`;
      if (nc.ssl.issuer) desc += fr ? `, émis par ${nc.ssl.issuer}` : `, issued by ${nc.ssl.issuer}`;
      if (nc.ssl.protocol) desc += ` (${nc.ssl.protocol})`;
      desc += fr ? ". Vos informations sont protégées." : ". Your information is protected.";
      sslItems.push({ ok: true, text: desc, tip: fr ? "Le cadenas dans la barre d'adresse confirme que la connexion est chiffrée." : "The padlock in the address bar confirms the connection is encrypted." });

      if (nc.ssl.expires_in_days !== undefined && nc.ssl.expires_in_days < 30) {
        sslItems.push({ ok: false, text: fr ? `Le certificat expire dans ${nc.ssl.expires_in_days} jour(s). Un certificat proche de l'expiration peut indiquer un site mal maintenu.` : `The certificate expires in ${nc.ssl.expires_in_days} day(s). A certificate close to expiration may indicate a poorly maintained site.` });
      }

      const chain = nc.ssl.chain;
      if (chain) {
        if (chain.cert_type === "OV/EV") {
          sslItems.push({ ok: true, text: fr ? `Certificat de type OV/EV émis par ${chain.issuer_org || chain.issuer_cn} — identité de l'organisation vérifiée.` : `OV/EV certificate issued by ${chain.issuer_org || chain.issuer_cn} — organization identity verified.` });
        }
        if (chain.validity_days && chain.validity_days > 90) {
          sslItems.push({ ok: true, text: fr ? `Durée de validité du certificat : ${chain.validity_days} jours.` : `Certificate validity period: ${chain.validity_days} days.` });
        }
        if (chain.anomalies && chain.anomalies.length > 0) {
          chain.anomalies.forEach(a => {
            sslItems.push({ ok: false, text: fr ? a.description_fr : a.description_en });
          });
        }
      }
    } else if (nc.ssl.status === "no_ssl") {
      sslItems.push({ ok: false, text: fr ? "Aucun certificat de sécurité trouvé. Ce site ne protège pas vos données." : "No security certificate found. This site doesn't protect your data.", tip: fr ? "Évitez absolument de saisir des informations personnelles (mot de passe, carte bancaire) sur ce site." : "Absolutely avoid entering personal information (password, credit card) on this site." });
    } else {
      sslItems.push({ ok: false, text: fr ? "Le certificat de sécurité est invalide ou expiré. Cela peut indiquer un site compromis." : "The security certificate is invalid or expired. This may indicate a compromised site." });
    }
  }
  if (sslItems.length > 0) {
    sections.push({
      title: fr ? "Certificat et connexion" : "Certificate and connection",
      icon: Lock,
      items: sslItems,
    });
  }

  // ── Section 3 : Identité du domaine ──
  const domainItems = [];
  if (nc.dns) {
    if (nc.dns.exists) {
      domainItems.push({ ok: true, text: fr ? "Le nom de domaine est bien enregistré et correspond à un serveur actif. Le site existe réellement." : "The domain name is registered and points to an active server. The site actually exists." });
      if (nc.dns.ip_count > 1) {
        domainItems.push({ ok: true, text: fr ? `Le domaine est associé à ${nc.dns.ip_count} adresses IP, ce qui indique une infrastructure robuste (typique des grands sites).` : `The domain is associated with ${nc.dns.ip_count} IP addresses, indicating a robust infrastructure (typical of major sites).` });
      }
    } else {
      domainItems.push({ ok: false, text: fr ? "Le nom de domaine n'a pas été trouvé. Ce site n'existe pas ou a été supprimé. C'est un signal d'alerte majeur." : "The domain name was not found. This site doesn't exist or has been removed. This is a major red flag.", tip: fr ? "Un site qui n'existe pas ne peut être légitime. Ne poursuivez pas." : "A site that doesn't exist cannot be legitimate. Do not proceed." });
    }
  }

  if (nc.whois) {
    const age = nc.whois.domain_age_days;
    if (age !== null && age < 30) {
      domainItems.push({ ok: false, text: fr ? `Ce domaine a été créé il y a seulement ${age} jour(s). Les sites de phishing sont très souvent créés récemment pour éviter d'être repérés.` : `This domain was created only ${age} day(s) ago. Phishing sites are very often created recently to avoid being detected.`, tip: fr ? "Méfiez-vous des sites très récents, surtout s'ils vous demandent des informations sensibles." : "Be wary of very new sites, especially if they ask for sensitive information." });
    } else if (age !== null && age < 180) {
      domainItems.push({ ok: null, text: fr ? `Ce domaine est relativement récent (${age} jours). Ce n'est pas forcément suspect, mais restez vigilant.` : `This domain is relatively new (${age} days). Not necessarily suspicious, but stay vigilant.` });
    } else if (age !== null && age > 365) {
      const years = Math.floor(age / 365);
      domainItems.push({ ok: true, text: fr ? `Ce domaine existe depuis ${years} an(s). Les sites frauduleux ont rarement une telle ancienneté, ce qui est rassurant.` : `This domain has existed for ${years} year(s). Fraudulent sites rarely have such longevity, which is reassuring.` });
    }
    if (nc.whois.registrar) {
      domainItems.push({ ok: true, text: fr ? `Enregistré auprès de ${nc.whois.registrar}.` : `Registered with ${nc.whois.registrar}.` });
    }
    if (nc.whois.status === "error") {
      domainItems.push({ ok: null, text: fr ? "Les informations WHOIS n'ont pas pu être récupérées. Ce n'est pas nécessairement suspect — certains domaines protègent ces données." : "WHOIS information could not be retrieved. Not necessarily suspicious — some domains protect this data." });
    }
  }

  if (nc.rdns && nc.rdns.status !== "skipped") {
    if (nc.rdns.is_known_cdn) {
      domainItems.push({ ok: true, text: fr ? `Le site est hébergé par un fournisseur reconnu (${nc.rdns.reverse_hostname || "CDN majeur"}). C'est typique des grands sites fiables.` : `The site is hosted by a recognized provider (${nc.rdns.reverse_hostname || "major CDN"}). This is typical of major reliable sites.` });
    } else if (nc.rdns.consistent === false) {
      domainItems.push({ ok: false, text: fr ? "L'adresse IP du serveur ne correspond pas au nom de domaine affiché. Cela peut indiquer une usurpation d'identité." : "The server's IP address doesn't match the displayed domain name. This may indicate identity spoofing." });
    }
  }

  if (domainItems.length > 0) {
    sections.push({
      title: fr ? "Identité du domaine" : "Domain identity",
      icon: Server,
      items: domainItems,
    });
  }

  // ── Section 4 : Typosquatting ──
  const typo = (result.content_details || {}).typosquatting || {};
  if (typo.is_typosquatting) {
    const techLabels = {
      substitution_caracteres: fr ? "Substitution de caractères (ex: 0 au lieu de o)" : "Character substitution (e.g., 0 instead of o)",
      faute_frappe: fr ? "Faute de frappe (lettre ajoutée, supprimée ou inversée)" : "Typo (added, removed, or swapped letter)",
      modification_multiple: fr ? "Modifications multiples du nom" : "Multiple name modifications",
      marque_dans_domaine: fr ? "Nom de marque intégré dans un domaine plus long" : "Brand name embedded in a longer domain",
      marque_avec_mot_piege: fr ? "Nom de marque combiné avec un mot piège (secure, login...)" : "Brand name combined with a trap word (secure, login...)",
      separation_par_tiret: fr ? "Nom de marque séparé par des tirets" : "Brand name split with hyphens",
    };
    sections.push({
      title: fr ? "Usurpation de nom (Typosquatting)" : "Name spoofing (Typosquatting)",
      icon: AlertTriangle,
      items: [
        { ok: false, text: fr
          ? `Ce domaine imite la marque "${typo.target_brand}" avec la technique : ${techLabels[typo.technique] || typo.technique}.`
          : `This domain mimics the brand "${typo.target_brand}" using: ${techLabels[typo.technique] || typo.technique}.`,
          tip: fr
            ? `Le(s) vrai(s) site(s) : ${(typo.legitimate_domains || []).join(", ")}. Vérifiez chaque lettre dans la barre d'adresse.`
            : `The real site(s): ${(typo.legitimate_domains || []).join(", ")}. Check every letter in the address bar.`
        },
      ],
    });
  }

  // ── Section 5 : Chaîne de redirections ──
  const chain = (result.content_details || {}).redirect_chain || [];
  if (chain.length >= 2) {
    const redirectItems = [];
    // Normalize domains (strip www. for comparison)
    const normalizeDomain = (d) => d ? d.replace(/^www\./, '') : '';
    const uniqueDomains = [...new Set(chain.map(h => normalizeDomain(h.domain)).filter(Boolean))];
    
    chain.forEach(hop => {
      const isRedirect = [301, 302, 303, 307, 308].includes(hop.status);
      const isFinal = hop.status === 200;
      redirectItems.push({
        ok: isFinal ? true : (isRedirect ? "warn" : false),
        text: fr
          ? `Étape ${hop.step} : ${isRedirect ? "Redirection" : (isFinal ? "Destination finale" : "Erreur")} (${hop.status}) → ${hop.domain || "?"}`
          : `Step ${hop.step}: ${isRedirect ? "Redirect" : (isFinal ? "Final destination" : "Error")} (${hop.status}) → ${hop.domain || "?"}`,
      });
    });

    // Only warn if redirected to a genuinely different domain (not just www)
    if (uniqueDomains.length >= 2) {
      redirectItems.push({
        ok: false,
        text: fr
          ? `Attention : le lien traverse ${uniqueDomains.length} domaines différents (${uniqueDomains.join(" → ")}).`
          : `Warning: the link crosses ${uniqueDomains.length} different domains (${uniqueDomains.join(" → ")}).`,
        tip: fr
          ? "Les sites légitimes redirigent rarement vers d'autres domaines. C'est un signe courant de phishing."
          : "Legitimate sites rarely redirect to other domains. This is a common sign of phishing.",
      });
    }

    sections.push({
      title: fr ? "Chaîne de redirections" : "Redirect chain",
      icon: Globe,
      items: redirectItems,
    });
  }

  // ── Section 6 : Contenu de la page ──
  const contentFindings = result.content_findings || [];
  const contentDetails = result.content_details || {};
  const contentItems = [];

  if (contentDetails.page_fetched === false) {
    contentItems.push({
      ok: null,
      text: fr
        ? "La page n'a pas pu être récupérée pour analyse. Le site est peut-être hors ligne ou bloque les accès automatiques."
        : "The page could not be fetched for analysis. The site might be offline or blocking automated access.",
    });
  } else if (contentDetails.page_fetched) {
    if (contentFindings.length === 0) {
      contentItems.push({
        ok: true,
        text: fr
          ? "Le contenu de la page ne présente aucun élément suspect. Pas de formulaire piégé, pas de script malveillant détecté."
          : "The page content shows no suspicious elements. No trapped forms, no malicious scripts detected.",
      });
    }

    contentFindings.forEach((finding) => {
      contentItems.push({
        ok: false,
        text: fr ? finding.description_fr : finding.description_en,
        tip: finding.tip_fr && fr ? finding.tip_fr : finding.tip_en || undefined,
      });
    });

    if (contentDetails.has_login_form && contentFindings.every(f => f.id !== "LOGIN_FORM")) {
      contentItems.push({
        ok: null,
        text: fr
          ? "La page contient un formulaire de connexion. Vérifiez que vous êtes bien sur le bon site avant de saisir vos identifiants."
          : "The page contains a login form. Make sure you're on the right site before entering your credentials.",
      });
    }

    if (contentDetails.brand_impersonation) {
      contentItems.push({
        ok: false,
        text: fr
          ? `La page tente de se faire passer pour « ${contentDetails.brand_impersonation} » alors que le domaine ne correspond pas.`
          : `The page is trying to impersonate "${contentDetails.brand_impersonation}" while the domain doesn't match.`,
        tip: fr
          ? `Le vrai site de ${contentDetails.brand_impersonation} n'utiliserait pas cette adresse.`
          : `The real ${contentDetails.brand_impersonation} site would not use this address.`,
      });
    }
  }

  if (contentItems.length > 0) {
    sections.push({
      title: fr ? "Contenu de la page" : "Page content",
      icon: FileSearch,
      items: contentItems,
    });
  }

  // ── Section 7 : Google Safe Browsing ──
  const sb = result.safe_browsing;
  if (sb && sb.checked) {
    const sbItems = [];
    if (sb.is_threat) {
      (sb.threats || []).forEach(threat => {
        sbItems.push({
          ok: false,
          text: fr
            ? `Google Safe Browsing signale cette URL comme : ${threat.label_fr}.`
            : `Google Safe Browsing flags this URL as: ${threat.label_en}.`,
          tip: fr
            ? "Google maintient une base de donnees mondiale de sites dangereux. Cette alerte est un signal fort."
            : "Google maintains a worldwide database of dangerous sites. This alert is a strong signal.",
        });
      });
    } else {
      sbItems.push({
        ok: true,
        text: fr
          ? "Cette URL ne figure pas dans la base de donnees Google Safe Browsing (malware, phishing, logiciels indesirables)."
          : "This URL is not listed in the Google Safe Browsing database (malware, phishing, unwanted software).",
        tip: fr
          ? "Google analyse des milliards d'URLs chaque jour. Ne pas etre signale est un bon indicateur."
          : "Google analyzes billions of URLs daily. Not being flagged is a good indicator.",
      });
    }
    sections.push({
      title: fr ? "Google Safe Browsing" : "Google Safe Browsing",
      icon: Shield,
      items: sbItems,
    });
  }

  // ── Section 8 : Phishing Kit Detection ──
  const kit = result.phishing_kit;
  if (kit && (kit.detected || kit.kits?.length > 0 || kit.structural_findings?.length > 0)) {
    const kitItems = [];
    (kit.kits || []).forEach(k => {
      kitItems.push({
        ok: false,
        text: fr ? k.description_fr : k.description_en,
        tip: fr
          ? "Les kits de phishing sont des outils tout-en-un utilises par les cybercriminels pour creer de faux sites en masse."
          : "Phishing kits are all-in-one tools used by cybercriminals to create fake sites at scale.",
      });
    });
    (kit.structural_findings || []).forEach(f => {
      kitItems.push({
        ok: false,
        text: fr ? f.description_fr : f.description_en,
      });
    });
    if (kitItems.length > 0) {
      sections.push({
        title: fr ? "Detection de kit de phishing" : "Phishing kit detection",
        icon: Fingerprint,
        items: kitItems,
      });
    }
  } else if (contentDetails.page_fetched) {
    // Show positive result if page was fetched but no kit detected
    sections.push({
      title: fr ? "Detection de kit de phishing" : "Phishing kit detection",
      icon: Fingerprint,
      items: [{
        ok: true,
        text: fr
          ? "Aucune signature de kit de phishing connu n'a ete detectee dans le code source de la page."
          : "No known phishing kit signature was detected in the page source code.",
      }],
    });
  }

  return sections;
}

/* =========================================================================
   Build the plain-language contextual summary (shown above details)
   ========================================================================= */
function buildSimpleSummary(result, lang) {
  const items = [];
  const fr = lang === "fr";
  const nc = result.network_checks || {};
  const fd = result.feature_details || {};

  if (result.traffic_light === "gray") {
    items.push({ type: "info", text: fr
      ? "Ce nom de domaine ne correspond a aucun serveur actif. Le site est inexistant ou a ete desactive."
      : "This domain name does not point to any active server. The site does not exist or has been taken down."
    });
    items.push({ type: "info", text: fr
      ? "Aucune analyse de contenu, de certificat ou de reputation n'est possible sans serveur actif."
      : "No content, certificate or reputation analysis is possible without an active server."
    });
    return items;
  }

  if (nc.dns && !nc.dns.exists) {
    items.push({ type: "danger", text: fr ? "Ce site n'existe pas : le nom de domaine ne correspond à aucun serveur." : "This site doesn't exist: the domain name doesn't resolve to any server." });
  }
  if (nc.ssl) {
    if (nc.ssl.status === "no_ssl" || nc.ssl.status === "invalid") {
      items.push({ type: "danger", text: fr ? "La connexion n'est pas sécurisée : aucun certificat SSL valide." : "The connection is not secure: no valid SSL certificate." });
    } else if (nc.ssl.valid) {
      items.push({ type: "safe", text: fr ? `Connexion sécurisée (${nc.ssl.protocol || "HTTPS"}) — certificat émis par ${nc.ssl.issuer || "un organisme reconnu"}.` : `Secure connection (${nc.ssl.protocol || "HTTPS"}) — certificate issued by ${nc.ssl.issuer || "a recognized authority"}.` });
    }
  }
  if (nc.whois) {
    const age = nc.whois.domain_age_days;
    if (age !== null && age < 30) {
      items.push({ type: "danger", text: fr ? `Domaine créé il y a seulement ${age} jour(s) — c'est souvent le signe d'un site de phishing.` : `Domain created only ${age} day(s) ago — often a sign of a phishing site.` });
    } else if (age !== null && age > 365) {
      items.push({ type: "safe", text: fr ? `Domaine établi depuis ${Math.floor(age / 365)} an(s).` : `Domain established for ${Math.floor(age / 365)} year(s).` });
    }
  }
  if (fd.has_https === 0 && !(nc.ssl && nc.ssl.valid)) {
    items.push({ type: "warning", text: fr ? "L'URL utilise HTTP au lieu de HTTPS : vos données ne sont pas chiffrées." : "The URL uses HTTP instead of HTTPS: your data is not encrypted." });
  }
  if (fd.suspicious_tld === 1) {
    items.push({ type: "warning", text: fr ? "L'extension du domaine est fréquemment utilisée par des sites frauduleux." : "The domain extension is frequently used by fraudulent sites." });
  }
  if (fd.has_ip === 1) {
    items.push({ type: "warning", text: fr ? "L'URL contient une adresse IP au lieu d'un nom de domaine." : "The URL contains an IP address instead of a domain name." });
  }
  if (fd.suspicious_keywords === 1) {
    items.push({ type: "warning", text: fr ? "L'URL contient des mots-clés associés au phishing (login, verify, secure...)." : "The URL contains keywords associated with phishing (login, verify, secure...)." });
  }
  if (fd.has_at === 1) {
    items.push({ type: "warning", text: fr ? "Le caractère « @ » dans l'URL peut masquer la vraie destination." : "The '@' character in the URL can mask the real destination." });
  }
  if (fd.shortened_url === 1) {
    items.push({ type: "warning", text: fr ? "URL raccourcie : la destination réelle est masquée." : "Shortened URL: the real destination is hidden." });
  }
  if (fd.domain_entropy > 3.5) {
    items.push({ type: "warning", text: fr ? "Le nom de domaine semble généré aléatoirement." : "The domain name appears randomly generated." });
  }

  // Typosquatting detection (from content analysis)
  const typo = (result.content_details || {}).typosquatting || {};
  if (typo.is_typosquatting) {
    const techLabels = {
      substitution_caracteres: fr ? "substitution de caractères" : "character substitution",
      faute_frappe: fr ? "faute de frappe" : "typo",
      modification_multiple: fr ? "modifications multiples" : "multiple modifications",
      marque_dans_domaine: fr ? "marque intégrée dans le domaine" : "brand embedded in domain",
      marque_avec_mot_piege: fr ? "marque + mot piège" : "brand + trap word",
      separation_par_tiret: fr ? "séparation par tiret" : "hyphen separation",
    };
    const technique = techLabels[typo.technique] || typo.technique;
    items.push({ type: "danger", text: fr
      ? `ALERTE TYPOSQUATTING : ce domaine imite la marque "${typo.target_brand}" (${technique}). Le vrai site est : ${(typo.legitimate_domains || []).join(", ")}.`
      : `TYPOSQUATTING ALERT: this domain mimics the brand "${typo.target_brand}" (${technique}). The real site is: ${(typo.legitimate_domains || []).join(", ")}.`
    });
  }

  // Redirect chain alert
  const chain = (result.content_details || {}).redirect_chain || [];
  if (chain.length >= 3) {
    const domains = [...new Set(chain.map(h => h.domain).filter(Boolean))];
    if (domains.length >= 2) {
      items.push({ type: "warning", text: fr
        ? `Ce lien traverse ${chain.length} redirections et ${domains.length} domaines différents avant d'atteindre sa destination.`
        : `This link goes through ${chain.length} redirects across ${domains.length} different domains before reaching its destination.`
      });
    }
  }

  // Content analysis findings
  const contentFindings = result.content_findings || [];
  const contentDetails = result.content_details || {};
  const criticalAndHighFindings = contentFindings.filter(f => f.severity === "high" || f.severity === "critical");
  if (criticalAndHighFindings.length > 0) {
    criticalAndHighFindings.forEach(f => {
      // Skip typosquatting finding (already shown above)
      if (f.id === "TYPOSQUATTING") return;
      items.push({ type: "danger", text: fr ? f.description_fr : f.description_en });
    });
  } else if (contentDetails.page_fetched && contentFindings.length === 0) {
    items.push({ type: "safe", text: fr ? "Le contenu de la page ne présente aucun élément suspect." : "The page content shows no suspicious elements." });
  }

  // Google Safe Browsing
  const sb = result.safe_browsing;
  if (sb && sb.checked) {
    if (sb.is_threat) {
      const threatLabels = (sb.threats || []).map(t => fr ? t.label_fr : t.label_en).join(", ");
      items.push({ type: "danger", text: fr
        ? `Google Safe Browsing signale ce site comme dangereux : ${threatLabels}.`
        : `Google Safe Browsing flags this site as dangerous: ${threatLabels}.`
      });
    } else {
      items.push({ type: "safe", text: fr
        ? "Non signale par Google Safe Browsing."
        : "Not flagged by Google Safe Browsing."
      });
    }
  }

  // Phishing Kit Detection
  const kit = result.phishing_kit;
  if (kit && kit.detected) {
    const kitNames = (kit.kits || []).map(k => k.name).join(", ");
    if (kitNames) {
      items.push({ type: "danger", text: fr
        ? `Kit de phishing detecte : ${kitNames}. Ce site utilise des outils de phishing connus.`
        : `Phishing kit detected: ${kitNames}. This site uses known phishing tools.`
      });
    } else if ((kit.structural_findings || []).length > 0) {
      items.push({ type: "warning", text: fr
        ? "Certaines structures de la page correspondent a des techniques de phishing connues."
        : "Some page structures match known phishing techniques."
      });
    }
  }

  // Company verification
  const cv = result.company_verification;
  if (cv && cv.verified && cv.company) {
    items.push({
      type: "safe",
      text: fr
        ? `Entreprise verifiee : ${cv.company.name} (SIREN ${cv.company.siren}) — ${cv.company.city || "France"}.`
        : `Verified company: ${cv.company.name} (SIREN ${cv.company.siren}) — ${cv.company.city || "France"}.`,
    });
  }

  // If everything looks good
  if (items.filter(i => i.type !== "safe").length === 0) {
    if (items.length === 0) {
      items.push({ type: "safe", text: fr ? "Aucun indicateur suspect détecté. Ce lien semble fiable." : "No suspicious indicators detected. This link appears reliable." });
    }
  }

  const seen = new Set();
  const deduped = items.filter(i => { if (seen.has(i.text)) return false; seen.add(i.text); return true; });

  // Prioritize: dangers first, then warnings, then limit safe items
  const dangers = deduped.filter(i => i.type === "danger");
  const warnings = deduped.filter(i => i.type === "warning");
  const infos = deduped.filter(i => i.type === "info");
  const safes = deduped.filter(i => i.type === "safe");

  if (infos.length > 0) return infos.slice(0, 5);

  const maxSafe = Math.max(1, 5 - dangers.length - warnings.length);
  return [...dangers, ...warnings, ...safes.slice(0, maxSafe)].slice(0, 5);
}

/* =========================================================================
   ResultPage Component
   ========================================================================= */
export default function ResultPage() {
  const location = useLocation();
  const navigate = useNavigate();
  const { t, lang } = useLanguage();
  const { token } = useAuth();
  const [showDetails, setShowDetails] = useState(false);
  const [feedbackSent, setFeedbackSent] = useState(false);
  const [showProtectTips, setShowProtectTips] = useState(false);
  const [openSections, setOpenSections] = useState({});
  const [screenshot, setScreenshot] = useState(null);
  const [screenshotLoading, setScreenshotLoading] = useState(false);
  const [officialScreenshot, setOfficialScreenshot] = useState(null);
  const [officialScreenshotLoading, setOfficialScreenshotLoading] = useState(false);
  const [showScreenshot, setShowScreenshot] = useState(false);

  const result = location.state?.result;

  const isTyposquatting = !!(result?.content_details?.typosquatting?.is_typosquatting || result?.typosquatting_target);
  const officialSite = result?.official_site || (result?.content_details?.typosquatting?.legitimate_domains?.[0] ? `https://www.${result.content_details.typosquatting.legitimate_domains[0]}` : null);
  const chain = result?.content_details?.redirect_chain || [];
  const finalDomain = chain.length > 0 ? (chain[chain.length - 1]?.domain || "") : "";
  const officialDomain = officialSite ? officialSite.replace(/^https?:\/\//, "").replace(/^www\./, "").split("/")[0] : "";
  const redirectsToOfficial = officialDomain && finalDomain.replace(/^www\./, "").includes(officialDomain.replace(/^www\./, ""));
  const showComparison = isTyposquatting && officialSite && !redirectsToOfficial;

  useEffect(() => {
    if (!result?.url) return;
    if (showComparison) {
      setShowScreenshot(true);
    }
  }, [result?.url, showComparison]);

  useEffect(() => {
    if (!showScreenshot || !result?.url) return;
    if (screenshot) return;
    setScreenshotLoading(true);
    axios.post(`${API}/screenshot`, { url: result.url })
      .then(res => {
        if (res.data?.captured && res.data?.image_base64) {
          setScreenshot(res.data.image_base64);
        }
      })
      .catch(() => {})
      .finally(() => setScreenshotLoading(false));
  }, [showScreenshot, result?.url, screenshot]);

  useEffect(() => {
    if (!showComparison || !officialSite || !showScreenshot) return;
    if (officialScreenshot) return;
    setOfficialScreenshotLoading(true);
    axios.post(`${API}/screenshot`, { url: officialSite })
      .then(res => {
        if (res.data?.captured && res.data?.image_base64) {
          setOfficialScreenshot(res.data.image_base64);
        }
      })
      .catch(() => {})
      .finally(() => setOfficialScreenshotLoading(false));
  }, [showComparison, officialSite, showScreenshot, officialScreenshot]);

  if (!result) { navigate("/"); return null; }
  const fr = lang === "fr";
  const isRed = result.traffic_light === "red";
  const summary = buildSimpleSummary(result, lang);
  const detailSections = buildDetailSections(result, lang);

  const trafficConfig = {
    gray: {
      icon: ShieldOff,
      bg: "bg-zinc-500/10",
      border: "border-zinc-400/30",
      pastilleBg: "bg-zinc-400",
      text: "text-zinc-500",
      glowClass: "",
      label_fr: "Hors ligne", label_en: "Offline",
      desc_fr: "Ce site n'existe pas ou est inaccessible. Le nom de domaine ne peut pas \u00eatre r\u00e9solu. Aucune analyse fiable n'est possible.",
      desc_en: "This site does not exist or is unreachable. The domain name cannot be resolved. No reliable analysis is possible.",
    },
    green: {
      icon: ShieldCheck,
      bg: "bg-safe/10",
      border: "border-safe/30",
      pastilleBg: "bg-safe",
      text: "text-safe",
      glowClass: "traffic-light-green",
      label_fr: "Sûr", label_en: "Safe",
      desc_fr: "Ce lien ne présente pas d'indicateur de phishing. Vous pouvez continuer en toute confiance.",
      desc_en: "This link shows no phishing indicators. You can proceed with confidence.",
    },
    yellow: {
      icon: ShieldAlert,
      bg: "bg-warning/10",
      border: "border-warning/30",
      pastilleBg: "bg-warning",
      text: "text-warning",
      glowClass: "traffic-light-yellow",
      label_fr: "Prudence", label_en: "Caution",
      desc_fr: "Ce lien comporte des éléments suspects. Réfléchissez avant de cliquer.",
      desc_en: "This link has suspicious elements. Think before clicking.",
    },
    red: {
      icon: ShieldX,
      bg: "bg-danger/10",
      border: "border-danger/30",
      pastilleBg: "bg-danger",
      text: "text-danger",
      glowClass: "traffic-light-red",
      label_fr: "Danger", label_en: "Danger",
      desc_fr: "Ce lien est potentiellement dangereux. Ne cliquez pas et ne saisissez aucune information.",
      desc_en: "This link is potentially dangerous. Do not click and do not enter any information.",
    },
  };
  const config = trafficConfig[result.traffic_light] || trafficConfig.green;
  const Icon = config.icon;

  const sendFeedback = async (isPhishing) => {
    try {
      const headers = token ? { Authorization: `Bearer ${token}` } : {};
      await axios.post(`${API}/feedback`, { analysis_id: result.id, is_phishing: isPhishing }, { headers });
      setFeedbackSent(true);
    } catch { /* ignore */ }
  };

  const xpEarned = result.user_xp !== undefined ? 10 : 0;
  const newBadges = result.new_badges || [];

  return (
    <div className="min-h-[calc(100vh-4rem)] py-8 sm:py-12" data-testid="result-page">
      <div className="max-w-2xl mx-auto px-4 sm:px-6">
        {/* Back */}
        <Button variant="ghost" onClick={() => navigate("/")} className="mb-6 gap-2 rounded-full" data-testid="back-to-home">
          <ArrowLeft className="w-4 h-4" /> {t("analyze_another")}
        </Button>

        {/* XP + Badge notification */}
        {(xpEarned > 0 || newBadges.length > 0) && (
          <div className="mb-4 flex flex-wrap gap-2 animate-slide-up" data-testid="xp-notification">
            {xpEarned > 0 && (
              <Badge className="gap-1.5 bg-amber-500/15 text-amber-700 dark:text-amber-400 border-amber-300 dark:border-amber-700 text-xs px-3 py-1">
                <Zap className="w-3 h-3" /> +{xpEarned} XP
              </Badge>
            )}
            {isRed && result.user_xp !== undefined && (
              <Badge className="gap-1.5 bg-red-500/15 text-red-700 dark:text-red-400 border-red-300 dark:border-red-700 text-xs px-3 py-1">
                <ShieldX className="w-3 h-3" /> +25 XP ({lang === "fr" ? "menace détectée" : "threat detected"})
              </Badge>
            )}
            {newBadges.map((badge) => (
              <Badge key={badge.id} className="gap-1.5 bg-violet-500/15 text-violet-700 dark:text-violet-400 border-violet-300 dark:border-violet-700 text-xs px-3 py-1" data-testid={`new-badge-${badge.id}`}>
                <Star className="w-3 h-3" /> {lang === "fr" ? badge.name_fr : badge.name_en}
              </Badge>
            ))}
          </div>
        )}

        {/* MAIN RESULT */}
        <Card className={`rounded-2xl border-2 ${config.border} ${config.bg} mb-6 animate-scale-pop overflow-hidden`} data-testid="result-card">
          <CardContent className="p-8 sm:p-10">
            <div className="flex items-center gap-5 mb-5">
              <div className={`w-16 h-16 rounded-full ${config.pastilleBg} ${config.glowClass} flex items-center justify-center flex-shrink-0`} data-testid="result-pastille">
                <Icon className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className={`text-2xl sm:text-3xl font-bold ${config.text}`} style={{ fontFamily: 'Outfit' }} data-testid="result-title">
                  {lang === "fr" ? config.label_fr : config.label_en}
                </h1>
                <p className="text-muted-foreground text-sm mt-1">
                  {lang === "fr" ? config.desc_fr : config.desc_en}
                </p>
              </div>
            </div>
            <div className="font-mono text-sm bg-background/80 rounded-xl p-4 break-all border flex items-center gap-3" data-testid="analyzed-url">
              <Search className="w-4 h-4 text-muted-foreground flex-shrink-0" />
              <span className="break-all">{result.url}</span>
            </div>
          </CardContent>
        </Card>

        {/* PAGE SCREENSHOT — collapsible + comparaison typosquatting */}
        <Card className="rounded-xl mb-6 animate-slide-up overflow-hidden" data-testid="screenshot-card">
          <CardContent className="p-0">
            <button
              onClick={() => setShowScreenshot(p => !p)}
              className="w-full flex items-center justify-between p-4 hover:bg-muted/40 transition-colors"
              data-testid="screenshot-toggle"
            >
              <div className="flex items-center gap-2">
                <Camera className="w-4 h-4 text-muted-foreground" />
                <span className="text-sm font-medium">
                  {showComparison
                    ? (fr ? "Comparaison visuelle — site suspect vs site officiel" : "Visual comparison — suspect site vs official site")
                    : (fr ? "Apercu de la page" : "Page preview")}
                </span>
                {showComparison && (
                  <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300">
                    TYPOSQUATTING
                  </span>
                )}
              </div>
              {showScreenshot ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
            </button>

            {showScreenshot && (
              <div className="px-4 pb-4">
                {showComparison ? (
                  /* ── Comparison mode: side by side ── */
                  <div>
                    <p className="text-xs text-muted-foreground mb-3">
                      {fr
                        ? "Le domaine analyse ressemble fortement a un site officiel connu. Comparez les deux pages pour identifier les differences."
                        : "The analyzed domain strongly resembles a known official site. Compare both pages to spot the differences."}
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3" data-testid="screenshot-comparison">
                      {/* Suspect site */}
                      <div>
                        <div className="flex items-center gap-1.5 mb-2">
                          <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />
                          <span className="text-xs font-semibold text-amber-600 dark:text-amber-400">
                            {fr ? "Site analyse (suspect)" : "Analyzed site (suspect)"}
                          </span>
                        </div>
                        {screenshotLoading ? (
                          <div className="flex items-center justify-center h-40 bg-muted/30 rounded-lg border border-dashed border-amber-300">
                            <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />
                          </div>
                        ) : screenshot ? (
                          <div className="relative rounded-lg overflow-hidden border border-amber-300 shadow-sm">
                            <img src={`data:image/jpeg;base64,${screenshot}`} alt="Suspect" className="w-full h-auto" style={{ maxHeight: "280px", objectFit: "cover", objectPosition: "top" }} />
                            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent px-2 py-1.5">
                              <p className="text-white text-[10px] truncate">{result.url}</p>
                            </div>
                          </div>
                        ) : (
                          <div className="flex items-center justify-center h-40 bg-muted/30 rounded-lg border border-dashed"><p className="text-xs text-muted-foreground">{fr ? "Non disponible" : "Unavailable"}</p></div>
                        )}
                      </div>

                      {/* Official site */}
                      <div>
                        <div className="flex items-center gap-1.5 mb-2">
                          <CheckCircle className="w-3.5 h-3.5 text-emerald-500" />
                          <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400">
                            {fr ? "Site officiel" : "Official site"}
                          </span>
                        </div>
                        {officialScreenshotLoading ? (
                          <div className="flex items-center justify-center h-40 bg-muted/30 rounded-lg border border-dashed border-emerald-300">
                            <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />
                          </div>
                        ) : officialScreenshot ? (
                          <div className="relative rounded-lg overflow-hidden border border-emerald-300 shadow-sm">
                            <img src={`data:image/jpeg;base64,${officialScreenshot}`} alt="Official" className="w-full h-auto" style={{ maxHeight: "280px", objectFit: "cover", objectPosition: "top" }} />
                            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent px-2 py-1.5">
                              <p className="text-white text-[10px] truncate">{officialSite}</p>
                            </div>
                          </div>
                        ) : (
                          <div className="flex items-center justify-center h-40 bg-muted/30 rounded-lg border border-dashed"><p className="text-xs text-muted-foreground">{fr ? "Non disponible" : "Unavailable"}</p></div>
                        )}
                      </div>
                    </div>
                  </div>
                ) : (
                  /* ── Normal single screenshot ── */
                  <>
                    {screenshotLoading ? (
                      <div className="flex items-center justify-center h-44 bg-muted/30 rounded-lg border border-dashed" data-testid="screenshot-loading">
                        <div className="flex flex-col items-center gap-2 text-muted-foreground">
                          <Loader2 className="w-5 h-5 animate-spin" />
                          <span className="text-xs">{fr ? "Capture en cours..." : "Capturing..."}</span>
                        </div>
                      </div>
                    ) : screenshot ? (
                      <div className="relative rounded-lg overflow-hidden border shadow-sm" data-testid="screenshot-image">
                        <img
                          src={`data:image/jpeg;base64,${screenshot}`}
                          alt={fr ? "Capture de la page analysee" : "Analyzed page screenshot"}
                          className="w-full h-auto rounded-lg"
                          style={{ maxHeight: "360px", objectFit: "cover", objectPosition: "top" }}
                        />
                        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-3">
                          <p className="text-white text-xs truncate">{result.url}</p>
                        </div>
                      </div>
                    ) : (
                      <div className="flex items-center justify-center h-44 bg-muted/30 rounded-lg border border-dashed" data-testid="screenshot-unavailable">
                        <p className="text-xs text-muted-foreground">{fr ? "Apercu non disponible" : "Preview unavailable"}</p>
                      </div>
                    )}
                  </>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* COMPANY VERIFICATION BADGE — only if verified (subtle inline) */}
        {result.company_verification?.verified && result.company_verification?.company && (
          <div className="flex items-center gap-2 px-4 py-2.5 mb-4 rounded-xl bg-emerald-50/80 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-900/30 animate-slide-up" data-testid="company-verified-card">
            <CheckCircle className="w-4 h-4 text-emerald-500 flex-shrink-0" />
            <p className="text-sm">
              <span className="font-medium">{result.company_verification.company.name}</span>
              <span className="text-muted-foreground"> — {lang === "fr" ? "entreprise verifiee" : "verified company"}</span>
            </p>
          </div>
        )}

        {/* TYPOSQUATTING ALERT — only if detected (prominent) */}
        {result.typosquatting_target && (
          <Card className="rounded-xl border-2 border-amber-200 dark:border-amber-800 bg-amber-50 dark:bg-amber-950/30 mb-6 animate-slide-up" data-testid="typosquatting-alert">
            <CardContent className="p-5">
              <div className="flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-bold text-amber-700 dark:text-amber-400 text-sm mb-1">{t("typosquatting_alert")}</h3>
                  <p className="text-sm text-muted-foreground mb-2">
                    {lang === "fr" ? result.typosquatting_explanation_fr : result.typosquatting_explanation_en}
                  </p>
                  <a href={result.official_site} target="_blank" rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:underline">
                    {t("official_site")}: {result.official_site} <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* CONTEXTUAL SUMMARY — limited to 5 essential points */}
        {summary.length > 0 && (
          <Card className="rounded-xl mb-6 animate-slide-up stagger-1" data-testid="context-summary-card">
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2" style={{ fontFamily: 'Outfit' }}>
                <Info className="w-5 h-5 text-primary" />
                {lang === "fr" ? "Notre analyse en bref" : "Our analysis at a glance"}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {summary.map((item, i) => (
                <div key={i} className={`flex items-start gap-3 p-3 rounded-lg border ${
                  item.type === "danger" ? "bg-red-50/80 dark:bg-red-950/20 border-red-100 dark:border-red-900/30" :
                  item.type === "warning" ? "bg-amber-50/80 dark:bg-amber-950/20 border-amber-100 dark:border-amber-900/30" :
                  item.type === "info" ? "bg-zinc-50/80 dark:bg-zinc-900/20 border-zinc-200 dark:border-zinc-700/30" :
                  "bg-emerald-50/80 dark:bg-emerald-950/20 border-emerald-100 dark:border-emerald-900/30"
                }`}>
                  {item.type === "danger" ? <XCircle className="w-4 h-4 text-red-500 mt-0.5 flex-shrink-0" /> :
                   item.type === "warning" ? <AlertTriangle className="w-4 h-4 text-amber-500 mt-0.5 flex-shrink-0" /> :
                   item.type === "info" ? <Info className="w-4 h-4 text-zinc-400 mt-0.5 flex-shrink-0" /> :
                   <CheckCircle className="w-4 h-4 text-emerald-500 mt-0.5 flex-shrink-0" />}
                  <p className="text-sm">{item.text}</p>
                </div>
              ))}
            </CardContent>
          </Card>
        )}

        {/* PROTECTION TIPS — only for danger */}
        {isRed && (
          <Card className="rounded-xl mb-6 animate-slide-up stagger-2" data-testid="protect-tips-card">
            <CardHeader className="pb-3 cursor-pointer" onClick={() => setShowProtectTips(!showProtectTips)}>
              <CardTitle className="text-base flex items-center justify-between" style={{ fontFamily: 'Outfit' }}>
                <span className="flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-primary" />
                  {lang === "fr" ? "Que faire maintenant ?" : "What to do now?"}
                </span>
                {showProtectTips ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </CardTitle>
            </CardHeader>
            {showProtectTips && (
              <CardContent className="space-y-2">
                {(lang === "fr" ? [
                  "Ne cliquez surtout pas sur ce lien et fermez l'onglet.",
                  "Ne saisissez aucune information personnelle.",
                  "Accedez au site officiel en tapant vous-meme l'adresse.",
                  "Signalez ce lien sur signal-spam.fr ou phishing-initiative.fr.",
                ] : [
                  "Do not click on this link and close the tab.",
                  "Do not enter any personal information.",
                  "Access the official site by typing the address yourself.",
                  "Report this link on signal-spam.fr or phishing-initiative.fr.",
                ]).map((tip, i) => (
                  <div key={i} className="flex items-center gap-3 p-3 rounded-lg bg-primary/5">
                    <span className="w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xs font-bold flex-shrink-0">{i + 1}</span>
                    <p className="text-sm">{tip}</p>
                  </div>
                ))}
              </CardContent>
            )}
          </Card>
        )}

        {/* TECHNICAL REPORT — single toggle for all details */}
        <Card className="rounded-xl mb-6 animate-slide-up stagger-3" data-testid="details-card">
          <CardContent className="p-0">
            <button
              onClick={() => setShowDetails(!showDetails)}
              className="w-full flex items-center justify-between p-5 hover:bg-muted/30 transition-colors rounded-xl"
              data-testid="details-toggle"
            >
              <div className="flex items-center gap-2">
                <Code className="w-4 h-4 text-muted-foreground" />
                <span className="text-sm font-medium">{lang === "fr" ? "Rapport technique" : "Technical report"}</span>
              </div>
              <ChevronDown className={`w-4 h-4 text-muted-foreground transition-transform ${showDetails ? 'rotate-180' : ''}`} />
            </button>

            {showDetails && (
              <div className="px-5 pb-5 space-y-2 border-t pt-4">
                <p className="text-xs text-muted-foreground mb-3">
                  {fr
                    ? "Details des verifications effectuees par nos algorithmes. Destiné aux utilisateurs avances."
                    : "Details of checks performed by our algorithms. Intended for advanced users."}
                </p>
                {detailSections.map((section, si) => {
                  const okCount = section.items.filter(i => i.ok === true).length;
                  const warnCount = section.items.filter(i => i.ok === "warn").length;
                  const badCount = section.items.filter(i => i.ok === false).length;

                  const sectionBadge = badCount > 0
                    ? { color: "text-red-500 bg-red-50 dark:bg-red-950/30", label: fr ? `${badCount} alerte${badCount > 1 ? "s" : ""}` : `${badCount} alert${badCount > 1 ? "s" : ""}` }
                    : warnCount > 0
                    ? { color: "text-amber-600 bg-amber-50 dark:bg-amber-950/30", label: fr ? `${warnCount} attention` : `${warnCount} note${warnCount > 1 ? "s" : ""}` }
                    : { color: "text-emerald-600 bg-emerald-50 dark:bg-emerald-950/30", label: fr ? `${okCount} OK` : `${okCount} OK` };

                  const isOpen = openSections[si] || false;

                  return (
                    <div key={si} className="border rounded-lg overflow-hidden" data-testid={`detail-section-${si}`}>
                      <button
                        onClick={() => setOpenSections(prev => ({ ...prev, [si]: !prev[si] }))}
                        className="w-full flex items-center justify-between p-3.5 hover:bg-muted/20 transition-colors text-left"
                      >
                        <div className="flex items-center gap-2.5">
                          <section.icon className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                          <span className="text-sm font-medium">{section.title}</span>
                          <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${sectionBadge.color}`}>
                            {sectionBadge.label}
                          </span>
                        </div>
                        <ChevronDown className={`w-4 h-4 text-muted-foreground transition-transform flex-shrink-0 ${isOpen ? 'rotate-180' : ''}`} />
                      </button>
                      {isOpen && (
                        <div className="px-3.5 pb-3.5 space-y-1.5 border-t">
                          {section.items.map((item, ii) => (
                            <div key={ii} className={`rounded-lg text-sm ${
                              item.ok === true ? "bg-emerald-50/60 dark:bg-emerald-950/15 border border-emerald-100/60 dark:border-emerald-900/20" :
                              item.ok === "warn" ? "bg-amber-50/60 dark:bg-amber-950/15 border border-amber-100/60 dark:border-amber-900/20" :
                              item.ok === false ? "bg-red-50/60 dark:bg-red-950/15 border border-red-100/60 dark:border-red-900/20" :
                              "bg-muted/30 border"
                            } mt-1.5`}>
                              <div className="flex items-start gap-2.5 p-2.5">
                                {item.ok === true ? <CheckCircle className="w-3.5 h-3.5 text-emerald-500 mt-0.5 flex-shrink-0" /> :
                                 item.ok === "warn" ? <AlertTriangle className="w-3.5 h-3.5 text-amber-500 mt-0.5 flex-shrink-0" /> :
                                 item.ok === false ? <XCircle className="w-3.5 h-3.5 text-red-500 mt-0.5 flex-shrink-0" /> :
                                 <Info className="w-3.5 h-3.5 text-muted-foreground mt-0.5 flex-shrink-0" />}
                                <p className="text-xs leading-relaxed">{item.text}</p>
                              </div>
                              {item.tip && (
                                <div className="px-2.5 pb-2.5 pt-0 ml-6">
                                  <p className="text-xs text-muted-foreground flex items-start gap-1.5">
                                    <Lightbulb className="w-3 h-3 mt-0.5 flex-shrink-0 text-amber-500" />
                                    {item.tip}
                                  </p>
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        {/* FEEDBACK */}
        <Card className="rounded-xl mb-8 animate-slide-up stagger-4" data-testid="feedback-card">
          <CardContent className="p-5 text-center">
            {feedbackSent ? (
              <p className="text-emerald-600 dark:text-emerald-400 font-medium text-sm" data-testid="feedback-thanks">{t("feedback_thanks")}</p>
            ) : (
              <div>
                <p className="text-sm text-muted-foreground mb-3">
                  {lang === "fr" ? "Ce résultat vous semble-t-il correct ?" : "Does this result seem correct to you?"}
                </p>
                <div className="flex items-center justify-center gap-3">
                  <Button variant="outline" size="sm" onClick={() => sendFeedback(isRed)} className="gap-2 rounded-full" data-testid="feedback-correct-btn">
                    <ThumbsUp className="w-3.5 h-3.5" /> {t("feedback_correct")}
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => sendFeedback(!isRed)} className="gap-2 rounded-full" data-testid="feedback-incorrect-btn">
                    <ThumbsDown className="w-3.5 h-3.5" /> {t("feedback_incorrect")}
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
