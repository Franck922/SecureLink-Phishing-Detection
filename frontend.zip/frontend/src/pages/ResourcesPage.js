import { useState, useEffect } from "react";
import { useAuth } from "../contexts/AuthContext";
import { useLanguage } from "../contexts/LanguageContext";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { Progress } from "../components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import {
  GraduationCap, BookOpen, Shield, Lock, Users, Award, FileText, Flag, ExternalLink,
  CheckCircle, ChevronRight, Activity
} from "lucide-react";
import axios from "axios";

const API = `${process.env.REACT_APP_BACKEND_URL}/api`;

const iconMap = {
  "graduation-cap": GraduationCap, "book-open": BookOpen, shield: Shield, lock: Lock,
  users: Users, award: Award, "file-text": FileText, flag: Flag,
};

export default function ResourcesPage() {
  const { token } = useAuth();
  const { t, lang } = useLanguage();
  const [resources, setResources] = useState([]);
  const [hygieneScore, setHygieneScore] = useState(null);
  const [loading, setLoading] = useState(true);
  const [completing, setCompleting] = useState(null);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    const headers = token ? { Authorization: `Bearer ${token}` } : {};
    try {
      const [resRes, hygRes] = await Promise.allSettled([
        axios.get(`${API}/resources`, { headers }),
        token ? axios.get(`${API}/user/hygiene-score`, { headers }) : Promise.resolve(null),
      ]);
      if (resRes.status === "fulfilled") setResources(resRes.value.data.resources);
      if (hygRes.status === "fulfilled" && hygRes.value) setHygieneScore(hygRes.value.data);
    } catch { /* ignore */ }
    setLoading(false);
  };

  const markComplete = async (resourceId) => {
    if (!token) return;
    setCompleting(resourceId);
    try {
      await axios.post(`${API}/resources/complete`, { resource_id: resourceId }, { headers: { Authorization: `Bearer ${token}` } });
      fetchData();
    } catch { /* ignore */ }
    setCompleting(null);
  };

  const scoreColor = (total) => {
    if (total >= 80) return "text-emerald-600 dark:text-emerald-400";
    if (total >= 60) return "text-blue-600 dark:text-blue-400";
    if (total >= 40) return "text-amber-600 dark:text-amber-400";
    return "text-red-600 dark:text-red-400";
  };

  const scoreRingColor = (total) => {
    if (total >= 80) return "border-emerald-500";
    if (total >= 60) return "border-blue-500";
    if (total >= 40) return "border-amber-500";
    return "border-red-500";
  };

  if (loading) return <div className="flex items-center justify-center min-h-[50vh]"><div className="w-8 h-8 border-4 border-primary/30 border-t-primary rounded-full animate-spin" /></div>;

  const sources = [...new Set(resources.map(r => r.source))];

  return (
    <div className="min-h-[calc(100vh-4rem)] py-8 sm:py-12" data-testid="resources-page">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10 animate-slide-up">
          <h1 className="text-2xl sm:text-3xl font-bold mb-2" style={{ fontFamily: 'Outfit' }} data-testid="resources-title">
            {lang === "fr" ? "Ressources & Formation" : "Resources & Training"}
          </h1>
          <p className="text-muted-foreground text-sm max-w-xl mx-auto">
            {lang === "fr"
              ? "Formations officielles, guides pratiques et outils pour renforcer votre cybersecurite."
              : "Official training, practical guides and tools to strengthen your cybersecurity."}
          </p>
        </div>

        {/* Hygiene Score — only for logged-in users */}
        {hygieneScore && (
          <Card className="rounded-xl mb-8 animate-slide-up stagger-1" data-testid="hygiene-score-card">
            <CardContent className="p-6">
              <div className="flex items-center gap-6">
                <div className="flex-shrink-0 text-center">
                  <div className={`w-20 h-20 rounded-full border-4 ${scoreRingColor(hygieneScore.total)} flex items-center justify-center`}>
                    <span className={`text-2xl font-bold ${scoreColor(hygieneScore.total)}`}>{hygieneScore.total}</span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1.5">
                    {lang === "fr" ? hygieneScore.grade_fr : hygieneScore.grade_en}
                  </p>
                </div>
                <div className="flex-1 space-y-2">
                  <p className="text-sm font-medium mb-3" style={{ fontFamily: 'Outfit' }}>
                    <Activity className="w-4 h-4 inline mr-1.5" />
                    {lang === "fr" ? "Votre score d'hygiene numerique" : "Your digital hygiene score"}
                  </p>
                  {Object.values(hygieneScore.breakdown).map((item) => (
                    <div key={item.label_en} className="flex items-center gap-3">
                      <span className="text-xs text-muted-foreground w-40 flex-shrink-0">{lang === "fr" ? item.label_fr : item.label_en}</span>
                      <Progress value={(item.score / item.max) * 100} className="h-1.5 flex-1" />
                      <span className="text-xs font-medium w-10 text-right">{item.score}/{item.max}</span>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <Tabs defaultValue="external" className="animate-slide-up stagger-2">
          <TabsList className="grid w-full grid-cols-2 max-w-md mx-auto mb-8 rounded-full" data-testid="resources-tabs">
            <TabsTrigger value="external" className="rounded-full text-sm">
              {lang === "fr" ? "Formations officielles" : "Official training"}
            </TabsTrigger>
            <TabsTrigger value="internal" className="rounded-full text-sm">
              {lang === "fr" ? "Modules SecureLink" : "SecureLink modules"}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="external">
            {sources.map(source => (
              <div key={source} className="mb-8">
                <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">{source}</h3>
                <div className="space-y-3">
                  {resources.filter(r => r.source === source).map((resource) => {
                    const RIcon = iconMap[resource.icon] || BookOpen;
                    return (
                      <Card key={resource.id} className="rounded-xl hover:shadow-sm transition-shadow" data-testid={`resource-${resource.id}`}>
                        <CardContent className="p-5 flex items-start gap-4">
                          <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${resource.completed ? 'bg-emerald-50 dark:bg-emerald-950/30 text-emerald-500' : 'bg-primary/10 text-primary'}`}>
                            {resource.completed ? <CheckCircle className="w-5 h-5" /> : <RIcon className="w-5 h-5" />}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <h4 className="font-medium text-sm">{lang === "fr" ? resource.title_fr : resource.title_en}</h4>
                              {resource.completed && (
                                <Badge variant="outline" className="text-emerald-600 border-emerald-300 text-xs">
                                  {lang === "fr" ? "Fait" : "Done"}
                                </Badge>
                              )}
                            </div>
                            <p className="text-xs text-muted-foreground line-clamp-2 mb-2">
                              {lang === "fr" ? resource.description_fr : resource.description_en}
                            </p>
                            <div className="flex items-center gap-3 text-xs text-muted-foreground">
                              <span>{lang === "fr" ? resource.duration_fr : resource.duration_en}</span>
                              <span>{"*".repeat(resource.difficulty)}</span>
                              {token && <span className="text-primary font-medium">+{resource.xp_reward} XP</span>}
                            </div>
                          </div>
                          <div className="flex flex-col gap-2 flex-shrink-0">
                            <a href={resource.url} target="_blank" rel="noopener noreferrer">
                              <Button variant="outline" size="sm" className="rounded-full gap-1.5 text-xs" data-testid={`resource-link-${resource.id}`}>
                                {lang === "fr" ? "Ouvrir" : "Open"} <ExternalLink className="w-3 h-3" />
                              </Button>
                            </a>
                            {token && !resource.completed && (
                              <Button size="sm" variant="ghost" className="rounded-full text-xs text-primary"
                                onClick={() => markComplete(resource.id)} disabled={completing === resource.id}
                                data-testid={`resource-complete-${resource.id}`}>
                                {completing === resource.id ? "..." : (lang === "fr" ? "J'ai termine" : "I'm done")}
                              </Button>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </div>
            ))}
          </TabsContent>

          <TabsContent value="internal">
            <div className="text-center py-8">
              <GraduationCap className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
              <p className="text-sm text-muted-foreground mb-4">
                {lang === "fr" ? "Retrouvez nos modules interactifs avec quiz dans l'E-Learning." : "Find our interactive modules with quizzes in E-Learning."}
              </p>
              <a href="/e-learning">
                <Button variant="outline" className="rounded-full gap-2">
                  {lang === "fr" ? "Aller à l'E-Learning" : "Go to E-Learning"} <ChevronRight className="w-4 h-4" />
                </Button>
              </a>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
