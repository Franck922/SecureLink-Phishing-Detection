import { useState, useEffect } from "react";
import { useLanguage } from "../contexts/LanguageContext";
import { Card, CardContent } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Button } from "../components/ui/button";
import {
  Newspaper, AlertTriangle, ExternalLink, Clock, Shield, Monitor,
  RefreshCw, Zap, Mail, QrCode, Phone, Globe
} from "lucide-react";
import axios from "axios";

const API = `${process.env.REACT_APP_BACKEND_URL}/api`;

const categoryIcons = {
  phishing: Mail, smishing: Phone, quishing: QrCode, vishing: Phone,
};

export default function NewsPage() {
  const { lang } = useLanguage();
  const [articles, setArticles] = useState([]);
  const [trends, setTrends] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [langFilter, setLangFilter] = useState("all");
  const [catFilter, setCatFilter] = useState("all");

  useEffect(() => { fetchNews(); }, []);

  const fetchNews = async () => {
    try {
      const res = await axios.get(`${API}/news`);
      setArticles(res.data.articles || []);
      setTrends(res.data.trends || []);
    } catch { /* ignore */ }
    setLoading(false);
  };

  const refresh = async () => {
    setRefreshing(true);
    await fetchNews();
    setRefreshing(false);
  };

  const filteredArticles = articles.filter((a) => {
    if (langFilter !== "all" && a.source_lang !== langFilter) return false;
    if (catFilter !== "all" && a.category !== catFilter) return false;
    return true;
  });

  const filteredTrends = trends;

  const sourceIcon = (icon) => {
    if (icon === "shield") return Shield;
    if (icon === "monitor") return Monitor;
    return Newspaper;
  };

  if (loading) return <div className="flex items-center justify-center min-h-[50vh]"><div className="w-8 h-8 border-4 border-primary/30 border-t-primary rounded-full animate-spin" /></div>;

  return (
    <div className="min-h-[calc(100vh-4rem)] py-8 sm:py-12" data-testid="news-page">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8 animate-slide-up">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold" style={{ fontFamily: 'Outfit' }} data-testid="news-title">
              {lang === "fr" ? "Veille Cyber" : "Cyber Watch"}
            </h1>
            <p className="text-muted-foreground text-sm mt-1">
              {lang === "fr" ? "Actualités et alertes en temps réel" : "Real-time news and alerts"}
            </p>
          </div>
          <Button variant="outline" size="sm" onClick={refresh} disabled={refreshing} className="rounded-full gap-2" data-testid="refresh-news-btn">
            <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin' : ''}`} />
            {lang === "fr" ? "Actualiser" : "Refresh"}
          </Button>
        </div>

        {/* ====== GLOBAL FILTERS ====== */}
        <div className="flex flex-wrap gap-2 mb-6 animate-slide-up stagger-1" data-testid="news-filters">
          {/* Language filter */}
          <div className="flex gap-1 bg-muted rounded-full p-0.5">
            {[
              { val: "all", label: lang === "fr" ? "Toutes langues" : "All langs", icon: Globe },
              { val: "fr", label: "FR", icon: null },
              { val: "en", label: "EN", icon: null },
            ].map((f) => (
              <Button
                key={f.val}
                variant={langFilter === f.val ? "secondary" : "ghost"}
                size="sm"
                className="rounded-full text-xs h-7 px-3"
                onClick={() => setLangFilter(f.val)}
                data-testid={`lang-filter-${f.val}`}
              >
                {f.icon && <f.icon className="w-3 h-3 mr-1" />}
                {f.label}
              </Button>
            ))}
          </div>
          {/* Category filter */}
          <div className="flex gap-1 bg-muted rounded-full p-0.5">
            {[
              { val: "all", label: lang === "fr" ? "Tout" : "All" },
              { val: "alertes", label: lang === "fr" ? "Alertes" : "Alerts" },
              { val: "actualites", label: lang === "fr" ? "Actualités" : "News" },
            ].map((f) => (
              <Button
                key={f.val}
                variant={catFilter === f.val ? "secondary" : "ghost"}
                size="sm"
                className="rounded-full text-xs h-7 px-3"
                onClick={() => setCatFilter(f.val)}
                data-testid={`cat-filter-${f.val}`}
              >
                {f.label}
              </Button>
            ))}
          </div>
        </div>

        {/* ====== TREND ALERTS — improved readability ====== */}
        {filteredTrends.length > 0 && (
          <div className="mb-8 animate-slide-up stagger-1">
            <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2">
              <Zap className="w-4 h-4" />
              {lang === "fr" ? "Alertes en cours" : "Current alerts"}
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {filteredTrends.map((trend) => {
                const CatIcon = categoryIcons[trend.category] || AlertTriangle;
                const isHigh = trend.severity === "high";
                const isMedium = trend.severity === "medium";
                return (
                  <Card key={trend.id} className={`rounded-xl overflow-hidden ${
                    isHigh ? "border-red-400/60 dark:border-red-600/50" :
                    isMedium ? "border-amber-400/60 dark:border-amber-600/50" :
                    "border-blue-400/60 dark:border-blue-600/50"
                  }`} data-testid={`trend-${trend.id}`}>
                    {/* Colored top accent bar */}
                    <div className={`h-1 ${
                      isHigh ? "bg-red-500" : isMedium ? "bg-amber-500" : "bg-blue-500"
                    }`} />
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <div className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${
                          isHigh ? "bg-red-500/15 dark:bg-red-500/20" :
                          isMedium ? "bg-amber-500/15 dark:bg-amber-500/20" :
                          "bg-blue-500/15 dark:bg-blue-500/20"
                        }`}>
                          <CatIcon className={`w-4 h-4 ${
                            isHigh ? "text-red-600 dark:text-red-400" :
                            isMedium ? "text-amber-600 dark:text-amber-400" :
                            "text-blue-600 dark:text-blue-400"
                          }`} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h3 className={`text-sm font-bold mb-1 ${
                            isHigh ? "text-red-700 dark:text-red-300" :
                            isMedium ? "text-amber-700 dark:text-amber-300" :
                            "text-blue-700 dark:text-blue-300"
                          }`}>
                            {lang === "fr" ? trend.title_fr : trend.title_en}
                          </h3>
                          <p className="text-xs text-foreground/70 dark:text-foreground/60 line-clamp-2 leading-relaxed">
                            {lang === "fr" ? trend.description_fr : trend.description_en}
                          </p>
                          <div className="flex items-center gap-2 mt-2.5">
                            <Badge className={`text-[10px] font-semibold border-0 ${
                              isHigh ? "bg-red-500/15 text-red-700 dark:text-red-300" :
                              isMedium ? "bg-amber-500/15 text-amber-700 dark:text-amber-300" :
                              "bg-blue-500/15 text-blue-700 dark:text-blue-300"
                            }`}>
                              {isHigh ? (lang === "fr" ? "Critique" : "Critical") : isMedium ? (lang === "fr" ? "Moyen" : "Medium") : (lang === "fr" ? "Faible" : "Low")}
                            </Badge>
                            <Badge variant="outline" className="text-[10px] capitalize">{trend.category}</Badge>
                            <span className="text-[10px] text-muted-foreground ml-auto">{trend.date}</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        )}

        {/* ====== NEWS FEED ====== */}
        <div className="animate-slide-up stagger-2">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-2">
              <Newspaper className="w-4 h-4" />
              {lang === "fr" ? "Fil d'actualité" : "News feed"}
              {filteredArticles.length > 0 && (
                <span className="text-xs font-normal ml-1">({filteredArticles.length})</span>
              )}
            </h2>
          </div>

          {filteredArticles.length === 0 ? (
            <Card className="rounded-xl">
              <CardContent className="p-8 text-center">
                <Newspaper className="w-8 h-8 text-muted-foreground mx-auto mb-3" />
                <p className="text-sm text-muted-foreground">
                  {lang === "fr" ? "Aucun article disponible pour ce filtre." : "No articles available for this filter."}
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-2">
              {filteredArticles.map((article, i) => {
                const SIcon = sourceIcon(article.source_icon);
                return (
                  <a key={`${article.link}-${i}`} href={article.link} target="_blank" rel="noopener noreferrer"
                    className="block" data-testid={`news-article-${i}`}>
                    <Card className="rounded-xl hover:shadow-sm hover:border-primary/20 transition-all cursor-pointer">
                      <CardContent className="p-4 flex items-start gap-3">
                        <div className="w-8 h-8 rounded-lg bg-muted flex items-center justify-center flex-shrink-0 mt-0.5">
                          <SIcon className="w-4 h-4 text-muted-foreground" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h3 className="text-sm font-medium line-clamp-1 mb-0.5">{article.title}</h3>
                          {article.summary && (
                            <p className="text-xs text-muted-foreground line-clamp-2 mb-1.5">{article.summary}</p>
                          )}
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-xs text-muted-foreground">{article.source_name}</span>
                            <Badge variant="outline" className="text-[10px]">{article.source_lang.toUpperCase()}</Badge>
                            {article.published && (
                              <span className="text-xs text-muted-foreground flex items-center gap-1">
                                <Clock className="w-3 h-3" />
                                {new Date(article.published).toLocaleDateString(lang === "fr" ? "fr-FR" : "en-US", { month: "short", day: "numeric" })}
                              </span>
                            )}
                          </div>
                        </div>
                        <ExternalLink className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0 mt-1" />
                      </CardContent>
                    </Card>
                  </a>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
