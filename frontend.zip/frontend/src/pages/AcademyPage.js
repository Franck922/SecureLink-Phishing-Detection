import { useState, useEffect } from "react";
import { useAuth } from "../contexts/AuthContext";
import { useLanguage } from "../contexts/LanguageContext";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { Progress } from "../components/ui/progress";
import { RadioGroup, RadioGroupItem } from "../components/ui/radio-group";
import { Label } from "../components/ui/label";
import {
  GraduationCap, Shield, Link, Lock, Eye, AlertCircle, ArrowRight, ArrowLeft,
  CheckCircle, XCircle, Star, Zap, BookOpen, ChevronRight
} from "lucide-react";
import axios from "axios";

const API = `${process.env.REACT_APP_BACKEND_URL}/api`;

const iconMap = { shield: Shield, link: Link, lock: Lock, eye: Eye, "alert-circle": AlertCircle };

export default function AcademyPage() {
  const { token } = useAuth();
  const { t, lang } = useLanguage();
  const [modules, setModules] = useState([]);
  const [activeModule, setActiveModule] = useState(null);
  const [activeLesson, setActiveLesson] = useState(0);
  const [quizMode, setQuizMode] = useState(false);
  const [answers, setAnswers] = useState({});
  const [quizResult, setQuizResult] = useState(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => { fetchModules(); }, []);

  const fetchModules = async () => {
    try {
      const headers = token ? { Authorization: `Bearer ${token}` } : {};
      const res = await axios.get(`${API}/training/modules`, { headers });
      setModules(res.data.modules);
    } catch { /* ignore */ }
    setLoading(false);
  };

  const openModule = async (moduleId) => {
    try {
      const res = await axios.get(`${API}/training/module/${moduleId}`);
      setActiveModule(res.data);
      setActiveLesson(0);
      setQuizMode(false);
      setQuizResult(null);
      setAnswers({});
    } catch { /* ignore */ }
  };

  const submitQuiz = async () => {
    if (!activeModule) return;
    const answerList = activeModule.quiz.map((_, i) => answers[i] ?? -1);
    setSubmitting(true);
    try {
      const headers = token ? { Authorization: `Bearer ${token}` } : {};
      const res = await axios.post(`${API}/training/quiz/submit?module_id=${activeModule.id}`, answerList, { headers });
      setQuizResult(res.data);
    } catch { /* ignore */ }
    setSubmitting(false);
  };

  const resetToModules = () => {
    setActiveModule(null);
    setQuizMode(false);
    setQuizResult(null);
    setAnswers({});
    fetchModules();
  };

  if (loading) return <div className="flex items-center justify-center min-h-[50vh]"><div className="w-8 h-8 border-4 border-primary/30 border-t-primary rounded-full animate-spin" /></div>;

  // Module list view
  if (!activeModule) {
    return (
      <div className="min-h-[calc(100vh-4rem)] py-8 sm:py-12" data-testid="academy-page">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12 animate-slide-up">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-xp/10 text-xp text-sm font-medium mb-4">
              <GraduationCap className="w-4 h-4" /> {t("academy_title")}
            </div>
            <h1 className="text-3xl sm:text-4xl font-bold mb-3" style={{ fontFamily: 'Outfit' }} data-testid="academy-title">
              {t("academy_title")}
            </h1>
            <p className="text-muted-foreground max-w-lg mx-auto">{t("academy_subtitle")}</p>
          </div>

          <div className="space-y-4">
            {modules.map((m, i) => {
              const ModIcon = iconMap[m.icon] || Shield;
              return (
                <Card key={m.id}
                  className="rounded-xl hover:shadow-md transition-all cursor-pointer opacity-0 animate-slide-up"
                  style={{ animationDelay: `${i * 0.1}s`, animationFillMode: 'forwards' }}
                  onClick={() => openModule(m.id)}
                  data-testid={`module-card-${m.id}`}>
                  <CardContent className="p-6 flex items-center gap-5">
                    <div className={`w-14 h-14 rounded-xl flex items-center justify-center flex-shrink-0 ${m.completed ? 'bg-safe/10 text-safe' : 'bg-primary/10 text-primary'}`}>
                      {m.completed ? <CheckCircle className="w-7 h-7" /> : <ModIcon className="w-7 h-7" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-bold text-lg" style={{ fontFamily: 'Outfit' }}>
                          {lang === "fr" ? m.title_fr : m.title_en}
                        </h3>
                        {m.completed && <Badge variant="outline" className="text-safe border-safe text-xs">{t("completed")}</Badge>}
                      </div>
                      <p className="text-sm text-muted-foreground line-clamp-1">
                        {lang === "fr" ? m.description_fr : m.description_en}
                      </p>
                      <div className="flex items-center gap-4 mt-2">
                        <span className="text-xs text-muted-foreground flex items-center gap-1">
                          <BookOpen className="w-3 h-3" /> {m.questions_count} {t("questions")}
                        </span>
                        <span className="text-xs text-muted-foreground flex items-center gap-1">
                          <Zap className="w-3 h-3" /> {m.xp_reward} XP
                        </span>
                        <span className="text-xs text-muted-foreground">
                          {t("difficulty")}: {"*".repeat(m.difficulty)}
                        </span>
                        {m.best_score > 0 && (
                          <span className="text-xs text-xp font-medium flex items-center gap-1">
                            <Star className="w-3 h-3" /> {m.best_score}%
                          </span>
                        )}
                      </div>
                    </div>
                    <ChevronRight className="w-5 h-5 text-muted-foreground flex-shrink-0" />
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  const lessons = lang === "fr" ? activeModule.lessons_fr : activeModule.lessons_en;

  // Quiz result view
  if (quizResult) {
    return (
      <div className="min-h-[calc(100vh-4rem)] py-8 sm:py-12" data-testid="quiz-result-view">
        <div className="max-w-2xl mx-auto px-4 sm:px-6">
          <Card className="rounded-2xl animate-scale-pop">
            <CardContent className="p-8 text-center">
              <div className={`w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 ${quizResult.passed ? 'bg-safe/10' : 'bg-danger/10'}`}>
                {quizResult.passed ? <CheckCircle className="w-10 h-10 text-safe" /> : <XCircle className="w-10 h-10 text-danger" />}
              </div>
              <h2 className="text-2xl font-bold mb-2" style={{ fontFamily: 'Outfit' }} data-testid="quiz-result-title">
                {quizResult.passed ? t("quiz_passed") : t("quiz_failed")}
              </h2>
              <p className="text-4xl font-bold text-primary mb-2">{quizResult.score}%</p>
              <p className="text-muted-foreground mb-6">
                {quizResult.correct_count}/{quizResult.total} {t("correct_answers")}
              </p>
              {quizResult.xp_earned > 0 && (
                <div className="flex items-center justify-center gap-2 text-xp mb-6">
                  <Zap className="w-5 h-5" /> <span className="font-bold">+{quizResult.xp_earned} XP</span>
                </div>
              )}

              {/* Show results per question */}
              <div className="space-y-3 text-left mb-8">
                {quizResult.results.map((r, i) => (
                  <div key={i} className={`p-3 rounded-lg border ${r.is_correct ? 'bg-safe/5 border-safe/20' : 'bg-danger/5 border-danger/20'}`}>
                    <div className="flex items-center gap-2 mb-1">
                      {r.is_correct ? <CheckCircle className="w-4 h-4 text-safe" /> : <XCircle className="w-4 h-4 text-danger" />}
                      <span className="text-sm font-medium">Q{i + 1}</span>
                    </div>
                    <p className="text-xs text-muted-foreground">{lang === "fr" ? r.explanation_fr : r.explanation_en}</p>
                  </div>
                ))}
              </div>

              <div className="flex gap-3 justify-center">
                <Button variant="outline" onClick={resetToModules} className="rounded-full gap-2" data-testid="back-to-modules-btn">
                  <ArrowLeft className="w-4 h-4" /> {t("back_to_modules")}
                </Button>
                {!quizResult.passed && (
                  <Button onClick={() => { setQuizResult(null); setAnswers({}); }} className="rounded-full gap-2" data-testid="retry-quiz-btn">
                    {t("retry_quiz")}
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Quiz mode
  if (quizMode) {
    return (
      <div className="min-h-[calc(100vh-4rem)] py-8 sm:py-12" data-testid="quiz-mode-view">
        <div className="max-w-2xl mx-auto px-4 sm:px-6">
          <Button variant="ghost" onClick={() => setQuizMode(false)} className="mb-6 gap-2 rounded-full" data-testid="back-from-quiz">
            <ArrowLeft className="w-4 h-4" /> {lang === "fr" ? "Retour aux lecons" : "Back to lessons"}
          </Button>

          <div className="mb-6">
            <h2 className="text-2xl font-bold" style={{ fontFamily: 'Outfit' }}>{t("quiz_title")}</h2>
            <Progress value={(Object.keys(answers).length / activeModule.quiz.length) * 100} className="h-2 mt-4" />
          </div>

          <div className="space-y-6">
            {activeModule.quiz.map((q, qi) => (
              <Card key={qi} className="rounded-xl animate-slide-up" style={{ animationDelay: `${qi * 0.1}s` }} data-testid={`quiz-question-${qi}`}>
                <CardContent className="p-6">
                  <p className="font-bold mb-4">
                    <span className="text-primary mr-2">Q{qi + 1}.</span>
                    {lang === "fr" ? q.question_fr : q.question_en}
                  </p>
                  <RadioGroup value={String(answers[qi] ?? "")} onValueChange={(val) => setAnswers(prev => ({ ...prev, [qi]: parseInt(val) }))}>
                    {(lang === "fr" ? q.options_fr : q.options_en).map((opt, oi) => (
                      <div key={oi} className="flex items-center gap-3 p-3 rounded-lg hover:bg-muted/50 transition-colors">
                        <RadioGroupItem value={String(oi)} id={`q${qi}-o${oi}`} data-testid={`quiz-option-${qi}-${oi}`} />
                        <Label htmlFor={`q${qi}-o${oi}`} className="cursor-pointer flex-1 text-sm">{opt}</Label>
                      </div>
                    ))}
                  </RadioGroup>
                </CardContent>
              </Card>
            ))}
          </div>

          <Button onClick={submitQuiz} disabled={Object.keys(answers).length < activeModule.quiz.length || submitting}
            className="w-full mt-8 rounded-full font-bold h-12 gap-2" data-testid="submit-quiz-btn">
            {submitting ? <span className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" /> : t("submit_quiz")}
          </Button>
        </div>
      </div>
    );
  }

  // Lesson view
  return (
    <div className="min-h-[calc(100vh-4rem)] py-8 sm:py-12" data-testid="lesson-view">
      <div className="max-w-2xl mx-auto px-4 sm:px-6">
        <Button variant="ghost" onClick={resetToModules} className="mb-6 gap-2 rounded-full" data-testid="back-to-modules">
          <ArrowLeft className="w-4 h-4" /> {t("back_to_modules")}
        </Button>

        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-2" style={{ fontFamily: 'Outfit' }}>
            {lang === "fr" ? activeModule.title_fr : activeModule.title_en}
          </h2>
          <Progress value={((activeLesson + 1) / lessons.length) * 100} className="h-2" />
          <p className="text-xs text-muted-foreground mt-2">
            {t("lesson")} {activeLesson + 1}/{lessons.length}
          </p>
        </div>

        <Card className="rounded-xl mb-8 animate-slide-up" data-testid="lesson-card">
          <CardContent className="p-8">
            <div className="text-lg leading-relaxed">{lessons[activeLesson]}</div>
          </CardContent>
        </Card>

        <div className="flex justify-between">
          <Button variant="outline" disabled={activeLesson === 0}
            onClick={() => setActiveLesson(prev => prev - 1)} className="rounded-full gap-2" data-testid="prev-lesson-btn">
            <ArrowLeft className="w-4 h-4" /> {lang === "fr" ? "Precedent" : "Previous"}
          </Button>

          {activeLesson < lessons.length - 1 ? (
            <Button onClick={() => setActiveLesson(prev => prev + 1)} className="rounded-full gap-2" data-testid="next-lesson-btn">
              {t("next_lesson")} <ArrowRight className="w-4 h-4" />
            </Button>
          ) : (
            <Button onClick={() => setQuizMode(true)} className="rounded-full gap-2 bg-xp hover:bg-xp/90" data-testid="take-quiz-btn">
              {t("take_quiz")} <ArrowRight className="w-4 h-4" />
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
