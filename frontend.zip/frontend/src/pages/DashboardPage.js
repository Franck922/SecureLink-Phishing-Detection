import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { useLanguage } from "../contexts/LanguageContext";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Progress } from "../components/ui/progress";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "../components/ui/tooltip";
import {
  Shield, Search, ShieldCheck, ShieldAlert, ShieldX,
  BarChart3, Clock, Download, FileText, Zap, Flame, Trophy,
  Star, AlertTriangle, GraduationCap, Heart, Award, Lock,
  ChevronRight, Sparkles, Target
} from "lucide-react";
import axios from "axios";

const API = `${process.env.REACT_APP_BACKEND_URL}/api`;

const BADGE_ICONS = {
  "shield": Shield,
  "alert-triangle": AlertTriangle,
  "graduation-cap": GraduationCap,
  "flame": Flame,
  "search": Search,
  "star": Star,
  "heart": Heart,
  "trophy": Trophy,
};

const BADGE_COLORS = {
  "first_scan": { bg: "from-blue-500/20 to-blue-600/10", border: "border-blue-500/30", text: "text-blue-500", glow: "shadow-blue-500/20" },
  "danger_detector": { bg: "from-red-500/20 to-red-600/10", border: "border-red-500/30", text: "text-red-500", glow: "shadow-red-500/20" },
  "quiz_master": { bg: "from-purple-500/20 to-purple-600/10", border: "border-purple-500/30", text: "text-purple-500", glow: "shadow-purple-500/20" },
  "streak_7": { bg: "from-orange-500/20 to-orange-600/10", border: "border-orange-500/30", text: "text-orange-500", glow: "shadow-orange-500/20" },
  "analyzer_50": { bg: "from-cyan-500/20 to-cyan-600/10", border: "border-cyan-500/30", text: "text-cyan-500", glow: "shadow-cyan-500/20" },
  "perfect_score": { bg: "from-yellow-500/20 to-yellow-600/10", border: "border-yellow-500/30", text: "text-yellow-500", glow: "shadow-yellow-500/20" },
  "community_helper": { bg: "from-pink-500/20 to-pink-600/10", border: "border-pink-500/30", text: "text-pink-500", glow: "shadow-pink-500/20" },
  "streak_30": { bg: "from-amber-500/20 to-amber-600/10", border: "border-amber-500/30", text: "text-amber-500", glow: "shadow-amber-500/20" },
};

export default function DashboardPage() {
  const { user, token } = useAuth();
  const { t, lang } = useLanguage();
  const navigate = useNavigate();
  const [dashboard, setDashboard] = useState(null);
  const [loading, setLoading] = useState(true);
  const [url, setUrl] = useState("");
  const [analyzing, setAnalyzing] = useState(false);
  const [badgeTab, setBadgeTab] = useState("all");

  useEffect(() => {
    if (!token) { navigate("/login"); return; }
    const fetchDashboard = async () => {
      try {
        const res = await axios.get(`${API}/user/dashboard`, { headers: { Authorization: `Bearer ${token}` } });
        setDashboard(res.data);
      } catch { /* ignore */ }
      setLoading(false);
    };
    fetchDashboard();
  }, [token, navigate]);

  const handleQuickAnalyze = async (e) => {
    e.preventDefault();
    if (!url.trim()) return;
    setAnalyzing(true);
    try {
      const res = await axios.post(`${API}/analyze`, { url: url.trim() }, { headers: { Authorization: `Bearer ${token}` } });
      navigate("/result", { state: { result: res.data, url: url.trim() } });
    } catch { /* ignore */ }
    setAnalyzing(false);
  };

  const handleExport = (format) => {
    fetch(`${API}/export/analyses/${format}`, {
      headers: { Authorization: `Bearer ${token}` },
    }).then(res => res.blob()).then(blob => {
      const dlUrl = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = dlUrl;
      a.download = `securelink_analyses.${format}`;
      a.click();
      window.URL.revokeObjectURL(dlUrl);
    }).catch(() => {});
  };

  if (loading) return <div className="flex items-center justify-center min-h-[50vh]"><div className="w-8 h-8 border-4 border-primary/30 border-t-primary rounded-full animate-spin" /></div>;
  if (!dashboard) return null;

  const { user: userData, badges, levels, recent_analyses, weekly_stats } = dashboard;
  const earnedBadges = badges.filter(b => b.earned);
  const unearnedBadges = badges.filter(b => !b.earned);
  const filteredBadges = badgeTab === "earned" ? earnedBadges : badgeTab === "locked" ? unearnedBadges : badges;

  const riskPastille = (rl) => {
    if (rl === "SAFE") return <div className="w-3 h-3 rounded-full bg-emerald-500 flex-shrink-0" />;
    if (rl === "SUSPICIOUS") return <div className="w-3 h-3 rounded-full bg-amber-500 flex-shrink-0" />;
    return <div className="w-3 h-3 rounded-full bg-red-500 flex-shrink-0" />;
  };

  const riskLabel = (rl) => {
    const labels = { SAFE: lang === "fr" ? "Sur" : "Safe", SUSPICIOUS: lang === "fr" ? "Prudence" : "Caution", DANGEROUS: lang === "fr" ? "Danger" : "Danger" };
    return labels[rl] || rl;
  };

  const formatDate = (dateStr) => {
    if (!dateStr) return "";
    try {
      const d = new Date(dateStr);
      return d.toLocaleDateString(lang === "fr" ? "fr-FR" : "en-US", { day: "numeric", month: "short", year: "numeric" });
    } catch { return ""; }
  };

  // Find current and next level indices for the level roadmap
  const currentLevelIdx = levels ? levels.findIndex(l => l.level === userData.level?.level) : 0;

  return (
    <div className="min-h-[calc(100vh-4rem)] py-8" data-testid="dashboard-page">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">

        {/* ===== HERO SECTION: Welcome + XP ===== */}
        <div className="mb-8 animate-slide-up" data-testid="dashboard-hero">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold" style={{ fontFamily: 'Outfit' }} data-testid="dashboard-title">
                {t("welcome_back")}, {userData.username}
              </h1>
              <p className="text-muted-foreground text-sm mt-1">
                {lang === "fr" ? "Votre progression en cybersecurite" : "Your cybersecurity progress"}
              </p>
            </div>
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-orange-500/10 border border-orange-500/20" data-testid="streak-badge">
                <Flame className="w-4 h-4 text-orange-500" />
                <span className="font-bold text-sm text-orange-500">{userData.streak}</span>
                <span className="text-xs text-muted-foreground">{lang === "fr" ? "jours" : "days"}</span>
              </div>
              <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-violet-500/10 border border-violet-500/20" data-testid="xp-badge">
                <Zap className="w-4 h-4 text-violet-500" />
                <span className="font-bold text-sm text-violet-500">{userData.xp} XP</span>
              </div>
            </div>
          </div>

          {/* XP Progress Card */}
          <Card className="rounded-xl overflow-hidden" data-testid="xp-progress-card">
            <CardContent className="p-0">
              <div className="p-5 pb-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center shadow-lg shadow-violet-500/20">
                      <span className="text-white font-bold text-sm" style={{ fontFamily: 'Outfit' }}>
                        {userData.level?.level}
                      </span>
                    </div>
                    <div>
                      <p className="font-bold text-sm" style={{ fontFamily: 'Outfit' }}>
                        {lang === "fr" ? userData.level?.name_fr : userData.level?.name_en}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {userData.next_level
                          ? `${userData.xp_for_next - userData.xp_in_level} XP ${lang === "fr" ? "avant" : "to"} ${lang === "fr" ? userData.next_level.name_fr : userData.next_level.name_en}`
                          : (lang === "fr" ? "Niveau maximum atteint !" : "Max level reached!")}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-muted-foreground">{lang === "fr" ? "Progression" : "Progress"}</p>
                    <p className="font-bold text-sm text-violet-500">{userData.xp_progress}%</p>
                  </div>
                </div>

                {/* XP Bar */}
                <div className="relative h-3 rounded-full bg-muted overflow-hidden" data-testid="xp-progress-bar">
                  <div
                    className="absolute inset-y-0 left-0 rounded-full bg-gradient-to-r from-violet-500 to-purple-500 transition-all duration-1000 ease-out"
                    style={{ width: `${userData.xp_progress}%` }}
                  />
                  <div
                    className="absolute inset-y-0 left-0 rounded-full bg-gradient-to-r from-violet-400/50 to-purple-400/50 animate-pulse"
                    style={{ width: `${userData.xp_progress}%` }}
                  />
                </div>

                <div className="flex justify-between mt-2 text-xs text-muted-foreground">
                  <span>{userData.level?.xp_required} XP</span>
                  <span>{userData.next_level?.xp_required || userData.level?.xp_required} XP</span>
                </div>
              </div>

              {/* Level roadmap */}
              {levels && (
                <div className="border-t px-5 py-3 bg-muted/30" data-testid="level-roadmap">
                  <div className="flex items-center gap-1 overflow-x-auto pb-1">
                    {levels.map((lvl, i) => {
                      const isReached = userData.xp >= lvl.xp_required;
                      const isCurrent = lvl.level === userData.level?.level;
                      return (
                        <TooltipProvider key={lvl.level}>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <div className="flex items-center gap-1 flex-shrink-0">
                                <div
                                  className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold transition-all cursor-default
                                    ${isCurrent
                                      ? "bg-gradient-to-br from-violet-500 to-purple-600 text-white shadow-lg shadow-violet-500/30 scale-110"
                                      : isReached
                                        ? "bg-violet-500/20 text-violet-500 border border-violet-500/30"
                                        : "bg-muted text-muted-foreground border border-border"
                                    }`}
                                  data-testid={`level-marker-${lvl.level}`}
                                >
                                  {lvl.level}
                                </div>
                                {i < levels.length - 1 && (
                                  <div className={`w-4 sm:w-6 h-0.5 rounded-full ${isReached && userData.xp >= (levels[i + 1]?.xp_required || 0) ? "bg-violet-500/50" : "bg-border"}`} />
                                )}
                              </div>
                            </TooltipTrigger>
                            <TooltipContent side="top" className="text-xs">
                              <p className="font-bold">{lang === "fr" ? lvl.name_fr : lvl.name_en}</p>
                              <p className="text-muted-foreground">{lvl.xp_required} XP</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      );
                    })}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* ===== QUICK ANALYZE ===== */}
        <Card className="rounded-xl mb-6 animate-slide-up stagger-1" data-testid="quick-analysis-card">
          <CardContent className="p-5">
            <form onSubmit={handleQuickAnalyze} className="flex gap-3">
              <div className="relative flex-1">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input value={url} onChange={(e) => setUrl(e.target.value)} placeholder={t("url_placeholder")} className="pl-10 h-11 rounded-full font-mono text-sm" data-testid="dashboard-url-input" />
              </div>
              <Button type="submit" disabled={analyzing} className="h-11 rounded-full font-bold" data-testid="dashboard-analyze-btn">
                <Shield className="w-4 h-4 mr-2" /> {analyzing ? t("analyzing") : t("analyze_btn")}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* ===== STATS GRID ===== */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6 animate-slide-up stagger-2">
          {[
            { label: t("total_analyses"), value: userData.stats.analyses_count, icon: BarChart3, color: "text-primary" },
            { label: t("safe_found"), value: userData.stats.safe_detected, icon: ShieldCheck, color: "text-emerald-500" },
            { label: t("suspects_found"), value: userData.stats.suspects_detected, icon: ShieldAlert, color: "text-amber-500" },
            { label: t("dangers_found"), value: userData.stats.dangers_detected, icon: ShieldX, color: "text-red-500" },
          ].map((stat, i) => (
            <Card key={i} className="rounded-xl" data-testid={`stat-card-${i}`}>
              <CardContent className="p-4 flex items-center gap-3">
                <stat.icon className={`w-5 h-5 ${stat.color} flex-shrink-0`} />
                <div>
                  <p className="text-xl font-bold leading-tight">{stat.value}</p>
                  <p className="text-xs text-muted-foreground">{stat.label}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* ===== BADGES SECTION ===== */}
        <Card className="rounded-xl mb-6 animate-slide-up stagger-3" data-testid="badges-section">
          <CardHeader className="pb-3 pt-5 px-5">
            <div className="flex items-center justify-between">
              <CardTitle className="text-base flex items-center gap-2" style={{ fontFamily: 'Outfit' }}>
                <Award className="w-5 h-5 text-violet-500" />
                {lang === "fr" ? "Badges" : "Badges"}
                <span className="text-xs font-normal text-muted-foreground ml-1">
                  {earnedBadges.length}/{badges.length}
                </span>
              </CardTitle>
              <div className="flex gap-1">
                {[
                  { key: "all", label: lang === "fr" ? "Tous" : "All" },
                  { key: "earned", label: lang === "fr" ? "Acquis" : "Earned" },
                  { key: "locked", label: lang === "fr" ? "En cours" : "Locked" },
                ].map(tab => (
                  <Button
                    key={tab.key}
                    variant={badgeTab === tab.key ? "secondary" : "ghost"}
                    size="sm"
                    className="text-xs h-7 rounded-full px-3"
                    onClick={() => setBadgeTab(tab.key)}
                    data-testid={`badge-tab-${tab.key}`}
                  >
                    {tab.label}
                  </Button>
                ))}
              </div>
            </div>
          </CardHeader>
          <CardContent className="px-5 pb-5">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3" data-testid="badges-grid">
              {filteredBadges.map((badge) => {
                const colors = BADGE_COLORS[badge.id] || { bg: "from-gray-500/20 to-gray-600/10", border: "border-gray-500/30", text: "text-gray-500", glow: "shadow-gray-500/20" };
                const IconComp = BADGE_ICONS[badge.icon] || Shield;
                return (
                  <div
                    key={badge.id}
                    className={`relative rounded-xl border p-4 transition-all duration-300
                      ${badge.earned
                        ? `bg-gradient-to-br ${colors.bg} ${colors.border} shadow-lg ${colors.glow} hover:scale-[1.02]`
                        : "bg-muted/30 border-border opacity-70 hover:opacity-90"
                      }`}
                    data-testid={`badge-${badge.id}`}
                  >
                    {/* Badge icon */}
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-3
                      ${badge.earned
                        ? `bg-gradient-to-br ${colors.bg} ${colors.border} border`
                        : "bg-muted border border-border"
                      }`}
                    >
                      {badge.earned
                        ? <IconComp className={`w-5 h-5 ${colors.text}`} />
                        : <Lock className="w-4 h-4 text-muted-foreground" />
                      }
                    </div>

                    {/* Badge name */}
                    <p className={`font-bold text-sm leading-tight ${badge.earned ? "" : "text-muted-foreground"}`} style={{ fontFamily: 'Outfit' }}>
                      {lang === "fr" ? badge.name_fr : badge.name_en}
                    </p>

                    {/* Badge description */}
                    <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                      {lang === "fr" ? badge.description_fr : badge.description_en}
                    </p>

                    {/* Earned date or progress */}
                    {badge.earned ? (
                      <div className="mt-3 flex items-center gap-1.5">
                        <Sparkles className={`w-3 h-3 ${colors.text}`} />
                        <span className="text-[11px] text-muted-foreground">
                          {badge.earned_at ? formatDate(badge.earned_at) : (lang === "fr" ? "Obtenu" : "Earned")}
                        </span>
                      </div>
                    ) : (
                      <div className="mt-3">
                        <div className="flex justify-between items-center mb-1">
                          <span className="text-[11px] text-muted-foreground">
                            {lang === "fr" ? "Progression" : "Progress"}
                          </span>
                          <span className="text-[11px] font-medium text-muted-foreground">{badge.progress}%</span>
                        </div>
                        <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                          <div
                            className="h-full rounded-full bg-gradient-to-r from-violet-500/60 to-purple-500/60 transition-all duration-500"
                            style={{ width: `${badge.progress}%` }}
                          />
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* ===== WEEKLY STATS + RECENT ANALYSES (2 columns on desktop) ===== */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6 animate-slide-up stagger-4">
          {/* Weekly stats */}
          <Card className="rounded-xl" data-testid="weekly-stats-card">
            <CardHeader className="pb-2 pt-4 px-5">
              <CardTitle className="text-sm flex items-center gap-2 text-muted-foreground" style={{ fontFamily: 'Outfit' }}>
                <Clock className="w-4 h-4" /> {t("this_week")}
              </CardTitle>
            </CardHeader>
            <CardContent className="px-5 pb-4">
              <div className="space-y-3">
                {[
                  { label: lang === "fr" ? "Surs" : "Safe", value: weekly_stats.safe, total: weekly_stats.total, color: "bg-emerald-500", dot: "bg-emerald-500" },
                  { label: lang === "fr" ? "Suspects" : "Suspicious", value: weekly_stats.suspicious, total: weekly_stats.total, color: "bg-amber-500", dot: "bg-amber-500" },
                  { label: lang === "fr" ? "Dangereux" : "Dangerous", value: weekly_stats.dangerous, total: weekly_stats.total, color: "bg-red-500", dot: "bg-red-500" },
                ].map((s, i) => (
                  <div key={i}>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="flex items-center gap-1.5"><div className={`w-2 h-2 rounded-full ${s.dot}`} />{s.label}</span>
                      <span className="font-medium">{s.value}</span>
                    </div>
                    <Progress value={s.total ? (s.value / s.total) * 100 : 0} className={`h-1.5 [&>div]:${s.color}`} />
                  </div>
                ))}
                <div className="pt-2 border-t">
                  <div className="flex justify-between text-xs">
                    <span className="text-muted-foreground">{lang === "fr" ? "Total cette semaine" : "Total this week"}</span>
                    <span className="font-bold">{weekly_stats.total}</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Recent Analyses */}
          <Card className="rounded-xl" data-testid="recent-analyses-card">
            <CardHeader className="pb-2 pt-4 px-5">
              <CardTitle className="text-sm flex items-center gap-2 text-muted-foreground" style={{ fontFamily: 'Outfit' }}>
                <Clock className="w-4 h-4" /> {t("recent_analyses")}
              </CardTitle>
            </CardHeader>
            <CardContent className="px-5 pb-4">
              {recent_analyses.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-8">{t("no_analyses_yet")}</p>
              ) : (
                <div className="space-y-1">
                  {recent_analyses.slice(0, 6).map((a) => (
                    <div key={a.id}
                      className="flex items-center gap-3 p-2.5 rounded-lg hover:bg-muted/50 transition-colors cursor-pointer"
                      onClick={() => navigate("/result", { state: { result: a, url: a.url } })}
                      data-testid={`analysis-item-${a.id}`}>
                      {riskPastille(a.risk_level)}
                      <span className="font-mono text-xs truncate flex-1">{a.url}</span>
                      <span className={`text-xs font-medium ${a.risk_level === "SAFE" ? "text-emerald-600 dark:text-emerald-400" : a.risk_level === "SUSPICIOUS" ? "text-amber-600 dark:text-amber-400" : "text-red-600 dark:text-red-400"}`}>
                        {riskLabel(a.risk_level)}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* ===== EXPORT ===== */}
        <Card className="rounded-xl animate-slide-up stagger-5" data-testid="export-card">
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Download className="w-4 h-4 text-muted-foreground" />
                <span className="text-sm text-muted-foreground">
                  {lang === "fr" ? "Exporter vos analyses" : "Export your analyses"}
                </span>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => handleExport("csv")} className="rounded-full gap-2 text-xs" data-testid="export-csv-btn">
                  <FileText className="w-3 h-3" /> CSV
                </Button>
                <Button variant="outline" size="sm" onClick={() => handleExport("pdf")} className="rounded-full gap-2 text-xs" data-testid="export-pdf-btn">
                  <FileText className="w-3 h-3" /> PDF
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
