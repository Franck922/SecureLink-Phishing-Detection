import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { useLanguage } from "../contexts/LanguageContext";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Badge } from "../components/ui/badge";
import { RadioGroup, RadioGroupItem } from "../components/ui/radio-group";
import {
  Plus, Search, ShieldCheck, ShieldX, HelpCircle, Clock, User, CheckCircle
} from "lucide-react";
import axios from "axios";

const API = `${process.env.REACT_APP_BACKEND_URL}/api`;

export default function ContributePage() {
  const { user, token } = useAuth();
  const { lang } = useLanguage();
  const navigate = useNavigate();
  const [url, setUrl] = useState("");
  const [category, setCategory] = useState("unknown");
  const [comment, setComment] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [recentContributions, setRecentContributions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!token) { navigate("/login"); return; }
    fetchContributions();
  }, [token]);

  const fetchContributions = async () => {
    try {
      const res = await axios.get(`${API}/contributions/recent`);
      setRecentContributions(res.data.contributions || []);
    } catch { /* ignore */ }
    setLoading(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!url.trim()) return;
    setSubmitting(true);
    setSuccess(false);
    try {
      await axios.post(`${API}/contribute`, { url: url.trim(), category, comment },
        { headers: { Authorization: `Bearer ${token}` } });
      setSuccess(true);
      setUrl("");
      setComment("");
      setCategory("unknown");
      fetchContributions();
    } catch { /* ignore */ }
    setSubmitting(false);
  };

  const categoryPastille = (cat) => {
    if (cat === "phishing") return <div className="w-2.5 h-2.5 rounded-full bg-red-500 flex-shrink-0" />;
    if (cat === "safe") return <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 flex-shrink-0" />;
    return <div className="w-2.5 h-2.5 rounded-full bg-gray-400 flex-shrink-0" />;
  };

  const categoryLabel = (cat) => {
    const labels = {
      phishing: lang === "fr" ? "Phishing" : "Phishing",
      safe: lang === "fr" ? "Legitime" : "Legitimate",
      unknown: lang === "fr" ? "A verifier" : "To verify",
    };
    return labels[cat] || cat;
  };

  if (!token) return null;

  return (
    <div className="min-h-[calc(100vh-4rem)] py-8 sm:py-12" data-testid="contribute-page">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8 animate-slide-up">
          <h1 className="text-2xl sm:text-3xl font-bold mb-2" style={{ fontFamily: 'Outfit' }} data-testid="contribute-title">
            {lang === "fr" ? "Contribuer" : "Contribute"}
          </h1>
          <p className="text-muted-foreground text-sm max-w-md mx-auto">
            {lang === "fr"
              ? "Partagez les URLs suspectes que vous rencontrez pour enrichir notre base et aider la communaute."
              : "Share suspicious URLs you encounter to enrich our database and help the community."}
          </p>
        </div>

        {/* Contribution Form */}
        <Card className="rounded-xl mb-8 animate-slide-up stagger-1" data-testid="contribute-form-card">
          <CardContent className="p-6">
            <form onSubmit={handleSubmit} className="space-y-5">
              <div>
                <Label className="text-sm mb-1.5 block">URL</Label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input value={url} onChange={(e) => setUrl(e.target.value)}
                    placeholder={lang === "fr" ? "Collez l'URL suspecte ici..." : "Paste the suspicious URL here..."}
                    className="pl-10 rounded-full font-mono text-sm" data-testid="contribute-url-input" />
                </div>
              </div>

              <div>
                <Label className="text-sm mb-2 block">
                  {lang === "fr" ? "Classification" : "Classification"}
                </Label>
                <RadioGroup value={category} onValueChange={setCategory} className="flex gap-4">
                  <div className="flex items-center gap-2">
                    <RadioGroupItem value="phishing" id="cat-phishing" data-testid="cat-phishing" />
                    <Label htmlFor="cat-phishing" className="cursor-pointer flex items-center gap-1.5 text-sm">
                      <ShieldX className="w-3.5 h-3.5 text-red-500" />
                      {lang === "fr" ? "Phishing" : "Phishing"}
                    </Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <RadioGroupItem value="safe" id="cat-safe" data-testid="cat-safe" />
                    <Label htmlFor="cat-safe" className="cursor-pointer flex items-center gap-1.5 text-sm">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
                      {lang === "fr" ? "Legitime" : "Legitimate"}
                    </Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <RadioGroupItem value="unknown" id="cat-unknown" data-testid="cat-unknown" />
                    <Label htmlFor="cat-unknown" className="cursor-pointer flex items-center gap-1.5 text-sm">
                      <HelpCircle className="w-3.5 h-3.5 text-muted-foreground" />
                      {lang === "fr" ? "Je ne suis pas sur(e)" : "I'm not sure"}
                    </Label>
                  </div>
                </RadioGroup>
              </div>

              <div>
                <Label className="text-sm mb-1.5 block">
                  {lang === "fr" ? "Commentaire (optionnel)" : "Comment (optional)"}
                </Label>
                <Input value={comment} onChange={(e) => setComment(e.target.value)}
                  placeholder={lang === "fr" ? "Ex: Recu par email, imite ma banque..." : "E.g., Received by email, imitates my bank..."}
                  className="rounded-full text-sm" data-testid="contribute-comment-input" />
              </div>

              {success && (
                <div className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400 text-sm" data-testid="contribute-success">
                  <CheckCircle className="w-4 h-4" />
                  {lang === "fr" ? "Merci pour votre contribution ! +20 XP" : "Thanks for your contribution! +20 XP"}
                </div>
              )}

              <Button type="submit" disabled={submitting || !url.trim()} className="w-full rounded-full font-bold gap-2" data-testid="contribute-submit-btn">
                {submitting ? (
                  <span className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
                ) : (
                  <>
                    <Plus className="w-4 h-4" />
                    {lang === "fr" ? "Soumettre" : "Submit"}
                  </>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Recent Community Contributions */}
        <Card className="rounded-xl animate-slide-up stagger-2" data-testid="recent-contributions-card">
          <CardHeader className="pb-2 pt-4 px-5">
            <CardTitle className="text-sm text-muted-foreground flex items-center gap-2" style={{ fontFamily: 'Outfit' }}>
              <Clock className="w-4 h-4" />
              {lang === "fr" ? "Contributions recentes de la communaute" : "Recent community contributions"}
            </CardTitle>
          </CardHeader>
          <CardContent className="px-5 pb-4">
            {recentContributions.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-6">
                {lang === "fr" ? "Aucune contribution encore. Soyez le premier!" : "No contributions yet. Be the first!"}
              </p>
            ) : (
              <div className="space-y-1">
                {recentContributions.slice(0, 15).map((c) => (
                  <div key={c.id} className="flex items-center gap-3 p-2.5 rounded-lg hover:bg-muted/50 transition-colors">
                    {categoryPastille(c.category)}
                    <span className="font-mono text-xs truncate flex-1">{c.url}</span>
                    <span className="text-xs text-muted-foreground flex items-center gap-1">
                      <User className="w-3 h-3" /> {c.submitted_by_name || "?"}
                    </span>
                    <Badge variant="outline" className="text-xs">{categoryLabel(c.category)}</Badge>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
