import { createContext, useContext, useState, useCallback } from "react";
import translations from "../translations";

const LanguageContext = createContext(null);

export function LanguageProvider({ children }) {
  const [lang, setLang] = useState(() => localStorage.getItem("sl_lang") || "fr");

  const t = useCallback((key) => {
    return translations[lang]?.[key] || translations["fr"]?.[key] || key;
  }, [lang]);

  const toggleLang = () => {
    const next = lang === "fr" ? "en" : "fr";
    setLang(next);
    localStorage.setItem("sl_lang", next);
  };

  return (
    <LanguageContext.Provider value={{ lang, setLang, toggleLang, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export const useLanguage = () => useContext(LanguageContext);
