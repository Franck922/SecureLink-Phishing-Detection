# SecureLink

Plateforme d'analyse d'URLs et d'education a la cybersecurite.

## Lancer le projet en local

### Prerequis

- Python 3.10+
- Node.js 18+
- MongoDB (local ou Atlas)
- Playwright : `playwright install chromium`

### Installation

```bash
# Backend
cd backend
cp .env.example .env          # puis remplir les cles API
pip install -r requirements-local.txt

# Frontend
cd ../frontend
cp .env.example .env
yarn install
```

### Demarrage

```bash
# Terminal 1 — Backend
cd backend
uvicorn server:app --host 0.0.0.0 --port 8001

# Terminal 2 — Frontend
cd frontend
yarn start
```

L'application est accessible sur `http://localhost:3000`.

### Cles API (dans backend/.env)

| Cle | Obligatoire | Ou l'obtenir |
|-----|-------------|-------------|
| MONGO_URL | Oui | MongoDB local ou [Atlas](https://cloud.mongodb.com) |
| GEMINI_API_KEY | Non | [Google AI Studio](https://aistudio.google.com/apikey) (pour le chatbot) |
| GOOGLE_SAFE_BROWSING_KEY | Non | [Google Cloud Console](https://console.cloud.google.com/apis/library/safebrowsing.googleapis.com) |
| PAPPERS_API_KEY | Non | [pappers.fr/api](https://www.pappers.fr/api) (verification entreprise FR) |

Les cles optionnelles activent des couches supplementaires. L'analyse fonctionne sans elles avec la degradation gracieuse.

## Structure

```
backend/          API FastAPI + moteur d'analyse (12 couches)
frontend/         Interface React
extension/        Extension Chrome (Manifest V3)
extension-firefox/Extension Firefox (Manifest V2)
docs/             Documentation PFE
```

## Documentation PFE

- `docs/PFE_DIAGRAMMES.md` — Diagrammes (sequence, deploiement, cas d'utilisation...)


## Benchmark

```bash
cd backend
python benchmark.py              # 74 URLs, accuracy 100%
python benchmark.py --calibrate  # Grid search des seuils
```
