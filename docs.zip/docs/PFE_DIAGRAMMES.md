# SecureLink — Diagrammes Techniques

---

## 1. Diagramme de sequence — Analyse complete d'une URL

```
Utilisateur          Frontend (React)        Backend (FastAPI)         Services externes
    │                      │                        │                        │
    │  Saisit une URL      │                        │                        │
    │─────────────────────>│                        │                        │
    │                      │  POST /api/analyze     │                        │
    │                      │  {url: "..."}          │                        │
    │                      │───────────────────────>│                        │
    │                      │                        │                        │
    │                      │                        │── C1: ML Model ──────>│ (local, <1ms)
    │                      │                        │<── probabilite 0-100 ─│
    │                      │                        │                        │
    │                      │                        │── C2: Rules ────────>│ (local, <1ms)
    │                      │                        │<── score + regles ────│
    │                      │                        │                        │
    │                      │                        │── C3: DNS ──────────>│ Serveurs DNS
    │                      │                        │── C3: SSL ──────────>│ Serveur cible
    │                      │                        │── C3: WHOIS ────────>│ Registrar
    │                      │                        │── C3: rDNS ─────────>│ Serveurs DNS
    │                      │                        │<── score + checks ───│
    │                      │                        │                        │
    │                      │                        │── C4: HTTP GET ─────>│ Serveur cible
    │                      │                        │<── HTML brut ─────────│
    │                      │                        │── C4: Parse HTML ───>│ (local, BS4)
    │                      │                        │<── findings + signaux │
    │                      │                        │                        │
    │                      │                        │── C5: API Pappers ──>│ pappers.fr
    │                      │                        │<── entreprise/null ───│
    │                      │                        │                        │
    │                      │                        │── C6: Typosquat ────>│ (local)
    │                      │                        │── C7: Redirections ──│ (depuis C4)
    │                      │                        │── C8: Mentions leg. ─│ (depuis C4)
    │                      │                        │                        │
    │                      │                        │── C9: Safe Browsing >│ Google API v4
    │                      │                        │<── menace oui/non ───│
    │                      │                        │                        │
    │                      │                        │── C10: Kit Detect ──>│ (local, regex)
    │                      │                        │<── detection/null ────│
    │                      │                        │                        │
    │                      │                        │══ SCORING HYBRIDE ═══│
    │                      │                        │   35% ML + 20% Rules │
    │                      │                        │   15% Net + 15% HTML │
    │                      │                        │   10% SB + 5% Kit   │
    │                      │                        │   + hard overrides   │
    │                      │                        │   → feu tricolore    │
    │                      │                        │                        │
    │                      │  Resultat JSON complet │                        │
    │                      │<──────────────────────│                        │
    │                      │                        │                        │
    │  Verdict + resume    │                        │                        │
    │<─────────────────────│                        │                        │
    │                      │                        │                        │
    │                      │  POST /api/screenshot  │                        │
    │                      │  (appel parallele)     │                        │
    │                      │───────────────────────>│── C11: Playwright ──>│ Chromium headless
    │                      │                        │<── JPEG base64 ──────│
    │                      │<──────────────────────│                        │
    │                      │                        │                        │
    │  Rapport complet     │                        │                        │
    │  + screenshot        │                        │                        │
    │<─────────────────────│                        │                        │
```

---

## 2. Diagramme de sequence — Chatbot SecureBot

```
Utilisateur          ChatWidget (React)      Backend (FastAPI)         Gemini 2.5 Flash
    │                      │                        │                        │
    │  Ouvre le widget      │                        │                        │
    │─────────────────────>│                        │                        │
    │                      │  GET /api/assistant/    │                        │
    │                      │  topics                 │                        │
    │                      │───────────────────────>│                        │
    │                      │<── 5 sujets suggeres ──│                        │
    │                      │                        │                        │
    │  Ecrit un message    │                        │                        │
    │─────────────────────>│                        │                        │
    │                      │  POST /api/assistant/   │                        │
    │                      │  chat {message,         │                        │
    │                      │  session_id}            │                        │
    │                      │───────────────────────>│                        │
    │                      │                        │── Charge historique ──>│ MongoDB
    │                      │                        │<── 10 derniers msg ───│
    │                      │                        │                        │
    │                      │                        │── System prompt ──────│
    │                      │                        │   + historique         │
    │                      │                        │   + message user      │
    │                      │                        │───────────────────────>│
    │                      │                        │<── Reponse JSON ──────│
    │                      │                        │   {message,            │
    │                      │                        │    is_analysis,        │
    │                      │                        │    analysis}           │
    │                      │                        │                        │
    │                      │                        │── Sauvegarde msg ────>│ MongoDB
    │                      │                        │                        │
    │                      │<── Reponse formatee ───│                        │
    │                      │                        │                        │
    │  Affiche reponse     │                        │                        │
    │  (+ carte d'analyse  │                        │                        │
    │   si is_analysis)    │                        │                        │
    │<─────────────────────│                        │                        │
```

---

## 3. Diagramme de sequence — Extension navigateur

```
Utilisateur          Extension (Popup)       Background (SW)         Backend (FastAPI)
    │                      │                        │                        │
    │  Clic droit sur      │                        │                        │
    │  un lien             │                        │                        │
    │─────────────────────>│                        │                        │
    │                      │                        │── contextMenus ──────>│
    │                      │                        │   stocke pendingUrl   │
    │                      │                        │   ouvre popup          │
    │                      │                        │                        │
    │  (ou ouvre le popup) │                        │                        │
    │─────────────────────>│                        │                        │
    │                      │── getPendingUrl ──────>│                        │
    │                      │<── url ou onglet actif │                        │
    │                      │                        │                        │
    │                      │  "Analyser"            │                        │
    │                      │───────────────────────────────────────────────>│
    │                      │  POST /api/analyze     │                        │
    │                      │  {url, token?}         │                        │
    │                      │                        │                        │
    │                      │<──────────────────────────────────────────────│
    │                      │  {traffic_light,       │                        │
    │                      │   final_score,         │                        │
    │                      │   network_checks: {    │                        │
    │                      │     ssl, whois},       │                        │
    │                      │   safe_browsing: {     │                        │
    │                      │     checked, is_threat},│                        │
    │                      │   phishing_kit: {      │                        │
    │                      │     detected, kits},   │                        │
    │                      │   content_findings,    │                        │
    │                      │   typosquatting_target} │                        │
    │                      │                        │                        │
    │                      │── displayResult() ────>│                        │
    │                      │   badge colore (vert/  │                        │
    │                      │   jaune/rouge)         │                        │
    │                      │                        │                        │
    │                      │── buildSummary() ─────>│                        │
    │                      │   4 points cles max    │                        │
    │                      │   (SSL, age domaine,   │                        │
    │                      │   Safe Browsing, kit)  │                        │
    │                      │                        │                        │
    │  Badge + resume +    │                        │                        │
    │  score + typosquat   │                        │                        │
    │<─────────────────────│                        │                        │
```

---

## 4. Diagramme de sequence — Capture d'ecran (subprocess worker)

```
Frontend (React)        Backend (FastAPI)          page_screenshot.py      screenshot_worker.py
    │                        │                        │                        │
    │  POST /api/screenshot  │                        │                        │
    │  {url: "..."}          │                        │                        │
    │───────────────────────>│                        │                        │
    │                        │                        │                        │
    │                        │── capture_screenshot()─>│                        │
    │                        │                        │                        │
    │                        │                        │── Validation SSRF ────│
    │                        │                        │   IP privee ? → bloquer│
    │                        │                        │                        │
    │                        │                        │── asyncio.to_thread() │
    │                        │                        │   _run_worker(url)     │
    │                        │                        │       │                │
    │                        │                        │       │ subprocess.run │
    │                        │                        │       │ (processus     │
    │                        │                        │       │  Python isole) │
    │                        │                        │       │───────────────>│
    │                        │                        │       │                │
    │                        │                        │       │                │── sync_playwright()
    │                        │                        │       │                │   Chromium headless
    │                        │                        │       │                │── page.goto(url)
    │                        │                        │       │                │── wait 2s
    │                        │                        │       │                │── screenshot(jpeg)
    │                        │                        │       │                │── base64 encode
    │                        │                        │       │                │
    │                        │                        │       │<── JSON stdout │
    │                        │                        │       │  {captured,    │
    │                        │                        │       │   image_base64,│
    │                        │                        │       │   error}       │
    │                        │                        │<──────│                │
    │                        │                        │                        │
    │                        │<── resultat ───────────│                        │
    │                        │                        │                        │
    │  {captured: true,      │                        │                        │
    │   image_base64: "..."}│                        │                        │
    │<──────────────────────│                        │                        │
```

**Pourquoi un subprocess ?** Sur Python 3.14 sous Windows, `asyncio.create_subprocess_exec` echoue dans la boucle evenementielle d'uvicorn (`NotImplementedError`). Le subprocess isole Playwright dans son propre interpreteur Python, evitant tout conflit.

---

## 5. Diagramme de composants backend

```
server.py ──────────── Point d'entree FastAPI, routage, middleware
│
├── url_analyzer.py ◄── Orchestrateur : appelle toutes les couches, calcule le score
│   │
│   ├── ml_model.py ............... RandomForest (scikit-learn)
│   │   ├── extract_features()      → 20 features depuis l'URL
│   │   ├── predict()               → probabilite [0-100]
│   │   └── retrain()               → re-entrainement avec nouvelles donnees
│   │
│   ├── network_checks.py ......... Verifications reseau live
│   │   ├── check_dns()             → resolution DNS
│   │   ├── check_ssl()             → certificat SSL
│   │   ├── check_whois()           → age du domaine
│   │   └── check_rdns()            → reverse DNS
│   │
│   ├── content_analyzer.py ........ Analyse HTML
│   │   ├── fetch_page()            → HTTP GET + redirections
│   │   ├── detect_login_forms()    → formulaires pieges
│   │   ├── detect_brand_impersonation() → usurpation de marque
│   │   ├── extract_company_signals()    → SIREN, nom entreprise
│   │   ├── analyze_scripts()       → JS suspect
│   │   └── follow_mentions_legales()    → extraction SIREN footer
│   │
│   ├── company_verifier.py ........ Verification entreprise
│   │   └── verify_with_pappers()   → API Pappers (SIREN/nom/NAF)
│   │
│   ├── typosquatting_detector.py .. Detection de sosies
│   │   ├── levenshtein_distance()  → distance d'edition
│   │   └── check_substitutions()   → o→0, l→1, rn→m...
│   │
│   ├── safe_browsing.py ........... Google Safe Browsing
│   │   └── check_google_safe_browsing() → API v4
│   │
│   ├── phishing_kit_detector.py ... Fingerprinting
│   │   ├── check_known_kits()      → 5 signatures de kits
│   │   └── check_structural_patterns() → 8 patterns HTML
│   │
│   └── page_screenshot.py ......... Orchestrateur screenshot
│       ├── capture_screenshot()    → validation SSRF + lancement worker
│       └── _run_worker()           → subprocess.run(screenshot_worker.py)
│
├── screenshot_worker.py ◄── Processus isole Playwright (sync API)
│   └── main()                  → Chromium headless → JPEG base64 → stdout
│
├── llm_helper.py ◄── Interface LLM (Google Gemini)
│   ├── send_chat_message()     → appel Gemini via SDK
│   └── _send_gemini()          → SDK google-generativeai
│
└── Services applicatifs (dans server.py)
    ├── Auth (register, login, JWT)
    ├── Chatbot (Gemini 1.5 Flash via llm_helper)
    ├── Gamification (XP, badges, niveaux, leaderboard)
    ├── E-Learning (modules, quiz)
    ├── Simulation (scenarios phishing)
    ├── Export (CSV, PDF)
    ├── Contributions (signalement communautaire)
    └── Administration (stats, moderation, retrain)
```

---

## 6. Schema de donnees — Relations entre collections

```
users ─────────┐
  │            │
  │ 1:N       │ 1:N
  ▼            ▼
analyses    chat_messages
  │            │
  │ 1:N       │ session_id
  ▼            │
feedback      └── groupees par session

users ────┐────────┐────────┐
  │       │        │        │
  │ 1:N   │ 1:N    │ 1:N    │ 1:N
  ▼       ▼        ▼        ▼
quiz_   simul_   contrib-  resource_
progress results  utions   completions
```

---

## 7. Diagramme de deploiement

```
┌─────────────────────────────────────────────────────────────────┐
│                        UTILISATEURS                              │
│                                                                  │
│   ┌──────────────┐    ┌──────────────────┐    ┌────────────┐   │
│   │  Navigateur   │    │  Extension Chrome │    │  Extension  │   │
│   │  Web (React)  │    │  (Manifest V3)    │    │  Firefox    │   │
│   └──────┬───────┘    └────────┬─────────┘    └──────┬─────┘   │
│          │                     │                      │          │
└──────────┼─────────────────────┼──────────────────────┼──────────┘
           │ HTTPS               │ HTTPS                │ HTTPS
           ▼                     ▼                      ▼
    ┌──────────────────────────────────────────────────────┐
    │              SERVEUR (local ou cloud)                  │
    │                                                        │
    │   ┌─────────────────────────────────────────────┐     │
    │   │  Frontend — React 19 (port 3000)             │     │
    │   │  • 11 pages, 3 contextes (Auth/Lang/Theme)  │     │
    │   │  • shadcn/ui + Tailwind CSS + Recharts      │     │
    │   └─────────────────────────────────────────────┘     │
    │                        │ REST /api                     │
    │   ┌────────────────────▼────────────────────────┐     │
    │   │  Backend — FastAPI (port 8001)               │     │
    │   │  • 38 endpoints REST                         │     │
    │   │  • 11 couches d'analyse                      │     │
    │   │  • JWT auth + rate limiting                  │     │
    │   │  • screenshot_worker.py (subprocess isole)   │     │
    │   └────────────────────┬────────────────────────┘     │
    │                        │                               │
    │   ┌────────────────────▼────────────────────────┐     │
    │   │  MongoDB (port 27017)                        │     │
    │   │  • 11 collections                            │     │
    │   │  • Schema flexible (documents JSON)          │     │
    │   └─────────────────────────────────────────────┘     │
    └──────────────────────────────────────────────────────┘
                        │
              HTTPS     │  APIs externes
                        ▼
    ┌──────────────────────────────────────────────────────┐
    │  Google Safe Browsing API v4  (detection de menaces)  │
    │  Google Gemini 2.5 Flash     (chatbot SecureBot)     │
    │  Pappers API                 (entreprises FR, opt.)  │
    └──────────────────────────────────────────────────────┘
```
