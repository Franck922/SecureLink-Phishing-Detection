// SecureLink Extension - Popup Logic (Firefox)
const DEFAULT_API = "http://localhost:8001/api";

const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);

let apiUrl = DEFAULT_API;

// Load settings
browser.storage.local.get(["apiUrl", "slToken"]).then((data) => {
  if (data.apiUrl) apiUrl = data.apiUrl;
  $("#api-url-input").value = apiUrl;
});

// Get current tab URL or pending URL from context menu
browser.runtime.sendMessage({ type: "getPendingUrl" }).then((response) => {
  if (response?.url) {
    $("#url-input").value = response.url;
    showPromptBanner(response.url);
  } else {
    browser.tabs.query({ active: true, currentWindow: true }).then((tabs) => {
      if (tabs[0]?.url) {
        $("#url-input").value = tabs[0].url;
      }
    });
  }
}).catch(() => {
  browser.tabs.query({ active: true, currentWindow: true }).then((tabs) => {
    if (tabs[0]?.url) {
      $("#url-input").value = tabs[0].url;
    }
  });
});

function showPromptBanner(url) {
  const banner = $("#prompt-banner");
  if (banner) {
    try {
      const domain = new URL(url).hostname;
      $("#prompt-url").textContent = domain;
    } catch { $("#prompt-url").textContent = url; }
    banner.classList.remove("hidden");
    $("#prompt-yes").addEventListener("click", () => {
      banner.classList.add("hidden");
      $("#analyze-btn").click();
    });
    $("#prompt-no").addEventListener("click", () => {
      banner.classList.add("hidden");
    });
  }
}

// Views
function showView(name) {
  $$(".view").forEach((v) => v.classList.remove("active"));
  $(`#view-${name}`).classList.add("active");
}

// Analyze
$("#analyze-btn").addEventListener("click", async () => {
  const url = $("#url-input").value;
  if (!url || url.startsWith("about:") || url.startsWith("moz-extension://")) {
    showView("error");
    $("#error-msg").textContent = "Cette URL ne peut pas etre analysee.";
    return;
  }

  $("#analyze-btn").disabled = true;
  $("#loading").classList.remove("hidden");

  try {
    const headers = { "Content-Type": "application/json" };
    const stored = await browser.storage.local.get(["slToken"]);
    if (stored.slToken) headers["Authorization"] = `Bearer ${stored.slToken}`;

    const res = await fetch(`${apiUrl}/analyze`, {
      method: "POST",
      headers,
      body: JSON.stringify({ url }),
    });

    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    displayResult(data);
  } catch (e) {
    showView("error");
    $("#error-msg").textContent = `Erreur: ${e.message || "Connexion impossible"}`;
  } finally {
    $("#analyze-btn").disabled = false;
    $("#loading").classList.add("hidden");
  }
});

function displayResult(data) {
  const light = data.traffic_light || "green";
  const badge = $("#result-badge");
  badge.className = `result-badge ${light}`;

  const labels = { green: "Sur", yellow: "Prudence", red: "Danger" };
  const icons = { green: "\u2713", yellow: "!", red: "\u2717" };
  const descs = {
    green: "Ce lien ne presente pas d'indicateur de phishing.",
    yellow: "Ce lien comporte des elements suspects.",
    red: "Ce lien est potentiellement dangereux.",
  };

  $("#badge-icon").textContent = icons[light] || "?";
  $("#risk-label").textContent = labels[light] || "Inconnu";
  $("#risk-desc").textContent = descs[light] || "";

  // Score
  $("#score-global").textContent = `${data.final_score || 0} / 100`;

  // Summary points
  const summaryEl = $("#summary");
  summaryEl.innerHTML = "";
  const summaryItems = buildSummary(data);
  summaryItems.slice(0, 4).forEach((item) => {
    const div = document.createElement("div");
    div.className = `summary-item ${item.type}`;
    const dot = document.createElement("span");
    dot.className = `summary-dot ${item.type}`;
    const text = document.createElement("span");
    text.textContent = item.text;
    div.appendChild(dot);
    div.appendChild(text);
    summaryEl.appendChild(div);
  });

  // Typosquatting alert
  const typoEl = $("#typosquatting-alert");
  if (data.typosquatting_target) {
    typoEl.classList.remove("hidden");
    $("#typo-text").textContent = `Ce domaine imite ${data.typosquatting_target}.`;
    if (data.official_site) {
      $("#typo-link").textContent = `Site officiel : ${data.official_site}`;
      $("#typo-link").href = data.official_site;
      $("#typo-link").classList.remove("hidden");
    }
  } else {
    typoEl.classList.add("hidden");
  }

  showView("result");
}

function buildSummary(data) {
  const items = [];
  const checks = data.network_checks || {};

  // SSL
  if (checks.ssl?.valid) {
    items.push({ type: "safe", text: "Connexion securisee (HTTPS)." });
  } else if (data.url && data.url.startsWith("http://")) {
    items.push({ type: "danger", text: "Connexion non securisee (pas de HTTPS)." });
  }

  // Domain age
  if (checks.whois?.domain_age_days != null) {
    const days = checks.whois.domain_age_days;
    if (days > 365) {
      items.push({ type: "safe", text: `Domaine enregistre depuis plus de ${Math.floor(days / 365)} an(s).` });
    } else if (days < 30) {
      items.push({ type: "danger", text: `Domaine tres recent (${days} jours). Signe frequent de phishing.` });
    }
  }

  // Safe Browsing
  const sb = data.safe_browsing;
  if (sb && sb.checked) {
    if (sb.is_threat) {
      items.push({ type: "danger", text: "Signale comme dangereux par Google Safe Browsing." });
    } else {
      items.push({ type: "safe", text: "Non signale par Google Safe Browsing." });
    }
  }

  // Phishing kit
  const kit = data.phishing_kit;
  if (kit && kit.detected && kit.kits?.length > 0) {
    items.push({ type: "danger", text: `Kit de phishing detecte : ${kit.kits.map((k) => k.name).join(", ")}.` });
  }

  // Content findings (high severity)
  const findings = data.content_findings || [];
  findings
    .filter((f) => f.severity === "critical" || f.severity === "high")
    .slice(0, 2)
    .forEach((f) => {
      items.push({ type: "danger", text: f.description_fr || f.description_en || f.id });
    });

  // Positive content
  const cd = data.content_details || {};
  if (cd.page_fetched && findings.length === 0) {
    items.push({ type: "safe", text: "Contenu de la page sans element suspect." });
  }

  // Dedupe + prioritize dangers first
  const seen = new Set();
  const deduped = items.filter((i) => {
    if (seen.has(i.text)) return false;
    seen.add(i.text);
    return true;
  });
  const dangers = deduped.filter((i) => i.type === "danger");
  const safes = deduped.filter((i) => i.type === "safe");
  return [...dangers, ...safes].slice(0, 4);
}

// Navigation
$("#back-btn").addEventListener("click", () => showView("analyze"));
$("#retry-btn").addEventListener("click", () => showView("analyze"));

// Settings
$("#settings-toggle").addEventListener("click", (e) => {
  e.preventDefault();
  $("#settings-panel").classList.toggle("hidden");
});
$("#close-settings").addEventListener("click", () => {
  $("#settings-panel").classList.add("hidden");
});
$("#save-settings").addEventListener("click", () => {
  const url = $("#api-url-input").value.trim();
  if (url) {
    apiUrl = url;
    browser.storage.local.set({ apiUrl: url });
    $("#settings-panel").classList.add("hidden");
  }
});
