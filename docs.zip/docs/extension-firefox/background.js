// SecureLink Background Script (Firefox)
const DEFAULT_API_URL = "http://localhost:8001/api";

browser.runtime.onInstalled.addListener(() => {
  browser.storage.local.set({ apiUrl: DEFAULT_API_URL, autoPrompt: true });

  browser.contextMenus?.create({
    id: "securelink-analyze",
    title: "Analyser ce lien avec SecureLink",
    contexts: ["link"],
  });
});

browser.contextMenus?.onClicked.addListener((info) => {
  if (info.menuItemId === "securelink-analyze" && info.linkUrl) {
    browser.storage.local.set({ pendingUrl: info.linkUrl });
    browser.browserAction.openPopup();
  }
});

browser.runtime.onMessage.addListener((msg) => {
  if (msg.type === "getPendingUrl") {
    return browser.storage.local.get(["pendingUrl"]).then((data) => {
      browser.storage.local.remove("pendingUrl");
      return { url: data.pendingUrl || null };
    });
  }
});
