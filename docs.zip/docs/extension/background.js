// SecureLink Background Service Worker
const DEFAULT_API_URL = "http://localhost:8001/api";

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({ apiUrl: DEFAULT_API_URL, autoPrompt: true });
});

// Context menu for right-clicking links
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus?.create({
    id: "securelink-analyze",
    title: "Analyser ce lien avec SecureLink",
    contexts: ["link"],
  });
});

chrome.contextMenus?.onClicked.addListener((info) => {
  if (info.menuItemId === "securelink-analyze" && info.linkUrl) {
    chrome.storage.local.set({ pendingUrl: info.linkUrl });
    chrome.action.openPopup();
  }
});

// Load pending URL if set via context menu
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "getPendingUrl") {
    chrome.storage.local.get(["pendingUrl"], (data) => {
      sendResponse({ url: data.pendingUrl || null });
      chrome.storage.local.remove("pendingUrl");
    });
    return true;
  }
});
