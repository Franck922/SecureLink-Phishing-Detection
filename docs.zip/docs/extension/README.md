# SecureLink - Extension Navigateur

> Analysez instantanement les URLs pour detecter les tentatives de phishing, directement depuis votre navigateur.

---

## Navigateurs compatibles

| Navigateur | Version min. | Dossier | Status |
|-----------|-------------|---------|--------|
| **Google Chrome** | 88+ | `/extension/` | Pret |
| **Microsoft Edge** | 88+ | `/extension/` | Pret (meme extension que Chrome) |
| **Mozilla Firefox** | 91+ | `/extension-firefox/` | Pret |
| **Brave** | 88+ | `/extension/` | Pret (meme extension que Chrome) |
| **Opera** | 74+ | `/extension/` | Pret (meme extension que Chrome) |

---

## Installation

### Chrome

1. Ouvrez `chrome://extensions/`
2. Activez le **Mode Developpeur** (interrupteur en haut a droite)
3. Cliquez sur **Charger l'extension non empaquetee**
4. Selectionnez le dossier `extension/`
5. L'icone SecureLink apparait dans votre barre d'outils

### Microsoft Edge

1. Ouvrez `edge://extensions/`
2. Activez le **Mode Developpeur** (interrupteur en bas a gauche)
3. Cliquez sur **Charger l'extension non empaquetee**
4. Selectionnez le dossier `extension/` (le meme que Chrome)
5. L'icone SecureLink apparait dans votre barre d'outils

> Edge utilise le moteur Chromium : l'extension Chrome fonctionne nativement, aucune modification necessaire.

### Mozilla Firefox

1. Ouvrez `about:debugging#/runtime/this-firefox`
2. Cliquez sur **Charger un module temporaire**
3. Selectionnez le fichier `extension-firefox/manifest.json`
4. L'icone SecureLink apparait dans votre barre d'outils

> Note : en mode developpeur, l'extension Firefox est temporaire et disparait a la fermeture du navigateur. Pour une installation permanente, l'extension doit etre signee et publiee sur addons.mozilla.org.

### Brave / Opera

Meme procedure que Chrome :
- **Brave** : `brave://extensions/`
- **Opera** : Menu > Extensions > Gerer les extensions > Mode developpeur

---

## Utilisation

1. Naviguez vers n'importe quel site web
2. Cliquez sur l'icone SecureLink dans la barre d'outils
3. L'URL de la page actuelle est automatiquement detectee
4. Cliquez sur **Analyser cette page**
5. Le resultat s'affiche avec :
   - **Verdict** : Sur / Prudence / Danger (vert / jaune / rouge)
   - **Resume** : jusqu'a 4 points cles (SSL, age du domaine, Safe Browsing, etc.)
   - **Score global** : 0-100 (0 = sur, 100 = dangereux)
   - **Alerte typosquatting** : si le domaine imite une marque connue

### Clic droit sur un lien

1. Faites un clic droit sur n'importe quel lien
2. Selectionnez **Analyser ce lien avec SecureLink**
3. Le popup s'ouvre avec l'URL pre-remplie et propose de lancer l'analyse

## Configuration

- Cliquez sur **Parametres** en bas du popup
- Modifiez l'URL du serveur API :
  - **Local** : `http://localhost:8001/api` (par defaut)
  - **Local** : `http://localhost:8001/api`

---

## Differences techniques Chrome vs Firefox

| Aspect | Chrome/Edge (Manifest V3) | Firefox (Manifest V2) |
|--------|--------------------------|----------------------|
| Manifest | `manifest_version: 3` | `manifest_version: 2` |
| Popup | `action.default_popup` | `browser_action.default_popup` |
| Background | `service_worker` | `scripts` array |
| API | `chrome.*` (callbacks) | `browser.*` (Promises) |
| URLs internes | `chrome://` | `about:`, `moz-extension://` |
| Storage | `chrome.storage.local.get(keys, cb)` | `browser.storage.local.get(keys).then()` |

---

## Structure

```
extension/                    # Chrome / Edge / Brave / Opera
  manifest.json              # Manifest V3
  background.js              # Service Worker
  popup.html / popup.js / popup.css
  icons/

extension-firefox/            # Firefox
  manifest.json              # Manifest V2 + gecko settings
  background.js              # Background script (browser.*)
  popup.html / popup.js / popup.css
  icons/
```
