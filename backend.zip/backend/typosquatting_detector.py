"""
SecureLink Typosquatting Detector
Detects if a domain is a visual/typographic imitation of a well-known brand.
Uses Levenshtein distance + common character substitution patterns + Unicode homoglyph detection.
"""
import re
import unicodedata
import logging

logger = logging.getLogger(__name__)

# Unicode confusables: characters that visually resemble Latin letters
UNICODE_CONFUSABLES = {
    # Cyrillic lookalikes
    '\u0430': 'a', '\u0435': 'e', '\u043e': 'o', '\u0440': 'p', '\u0441': 'c',
    '\u0443': 'y', '\u0445': 'x', '\u0456': 'i', '\u0458': 'j', '\u04bb': 'h',
    '\u0501': 'd', '\u051b': 'q', '\u051d': 'w',
    '\u0410': 'A', '\u0412': 'B', '\u0415': 'E', '\u041a': 'K', '\u041c': 'M',
    '\u041d': 'H', '\u041e': 'O', '\u0420': 'P', '\u0421': 'C', '\u0422': 'T',
    '\u0425': 'X',
    # Greek lookalikes
    '\u03b1': 'a', '\u03b5': 'e', '\u03b9': 'i', '\u03bf': 'o', '\u03c1': 'p',
    '\u03ba': 'k', '\u03bd': 'v', '\u03c5': 'u', '\u03c9': 'w',
    # Latin extended / special
    '\u0101': 'a', '\u0103': 'a', '\u00e0': 'a', '\u00e1': 'a', '\u00e2': 'a',
    '\u00e8': 'e', '\u00e9': 'e', '\u00ea': 'e', '\u00eb': 'e',
    '\u00ec': 'i', '\u00ed': 'i', '\u00ee': 'i', '\u00ef': 'i',
    '\u00f2': 'o', '\u00f3': 'o', '\u00f4': 'o', '\u00f6': 'o', '\u00f8': 'o',
    '\u00f9': 'u', '\u00fa': 'u', '\u00fb': 'u', '\u00fc': 'u',
    '\u0131': 'i',  # dotless i
    '\u1d00': 'a', '\u1d04': 'c', '\u1d05': 'd', '\u1d07': 'e',
    '\u1d0f': 'o', '\u1d18': 'p', '\u1d1b': 't', '\u1d1c': 'u',
}


def normalize_unicode(text):
    """Normalize Unicode confusables to their ASCII equivalents.
    Detects IDN homograph attacks (e.g., аpple.com using Cyrillic 'а').
    Returns (normalized_text, has_confusables).
    """
    normalized = []
    has_confusables = False
    for char in text:
        if char in UNICODE_CONFUSABLES:
            normalized.append(UNICODE_CONFUSABLES[char])
            has_confusables = True
        else:
            # Try NFKD normalization for accented characters
            decomposed = unicodedata.normalize('NFKD', char)
            ascii_char = ''.join(c for c in decomposed if unicodedata.category(c) != 'Mn')
            if ascii_char and ascii_char != char and char.isalpha():
                normalized.append(ascii_char.lower())
                has_confusables = True
            else:
                normalized.append(char)
    return ''.join(normalized), has_confusables

# Known brands with their legitimate domains
KNOWN_BRANDS_DOMAINS = {
    # French services
    "ameli": ["ameli.fr"],
    "impots": ["impots.gouv.fr"],
    "caf": ["caf.fr"],
    "laposte": ["laposte.fr", "laposte.net"],
    "colissimo": ["colissimo.fr"],
    "chronopost": ["chronopost.fr"],
    "edf": ["edf.fr"],
    "engie": ["engie.fr"],
    "free": ["free.fr"],
    "orange": ["orange.fr", "orange.com"],
    "sfr": ["sfr.fr"],
    "bouygues": ["bouyguestelecom.fr", "bouygues.com"],
    "sncf": ["sncf.com", "oui.sncf"],
    "credit agricole": ["credit-agricole.fr"],
    "bnp paribas": ["bnpparibas.com", "bnpparibas.fr"],
    "societe generale": ["societegenerale.fr", "societe-generale.fr"],
    "lcl": ["lcl.fr"],
    "caisse epargne": ["caisse-epargne.fr"],
    "la banque postale": ["labanquepostale.fr"],
    "credit mutuel": ["creditmutuel.fr"],
    "boursorama": ["boursorama.com"],
    "maif": ["maif.fr"],
    "matmut": ["matmut.fr"],
    "macif": ["macif.fr"],
    "pole emploi": ["pole-emploi.fr", "francetravail.fr"],
    "cpam": ["ameli.fr"],
    "dgfip": ["impots.gouv.fr"],
    "antai": ["antai.gouv.fr"],
    # International tech
    "google": ["google.com", "google.fr"],
    "facebook": ["facebook.com"],
    "instagram": ["instagram.com"],
    "whatsapp": ["whatsapp.com"],
    "microsoft": ["microsoft.com"],
    "apple": ["apple.com"],
    "amazon": ["amazon.fr", "amazon.com"],
    "netflix": ["netflix.com"],
    "paypal": ["paypal.com"],
    "linkedin": ["linkedin.com"],
    "twitter": ["twitter.com", "x.com"],
    "dropbox": ["dropbox.com"],
    "adobe": ["adobe.com"],
    "spotify": ["spotify.com"],
    "zoom": ["zoom.us"],
    "slack": ["slack.com"],
    # E-commerce / delivery
    "cdiscount": ["cdiscount.com"],
    "fnac": ["fnac.com"],
    "leboncoin": ["leboncoin.fr"],
    "vinted": ["vinted.fr"],
    "aliexpress": ["aliexpress.com"],
    "wish": ["wish.com"],
    "dhl": ["dhl.com", "dhl.fr"],
    "ups": ["ups.com"],
    "fedex": ["fedex.com"],
    "mondial relay": ["mondialrelay.fr"],
    # Banking international
    "hsbc": ["hsbc.fr", "hsbc.com"],
    "ing": ["ing.fr"],
    "revolut": ["revolut.com"],
    "n26": ["n26.com"],
}

# Common character substitutions used in phishing
CHAR_SUBSTITUTIONS = {
    "o": ["0", "ö", "ø"],
    "0": ["o"],
    "l": ["1", "i", "|"],
    "1": ["l", "i"],
    "i": ["1", "l", "!"],
    "e": ["3", "é", "è", "ê"],
    "a": ["@", "4", "à", "â"],
    "s": ["5", "$"],
    "t": ["7"],
    "g": ["9"],
    "b": ["8"],
}


def _levenshtein_distance(s1, s2):
    """Calculate the Levenshtein (edit) distance between two strings."""
    if len(s1) < len(s2):
        return _levenshtein_distance(s2, s1)
    if len(s2) == 0:
        return len(s1)

    prev_row = range(len(s2) + 1)
    for i, c1 in enumerate(s1):
        curr_row = [i + 1]
        for j, c2 in enumerate(s2):
            cost = 0 if c1 == c2 else 1
            curr_row.append(min(
                curr_row[j] + 1,          # insertion
                prev_row[j + 1] + 1,      # deletion
                prev_row[j] + cost,        # substitution
            ))
        prev_row = curr_row

    return prev_row[-1]


def _normalize_domain(domain):
    """Normalize a domain for comparison: remove www, TLD, hyphens."""
    domain = domain.lower().strip()
    if domain.startswith("www."):
        domain = domain[4:]
    # Remove TLD
    parts = domain.split(".")
    tlds = {"fr", "com", "net", "org", "eu", "io", "co", "uk", "de", "es", "it", "be", "ch", "us", "info", "biz"}
    while len(parts) > 1 and parts[-1] in tlds:
        parts.pop()
    return ".".join(parts)


def _check_char_substitution(domain_clean, brand_clean):
    """Check if domain uses known character substitutions to mimic a brand.
    Also checks for substituted brand + suffix (faceb00k-verify → facebook).
    Returns (is_substitution, prefix_only) tuple.
    """
    # Exact length match: direct substitution
    if len(domain_clean) == len(brand_clean):
        substitution_count = 0
        for dc, bc in zip(domain_clean, brand_clean):
            if dc == bc:
                continue
            subs = CHAR_SUBSTITUTIONS.get(bc, [])
            if dc in subs:
                substitution_count += 1
            else:
                return False, False
        return substitution_count > 0, False

    # Prefix match: substituted brand + extra chars (faceb00kverify → facebook + verify)
    if len(domain_clean) > len(brand_clean):
        prefix = domain_clean[:len(brand_clean)]
        substitution_count = 0
        for dc, bc in zip(prefix, brand_clean):
            if dc == bc:
                continue
            subs = CHAR_SUBSTITUTIONS.get(bc, [])
            if dc in subs:
                substitution_count += 1
            else:
                return False, False
        if substitution_count > 0:
            return True, True  # prefix substitution with suffix

    return False, False


def detect_typosquatting(domain):
    """Detect if a domain is trying to impersonate a known brand.

    Returns:
        dict with keys:
        - is_typosquatting (bool)
        - target_brand (str or None)
        - legitimate_domains (list)
        - technique (str): type of impersonation detected
        - similarity (float 0-1)
    """
    result = {
        "is_typosquatting": False,
        "target_brand": None,
        "legitimate_domains": [],
        "technique": None,
        "similarity": 0.0,
    }

    domain_lower = domain.lower().strip()

    # Extract hostname from URL if needed
    if "://" in domain_lower:
        try:
            from urllib.parse import urlparse
            parsed = urlparse(domain_lower)
            domain_lower = parsed.hostname or domain_lower
        except Exception:
            pass

    # Remove www. prefix
    if domain_lower.startswith("www."):
        domain_lower = domain_lower[4:]

    # Remove port
    domain_lower = domain_lower.split(":")[0]

    domain_clean = _normalize_domain(domain_lower)
    domain_nohyphen = domain_clean.replace("-", "").replace(".", "")

    # Normalize Unicode confusables (IDN homograph attack detection)
    domain_ascii, has_confusables = normalize_unicode(domain_nohyphen)

    best_match = None
    best_score = 0.0

    for brand_name, legit_domains in KNOWN_BRANDS_DOMAINS.items():
        # Skip if it IS the legitimate domain
        if domain_lower in legit_domains or any(domain_lower.endswith("." + d) for d in legit_domains):
            return result  # It's the real domain, not typosquatting

        brand_clean = brand_name.replace(" ", "").replace("-", "").lower()

        # 0. Check Unicode homoglyph attack (аpple.com with Cyrillic 'а')
        if has_confusables and domain_ascii == brand_clean:
            score = 0.99
            technique = "homoglyphe_unicode"
            if score > best_score:
                best_score = score
                best_match = {"brand": brand_name, "domains": legit_domains, "technique": technique}

        # 1. Check character substitution (g00gle, amaz0n, 0range, faceb00k-verify)
        is_sub, is_prefix = _check_char_substitution(domain_nohyphen, brand_clean)
        if is_sub:
            if is_prefix:
                score = 0.92
                technique = "substitution_avec_suffixe"
            else:
                score = 0.95
                technique = "substitution_caracteres"
            if score > best_score:
                best_score = score
                best_match = {"brand": brand_name, "domains": legit_domains, "technique": technique}

        # 2. Check Levenshtein distance (gooogle, amazom, oarnge)
        dist = _levenshtein_distance(domain_nohyphen, brand_clean)
        brand_len = len(brand_clean)
        if brand_len >= 4 and dist > 0:
            # Allow 1 edit for short brands (4-6 chars), 2 for longer
            max_dist = 1 if brand_len <= 6 else 2
            if dist <= max_dist:
                score = 1 - (dist / brand_len)
                technique = "faute_frappe" if dist == 1 else "modification_multiple"
                if score > best_score:
                    best_score = score
                    best_match = {"brand": brand_name, "domains": legit_domains, "technique": technique}

        # 3. Check brand name embedded with extra chars (paypal-secure.com, google-login.com)
        if brand_clean in domain_nohyphen and domain_nohyphen != brand_clean:
            extra = len(domain_nohyphen) - len(brand_clean)
            if 1 <= extra <= 15:
                score = 0.85
                technique = "marque_dans_domaine"
                # Common phishing suffixes/prefixes
                phishing_words = ["secure", "login", "verify", "account", "update", "confirm",
                                  "service", "support", "alert", "notification", "fr", "online"]
                remaining = domain_nohyphen.replace(brand_clean, "")
                if any(pw in remaining for pw in phishing_words):
                    score = 0.92
                    technique = "marque_avec_mot_piege"
                if score > best_score:
                    best_score = score
                    best_match = {"brand": brand_name, "domains": legit_domains, "technique": technique}

        # 4. Check hyphenated brand splitting (pay-pal.com, face-book.com)
        if "-" in domain_clean:
            domain_joined = domain_clean.replace("-", "")
            if domain_joined == brand_clean:
                score = 0.90
                technique = "separation_par_tiret"
                if score > best_score:
                    best_score = score
                    best_match = {"brand": brand_name, "domains": legit_domains, "technique": technique}

    if best_match and best_score >= 0.75:
        result["is_typosquatting"] = True
        result["target_brand"] = best_match["brand"]
        result["legitimate_domains"] = best_match["domains"]
        result["technique"] = best_match["technique"]
        result["similarity"] = round(best_score, 2)

    return result
