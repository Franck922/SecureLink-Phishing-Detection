"""
SecureLink Phishing Kit Fingerprinting Module
Detects signatures and patterns associated with known phishing kits.

IMPORTANT: Kit detection patterns must be specific enough to avoid false positives
on large, complex legitimate sites (e.g., YouTube, Facebook, Amazon).
Patterns are only matched when contextual conditions are met (login form, small page, etc.)
"""
import re
import logging
from urllib.parse import urlparse

logger = logging.getLogger(__name__)

# Well-known legitimate domains that should never trigger kit detection
# (their HTML is too complex and would match loose patterns)
KNOWN_LEGITIMATE_DOMAINS = {
    "google.com", "youtube.com", "facebook.com", "instagram.com", "twitter.com",
    "x.com", "linkedin.com", "amazon.com", "amazon.fr", "apple.com", "microsoft.com",
    "github.com", "stackoverflow.com", "wikipedia.org", "reddit.com", "netflix.com",
    "spotify.com", "twitch.tv", "tiktok.com", "whatsapp.com", "telegram.org",
    "yahoo.com", "bing.com", "duckduckgo.com", "brave.com", "mozilla.org",
    "paypal.com", "stripe.com", "chase.com", "bankofamerica.com", "wellsfargo.com",
    "citi.com", "hsbc.com", "barclays.com", "bnpparibas.com", "societegenerale.fr",
    "credit-agricole.fr", "labanquepostale.fr", "lcl.fr", "boursorama.com",
    "ebay.com", "ebay.fr", "aliexpress.com", "cdiscount.com", "fnac.com",
    "leboncoin.fr", "orange.fr", "free.fr", "sfr.fr", "bouyguestelecom.fr",
    "impots.gouv.fr", "service-public.fr", "ameli.fr", "caf.fr",
    "legifrance.gouv.fr", "education.gouv.fr", "pole-emploi.fr", "france.tv",
    "office.com", "live.com", "outlook.com", "adobe.com", "zoom.us",
    "dropbox.com", "slack.com", "notion.so", "figma.com", "canva.com",
    "cloudflare.com", "aws.amazon.com", "azure.microsoft.com",
    "wikipedia.org", "wikimedia.org", "wiktionary.org",
    "digitalocean.com", "heroku.com", "vercel.com", "netlify.com",
}


def _extract_domain(url):
    """Extract the registrable domain from a URL."""
    try:
        parsed = urlparse(url if url.startswith(("http://", "https://")) else "http://" + url)
        host = parsed.netloc.lower().split(":")[0].replace("www.", "")
        # Handle subdomains: keep last 2 parts (or 3 for .co.uk etc.)
        parts = host.split(".")
        if len(parts) >= 2:
            return ".".join(parts[-2:])
        return host
    except Exception:
        return ""


def _is_known_legitimate(url):
    """Check if URL belongs to a known legitimate domain."""
    domain = _extract_domain(url)
    return domain in KNOWN_LEGITIMATE_DOMAINS


# Known phishing kit signatures - STRICT patterns requiring multiple indicators
KIT_SIGNATURES = [
    {
        "id": "16shop",
        "name": "16Shop",
        "patterns": [
            r"16shop",
            r"sixteenshop",
            r"/antibot\.php",
            r"priv8tools",
        ],
        "description_fr": "Signature du kit de phishing \"16Shop\" detectee. Ce kit est utilise pour voler des identifiants Apple, Amazon et PayPal.",
        "description_en": "\"16Shop\" phishing kit signature detected. This kit is used to steal Apple, Amazon and PayPal credentials.",
        "min_matches": 1,
    },
    {
        "id": "logokit",
        "name": "LogoKit",
        "patterns": [
            r"logokit",
            r"/logo\.php\?",
            r"dynamiclogo",
        ],
        "description_fr": "Signature du kit \"LogoKit\" detectee. Ce kit genere dynamiquement des pages de phishing avec le logo de la marque ciblee.",
        "description_en": "\"LogoKit\" kit signature detected. This kit dynamically generates phishing pages with the target brand's logo.",
        "min_matches": 1,
    },
    {
        "id": "chase_kit",
        "name": "Chase Phishing Kit",
        "patterns": [
            r"chaseonline\.chase\.com.*verify",
            r"/chase/(?:auth|login|verify)\.php",
        ],
        "description_fr": "Kit de phishing imitant la banque Chase detecte.",
        "description_en": "Phishing kit imitating Chase bank detected.",
        "min_matches": 1,
        "requires_login_form": True,
    },
    {
        "id": "office365_kit",
        "name": "Office 365 Phishing Kit",
        "patterns": [
            r"office365.*phish",
            r"o365.*credentials",
            r"microsoftonline.*fake",
            r"/owa/auth/logon\.aspx.*impersonate",
        ],
        "description_fr": "Kit de phishing imitant Microsoft Office 365 detecte.",
        "description_en": "Phishing kit imitating Microsoft Office 365 detected.",
        "min_matches": 1,
    },
    {
        "id": "generic_telegram",
        "name": "Telegram Exfiltration Kit",
        "patterns": [
            r"api\.telegram\.org/bot[0-9]+:",
        ],
        "description_fr": "Ce site envoie des donnees volees via un bot Telegram. Technique frequente des kits de phishing modernes.",
        "description_en": "This site sends stolen data via a Telegram bot. Common technique in modern phishing kits.",
        "min_matches": 1,
    },
]

# Structural patterns - only checked on smaller pages or with login forms
STRUCTURAL_PATTERNS = [
    {
        "id": "base64_brand_logo",
        "pattern": r'<img[^>]*src\s*=\s*["\']data:image/(?:png|jpeg|gif|svg);base64,[A-Za-z0-9+/=]{500,}["\']',
        "description_fr": "Le logo de marque est embarque en base64 dans la page (technique de kit de phishing pour eviter la detection).",
        "description_en": "The brand logo is embedded as base64 in the page (phishing kit technique to avoid detection).",
        "severity": "medium",
        "condition": "login_form",
    },
    {
        "id": "credential_exfil_ajax",
        "pattern": r'(?:XMLHttpRequest|fetch)\s*\([^)]*(?:\.php|\.aspx)[^)]*\).*(?:password|passwd|email|login)',
        "description_fr": "La page envoie les identifiants saisis vers un script externe via AJAX.",
        "description_en": "The page sends entered credentials to an external script via AJAX.",
        "severity": "critical",
        "condition": "login_form",
    },
    {
        "id": "obfuscated_redirect",
        "pattern": r'(?:window\.location|document\.location|location\.href)\s*=\s*(?:atob|unescape|decodeURIComponent)\s*\(',
        "description_fr": "La page utilise une redirection obfusquee (encodee) pour masquer la destination.",
        "description_en": "The page uses an obfuscated (encoded) redirect to hide the destination.",
        "severity": "high",
    },
    {
        "id": "php_mailer_form",
        "pattern": r'<form[^>]*action\s*=\s*["\'][^"\']*(?:mail|send|submit|post|log|result)\.php["\']',
        "description_fr": "Le formulaire envoie les donnees vers un script PHP (mail.php, send.php...) typique des kits de phishing.",
        "description_en": "The form sends data to a PHP script (mail.php, send.php...) typical of phishing kits.",
        "severity": "high",
        "condition": "login_form",
    },
    {
        "id": "multiple_step_form",
        "pattern": r'(?:step|etape|phase)\s*["\']?\s*[:\-=]\s*["\']?\s*[123].*(?:password|carte|card|ssn|cvv)',
        "description_fr": "La page utilise un formulaire multi-etapes pour collecter progressivement vos informations sensibles.",
        "description_en": "The page uses a multi-step form to progressively collect your sensitive information.",
        "severity": "high",
        "condition": "login_form",
    },
    {
        "id": "fake_loading_animation",
        "pattern": r'(?:loading|chargement|verification|verifying).*(?:spinner|loader|progress)',
        "description_fr": "La page affiche une fausse animation de chargement/verification, souvent pour simuler un traitement.",
        "description_en": "The page displays a fake loading/verification animation, often to simulate processing.",
        "severity": "low",
        "condition": "login_form",
    },
    {
        "id": "countdown_urgency",
        "pattern": r'(?:countdown|compte.?a.?rebours).*(?:\d+\s*[:h]\s*\d+)',
        "description_fr": "La page contient un compte a rebours pour creer un sentiment d'urgence et vous presser d'agir.",
        "description_en": "The page contains a countdown timer to create urgency and pressure you into acting.",
        "severity": "medium",
        "condition": "small_page",
    },
    {
        "id": "data_uri_form_action",
        "pattern": r'<form[^>]*action\s*=\s*["\']data:',
        "description_fr": "Le formulaire utilise un Data URI comme action, technique d'exfiltration sophistiquee.",
        "description_en": "The form uses a Data URI as action, a sophisticated exfiltration technique.",
        "severity": "critical",
    },
]


def detect_phishing_kit(html, url="", has_login_form=False):
    """Analyze HTML for known phishing kit signatures and structural patterns.
    
    Args:
        html: Raw HTML content of the page
        url: The URL being analyzed (used for domain whitelist)
        has_login_form: Whether the page contains a login form
    
    Returns a dict with detection results.
    """
    result = {
        "detected": False,
        "kits": [],
        "structural_findings": [],
        "risk_score": 0,
    }

    if not html:
        return result

    # Skip kit detection for known legitimate domains
    if url and _is_known_legitimate(url):
        return result

    html_lower = html.lower()
    is_small_page = len(html) < 100_000  # < 100KB

    # 1. Check known kit signatures
    for kit in KIT_SIGNATURES:
        # Some kits only make sense with a login form present
        if kit.get("requires_login_form") and not has_login_form:
            continue

        match_count = 0
        min_needed = kit.get("min_matches", 1)
        for pattern in kit["patterns"]:
            if re.search(pattern, html_lower, re.I):
                match_count += 1
        
        if match_count >= min_needed:
            result["detected"] = True
            result["kits"].append({
                "id": kit["id"],
                "name": kit["name"],
                "description_fr": kit["description_fr"],
                "description_en": kit["description_en"],
            })
            result["risk_score"] += 40

    # 2. Check structural patterns
    for sp in STRUCTURAL_PATTERNS:
        cond = sp.get("condition")
        if cond == "login_form" and not has_login_form:
            continue
        if cond == "small_page" and not is_small_page:
            continue
        if re.search(sp["pattern"], html, re.I | re.S):
            severity_score = {"critical": 35, "high": 25, "medium": 15, "low": 5}
            result["structural_findings"].append({
                "id": sp["id"],
                "description_fr": sp["description_fr"],
                "description_en": sp["description_en"],
                "severity": sp["severity"],
            })
            result["risk_score"] += severity_score.get(sp["severity"], 10)
            if not result["detected"]:
                result["detected"] = True

    result["risk_score"] = min(100, result["risk_score"])
    return result
