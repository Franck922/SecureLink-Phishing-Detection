from fastapi import FastAPI, APIRouter, Request, HTTPException
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
from slowapi import Limiter
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
from starlette.responses import JSONResponse
import os
import logging
import re as re_module
from pathlib import Path
from pydantic import BaseModel, Field, field_validator
from typing import List, Optional
import uuid
import io
from datetime import datetime, timezone, timedelta

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# Rate limiter
limiter = Limiter(key_func=get_remote_address)
app = FastAPI()
app.state.limiter = limiter

@app.exception_handler(RateLimitExceeded)
async def rate_limit_handler(request: Request, exc: RateLimitExceeded):
    return JSONResponse(
        status_code=429,
        content={"detail": "Trop de requetes. Reessayez dans quelques minutes."},
    )

api_router = APIRouter(prefix="/api")

# Import local modules
from fastapi.responses import StreamingResponse
from auth import hash_password, verify_password, create_token, get_current_user
from url_analyzer import analyze_url
from ml_model import get_model
from news_feeds import fetch_news, TREND_ALERTS, EXTERNAL_RESOURCES
from dataset_manager import fetch_and_store, get_training_data, get_dataset_stats
from simulation import get_random_scenarios, get_scenario_by_id
from export_utils import generate_analyses_csv, generate_users_csv, generate_analyses_pdf, generate_admin_report_pdf
from weekly_report import generate_weekly_report

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# ==================== MODELS ====================

class RegisterInput(BaseModel):
    username: str
    email: str
    password: str
    language: str = "fr"

    @field_validator("password")
    @classmethod
    def validate_password(cls, v):
        if len(v) < 8:
            raise ValueError("Le mot de passe doit contenir au moins 8 caracteres")
        if not re_module.search(r"[A-Z]", v):
            raise ValueError("Le mot de passe doit contenir au moins une majuscule")
        if not re_module.search(r"[0-9]", v):
            raise ValueError("Le mot de passe doit contenir au moins un chiffre")
        return v

class LoginInput(BaseModel):
    email: str
    password: str

class AnalyzeInput(BaseModel):
    url: str

class FeedbackInput(BaseModel):
    analysis_id: str
    is_phishing: bool

class QuizAnswerInput(BaseModel):
    module_id: str
    question_index: int
    answer: int

class ContributeInput(BaseModel):
    url: str
    category: str = "unknown"  # phishing, safe, unknown
    comment: str = ""

class ResourceCompleteInput(BaseModel):
    resource_id: str

class SimulationAnswerInput(BaseModel):
    scenario_id: str
    user_answer: bool  # True = user thinks it's phishing

class NotificationReadInput(BaseModel):
    notification_ids: List[str] = []

class AdminPromoteInput(BaseModel):
    email: str

class ContributionValidateInput(BaseModel):
    contribution_id: str
    status: str  # approved, rejected
    is_phishing: Optional[bool] = None

# ==================== XP / GAMIFICATION HELPERS ====================

XP_ACTIONS = {
    "analyze_url": 10,
    "detect_danger": 25,
    "complete_quiz": 50,
    "perfect_quiz": 100,
    "daily_login": 5,
    "submit_feedback": 15,
    "contribute_url": 20,
    "complete_resource": 30,
}

LEVELS = [
    {"level": 1, "name_fr": "Débutant", "name_en": "Beginner", "xp_required": 0},
    {"level": 2, "name_fr": "Apprenti", "name_en": "Apprentice", "xp_required": 100},
    {"level": 3, "name_fr": "Gardien", "name_en": "Guardian", "xp_required": 300},
    {"level": 4, "name_fr": "Protecteur", "name_en": "Protector", "xp_required": 600},
    {"level": 5, "name_fr": "Sentinelle", "name_en": "Sentinel", "xp_required": 1000},
    {"level": 6, "name_fr": "Expert", "name_en": "Expert", "xp_required": 1500},
    {"level": 7, "name_fr": "Maître", "name_en": "Master", "xp_required": 2500},
    {"level": 8, "name_fr": "Légende", "name_en": "Legend", "xp_required": 4000},
]

BADGES = [
    {"id": "first_scan", "name_fr": "Premier Scan", "name_en": "First Scan", "description_fr": "Analysez votre premier lien", "description_en": "Analyze your first link", "icon": "shield", "condition": "analyses_count >= 1"},
    {"id": "danger_detector", "name_fr": "Détecteur de Danger", "name_en": "Danger Detector", "description_fr": "Détectez 5 liens dangereux", "description_en": "Detect 5 dangerous links", "icon": "alert-triangle", "condition": "dangers_detected >= 5"},
    {"id": "quiz_master", "name_fr": "Maître du Quiz", "name_en": "Quiz Master", "description_fr": "Complétez tous les modules de formation", "description_en": "Complete all training modules", "icon": "graduation-cap", "condition": "modules_completed >= 5"},
    {"id": "streak_7", "name_fr": "Semaine de Feu", "name_en": "Fire Week", "description_fr": "Maintenez une série de 7 jours", "description_en": "Maintain a 7-day streak", "icon": "flame", "condition": "streak >= 7"},
    {"id": "analyzer_50", "name_fr": "Analyste Pro", "name_en": "Pro Analyst", "description_fr": "Analysez 50 liens", "description_en": "Analyze 50 links", "icon": "search", "condition": "analyses_count >= 50"},
    {"id": "perfect_score", "name_fr": "Score Parfait", "name_en": "Perfect Score", "description_fr": "Obtenez 100% à un quiz", "description_en": "Get 100% on a quiz", "icon": "star", "condition": "perfect_quizzes >= 1"},
    {"id": "community_helper", "name_fr": "Aide Communautaire", "name_en": "Community Helper", "description_fr": "Soumettez 10 retours de feedback", "description_en": "Submit 10 feedback reports", "icon": "heart", "condition": "feedback_count >= 10"},
    {"id": "streak_30", "name_fr": "Mois de Feu", "name_en": "Fire Month", "description_fr": "Maintenez une série de 30 jours", "description_en": "Maintain a 30-day streak", "icon": "trophy", "condition": "streak >= 30"},
]

def get_level(xp):
    current_level = LEVELS[0]
    for lvl in LEVELS:
        if xp >= lvl["xp_required"]:
            current_level = lvl
    return current_level

def get_next_level(xp):
    for lvl in LEVELS:
        if xp < lvl["xp_required"]:
            return lvl
    return None

async def award_xp(user_id, action, db_ref):
    xp = XP_ACTIONS.get(action, 0)
    if xp == 0:
        return
    await db_ref.users.update_one(
        {"id": user_id},
        {"$inc": {"xp": xp, "total_xp_earned": xp}}
    )
    # Check and update streak
    user = await db_ref.users.find_one({"id": user_id}, {"_id": 0})
    if user:
        today = datetime.now(timezone.utc).date().isoformat()
        last_active = user.get("last_active_date", "")
        yesterday = (datetime.now(timezone.utc).date() - timedelta(days=1)).isoformat()
        if last_active == yesterday:
            await db_ref.users.update_one({"id": user_id}, {"$inc": {"streak": 1}, "$set": {"last_active_date": today}})
        elif last_active != today:
            await db_ref.users.update_one({"id": user_id}, {"$set": {"streak": 1, "last_active_date": today}})
        else:
            await db_ref.users.update_one({"id": user_id}, {"$set": {"last_active_date": today}})

def _get_earned_badge_ids(badges_data):
    """Extract badge IDs from badges data (handles both old format [str] and new format [{id, earned_at}])."""
    ids = []
    for b in badges_data:
        if isinstance(b, str):
            ids.append(b)
        elif isinstance(b, dict):
            ids.append(b.get("id", ""))
    return ids

def _compute_badge_progress(badge, stats, streak):
    """Compute progress (0-100) toward a badge based on its condition."""
    analyses_count = stats.get("analyses_count", 0)
    dangers_detected = stats.get("dangers_detected", 0)
    modules_completed = stats.get("modules_completed", 0)
    perfect_quizzes = stats.get("perfect_quizzes", 0)
    feedback_count = stats.get("feedback_count", 0)
    cond = badge["condition"]
    try:
        if "analyses_count" in cond:
            target = int(cond.split(">=")[1].strip())
            return min(100, int((analyses_count / target) * 100))
        elif "dangers_detected" in cond:
            target = int(cond.split(">=")[1].strip())
            return min(100, int((dangers_detected / target) * 100))
        elif "modules_completed" in cond:
            target = int(cond.split(">=")[1].strip())
            return min(100, int((modules_completed / target) * 100))
        elif "streak" in cond:
            target = int(cond.split(">=")[1].strip())
            return min(100, int((streak / target) * 100))
        elif "perfect_quizzes" in cond:
            target = int(cond.split(">=")[1].strip())
            return min(100, int((perfect_quizzes / target) * 100))
        elif "feedback_count" in cond:
            target = int(cond.split(">=")[1].strip())
            return min(100, int((feedback_count / target) * 100))
    except Exception:
        pass
    return 0

async def check_badges(user_id, db_ref):
    user = await db_ref.users.find_one({"id": user_id}, {"_id": 0})
    if not user:
        return []
    badges_data = user.get("badges", [])
    earned_ids = _get_earned_badge_ids(badges_data)
    new_badges = []
    stats = user.get("stats", {})
    analyses_count = stats.get("analyses_count", 0)
    dangers_detected = stats.get("dangers_detected", 0)
    modules_completed = stats.get("modules_completed", 0)
    streak = user.get("streak", 0)
    perfect_quizzes = stats.get("perfect_quizzes", 0)
    feedback_count = stats.get("feedback_count", 0)

    for badge in BADGES:
        if badge["id"] in earned_ids:
            continue
        try:
            if eval(badge["condition"]):
                badges_data.append({"id": badge["id"], "earned_at": datetime.now(timezone.utc).isoformat()})
                new_badges.append(badge)
        except Exception:
            continue

    if new_badges:
        await db_ref.users.update_one({"id": user_id}, {"$set": {"badges": badges_data}})
    return new_badges


# ==================== AUTH ROUTES ====================

@api_router.post("/auth/register")
@limiter.limit("10/hour")
async def register(request: Request, input: RegisterInput):
    existing = await db.users.find_one({"email": input.email.lower()}, {"_id": 0})
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")

    user_id = str(uuid.uuid4())
    user = {
        "id": user_id,
        "username": input.username,
        "email": input.email.lower(),
        "password_hash": hash_password(input.password),
        "language": input.language,
        "xp": 0,
        "total_xp_earned": 0,
        "streak": 0,
        "last_active_date": "",
        "badges": [],
        "stats": {
            "analyses_count": 0,
            "dangers_detected": 0,
            "suspects_detected": 0,
            "safe_detected": 0,
            "modules_completed": 0,
            "perfect_quizzes": 0,
            "feedback_count": 0,
            "contributions_count": 0,
        },
        "is_admin": False,
        "onboarding_completed": False,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    await db.users.insert_one(user)
    token = create_token(user_id, input.email.lower())
    return {
        "token": token,
        "user": {
            "id": user_id, "username": input.username, "email": input.email.lower(),
            "xp": 0, "streak": 0, "badges": [], "language": input.language,
            "level": LEVELS[0], "is_admin": False, "onboarding_completed": False,
        }
    }

@api_router.post("/auth/login")
@limiter.limit("20/hour")
async def login(request: Request, input: LoginInput):
    user = await db.users.find_one({"email": input.email.lower()}, {"_id": 0})
    if not user or not verify_password(input.password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Invalid credentials")

    token = create_token(user["id"], user["email"])
    level = get_level(user.get("xp", 0))
    next_level = get_next_level(user.get("xp", 0))
    return {
        "token": token,
        "user": {
            "id": user["id"], "username": user["username"], "email": user["email"],
            "xp": user.get("xp", 0), "streak": user.get("streak", 0),
            "badges": user.get("badges", []), "language": user.get("language", "fr"),
            "level": level, "next_level": next_level,
            "stats": user.get("stats", {}), "is_admin": user.get("is_admin", False),
            "onboarding_completed": user.get("onboarding_completed", False),
        }
    }

@api_router.get("/auth/me")
async def get_me(request: Request):
    user = await get_current_user(request, db)
    if not user:
        raise HTTPException(status_code=401, detail="Not authenticated")
    level = get_level(user.get("xp", 0))
    next_level = get_next_level(user.get("xp", 0))
    return {
        "id": user["id"], "username": user["username"], "email": user["email"],
        "xp": user.get("xp", 0), "streak": user.get("streak", 0),
        "badges": user.get("badges", []), "language": user.get("language", "fr"),
        "level": level, "next_level": next_level,
        "stats": user.get("stats", {}), "is_admin": user.get("is_admin", False),
        "onboarding_completed": user.get("onboarding_completed", False),
    }

@api_router.post("/user/onboarding/complete")
async def complete_onboarding(request: Request):
    user = await get_current_user(request, db)
    if not user:
        raise HTTPException(status_code=401, detail="Not authenticated")
    await db.users.update_one({"id": user["id"]}, {"$set": {"onboarding_completed": True}})
    return {"status": "ok"}


# ==================== URL ANALYSIS ROUTES ====================

@api_router.post("/analyze")
@limiter.limit("20/hour")
async def analyze(input: AnalyzeInput, request: Request):
    url = input.url.strip()
    if not url:
        raise HTTPException(status_code=400, detail="URL is required")
    # URL validation
    if len(url) > 2048:
        raise HTTPException(status_code=400, detail="URL trop longue")
    if any(c in url for c in ['<', '>', '{', '}', '|', '\\', '^', '`']):
        raise HTTPException(status_code=400, detail="URL contient des caracteres invalides")

    result = analyze_url(url)
    analysis_id = str(uuid.uuid4())
    result["id"] = analysis_id
    result["analyzed_at"] = datetime.now(timezone.utc).isoformat()

    # Company verification via Pappers (content-driven)
    from company_verifier import verify_company
    from urllib.parse import urlparse as _urlparse
    try:
        parsed = _urlparse(url if url.startswith(("http://", "https://")) else "https://" + url)
        domain = parsed.hostname or ""
        # Pass content signals for smarter matching
        content_signals = result.get("content_details", {}).get("company_signals") or {}
        company_data = await verify_company(domain, db, content_signals=content_signals)
        result["company_verification"] = company_data
        if company_data.get("verified") and company_data.get("company"):
            # Reduce risk score for verified companies
            original_score = result["final_score"]
            result["final_score"] = max(0, result["final_score"] - 20)
            if result["final_score"] < 30:
                result["risk_level"] = "SAFE"
                result["traffic_light"] = "green"
            elif result["final_score"] < 60:
                result["risk_level"] = "SUSPICIOUS"
                result["traffic_light"] = "orange"
    except Exception as e:
        logger.warning(f"Company verification failed: {e}")
        result["company_verification"] = {"verified": False, "company": None, "source": "error"}

    # Check if user is authenticated
    user = await get_current_user(request, db)
    if user:
        result["user_id"] = user["id"]
        # Save to history
        await db.analyses.insert_one({**result, "user_id": user["id"]})
        # Award XP
        await award_xp(user["id"], "analyze_url", db)
        if result["risk_level"] == "DANGEROUS":
            await award_xp(user["id"], "detect_danger", db)
            await db.users.update_one({"id": user["id"]}, {"$inc": {"stats.dangers_detected": 1}})
        elif result["risk_level"] == "SUSPICIOUS":
            await db.users.update_one({"id": user["id"]}, {"$inc": {"stats.suspects_detected": 1}})
        else:
            await db.users.update_one({"id": user["id"]}, {"$inc": {"stats.safe_detected": 1}})
        await db.users.update_one({"id": user["id"]}, {"$inc": {"stats.analyses_count": 1}})
        new_badges = await check_badges(user["id"], db)
        result["new_badges"] = new_badges
        # Get updated user info
        updated_user = await db.users.find_one({"id": user["id"]}, {"_id": 0, "password_hash": 0})
        if updated_user:
            result["user_xp"] = updated_user.get("xp", 0)
            result["user_streak"] = updated_user.get("streak", 0)
    else:
        # Save anonymous analysis
        await db.analyses.insert_one({**result, "user_id": "anonymous"})

    # Remove MongoDB _id if present
    result.pop("_id", None)
    return result

@api_router.get("/analysis/{analysis_id}")
async def get_analysis(analysis_id: str):
    analysis = await db.analyses.find_one({"id": analysis_id}, {"_id": 0})
    if not analysis:
        raise HTTPException(status_code=404, detail="Analysis not found")
    return analysis


class ScreenshotInput(BaseModel):
    url: str


@api_router.post("/screenshot")
@limiter.limit("20/hour")
async def take_screenshot(input: ScreenshotInput, request: Request):
    """Capture a screenshot of the given URL using a headless browser."""
    from page_screenshot import capture_screenshot

    url = input.url.strip()
    if not url:
        raise HTTPException(status_code=400, detail="URL is required")
    if len(url) > 2048:
        raise HTTPException(status_code=400, detail="URL trop longue")

    result = await capture_screenshot(url)
    return result

@api_router.post("/feedback")
async def submit_feedback(input: FeedbackInput, request: Request):
    user = await get_current_user(request, db)
    feedback = {
        "id": str(uuid.uuid4()),
        "analysis_id": input.analysis_id,
        "is_phishing": input.is_phishing,
        "submitted_by": user["id"] if user else "anonymous",
        "submitted_at": datetime.now(timezone.utc).isoformat(),
    }
    await db.feedback.insert_one(feedback)

    # Get the analysis to store URL for retraining
    analysis = await db.analyses.find_one({"id": input.analysis_id}, {"_id": 0})
    if analysis:
        await db.training_data.insert_one({
            "url": analysis["url"],
            "is_phishing": input.is_phishing,
            "source": "user_feedback",
            "submitted_at": datetime.now(timezone.utc).isoformat(),
        })

    if user:
        await award_xp(user["id"], "submit_feedback", db)
        await db.users.update_one({"id": user["id"]}, {"$inc": {"stats.feedback_count": 1}})
        await check_badges(user["id"], db)

    return {"message": "Feedback submitted", "id": feedback["id"]}


# ==================== USER DASHBOARD ROUTES ====================

@api_router.get("/user/dashboard")
async def get_dashboard(request: Request):
    user = await get_current_user(request, db)
    if not user:
        raise HTTPException(status_code=401, detail="Not authenticated")

    level = get_level(user.get("xp", 0))
    next_level = get_next_level(user.get("xp", 0))

    # Recent analyses
    recent = await db.analyses.find(
        {"user_id": user["id"]},
        {"_id": 0}
    ).sort("analyzed_at", -1).limit(10).to_list(10)

    # Weekly stats
    week_ago = (datetime.now(timezone.utc) - timedelta(days=7)).isoformat()
    weekly_analyses = await db.analyses.find(
        {"user_id": user["id"], "analyzed_at": {"$gte": week_ago}},
        {"_id": 0}
    ).to_list(100)

    weekly_stats = {"total": len(weekly_analyses), "safe": 0, "suspicious": 0, "dangerous": 0}
    for a in weekly_analyses:
        level_key = a.get("risk_level", "").lower()
        if level_key in weekly_stats:
            weekly_stats[level_key] += 1

    # Badge details with progress and earned dates
    badges_data = user.get("badges", [])
    earned_ids = _get_earned_badge_ids(badges_data)
    earned_dates = {}
    for b in badges_data:
        if isinstance(b, dict):
            earned_dates[b.get("id", "")] = b.get("earned_at", "")
        elif isinstance(b, str):
            earned_dates[b] = ""

    stats = user.get("stats", {})
    streak = user.get("streak", 0)
    badge_details = []
    for b in BADGES:
        is_earned = b["id"] in earned_ids
        progress = 100 if is_earned else _compute_badge_progress(b, stats, streak)
        badge_details.append({
            **b,
            "earned": is_earned,
            "earned_at": earned_dates.get(b["id"], "") if is_earned else None,
            "progress": progress,
        })

    # XP progression details
    current_xp = user.get("xp", 0)
    xp_in_level = current_xp - level["xp_required"]
    xp_for_next = (next_level["xp_required"] - level["xp_required"]) if next_level else 0
    xp_progress = min(100, int((xp_in_level / xp_for_next) * 100)) if xp_for_next > 0 else 100

    return {
        "user": {
            "id": user["id"], "username": user["username"], "email": user["email"],
            "xp": current_xp, "streak": streak,
            "language": user.get("language", "fr"),
            "level": level, "next_level": next_level,
            "stats": stats,
            "xp_in_level": xp_in_level,
            "xp_for_next": xp_for_next,
            "xp_progress": xp_progress,
            "total_xp_earned": user.get("total_xp_earned", current_xp),
        },
        "badges": badge_details,
        "levels": LEVELS,
        "recent_analyses": recent,
        "weekly_stats": weekly_stats,
    }

@api_router.get("/user/history")
async def get_history(request: Request, page: int = 1, limit: int = 20, risk_filter: Optional[str] = None):
    user = await get_current_user(request, db)
    if not user:
        raise HTTPException(status_code=401, detail="Not authenticated")

    query = {"user_id": user["id"]}
    if risk_filter and risk_filter in ["SAFE", "SUSPICIOUS", "DANGEROUS"]:
        query["risk_level"] = risk_filter

    total = await db.analyses.count_documents(query)
    skip = (page - 1) * limit
    analyses = await db.analyses.find(query, {"_id": 0}).sort("analyzed_at", -1).skip(skip).limit(limit).to_list(limit)

    return {
        "analyses": analyses,
        "total": total,
        "page": page,
        "pages": max(1, (total + limit - 1) // limit),
    }


# ==================== GAMIFICATION ROUTES ====================

@api_router.get("/gamification/leaderboard")
async def get_leaderboard():
    users = await db.users.find(
        {},
        {"_id": 0, "id": 1, "username": 1, "xp": 1, "streak": 1, "badges": 1, "stats": 1}
    ).sort("xp", -1).limit(50).to_list(50)

    leaderboard = []
    for i, u in enumerate(users):
        level = get_level(u.get("xp", 0))
        leaderboard.append({
            "rank": i + 1,
            "username": u["username"],
            "xp": u.get("xp", 0),
            "streak": u.get("streak", 0),
            "level": level,
            "badges_count": len(u.get("badges", [])),
            "analyses_count": u.get("stats", {}).get("analyses_count", 0),
        })
    return {"leaderboard": leaderboard}

@api_router.get("/gamification/badges")
async def get_all_badges():
    return {"badges": BADGES, "levels": LEVELS}


# ==================== TRAINING ROUTES ====================

TRAINING_MODULES = [
    {
        "id": "module_1",
        "title_fr": "Qu'est-ce que le phishing ?",
        "title_en": "What is phishing?",
        "description_fr": "Apprenez les bases du phishing et comment les attaquants vous ciblent.",
        "description_en": "Learn the basics of phishing and how attackers target you.",
        "difficulty": 1,
        "xp_reward": 50,
        "icon": "shield",
        "lessons_fr": [
            "Le phishing est une technique de fraude en ligne où des attaquants se font passer pour des entités de confiance pour voler vos informations personnelles.",
            "Les attaques de phishing arrivent le plus souvent par email, SMS ou messages sur les réseaux sociaux.",
            "L'objectif est de vous faire cliquer sur un lien malveillant ou de vous faire entrer vos identifiants sur un faux site.",
        ],
        "lessons_en": [
            "Phishing is an online fraud technique where attackers impersonate trusted entities to steal your personal information.",
            "Phishing attacks most commonly arrive via email, SMS, or social media messages.",
            "The goal is to get you to click on a malicious link or enter your credentials on a fake site.",
        ],
        "quiz": [
            {
                "question_fr": "Qu'est-ce que le phishing ?",
                "question_en": "What is phishing?",
                "options_fr": ["Un virus informatique", "Une technique de fraude en ligne", "Un logiciel antivirus", "Un type de firewall"],
                "options_en": ["A computer virus", "An online fraud technique", "An antivirus software", "A type of firewall"],
                "correct": 1,
                "explanation_fr": "Le phishing est une technique de fraude où les attaquants usurpent l'identité d'entités de confiance.",
                "explanation_en": "Phishing is a fraud technique where attackers impersonate trusted entities.",
            },
            {
                "question_fr": "Par quel moyen le phishing arrive-t-il le plus souvent ?",
                "question_en": "What is the most common delivery method for phishing?",
                "options_fr": ["Par courrier postal", "Par email ou SMS", "Par téléphone fixe", "Par la télévision"],
                "options_en": ["By postal mail", "By email or SMS", "By landline phone", "By television"],
                "correct": 1,
                "explanation_fr": "Les emails et SMS sont les vecteurs les plus courants du phishing.",
                "explanation_en": "Emails and SMS are the most common phishing vectors.",
            },
            {
                "question_fr": "Quel est l'objectif principal du phishing ?",
                "question_en": "What is the main goal of phishing?",
                "options_fr": ["Améliorer votre sécurité", "Voler vos informations personnelles", "Mettre à jour votre navigateur", "Tester votre antivirus"],
                "options_en": ["Improve your security", "Steal your personal information", "Update your browser", "Test your antivirus"],
                "correct": 1,
                "explanation_fr": "Le but du phishing est de voler vos identifiants, mots de passe et données personnelles.",
                "explanation_en": "The goal of phishing is to steal your credentials, passwords and personal data.",
            },
        ],
    },
    {
        "id": "module_2",
        "title_fr": "Reconnaître une URL suspecte",
        "title_en": "Recognizing a suspicious URL",
        "description_fr": "Apprenez à identifier les signes d'une URL malveillante.",
        "description_en": "Learn to identify the signs of a malicious URL.",
        "difficulty": 2,
        "xp_reward": 75,
        "icon": "link",
        "lessons_fr": [
            "HTTPS ne signifie pas que le site est sûr ! Cela signifie seulement que la connexion est chiffrée.",
            "Vérifiez toujours le nom de domaine. Les arnaqueurs utilisent des variations subtiles (paypa1.com au lieu de paypal.com).",
            "Les URLs très longues avec beaucoup de caractères spéciaux sont souvent suspectes.",
            "Les extensions de domaine comme .tk, .ml, .xyz sont souvent utilisées par les arnaqueurs car elles sont gratuites.",
        ],
        "lessons_en": [
            "HTTPS doesn't mean the site is safe! It only means the connection is encrypted.",
            "Always check the domain name. Scammers use subtle variations (paypa1.com instead of paypal.com).",
            "Very long URLs with many special characters are often suspicious.",
            "Domain extensions like .tk, .ml, .xyz are often used by scammers because they're free.",
        ],
        "quiz": [
            {
                "question_fr": "HTTPS garantit-il qu'un site est sûr ?",
                "question_en": "Does HTTPS guarantee a site is safe?",
                "options_fr": ["Oui, toujours", "Non, cela signifie seulement que la connexion est chiffrée", "Oui, si le cadenas est vert", "Non, HTTPS n'existe pas"],
                "options_en": ["Yes, always", "No, it only means the connection is encrypted", "Yes, if the padlock is green", "No, HTTPS doesn't exist"],
                "correct": 1,
                "explanation_fr": "HTTPS chiffre la connexion mais ne garantit pas que le site est légitime.",
                "explanation_en": "HTTPS encrypts the connection but doesn't guarantee the site is legitimate.",
            },
            {
                "question_fr": "Quelle URL est suspecte?",
                "question_en": "Which URL is suspicious?",
                "options_fr": ["https://www.google.com", "http://g00gle-secure.tk/login", "https://www.wikipedia.org", "https://github.com"],
                "options_en": ["https://www.google.com", "http://g00gle-secure.tk/login", "https://www.wikipedia.org", "https://github.com"],
                "correct": 1,
                "explanation_fr": "Cette URL utilise des chiffres au lieu de lettres (g00gle), un domaine .tk et un chemin /login suspect.",
                "explanation_en": "This URL uses numbers instead of letters (g00gle), a .tk domain and a suspicious /login path.",
            },
            {
                "question_fr": "Qu'est-ce que le typosquatting ?",
                "question_en": "What is typosquatting?",
                "options_fr": ["Écrire très vite au clavier", "Créer de faux domaines avec des fautes de frappe", "Un type de clavier", "Un logiciel de frappe"],
                "options_en": ["Typing very fast", "Creating fake domains with typos", "A type of keyboard", "A typing software"],
                "correct": 1,
                "explanation_fr": "Le typosquatting consiste à enregistrer des domaines similaires à des sites connus (ex: faceb00k.com).",
                "explanation_en": "Typosquatting involves registering domains similar to known sites (e.g., faceb00k.com).",
            },
        ],
    },
    {
        "id": "module_3",
        "title_fr": "Se protéger au quotidien",
        "title_en": "Daily protection habits",
        "description_fr": "Adoptez les bons réflexes pour vous protéger du phishing chaque jour.",
        "description_en": "Adopt good habits to protect yourself from phishing every day.",
        "difficulty": 2,
        "xp_reward": 75,
        "icon": "lock",
        "lessons_fr": [
            "Ne cliquez jamais sur un lien dans un email suspect. Allez directement sur le site officiel en tapant l'adresse.",
            "Activez l'authentification à deux facteurs (2FA) sur tous vos comptes importants.",
            "Utilisez un gestionnaire de mots de passe pour éviter de réutiliser les mêmes mots de passe.",
            "Mettez à jour régulièrement votre navigateur et votre système d'exploitation.",
        ],
        "lessons_en": [
            "Never click on a link in a suspicious email. Go directly to the official site by typing the address.",
            "Enable two-factor authentication (2FA) on all your important accounts.",
            "Use a password manager to avoid reusing the same passwords.",
            "Regularly update your browser and operating system.",
        ],
        "quiz": [
            {
                "question_fr": "Que faire si vous recevez un email suspect de votre banque ?",
                "question_en": "What should you do if you receive a suspicious email from your bank?",
                "options_fr": ["Cliquer sur le lien immédiatement", "Aller directement sur le site de la banque", "Répondre à l'email", "Transférer l'email à vos amis"],
                "options_en": ["Click the link immediately", "Go directly to the bank's website", "Reply to the email", "Forward the email to friends"],
                "correct": 1,
                "explanation_fr": "Tapez toujours l'adresse de votre banque directement dans le navigateur.",
                "explanation_en": "Always type your bank's address directly in the browser.",
            },
            {
                "question_fr": "Qu'est-ce que l'authentification à deux facteurs ?",
                "question_en": "What is two-factor authentication?",
                "options_fr": ["Utiliser deux mots de passe", "Un code supplémentaire en plus du mot de passe", "Deux personnes qui se connectent", "Un double antivirus"],
                "options_en": ["Using two passwords", "An additional code besides the password", "Two people logging in", "A double antivirus"],
                "correct": 1,
                "explanation_fr": "Le 2FA ajoute une couche de sécurité avec un code temporaire en plus du mot de passe.",
                "explanation_en": "2FA adds a security layer with a temporary code in addition to the password.",
            },
            {
                "question_fr": "Pourquoi utiliser un gestionnaire de mots de passe ?",
                "question_en": "Why use a password manager?",
                "options_fr": ["C'est plus rapide", "Pour avoir des mots de passe uniques et forts pour chaque site", "C'est gratuit", "C'est à la mode"],
                "options_en": ["It's faster", "To have unique and strong passwords for each site", "It's free", "It's trendy"],
                "correct": 1,
                "explanation_fr": "Un gestionnaire de mots de passe vous permet d'utiliser des mots de passe différents et complexes sans les mémoriser.",
                "explanation_en": "A password manager lets you use different and complex passwords without memorizing them.",
            },
        ],
    },
    {
        "id": "module_4",
        "title_fr": "Les techniques avancées de phishing",
        "title_en": "Advanced phishing techniques",
        "description_fr": "Découvrez les méthodes sophistiquées utilisées par les cybercriminels.",
        "description_en": "Discover the sophisticated methods used by cybercriminals.",
        "difficulty": 3,
        "xp_reward": 100,
        "icon": "eye",
        "lessons_fr": [
            "Le spear phishing cible des individus spécifiques avec des informations personnalisées.",
            "Le whaling cible les dirigeants d'entreprise avec des attaques très élaborées.",
            "Le smishing (phishing par SMS) est en forte augmentation. Méfiance avec les SMS contenant des liens !",
            "Les attaques par QR code (quishing) sont une nouvelle tendance. Scannez uniquement les QR codes de confiance.",
        ],
        "lessons_en": [
            "Spear phishing targets specific individuals with personalized information.",
            "Whaling targets business executives with highly elaborate attacks.",
            "Smishing (SMS phishing) is on the rise. Beware of SMS containing links!",
            "QR code attacks (quishing) are a new trend. Only scan trusted QR codes.",
        ],
        "quiz": [
            {
                "question_fr": "Qu'est-ce que le spear phishing ?",
                "question_en": "What is spear phishing?",
                "options_fr": ["Du phishing par la poste", "Du phishing ciblé avec des infos personnalisées", "Du phishing par téléphone", "Un type de pêche"],
                "options_en": ["Phishing by mail", "Targeted phishing with personalized info", "Phone phishing", "A type of fishing"],
                "correct": 1,
                "explanation_fr": "Le spear phishing utilise des informations personnelles pour rendre l'attaque plus crédible.",
                "explanation_en": "Spear phishing uses personal information to make the attack more credible.",
            },
            {
                "question_fr": "Qu'est-ce que le smishing ?",
                "question_en": "What is smishing?",
                "options_fr": ["Du phishing par email", "Du phishing par SMS", "Du phishing par appel vidéo", "Du phishing par courrier"],
                "options_en": ["Email phishing", "SMS phishing", "Video call phishing", "Mail phishing"],
                "correct": 1,
                "explanation_fr": "Le smishing combine SMS et phishing pour vous piéger via des messages texte.",
                "explanation_en": "Smishing combines SMS and phishing to trap you via text messages.",
            },
            {
                "question_fr": "Comment se protéger du quishing (QR code) ?",
                "question_en": "How to protect yourself from quishing (QR code)?",
                "options_fr": ["Scanner tous les QR codes", "Ne jamais scanner de QR code", "Scanner uniquement les QR codes de confiance", "Les QR codes sont toujours sûrs"],
                "options_en": ["Scan all QR codes", "Never scan any QR code", "Only scan trusted QR codes", "QR codes are always safe"],
                "correct": 2,
                "explanation_fr": "Ne scannez que les QR codes provenant de sources fiables et vérifiez l'URL avant de continuer.",
                "explanation_en": "Only scan QR codes from trusted sources and check the URL before proceeding.",
            },
        ],
    },
    {
        "id": "module_5",
        "title_fr": "Réagir face à une attaque",
        "title_en": "Responding to an attack",
        "description_fr": "Que faire si vous êtes victime de phishing ou si vous détectez une attaque ?",
        "description_en": "What to do if you're a victim of phishing or detect an attack?",
        "difficulty": 3,
        "xp_reward": 100,
        "icon": "alert-circle",
        "lessons_fr": [
            "Si vous avez cliqué sur un lien suspect : changez immédiatement vos mots de passe.",
            "Signalez l'attaque à votre banque si des informations financières sont compromises.",
            "Signalez le site de phishing sur signal-spam.fr ou phishing-initiative.fr.",
            "Conservez les preuves (captures d'écran, emails) pour un éventuel dépôt de plainte.",
        ],
        "lessons_en": [
            "If you clicked on a suspicious link: immediately change your passwords.",
            "Report the attack to your bank if financial information is compromised.",
            "Report the phishing site on signal-spam.fr or phishing-initiative.fr.",
            "Keep evidence (screenshots, emails) for a potential complaint.",
        ],
        "quiz": [
            {
                "question_fr": "Que faire en premier si vous avez cliqué sur un lien de phishing ?",
                "question_en": "What should you do first if you clicked a phishing link?",
                "options_fr": ["Éteindre l'ordinateur", "Changer vos mots de passe immédiatement", "Ignorer le problème", "Envoyer le lien à vos amis"],
                "options_en": ["Turn off the computer", "Change your passwords immediately", "Ignore the problem", "Send the link to friends"],
                "correct": 1,
                "explanation_fr": "La priorité est de sécuriser vos comptes en changeant les mots de passe compromis.",
                "explanation_en": "The priority is to secure your accounts by changing compromised passwords.",
            },
            {
                "question_fr": "Où signaler un site de phishing en France ?",
                "question_en": "Where to report a phishing site in France?",
                "options_fr": ["Sur Facebook", "Sur signal-spam.fr", "Sur Google", "Sur Wikipedia"],
                "options_en": ["On Facebook", "On signal-spam.fr", "On Google", "On Wikipedia"],
                "correct": 1,
                "explanation_fr": "signal-spam.fr et phishing-initiative.fr sont les plateformes officielles de signalement en France.",
                "explanation_en": "signal-spam.fr and phishing-initiative.fr are the official reporting platforms in France.",
            },
            {
                "question_fr": "Pourquoi conserver les preuves d'une attaque ?",
                "question_en": "Why keep evidence of an attack?",
                "options_fr": ["Pour les publier en ligne", "Pour un dépôt de plainte", "Pour les envoyer aux hackers", "Ce n'est pas nécessaire"],
                "options_en": ["To publish online", "For filing a complaint", "To send to hackers", "It's not necessary"],
                "correct": 1,
                "explanation_fr": "Les preuves sont nécessaires si vous souhaitez déposer plainte auprès des autorités.",
                "explanation_en": "Evidence is necessary if you want to file a complaint with authorities.",
            },
        ],
    },
]

@api_router.get("/training/modules")
async def get_training_modules(request: Request):
    user = await get_current_user(request, db)
    modules_out = []
    for m in TRAINING_MODULES:
        module_data = {k: v for k, v in m.items() if k != "quiz"}
        module_data["questions_count"] = len(m["quiz"])
        if user:
            progress = await db.quiz_progress.find_one(
                {"user_id": user["id"], "module_id": m["id"]}, {"_id": 0}
            )
            module_data["completed"] = progress.get("completed", False) if progress else False
            module_data["best_score"] = progress.get("best_score", 0) if progress else 0
        else:
            module_data["completed"] = False
            module_data["best_score"] = 0
        modules_out.append(module_data)
    return {"modules": modules_out}

@api_router.get("/training/module/{module_id}")
async def get_training_module(module_id: str):
    for m in TRAINING_MODULES:
        if m["id"] == module_id:
            return m
    raise HTTPException(status_code=404, detail="Module not found")

@api_router.post("/training/quiz/submit")
async def submit_quiz(request: Request, module_id: str, answers: List[int]):
    module = None
    for m in TRAINING_MODULES:
        if m["id"] == module_id:
            module = m
            break
    if not module:
        raise HTTPException(status_code=404, detail="Module not found")

    quiz = module["quiz"]
    correct_count = 0
    results = []
    for i, (answer, question) in enumerate(zip(answers, quiz)):
        is_correct = answer == question["correct"]
        if is_correct:
            correct_count += 1
        results.append({
            "question_index": i,
            "user_answer": answer,
            "correct_answer": question["correct"],
            "is_correct": is_correct,
            "explanation_fr": question["explanation_fr"],
            "explanation_en": question["explanation_en"],
        })

    score = round((correct_count / len(quiz)) * 100) if quiz else 0
    is_perfect = score == 100

    user = await get_current_user(request, db)
    if user:
        # Update progress
        progress = await db.quiz_progress.find_one(
            {"user_id": user["id"], "module_id": module_id}, {"_id": 0}
        )
        if not progress or score > progress.get("best_score", 0):
            await db.quiz_progress.update_one(
                {"user_id": user["id"], "module_id": module_id},
                {"$set": {
                    "user_id": user["id"],
                    "module_id": module_id,
                    "best_score": score,
                    "completed": score >= 70,
                    "last_attempt": datetime.now(timezone.utc).isoformat(),
                }},
                upsert=True
            )

        if score >= 70:
            await award_xp(user["id"], "complete_quiz", db)
            # Count completed modules
            completed = await db.quiz_progress.count_documents(
                {"user_id": user["id"], "completed": True}
            )
            await db.users.update_one(
                {"id": user["id"]},
                {"$set": {"stats.modules_completed": completed}}
            )
        if is_perfect:
            await award_xp(user["id"], "perfect_quiz", db)
            await db.users.update_one(
                {"id": user["id"]},
                {"$inc": {"stats.perfect_quizzes": 1}}
            )
        await check_badges(user["id"], db)

    return {
        "score": score,
        "correct_count": correct_count,
        "total": len(quiz),
        "is_perfect": is_perfect,
        "passed": score >= 70,
        "results": results,
        "xp_earned": module["xp_reward"] if score >= 70 else 0,
    }


# ==================== MODEL STATS (kept public) ====================

@api_router.get("/model/stats")
async def get_model_stats():
    model = get_model()
    importance = model.get_feature_importance()
    feedback_count = await db.training_data.count_documents({})
    total_analyses = await db.analyses.count_documents({})
    return {
        "accuracy": round(model.accuracy * 100, 1),
        "feature_importance": importance,
        "feedback_samples": feedback_count,
        "total_analyses": total_analyses,
    }


# ==================== NEWS & VEILLE ROUTES ====================

@api_router.get("/news")
async def get_news():
    articles = await fetch_news()
    return {"articles": articles, "trends": TREND_ALERTS}

@api_router.get("/trends")
async def get_trends():
    return {"trends": TREND_ALERTS}


# ==================== EXTERNAL RESOURCES ROUTES ====================

@api_router.get("/resources")
async def get_resources(request: Request):
    user = await get_current_user(request, db)
    resources = []
    for r in EXTERNAL_RESOURCES:
        res = {**r}
        if user:
            completion = await db.resource_completions.find_one(
                {"user_id": user["id"], "resource_id": r["id"]}, {"_id": 0}
            )
            res["completed"] = completion is not None
            res["completed_at"] = completion.get("completed_at", "") if completion else ""
        else:
            res["completed"] = False
            res["completed_at"] = ""
        resources.append(res)
    return {"resources": resources}

@api_router.post("/resources/complete")
async def complete_resource(input: ResourceCompleteInput, request: Request):
    user = await get_current_user(request, db)
    if not user:
        raise HTTPException(status_code=401, detail="Not authenticated")

    resource = None
    for r in EXTERNAL_RESOURCES:
        if r["id"] == input.resource_id:
            resource = r
            break
    if not resource:
        raise HTTPException(status_code=404, detail="Resource not found")

    existing = await db.resource_completions.find_one(
        {"user_id": user["id"], "resource_id": input.resource_id}, {"_id": 0}
    )
    if existing:
        return {"message": "Already completed", "xp_earned": 0}

    await db.resource_completions.insert_one({
        "user_id": user["id"],
        "resource_id": input.resource_id,
        "completed_at": datetime.now(timezone.utc).isoformat(),
    })
    await award_xp(user["id"], "complete_resource", db)
    await check_badges(user["id"], db)

    return {"message": "Resource completed", "xp_earned": XP_ACTIONS["complete_resource"]}


# ==================== CONTRIBUTION ROUTES ====================

@api_router.post("/contribute")
async def contribute_url(input: ContributeInput, request: Request):
    user = await get_current_user(request, db)
    if not user:
        raise HTTPException(status_code=401, detail="Not authenticated")

    url_val = input.url.strip()
    if not url_val:
        raise HTTPException(status_code=400, detail="URL is required")

    contribution = {
        "id": str(uuid.uuid4()),
        "url": url_val,
        "category": input.category,
        "comment": input.comment[:500],
        "submitted_by": user["id"],
        "submitted_by_name": user.get("username", ""),
        "verified": False,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    await db.contributions.insert_one(contribution)

    # Also add to training data
    is_phishing = input.category == "phishing"
    if input.category != "unknown":
        await db.training_data.insert_one({
            "url": url_val,
            "is_phishing": is_phishing,
            "source": "user_contribution",
            "submitted_at": datetime.now(timezone.utc).isoformat(),
        })

    await award_xp(user["id"], "contribute_url", db)
    await db.users.update_one({"id": user["id"]}, {"$inc": {"stats.contributions_count": 1}})
    await check_badges(user["id"], db)

    contribution.pop("_id", None)
    return {"message": "Contribution submitted", "contribution": contribution, "xp_earned": XP_ACTIONS["contribute_url"]}

@api_router.get("/contributions/recent")
async def get_recent_contributions():
    contributions = await db.contributions.find(
        {}, {"_id": 0}
    ).sort("created_at", -1).limit(30).to_list(30)
    return {"contributions": contributions}


# ==================== HYGIENE SCORE ROUTES ====================

@api_router.get("/user/hygiene-score")
async def get_hygiene_score(request: Request):
    user = await get_current_user(request, db)
    if not user:
        raise HTTPException(status_code=401, detail="Not authenticated")

    stats = user.get("stats", {})
    streak = user.get("streak", 0)

    # Calculate sub-scores (each out of 20, total 100)
    week_ago = (datetime.now(timezone.utc) - timedelta(days=7)).isoformat()
    recent_analyses = await db.analyses.count_documents(
        {"user_id": user["id"], "analyzed_at": {"$gte": week_ago}}
    )

    # 1. Regular usage (0-25): based on analyses in last 7 days
    usage_score = min(25, recent_analyses * 5)

    # 2. Learning progress (0-25): based on modules + resources completed
    modules_done = stats.get("modules_completed", 0)
    resources_done = await db.resource_completions.count_documents({"user_id": user["id"]})
    learning_score = min(25, (modules_done * 3) + (resources_done * 2))

    # 3. Community engagement (0-20): feedback + contributions
    feedback_ct = stats.get("feedback_count", 0)
    contrib_ct = stats.get("contributions_count", 0)
    engagement_score = min(20, (feedback_ct * 2) + (contrib_ct * 3))

    # 4. Consistency (0-15): streak
    consistency_score = min(15, streak * 2)

    # 5. Detection skills (0-15): dangers detected
    dangers = stats.get("dangers_detected", 0)
    detection_score = min(15, dangers * 3)

    total = usage_score + learning_score + engagement_score + consistency_score + detection_score

    # Grade
    if total >= 80:
        grade_fr, grade_en = "Excellent", "Excellent"
    elif total >= 60:
        grade_fr, grade_en = "Bon", "Good"
    elif total >= 40:
        grade_fr, grade_en = "À améliorer", "Needs improvement"
    else:
        grade_fr, grade_en = "Débutant", "Beginner"

    return {
        "total": total,
        "grade_fr": grade_fr,
        "grade_en": grade_en,
        "breakdown": {
            "usage": {"score": usage_score, "max": 25, "label_fr": "Utilisation régulière", "label_en": "Regular usage"},
            "learning": {"score": learning_score, "max": 25, "label_fr": "Apprentissage", "label_en": "Learning"},
            "engagement": {"score": engagement_score, "max": 20, "label_fr": "Engagement communautaire", "label_en": "Community engagement"},
            "consistency": {"score": consistency_score, "max": 15, "label_fr": "Régularité", "label_en": "Consistency"},
            "detection": {"score": detection_score, "max": 15, "label_fr": "Détection des menaces", "label_en": "Threat detection"},
        },
    }


# ==================== PHISHING SIMULATION ROUTES ====================

@api_router.get("/simulation/scenarios")
async def get_simulation_scenarios(count: int = 5, difficulty: Optional[int] = None):
    scenarios = get_random_scenarios(count=count, difficulty=difficulty)
    return {"scenarios": scenarios}

@api_router.post("/simulation/answer")
async def submit_simulation_answer(input: SimulationAnswerInput, request: Request):
    scenario = get_scenario_by_id(input.scenario_id)
    if not scenario:
        raise HTTPException(status_code=404, detail="Scenario not found")

    is_correct = input.user_answer == scenario["is_phishing"]
    result = {
        "correct": is_correct,
        "is_phishing": scenario["is_phishing"],
        "indicators_fr": scenario.get("indicators_fr", []),
        "indicators_en": scenario.get("indicators_en", []),
    }

    user = await get_current_user(request, db)
    if user:
        # Store simulation result
        sim_result = {
            "id": str(uuid.uuid4()),
            "user_id": user["id"],
            "scenario_id": input.scenario_id,
            "user_answer": input.user_answer,
            "correct": is_correct,
            "difficulty": scenario.get("difficulty", 1),
            "completed_at": datetime.now(timezone.utc).isoformat(),
        }
        await db.simulation_results.insert_one(sim_result)

        if is_correct:
            xp_amount = 10 * scenario.get("difficulty", 1)
            await db.users.update_one({"id": user["id"]}, {"$inc": {"xp": xp_amount, "total_xp_earned": xp_amount}})
            result["xp_earned"] = xp_amount

    return result

@api_router.get("/simulation/stats")
async def get_simulation_stats(request: Request):
    user = await get_current_user(request, db)
    if not user:
        raise HTTPException(status_code=401, detail="Not authenticated")

    total = await db.simulation_results.count_documents({"user_id": user["id"]})
    correct = await db.simulation_results.count_documents({"user_id": user["id"], "correct": True})
    recent = await db.simulation_results.find(
        {"user_id": user["id"]}, {"_id": 0}
    ).sort("completed_at", -1).limit(20).to_list(20)

    return {
        "total_attempts": total,
        "correct_answers": correct,
        "accuracy": round((correct / total) * 100, 1) if total > 0 else 0,
        "recent_results": recent,
    }


# ==================== NOTIFICATION ROUTES ====================

@api_router.get("/notifications")
async def get_notifications(request: Request):
    user = await get_current_user(request, db)
    user_id = user["id"] if user else None

    # Get trend alerts as notifications
    notifications = []
    for trend in TREND_ALERTS:
        notifications.append({
            "id": f"trend_{trend['id']}",
            "type": "trend_alert",
            "title_fr": trend["title_fr"],
            "title_en": trend["title_en"],
            "description_fr": trend["description_fr"],
            "description_en": trend["description_en"],
            "severity": trend["severity"],
            "category": trend["category"],
            "date": trend["date"],
        })

    # Get user-specific read status
    unread_count = len(notifications)
    if user_id:
        read_doc = await db.notification_reads.find_one({"user_id": user_id}, {"_id": 0})
        read_ids = set(read_doc.get("read_ids", [])) if read_doc else set()
        for n in notifications:
            n["read"] = n["id"] in read_ids
        unread_count = sum(1 for n in notifications if not n.get("read"))
    else:
        for n in notifications:
            n["read"] = False

    return {"notifications": notifications, "unread_count": unread_count}

@api_router.post("/notifications/read")
async def mark_notifications_read(input: NotificationReadInput, request: Request):
    user = await get_current_user(request, db)
    if not user:
        raise HTTPException(status_code=401, detail="Not authenticated")

    if input.notification_ids:
        await db.notification_reads.update_one(
            {"user_id": user["id"]},
            {"$addToSet": {"read_ids": {"$each": input.notification_ids}}},
            upsert=True,
        )
    else:
        # Mark all as read
        all_ids = [f"trend_{t['id']}" for t in TREND_ALERTS]
        await db.notification_reads.update_one(
            {"user_id": user["id"]},
            {"$set": {"read_ids": all_ids}},
            upsert=True,
        )

    return {"message": "Notifications marked as read"}


# ==================== EXPORT ROUTES ====================

@api_router.get("/export/analyses/csv")
async def export_user_analyses_csv(request: Request):
    user = await get_current_user(request, db)
    if not user:
        raise HTTPException(status_code=401, detail="Not authenticated")

    analyses = await db.analyses.find(
        {"user_id": user["id"]}, {"_id": 0}
    ).sort("analyzed_at", -1).to_list(5000)

    lang = user.get("language", "fr")
    csv_data = generate_analyses_csv(analyses, lang)
    return StreamingResponse(
        io.BytesIO(csv_data.encode("utf-8-sig")),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=securelink_analyses.csv"},
    )

@api_router.get("/export/analyses/pdf")
async def export_user_analyses_pdf(request: Request):
    user = await get_current_user(request, db)
    if not user:
        raise HTTPException(status_code=401, detail="Not authenticated")

    analyses = await db.analyses.find(
        {"user_id": user["id"]}, {"_id": 0}
    ).sort("analyzed_at", -1).to_list(500)

    lang = user.get("language", "fr")
    prefix = "Rapport d'analyses de" if lang == "fr" else "Analysis report for"
    title = f"{prefix} {user.get('username', '')}"
    pdf_bytes = generate_analyses_pdf(analyses, lang, title)
    return StreamingResponse(
        io.BytesIO(pdf_bytes),
        media_type="application/pdf",
        headers={"Content-Disposition": "attachment; filename=securelink_report.pdf"},
    )


# ==================== ADMIN ROUTES ====================

async def require_admin(request: Request):
    user = await get_current_user(request, db)
    if not user:
        raise HTTPException(status_code=401, detail="Not authenticated")
    if not user.get("is_admin", False):
        raise HTTPException(status_code=403, detail="Admin access required")
    return user

@api_router.post("/admin/promote")
async def promote_to_admin(input: AdminPromoteInput, request: Request):
    """Promote a user to admin. First call doesn't need auth (bootstrap), subsequent calls need admin."""
    admin_count = await db.users.count_documents({"is_admin": True})
    if admin_count > 0:
        await require_admin(request)

    result = await db.users.update_one(
        {"email": input.email.lower()},
        {"$set": {"is_admin": True}}
    )
    if result.modified_count == 0:
        existing = await db.users.find_one({"email": input.email.lower()}, {"_id": 0})
        if not existing:
            raise HTTPException(status_code=404, detail="User not found")
        return {"message": "User is already admin"}
    return {"message": f"User {input.email} promoted to admin"}

@api_router.get("/admin/stats")
async def admin_stats(request: Request):
    await require_admin(request)

    total_users = await db.users.count_documents({})
    total_analyses = await db.analyses.count_documents({})
    total_contributions = await db.contributions.count_documents({})
    pending_contributions = await db.contributions.count_documents({"verified": False})
    total_feedback = await db.feedback.count_documents({})
    training_samples = await db.training_data.count_documents({})

    # Analyses by risk level
    safe_count = await db.analyses.count_documents({"risk_level": "SAFE"})
    suspicious_count = await db.analyses.count_documents({"risk_level": "SUSPICIOUS"})
    dangerous_count = await db.analyses.count_documents({"risk_level": "DANGEROUS"})

    # Recent week activity
    week_ago = (datetime.now(timezone.utc) - timedelta(days=7)).isoformat()
    weekly_analyses = await db.analyses.count_documents({"analyzed_at": {"$gte": week_ago}})
    weekly_users = await db.users.count_documents({"last_active_date": {"$gte": (datetime.now(timezone.utc).date() - timedelta(days=7)).isoformat()}})

    model = get_model()

    return {
        "total_users": total_users,
        "total_analyses": total_analyses,
        "total_contributions": total_contributions,
        "pending_contributions": pending_contributions,
        "total_feedback": total_feedback,
        "training_samples": training_samples,
        "analyses_by_risk": {"safe": safe_count, "suspicious": suspicious_count, "dangerous": dangerous_count},
        "weekly_analyses": weekly_analyses,
        "weekly_active_users": weekly_users,
        "model_accuracy": round(model.accuracy * 100, 1),
    }

@api_router.get("/admin/analytics")
async def admin_analytics(request: Request):
    await require_admin(request)

    now = datetime.now(timezone.utc)

    # 1. Daily analysis counts for last 30 days
    daily_analyses = []
    for i in range(29, -1, -1):
        day = (now - timedelta(days=i)).date()
        day_start = day.isoformat()
        day_end = (day + timedelta(days=1)).isoformat()
        count = await db.analyses.count_documents({
            "analyzed_at": {"$gte": day_start, "$lt": day_end}
        })
        safe = await db.analyses.count_documents({
            "analyzed_at": {"$gte": day_start, "$lt": day_end}, "risk_level": "SAFE"
        })
        suspicious = await db.analyses.count_documents({
            "analyzed_at": {"$gte": day_start, "$lt": day_end}, "risk_level": "SUSPICIOUS"
        })
        dangerous = await db.analyses.count_documents({
            "analyzed_at": {"$gte": day_start, "$lt": day_end}, "risk_level": "DANGEROUS"
        })
        daily_analyses.append({
            "date": day.strftime("%d/%m"),
            "total": count,
            "safe": safe,
            "suspicious": suspicious,
            "dangerous": dangerous,
        })

    # 2. Detection rates
    total = await db.analyses.count_documents({})
    safe_total = await db.analyses.count_documents({"risk_level": "SAFE"})
    suspicious_total = await db.analyses.count_documents({"risk_level": "SUSPICIOUS"})
    dangerous_total = await db.analyses.count_documents({"risk_level": "DANGEROUS"})
    detection_rates = {
        "total": total,
        "safe": safe_total,
        "suspicious": suspicious_total,
        "dangerous": dangerous_total,
        "safe_pct": round((safe_total / total) * 100, 1) if total else 0,
        "suspicious_pct": round((suspicious_total / total) * 100, 1) if total else 0,
        "dangerous_pct": round((dangerous_total / total) * 100, 1) if total else 0,
    }

    # 3. Engagement metrics
    today = now.date().isoformat()
    yesterday = (now.date() - timedelta(days=1)).isoformat()
    analyses_today = await db.analyses.count_documents({"analyzed_at": {"$gte": today}})
    analyses_yesterday = await db.analyses.count_documents({
        "analyzed_at": {"$gte": yesterday, "$lt": today}
    })
    total_simulations = await db.simulation_results.count_documents({})
    correct_simulations = await db.simulation_results.count_documents({"correct": True})
    total_feedback = await db.feedback.count_documents({})
    week_ago_str = (now - timedelta(days=7)).isoformat()
    feedback_this_week = await db.feedback.count_documents({"created_at": {"$gte": week_ago_str}})
    active_users_today = await db.users.count_documents({"last_active_date": {"$gte": today}})

    engagement = {
        "analyses_today": analyses_today,
        "analyses_yesterday": analyses_yesterday,
        "analyses_trend": analyses_today - analyses_yesterday,
        "total_simulations": total_simulations,
        "simulation_accuracy": round((correct_simulations / total_simulations) * 100, 1) if total_simulations else 0,
        "total_feedback": total_feedback,
        "feedback_this_week": feedback_this_week,
        "active_users_today": active_users_today,
    }

    # 4. User growth (last 30 days)
    user_growth = []
    for i in range(29, -1, -1):
        day = (now - timedelta(days=i)).date()
        day_start = day.isoformat()
        day_end = (day + timedelta(days=1)).isoformat()
        new_users = await db.users.count_documents({
            "created_at": {"$gte": day_start, "$lt": day_end}
        })
        user_growth.append({
            "date": day.strftime("%d/%m"),
            "new_users": new_users,
        })

    total_users = await db.users.count_documents({})
    users_last_7d = await db.users.count_documents({
        "created_at": {"$gte": (now - timedelta(days=7)).isoformat()}
    })
    users_last_30d = await db.users.count_documents({
        "created_at": {"$gte": (now - timedelta(days=30)).isoformat()}
    })

    return {
        "daily_analyses": daily_analyses,
        "detection_rates": detection_rates,
        "engagement": engagement,
        "user_growth": user_growth,
        "user_totals": {
            "total": total_users,
            "last_7d": users_last_7d,
            "last_30d": users_last_30d,
        },
    }

@api_router.get("/admin/users")
async def admin_users(request: Request, page: int = 1, limit: int = 20):
    await require_admin(request)
    total = await db.users.count_documents({})
    skip = (page - 1) * limit
    users = await db.users.find(
        {}, {"_id": 0, "password_hash": 0}
    ).sort("created_at", -1).skip(skip).limit(limit).to_list(limit)

    user_list = []
    for u in users:
        level = get_level(u.get("xp", 0))
        user_list.append({
            "id": u["id"],
            "username": u.get("username", ""),
            "email": u.get("email", ""),
            "xp": u.get("xp", 0),
            "streak": u.get("streak", 0),
            "is_admin": u.get("is_admin", False),
            "level": level,
            "stats": u.get("stats", {}),
            "created_at": u.get("created_at", ""),
            "last_active_date": u.get("last_active_date", ""),
        })

    return {"users": user_list, "total": total, "page": page, "pages": max(1, (total + limit - 1) // limit)}

@api_router.get("/admin/contributions")
async def admin_contributions(request: Request, status_filter: Optional[str] = None, page: int = 1, limit: int = 30):
    await require_admin(request)
    query = {}
    if status_filter == "pending":
        query["verified"] = False
    elif status_filter == "verified":
        query["verified"] = True

    total = await db.contributions.count_documents(query)
    skip = (page - 1) * limit
    contributions = await db.contributions.find(
        query, {"_id": 0}
    ).sort("created_at", -1).skip(skip).limit(limit).to_list(limit)

    return {"contributions": contributions, "total": total, "page": page, "pages": max(1, (total + limit - 1) // limit)}

@api_router.post("/admin/contributions/validate")
async def validate_contribution(input: ContributionValidateInput, request: Request):
    admin = await require_admin(request)

    contribution = await db.contributions.find_one({"id": input.contribution_id}, {"_id": 0})
    if not contribution:
        raise HTTPException(status_code=404, detail="Contribution not found")

    update = {
        "verified": True,
        "validation_status": input.status,
        "validated_by": admin["id"],
        "validated_at": datetime.now(timezone.utc).isoformat(),
    }

    if input.status == "approved" and input.is_phishing is not None:
        update["category"] = "phishing" if input.is_phishing else "safe"
        # Update training data
        await db.training_data.update_one(
            {"url": contribution["url"], "source": "user_contribution"},
            {"$set": {"is_phishing": input.is_phishing, "verified": True}},
            upsert=True
        )

    await db.contributions.update_one({"id": input.contribution_id}, {"$set": update})
    return {"message": f"Contribution {input.status}", "contribution_id": input.contribution_id}

@api_router.get("/admin/analyses")
async def admin_analyses(request: Request, page: int = 1, limit: int = 30, risk_filter: Optional[str] = None):
    await require_admin(request)
    query = {}
    if risk_filter and risk_filter in ["SAFE", "SUSPICIOUS", "DANGEROUS"]:
        query["risk_level"] = risk_filter

    total = await db.analyses.count_documents(query)
    skip = (page - 1) * limit
    analyses = await db.analyses.find(
        query, {"_id": 0, "feature_details": 0}
    ).sort("analyzed_at", -1).skip(skip).limit(limit).to_list(limit)

    return {"analyses": analyses, "total": total, "page": page, "pages": max(1, (total + limit - 1) // limit)}

@api_router.get("/admin/feedback")
async def admin_feedback(request: Request, page: int = 1, limit: int = 30):
    await require_admin(request)
    total = await db.feedback.count_documents({})
    skip = (page - 1) * limit
    feedbacks = await db.feedback.find(
        {}, {"_id": 0}
    ).sort("submitted_at", -1).skip(skip).limit(limit).to_list(limit)

    # Enrich with analysis URL
    enriched = []
    for f in feedbacks:
        analysis = await db.analyses.find_one({"id": f.get("analysis_id")}, {"_id": 0, "url": 1, "risk_level": 1})
        enriched.append({
            **f,
            "url": analysis.get("url", "?") if analysis else "?",
            "original_risk": analysis.get("risk_level", "?") if analysis else "?",
        })

    return {"feedback": enriched, "total": total, "page": page}

@api_router.post("/admin/retrain")
async def retrain_model_endpoint(request: Request):
    admin = await require_admin(request)

    # Check for force flag
    body = {}
    try:
        body = await request.json()
    except Exception:
        pass
    force = body.get("force", False)

    # Get combined training data (real dataset + user contributions + feedback)
    urls, labels = await get_training_data(db)

    if len(urls) < 20:
        return {"message": "Not enough training data. Fetch a real dataset first.", "samples": len(urls)}

    # Balance check
    phishing_count = sum(labels)
    legit_count = len(labels) - phishing_count
    total = len(labels)
    phishing_ratio = round(phishing_count / total * 100, 1) if total > 0 else 0
    legit_ratio = round(legit_count / total * 100, 1) if total > 0 else 0
    max_ratio = max(phishing_ratio, legit_ratio)
    is_balanced = max_ratio <= 65

    balance_info = {
        "total_phishing": phishing_count,
        "total_legit": legit_count,
        "phishing_ratio": phishing_ratio,
        "legit_ratio": legit_ratio,
        "is_balanced": is_balanced,
        "max_ratio": max_ratio,
        "threshold": 65,
    }

    if not is_balanced and not force:
        dominant = "phishing" if phishing_ratio > legit_ratio else "légitime"
        return {
            "blocked": True,
            "message": f"Dataset déséquilibré ({dominant} : {max_ratio}%). Seuil max : 65%. Corrigez le dataset ou forcez le réentraînement.",
            "message_en": f"Imbalanced dataset ({dominant}: {max_ratio}%). Max threshold: 65%. Fix the dataset or force retrain.",
            "balance": balance_info,
            "samples": total,
        }

    model = get_model()
    accuracy = model.retrain(urls, labels)
    return {
        "message": "Model retrained with real data",
        "accuracy": round(accuracy * 100, 2),
        "samples": len(urls),
        "phishing_samples": phishing_count,
        "legit_samples": legit_count,
        "balance": balance_info,
        "forced": force and not is_balanced,
    }

@api_router.post("/admin/dataset/fetch")
async def fetch_dataset(request: Request):
    """Fetch real phishing datasets from PhishTank & URLhaus."""
    await require_admin(request)
    result = await fetch_and_store(db)
    return result

@api_router.get("/admin/dataset/stats")
async def dataset_stats(request: Request):
    """Get current dataset statistics."""
    await require_admin(request)
    return await get_dataset_stats(db)

@api_router.post("/admin/dataset/fetch-and-train")
async def fetch_and_train(request: Request):
    """Fetch real datasets then retrain the model in one step."""
    await require_admin(request)

    # Check for force flag
    body = {}
    try:
        body = await request.json()
    except Exception:
        pass
    force = body.get("force", False)

    # Step 1: Fetch
    fetch_result = await fetch_and_store(db)

    # Step 2: Get combined training data
    urls, labels = await get_training_data(db)

    if len(urls) < 20:
        return {"fetch": fetch_result, "train": {"message": "Not enough data", "samples": len(urls)}}

    # Balance check
    phishing_count = sum(labels)
    legit_count = len(labels) - phishing_count
    total = len(labels)
    phishing_ratio = round(phishing_count / total * 100, 1) if total > 0 else 0
    legit_ratio = round(legit_count / total * 100, 1) if total > 0 else 0
    max_ratio = max(phishing_ratio, legit_ratio)
    is_balanced = max_ratio <= 65

    balance_info = {
        "total_phishing": phishing_count,
        "total_legit": legit_count,
        "phishing_ratio": phishing_ratio,
        "legit_ratio": legit_ratio,
        "is_balanced": is_balanced,
        "max_ratio": max_ratio,
        "threshold": 65,
    }

    if not is_balanced and not force:
        dominant = "phishing" if phishing_ratio > legit_ratio else "légitime"
        return {
            "fetch": fetch_result,
            "train": {
                "blocked": True,
                "message": f"Dataset déséquilibré ({dominant} : {max_ratio}%). Seuil max : 65%. Corrigez le dataset ou forcez le réentraînement.",
                "message_en": f"Imbalanced dataset ({dominant}: {max_ratio}%). Max threshold: 65%. Fix the dataset or force retrain.",
                "balance": balance_info,
                "samples": total,
            }
        }

    # Step 3: Retrain
    model = get_model()
    accuracy = model.retrain(urls, labels)

    return {
        "fetch": fetch_result,
        "train": {
            "message": "Model retrained with real data",
            "accuracy": round(accuracy * 100, 2),
            "samples": len(urls),
            "phishing_samples": phishing_count,
            "legit_samples": legit_count,
            "balance": balance_info,
            "forced": force and not is_balanced,
        }
    }


# ==================== ADMIN EXPORT ROUTES ====================

@api_router.get("/admin/export/analyses/csv")
async def admin_export_analyses_csv(request: Request, risk_filter: Optional[str] = None):
    admin = await require_admin(request)
    query = {}
    if risk_filter and risk_filter in ["SAFE", "SUSPICIOUS", "DANGEROUS"]:
        query["risk_level"] = risk_filter

    analyses = await db.analyses.find(query, {"_id": 0}).sort("analyzed_at", -1).to_list(10000)
    lang = admin.get("language", "fr")
    csv_data = generate_analyses_csv(analyses, lang)
    return StreamingResponse(
        io.BytesIO(csv_data.encode("utf-8-sig")),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=securelink_all_analyses.csv"},
    )

@api_router.get("/admin/export/users/csv")
async def admin_export_users_csv(request: Request):
    admin = await require_admin(request)
    users_list = await db.users.find({}, {"_id": 0, "password_hash": 0}).sort("created_at", -1).to_list(10000)

    # Add level info
    from ml_model import get_model as _  # noqa
    enriched = []
    for u in users_list:
        level = get_level(u.get("xp", 0))
        enriched.append({**u, "level": level})

    lang = admin.get("language", "fr")
    csv_data = generate_users_csv(enriched, lang)
    return StreamingResponse(
        io.BytesIO(csv_data.encode("utf-8-sig")),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=securelink_users.csv"},
    )

@api_router.get("/admin/export/report/pdf")
async def admin_export_report_pdf(request: Request):
    admin = await require_admin(request)

    # Gather stats
    total_users = await db.users.count_documents({})
    total_analyses = await db.analyses.count_documents({})
    total_contributions = await db.contributions.count_documents({})
    total_feedback = await db.feedback.count_documents({})
    training_samples = await db.training_data.count_documents({})
    safe_count = await db.analyses.count_documents({"risk_level": "SAFE"})
    suspicious_count = await db.analyses.count_documents({"risk_level": "SUSPICIOUS"})
    dangerous_count = await db.analyses.count_documents({"risk_level": "DANGEROUS"})
    week_ago = (datetime.now(timezone.utc) - timedelta(days=7)).isoformat()
    weekly_analyses = await db.analyses.count_documents({"analyzed_at": {"$gte": week_ago}})
    weekly_users = await db.users.count_documents({"last_active_date": {"$gte": (datetime.now(timezone.utc).date() - timedelta(days=7)).isoformat()}})
    model = get_model()

    stats_data = {
        "total_users": total_users,
        "total_analyses": total_analyses,
        "total_contributions": total_contributions,
        "total_feedback": total_feedback,
        "training_samples": training_samples,
        "model_accuracy": round(model.accuracy * 100, 1),
        "analyses_by_risk": {"safe": safe_count, "suspicious": suspicious_count, "dangerous": dangerous_count},
        "weekly_analyses": weekly_analyses,
        "weekly_active_users": weekly_users,
    }

    lang = admin.get("language", "fr")
    pdf_bytes = generate_admin_report_pdf(stats_data, lang)
    return StreamingResponse(
        io.BytesIO(pdf_bytes),
        media_type="application/pdf",
        headers={"Content-Disposition": "attachment; filename=securelink_admin_report.pdf"},
    )


# ==================== WEEKLY REPORTS ROUTES ====================

@api_router.get("/admin/reports")
async def list_weekly_reports(request: Request):
    await require_admin(request)
    reports = await db.weekly_reports.find(
        {}, {"_id": 0, "pdf_base64": 0}
    ).sort("week_end", -1).limit(12).to_list(12)
    return {"reports": reports}

@api_router.post("/admin/reports/generate")
async def generate_report(request: Request):
    admin = await require_admin(request)
    lang = admin.get("language", "fr")
    result = await generate_weekly_report(db, lang)
    return result

@api_router.get("/admin/reports/{report_id}/pdf")
async def download_weekly_report(report_id: str, request: Request):
    await require_admin(request)
    import base64
    report = await db.weekly_reports.find_one({"id": report_id}, {"_id": 0})
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    pdf_bytes = base64.b64decode(report["pdf_base64"])
    filename = f"securelink_{report_id}.pdf"
    return StreamingResponse(
        io.BytesIO(pdf_bytes),
        media_type="application/pdf",
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )


# ==================== AI CHATBOT ROUTES ====================

CHATBOT_SYSTEM_PROMPT = """Tu es SecureBot, l'assistant conversationnel de SecureLink, specialise en cybersecurite. Tu aides les utilisateurs non-inities a comprendre et se proteger contre les menaces en ligne.

PERSONNALITE :
- Amical, rassurant et pedagogique
- Tu expliques tout en termes simples, sans jargon technique
- Tu utilises des analogies du quotidien pour expliquer les concepts
- Tu es proactif : tu poses des questions de suivi pour approfondir
- Tu reponds en francais par defaut, en anglais si l'utilisateur ecrit en anglais

MISE EN FORME :
- PAS d'emojis, jamais
- Phrases courtes et aeres. Maximum 2-3 phrases par paragraphe
- Saute des lignes entre les idees pour aerer la lecture
- Va a l'essentiel, evite les longs blocs de texte
- Utilise un ton direct et clair

EXPERTISE (coeur metier SecureLink) :
- Phishing (emails, SMS, appels)
- Analyse d'URLs et de liens suspects
- Arnaques en ligne (faux colis, faux remboursements, fausses factures)
- Bonnes pratiques de securite (mots de passe, 2FA, mises a jour)
- Que faire en cas de clic sur un lien suspect
- Reconnaitre les techniques de manipulation psychologique
- Protection des donnees personnelles

REGLES :
1. Reponds TOUJOURS en JSON valide avec ce format :
{
  "message": "Ta reponse conversationnelle ici. Pas d'emojis. Phrases courtes. Sauts de ligne entre les idees.",
  "is_analysis": false,
  "analysis": null
}
2. Si l'utilisateur colle un email/message suspect a analyser, reponds avec :
{
  "message": "Un court commentaire conversationnel (2-3 phrases max, pas d'emojis)",
  "is_analysis": true,
  "analysis": {
    "verdict": "dangereux" | "suspect" | "normal",
    "summary": "Resume clair en 1 phrase courte",
    "techniques_detected": ["liste courte, 3-4 max"],
    "red_flags": ["liste concise, chaque item = 1 phrase courte"],
    "urls_found": ["liste des URLs extraites"],
    "immediate_actions": ["3-4 conseils concrets et courts"],
    "educational_tip": "1 conseil utile en 1-2 phrases sans emoji"
  }
}
3. Pour detecter si c'est une analyse : le message fait plus de 100 caracteres OU contient des URLs OU ressemble a un email/SMS copie-colle
4. Reste TOUJOURS dans le domaine de la cybersecurite. Si on te demande autre chose, redirige poliment vers ton expertise
5. Ne repete jamais les memes conseils. Varie tes reponses
6. AUCUN emoji dans aucun champ. AUCUN markdown. Texte simple uniquement
7. Garde les reponses CONCISES. Chaque red_flag et action en 1 phrase maximum"""

SUGGESTED_TOPICS = [
    {"id": "phishing", "label_fr": "C'est quoi le phishing ?", "label_en": "What is phishing?", "icon": "mail"},
    {"id": "clicked", "label_fr": "J'ai clique sur un lien suspect", "label_en": "I clicked a suspicious link", "icon": "alert"},
    {"id": "password", "label_fr": "Comment creer un bon mot de passe ?", "label_en": "How to create a strong password?", "icon": "lock"},
    {"id": "recognize", "label_fr": "Comment reconnaitre une arnaque ?", "label_en": "How to spot a scam?", "icon": "eye"},
    {"id": "analyze", "label_fr": "Analyser un message suspect", "label_en": "Analyze a suspicious message", "icon": "scan"},
]

class ChatInput(BaseModel):
    message: str
    session_id: Optional[str] = None

@api_router.post("/assistant/chat")
@limiter.limit("30/hour")
async def assistant_chat(input: ChatInput, request: Request):
    """Conversational AI chatbot for cybersecurity guidance."""
    if not input.message.strip():
        raise HTTPException(status_code=400, detail="Message is empty")

    gemini_key = os.environ.get("GEMINI_API_KEY", "")
    if not gemini_key:
        raise HTTPException(status_code=500, detail="GEMINI_API_KEY non configure dans backend/.env")

    session_id = input.session_id or str(uuid.uuid4())

    try:
        from llm_helper import send_chat_message
        import json as json_lib

        response_text = await send_chat_message(
            message=input.message,
            system_prompt=CHATBOT_SYSTEM_PROMPT,
            session_id=session_id,
        )

        clean = response_text.strip()
        if clean.startswith("```"):
            clean = clean.split("\n", 1)[-1].rsplit("```", 1)[0].strip()

        parsed = json_lib.loads(clean)

        user = await get_current_user(request, db)
        record = {
            "id": str(uuid.uuid4()),
            "session_id": session_id,
            "user_id": user["id"] if user else None,
            "user_message": input.message[:500],
            "bot_response": parsed,
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        await db.chat_messages.insert_one(record)

        if user and parsed.get("is_analysis"):
            await award_xp(user["id"], "analyze_url", db)

        return {"session_id": session_id, "response": parsed}

    except (json_lib.JSONDecodeError, Exception) as e:
        fallback_msg = response_text if 'response_text' in dir() else str(e)
        return {
            "session_id": session_id,
            "response": {
                "message": fallback_msg[:500] if isinstance(fallback_msg, str) else "Desole, je n'ai pas pu traiter votre message. Pouvez-vous reformuler ?",
                "is_analysis": False,
                "analysis": None,
            },
        }

@api_router.get("/assistant/topics")
async def assistant_topics():
    """Get suggested conversation topics."""
    return {"topics": SUGGESTED_TOPICS}

@api_router.get("/assistant/history")
async def assistant_history(request: Request):
    """Get user's chat history."""
    user = await get_current_user(request, db)
    if not user:
        raise HTTPException(status_code=401, detail="Not authenticated")

    messages = await db.chat_messages.find(
        {"user_id": user["id"]},
        {"_id": 0}
    ).sort("created_at", -1).limit(50).to_list(50)

    return {"messages": messages}


# ==================== GENERAL ====================

@api_router.get("/")
async def root():
    return {"message": "SecureLink API v1.0", "status": "operational"}

@api_router.get("/health")
async def health():
    return {"status": "healthy"}

# Include the router in the main app
app.include_router(api_router)

cors_origins_raw = os.environ.get('CORS_ORIGINS', '*').strip().strip('"').strip("'")
cors_origins = [o.strip() for o in cors_origins_raw.split(',') if o.strip()]
if not cors_origins:
    cors_origins = ["*"]

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=cors_origins,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
async def startup():
    # Pre-load the ML model
    logger.info("Loading ML model on startup...")
    get_model()
    logger.info("ML model loaded.")

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
