"""
SecureLink RSS News Feed Aggregator
Fetches and caches cybersecurity news from multiple sources
Categorized by language (fr/en) and level (novice/expert)
"""
import asyncio
import logging
import time
import feedparser
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor

logger = logging.getLogger(__name__)

FEEDS = [
    # --- FR Novice (priorité : utilisateurs bureautiques) ---
    {
        "id": "cybermalveillance",
        "name": "Cybermalveillance.gouv.fr",
        "url": "https://www.cybermalveillance.gouv.fr/feed/",
        "lang": "fr",
        "level": "novice",
        "icon": "shield",
        "category": "actualites",
    },
    # --- FR Expert ---
    {
        "id": "cert_fr",
        "name": "CERT-FR (ANSSI)",
        "url": "https://www.cert.ssi.gouv.fr/feed/",
        "lang": "fr",
        "level": "expert",
        "icon": "shield",
        "category": "alertes",
    },
    # --- EN Novice ---
    {
        "id": "ncsc_uk",
        "name": "NCSC (UK)",
        "url": "https://www.ncsc.gov.uk/api/1/services/v1/report-rss-feed.xml",
        "lang": "en",
        "level": "novice",
        "icon": "shield",
        "category": "actualites",
    },
    # --- EN Expert ---
    {
        "id": "bleepingcomputer",
        "name": "BleepingComputer",
        "url": "https://www.bleepingcomputer.com/feed/",
        "lang": "en",
        "level": "expert",
        "icon": "monitor",
        "category": "actualites",
    },
]

# Cache
_cache = {"articles": [], "last_fetch": 0, "ttl": 1800}  # 30 min cache

executor = ThreadPoolExecutor(max_workers=5)


def _fetch_single_feed(feed_config):
    """Synchronous feed fetch (runs in thread pool)."""
    articles = []
    try:
        parsed = feedparser.parse(feed_config["url"])
        for entry in parsed.entries[:8]:
            published = ""
            if hasattr(entry, "published_parsed") and entry.published_parsed:
                try:
                    published = datetime(*entry.published_parsed[:6], tzinfo=timezone.utc).isoformat()
                except Exception:
                    published = ""

            summary = ""
            if hasattr(entry, "summary"):
                import re
                summary = re.sub(r'<[^>]+>', '', entry.summary or "")[:200]

            articles.append({
                "title": entry.get("title", ""),
                "link": entry.get("link", ""),
                "summary": summary,
                "published": published,
                "source_id": feed_config["id"],
                "source_name": feed_config["name"],
                "source_lang": feed_config["lang"],
                "source_level": feed_config["level"],
                "source_icon": feed_config["icon"],
                "category": feed_config["category"],
            })
    except Exception as e:
        logger.warning(f"Failed to fetch feed {feed_config['name']}: {e}")
    return articles


async def fetch_news():
    """Fetch all RSS feeds with caching."""
    now = time.time()
    if _cache["articles"] and (now - _cache["last_fetch"]) < _cache["ttl"]:
        return _cache["articles"]

    loop = asyncio.get_event_loop()
    tasks = [loop.run_in_executor(executor, _fetch_single_feed, feed) for feed in FEEDS]
    results = await asyncio.gather(*tasks, return_exceptions=True)

    all_articles = []
    for result in results:
        if isinstance(result, list):
            all_articles.extend(result)

    # Sort by published date
    all_articles.sort(key=lambda a: a.get("published", ""), reverse=True)

    _cache["articles"] = all_articles
    _cache["last_fetch"] = now
    logger.info(f"Fetched {len(all_articles)} articles from {len(FEEDS)} feeds")
    return all_articles


# Seed trend alerts — orientées utilisateurs bureautiques non avertis
TREND_ALERTS = [
    {
        "id": "trend_1",
        "title_fr": "Faux emails de livraison Colissimo / Chronopost",
        "title_en": "Fake Colissimo / Chronopost delivery emails",
        "description_fr": "Vous recevez un email ou SMS disant qu'un colis est en attente et qu'il faut payer des frais de livraison. C'est une arnaque ! Ne cliquez pas sur le lien. Allez directement sur le site officiel du transporteur pour vérifier.",
        "description_en": "You receive an email or SMS saying a package is waiting and you need to pay delivery fees. It's a scam! Don't click the link. Go directly to the carrier's official website to verify.",
        "severity": "high",
        "category": "smishing",
        "level": "novice",
        "date": "2026-03-10",
    },
    {
        "id": "trend_2",
        "title_fr": "Faux remboursement Assurance Maladie / Impôts",
        "title_en": "Fake Health Insurance / Tax refund emails",
        "description_fr": "Des emails imitant Ameli ou les Impôts vous promettent un remboursement et vous demandent vos coordonnées bancaires. Ni l'Assurance Maladie ni les impôts ne vous demandent vos informations bancaires par email.",
        "description_en": "Emails imitating Health Insurance or Tax authorities promise a refund and ask for your bank details. These institutions never ask for banking information by email.",
        "severity": "high",
        "category": "phishing",
        "level": "novice",
        "date": "2026-03-08",
    },
    {
        "id": "trend_3",
        "title_fr": "Fausse facture ou relance de paiement par email",
        "title_en": "Fake invoice or payment reminder by email",
        "description_fr": "Vous recevez une facture inattendue avec une pièce jointe ou un lien de paiement. Avant de cliquer, vérifiez l'expéditeur et contactez directement le fournisseur supposé par téléphone.",
        "description_en": "You receive an unexpected invoice with an attachment or payment link. Before clicking, verify the sender and contact the supposed provider directly by phone.",
        "severity": "high",
        "category": "phishing",
        "level": "novice",
        "date": "2026-03-05",
    },
    {
        "id": "trend_4",
        "title_fr": "Pop-up « Votre ordinateur est infecté » — faux support Microsoft",
        "title_en": "'Your computer is infected' pop-up — fake Microsoft support",
        "description_fr": "Un message d'alerte apparaît sur votre écran disant que votre PC est infecté et vous demande d'appeler un numéro. C'est un piège ! Fermez simplement l'onglet ou le navigateur (Ctrl+W ou Alt+F4). Microsoft ne vous contacte jamais de cette façon.",
        "description_en": "An alert message appears on your screen saying your PC is infected and asks you to call a number. It's a trap! Simply close the tab or browser (Ctrl+W or Alt+F4). Microsoft never contacts you this way.",
        "severity": "medium",
        "category": "vishing",
        "level": "novice",
        "date": "2026-03-02",
    },
    {
        "id": "trend_5",
        "title_fr": "Faux email de votre banque demandant de « confirmer votre identité »",
        "title_en": "Fake bank email asking to 'confirm your identity'",
        "description_fr": "Un email vous dit que votre compte sera bloqué si vous ne confirmez pas vos informations. Votre banque ne vous demande jamais de cliquer sur un lien pour vérifier votre identité. En cas de doute, appelez votre conseiller directement.",
        "description_en": "An email tells you your account will be blocked if you don't confirm your information. Your bank never asks you to click a link to verify your identity. When in doubt, call your advisor directly.",
        "severity": "high",
        "category": "phishing",
        "level": "novice",
        "date": "2026-02-28",
    },
    {
        "id": "trend_6",
        "title_fr": "QR codes suspects sur des affiches ou faux avis de contravention",
        "title_en": "Suspicious QR codes on posters or fake parking tickets",
        "description_fr": "Des faux QR codes sont collés dans les lieux publics ou déposés sur les pare-brises. Ils redirigent vers des sites de phishing. Ne scannez un QR code que si vous êtes sûr de sa provenance.",
        "description_en": "Fake QR codes are stuck in public places or placed on windshields. They redirect to phishing sites. Only scan a QR code if you're sure of its origin.",
        "severity": "medium",
        "category": "quishing",
        "level": "novice",
        "date": "2026-02-25",
    },
    {
        "id": "trend_7",
        "title_fr": "Arnaque « Votre mot de passe a été compromis »",
        "title_en": "'Your password has been compromised' scam",
        "description_fr": "Vous recevez un email affirmant que votre mot de passe a fuité et vous demandant de le changer via un lien. Ne cliquez pas ! Si vous avez un doute, changez votre mot de passe directement sur le site officiel du service concerné.",
        "description_en": "You receive an email claiming your password has leaked and asking you to change it via a link. Don't click! If in doubt, change your password directly on the official site of the service.",
        "severity": "medium",
        "category": "phishing",
        "level": "novice",
        "date": "2026-02-20",
    },
]

# External learning resources
EXTERNAL_RESOURCES = [
    {
        "id": "anssi_secnum",
        "source": "ANSSI",
        "title_fr": "SecNumacadémie - MOOC Cybersécurité",
        "title_en": "SecNumacademie - Cybersecurity MOOC",
        "description_fr": "Formation gratuite et certifiante de l'ANSSI. 4 modules pour comprendre les enjeux de la cybersécurité.",
        "description_en": "Free certified training from ANSSI. 4 modules to understand cybersecurity challenges.",
        "url": "https://secnumacademie.gouv.fr/",
        "difficulty": 2,
        "duration_fr": "~15 heures",
        "duration_en": "~15 hours",
        "xp_reward": 200,
        "category": "formation",
        "icon": "graduation-cap",
    },
    {
        "id": "anssi_hygiene",
        "source": "ANSSI",
        "title_fr": "Guide d'hygiène informatique - 42 règles",
        "title_en": "IT Hygiene Guide - 42 rules",
        "description_fr": "Les 42 règles essentielles pour sécuriser votre système d'information. Guide de référence de l'ANSSI.",
        "description_en": "The 42 essential rules to secure your information system. ANSSI reference guide.",
        "url": "https://www.ssi.gouv.fr/guide/guide-dhygiene-informatique/",
        "difficulty": 2,
        "duration_fr": "~2 heures",
        "duration_en": "~2 hours",
        "xp_reward": 80,
        "category": "guide",
        "icon": "book-open",
    },
    {
        "id": "cnil_rgpd",
        "source": "CNIL",
        "title_fr": "MOOC Atelier RGPD",
        "title_en": "GDPR Workshop MOOC",
        "description_fr": "Formation en ligne de la CNIL pour comprendre et appliquer le RGPD. 4 modules interactifs.",
        "description_en": "CNIL online training to understand and apply GDPR. 4 interactive modules.",
        "url": "https://atelier-rgpd.cnil.fr/",
        "difficulty": 2,
        "duration_fr": "~5 heures",
        "duration_en": "~5 hours",
        "xp_reward": 120,
        "category": "formation",
        "icon": "shield",
    },
    {
        "id": "cnil_securite",
        "source": "CNIL",
        "title_fr": "Guide sécurité des données personnelles",
        "title_en": "Personal Data Security Guide",
        "description_fr": "Les bonnes pratiques pour protéger les données personnelles selon la CNIL.",
        "description_en": "Best practices for protecting personal data according to CNIL.",
        "url": "https://www.cnil.fr/fr/principes-cles/guide-de-la-securite-des-donnees-personnelles",
        "difficulty": 1,
        "duration_fr": "~1 heure",
        "duration_en": "~1 hour",
        "xp_reward": 50,
        "category": "guide",
        "icon": "lock",
    },
    {
        "id": "cybermalv_kit",
        "source": "Cybermalveillance.gouv.fr",
        "title_fr": "Kit de sensibilisation à la cybersécurité",
        "title_en": "Cybersecurity Awareness Kit",
        "description_fr": "Kit complet avec fiches pratiques, vidéos et quiz pour sensibiliser aux risques numériques.",
        "description_en": "Complete kit with practical sheets, videos and quizzes to raise awareness of digital risks.",
        "url": "https://www.cybermalveillance.gouv.fr/tous-nos-contenus/kit-de-sensibilisation",
        "difficulty": 1,
        "duration_fr": "~3 heures",
        "duration_en": "~3 hours",
        "xp_reward": 100,
        "category": "sensibilisation",
        "icon": "users",
    },
    {
        "id": "cybermalv_fiches",
        "source": "Cybermalveillance.gouv.fr",
        "title_fr": "Fiches réflexes - Les bons gestes",
        "title_en": "Quick Reference Cards - Good Practices",
        "description_fr": "Fiches pratiques pour réagir face aux principales menaces : phishing, ransomware, arnaque au faux support.",
        "description_en": "Practical cards to respond to main threats: phishing, ransomware, fake support scam.",
        "url": "https://www.cybermalveillance.gouv.fr/tous-nos-contenus/fiches-reflexes",
        "difficulty": 1,
        "duration_fr": "~30 minutes",
        "duration_en": "~30 minutes",
        "xp_reward": 30,
        "category": "guide",
        "icon": "file-text",
    },
    {
        "id": "pix_competences",
        "source": "Pix",
        "title_fr": "Pix - Testez vos compétences numériques",
        "title_en": "Pix - Test your digital skills",
        "description_fr": "Plateforme officielle pour évaluer et certifier vos compétences numériques, dont la sécurité.",
        "description_en": "Official platform to evaluate and certify your digital skills, including security.",
        "url": "https://pix.fr/",
        "difficulty": 2,
        "duration_fr": "Variable",
        "duration_en": "Variable",
        "xp_reward": 150,
        "category": "certification",
        "icon": "award",
    },
    {
        "id": "signal_spam",
        "source": "Signal Spam",
        "title_fr": "Signal Spam - Signaler et comprendre le spam",
        "title_en": "Signal Spam - Report and understand spam",
        "description_fr": "Plateforme nationale de signalement du spam. Apprenez à identifier et signaler les tentatives de phishing.",
        "description_en": "National spam reporting platform. Learn to identify and report phishing attempts.",
        "url": "https://www.signal-spam.fr/",
        "difficulty": 1,
        "duration_fr": "~15 minutes",
        "duration_en": "~15 minutes",
        "xp_reward": 20,
        "category": "outil",
        "icon": "flag",
    },
]
