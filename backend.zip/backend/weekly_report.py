"""
SecureLink Weekly Report Generator
Generates weekly PDF reports accessible from the admin dashboard.
"""
import io
from datetime import datetime, timezone, timedelta
from fpdf import FPDF


class WeeklyReportPDF(FPDF):
    def __init__(self, week_start, week_end, lang="fr"):
        super().__init__()
        self.week_start = week_start
        self.week_end = week_end
        self.lang = lang

    def header(self):
        self.set_font("Helvetica", "B", 16)
        title = "Rapport Hebdomadaire SecureLink" if self.lang == "fr" else "SecureLink Weekly Report"
        self.cell(0, 10, title, align="C", new_x="LMARGIN", new_y="NEXT")
        self.set_font("Helvetica", "", 9)
        period = f"{self.week_start} - {self.week_end}"
        label = "Periode" if self.lang == "fr" else "Period"
        self.cell(0, 6, f"{label}: {period}", align="C", new_x="LMARGIN", new_y="NEXT")
        gen_label = "Genere le" if self.lang == "fr" else "Generated on"
        self.cell(0, 5, f"{gen_label}: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}", align="C", new_x="LMARGIN", new_y="NEXT")
        self.ln(8)

    def footer(self):
        self.set_y(-15)
        self.set_font("Helvetica", "I", 8)
        self.cell(0, 10, f"SecureLink - Page {self.page_no()}/{{nb}}", align="C")

    def add_section(self, title):
        self.set_font("Helvetica", "B", 12)
        self.set_fill_color(240, 240, 245)
        self.cell(0, 8, f"  {title}", fill=True, new_x="LMARGIN", new_y="NEXT")
        self.ln(3)

    def add_kpi(self, label, value, delta=None):
        self.set_font("Helvetica", "", 10)
        self.cell(80, 6, f"  {label}:")
        self.set_font("Helvetica", "B", 10)
        text = str(value)
        if delta is not None:
            sign = "+" if delta >= 0 else ""
            text += f"  ({sign}{delta} vs semaine precedente)" if self.lang == "fr" else f"  ({sign}{delta} vs previous week)"
        self.cell(0, 6, text, new_x="LMARGIN", new_y="NEXT")


async def generate_weekly_report(db, lang="fr"):
    """Generate a weekly report and store it in the database."""
    now = datetime.now(timezone.utc)
    week_end = now.date() + timedelta(days=1)  # Include today
    week_start = week_end - timedelta(days=7)
    prev_week_start = week_start - timedelta(days=7)

    ws = week_start.isoformat()
    we = week_end.isoformat()
    pws = prev_week_start.isoformat()

    # Current week stats
    analyses_count = await db.analyses.count_documents({"analyzed_at": {"$gte": ws, "$lt": we}})
    safe_count = await db.analyses.count_documents({"analyzed_at": {"$gte": ws, "$lt": we}, "risk_level": "SAFE"})
    suspicious_count = await db.analyses.count_documents({"analyzed_at": {"$gte": ws, "$lt": we}, "risk_level": "SUSPICIOUS"})
    dangerous_count = await db.analyses.count_documents({"analyzed_at": {"$gte": ws, "$lt": we}, "risk_level": "DANGEROUS"})
    new_users = await db.users.count_documents({"created_at": {"$gte": ws, "$lt": we}})
    total_users = await db.users.count_documents({})
    feedback_count = await db.feedback.count_documents({"created_at": {"$gte": ws, "$lt": we}})
    sim_count = await db.simulation_results.count_documents({"completed_at": {"$gte": ws, "$lt": we}})
    sim_correct = await db.simulation_results.count_documents({"completed_at": {"$gte": ws, "$lt": we}, "correct": True})
    contributions = await db.contributions.count_documents({"created_at": {"$gte": ws, "$lt": we}})

    # Previous week stats for deltas
    prev_analyses = await db.analyses.count_documents({"analyzed_at": {"$gte": pws, "$lt": ws}})
    prev_users = await db.users.count_documents({"created_at": {"$gte": pws, "$lt": ws}})

    # Top analyzed domains this week
    analyses_list = await db.analyses.find(
        {"analyzed_at": {"$gte": ws, "$lt": we}}, {"_id": 0, "url": 1, "risk_level": 1}
    ).to_list(5000)

    domain_counts = {}
    for a in analyses_list:
        url = a.get("url", "")
        try:
            from urllib.parse import urlparse
            domain = urlparse(url).netloc or url
        except Exception:
            domain = url
        domain_counts[domain] = domain_counts.get(domain, 0) + 1
    top_domains = sorted(domain_counts.items(), key=lambda x: -x[1])[:10]

    # Generate PDF
    pdf = WeeklyReportPDF(
        week_start=week_start.strftime("%d/%m/%Y"),
        week_end=week_end.strftime("%d/%m/%Y"),
        lang=lang,
    )
    pdf.alias_nb_pages()
    pdf.add_page()
    pdf.set_auto_page_break(auto=True, margin=20)

    # Section 1: Activity Overview
    pdf.add_section("Vue d'ensemble" if lang == "fr" else "Activity Overview")
    pdf.add_kpi("Analyses cette semaine" if lang == "fr" else "Analyses this week", analyses_count, analyses_count - prev_analyses)
    pdf.add_kpi("Nouveaux utilisateurs" if lang == "fr" else "New users", new_users, new_users - prev_users)
    pdf.add_kpi("Total utilisateurs" if lang == "fr" else "Total users", total_users)
    pdf.add_kpi("Feedback soumis" if lang == "fr" else "Feedback submitted", feedback_count)
    pdf.add_kpi("Contributions" if lang == "fr" else "Contributions", contributions)
    pdf.ln(5)

    # Section 2: Detection
    pdf.add_section("Taux de detection" if lang == "fr" else "Detection Rates")
    total = safe_count + suspicious_count + dangerous_count
    if total > 0:
        pdf.add_kpi("Surs" if lang == "fr" else "Safe", f"{safe_count} ({round(safe_count/total*100, 1)}%)")
        pdf.add_kpi("Suspects" if lang == "fr" else "Suspicious", f"{suspicious_count} ({round(suspicious_count/total*100, 1)}%)")
        pdf.add_kpi("Dangereux" if lang == "fr" else "Dangerous", f"{dangerous_count} ({round(dangerous_count/total*100, 1)}%)")
    else:
        pdf.set_font("Helvetica", "I", 10)
        pdf.cell(0, 6, "  Aucune analyse cette semaine." if lang == "fr" else "  No analyses this week.", new_x="LMARGIN", new_y="NEXT")
    pdf.ln(5)

    # Section 3: Simulation
    pdf.add_section("Simulations Phishing" if lang == "fr" else "Phishing Simulations")
    pdf.add_kpi("Sessions de simulation" if lang == "fr" else "Simulation sessions", sim_count)
    accuracy = round((sim_correct / sim_count) * 100, 1) if sim_count > 0 else 0
    pdf.add_kpi("Precision moyenne" if lang == "fr" else "Average accuracy", f"{accuracy}%")
    pdf.ln(5)

    # Section 4: Top Domains
    if top_domains:
        pdf.add_section("Top domaines analyses" if lang == "fr" else "Top Analyzed Domains")
        pdf.set_font("Helvetica", "", 9)
        for i, (domain, count) in enumerate(top_domains, 1):
            d = domain if len(domain) <= 50 else domain[:47] + "..."
            pdf.cell(0, 5, f"  {i}. {d} ({count}x)", new_x="LMARGIN", new_y="NEXT")

    pdf_bytes = pdf.output()

    # Store report in database
    report_id = f"report_{week_start.isoformat()}_{week_end.isoformat()}"
    import base64
    report_doc = {
        "id": report_id,
        "week_start": ws,
        "week_end": we,
        "generated_at": now.isoformat(),
        "stats": {
            "analyses": analyses_count,
            "safe": safe_count,
            "suspicious": suspicious_count,
            "dangerous": dangerous_count,
            "new_users": new_users,
            "total_users": total_users,
            "feedback": feedback_count,
            "simulations": sim_count,
            "contributions": contributions,
        },
        "pdf_base64": base64.b64encode(pdf_bytes).decode("utf-8"),
    }

    await db.weekly_reports.update_one(
        {"id": report_id}, {"$set": report_doc}, upsert=True
    )

    return {
        "id": report_id,
        "week_start": ws,
        "week_end": we,
        "generated_at": now.isoformat(),
        "stats": report_doc["stats"],
    }
