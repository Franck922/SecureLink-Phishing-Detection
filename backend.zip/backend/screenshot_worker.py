"""
Standalone Playwright screenshot script.
Called as a subprocess to avoid event loop conflicts with uvicorn on Windows.
Usage: python screenshot_worker.py <url>
Outputs JSON to stdout: {"captured": bool, "image_base64": str|null, "error": str|null}
"""
import sys
import json
import base64

def main():
    url = sys.argv[1] if len(sys.argv) > 1 else ""
    result = {"captured": False, "image_base64": None, "error": None}

    if not url:
        result["error"] = "no_url"
        print(json.dumps(result))
        return

    try:
        from playwright.sync_api import sync_playwright

        with sync_playwright() as p:
            browser = p.chromium.launch(
                headless=True,
                args=["--no-sandbox", "--disable-dev-shm-usage"],
            )
            context = browser.new_context(
                viewport={"width": 1280, "height": 800},
                user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 SecureLink/1.0",
                ignore_https_errors=True,
            )
            page = context.new_page()

            try:
                page.goto(url, wait_until="domcontentloaded", timeout=12000)
                page.wait_for_timeout(2000)
                screenshot_bytes = page.screenshot(type="jpeg", quality=40, full_page=False)
                result["captured"] = True
                result["image_base64"] = base64.b64encode(screenshot_bytes).decode("utf-8")
            except Exception as e:
                result["error"] = "capture_failed"
            finally:
                context.close()
                browser.close()

    except Exception as e:
        result["error"] = f"browser_error: {type(e).__name__}"

    print(json.dumps(result))

if __name__ == "__main__":
    main()
