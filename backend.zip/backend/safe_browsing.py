"""
SecureLink Safe Browsing Module
Checks URLs against Google Safe Browsing API and provides threat intelligence.
Gracefully disabled if no API key is configured.
"""
import os
import logging
import requests

logger = logging.getLogger(__name__)

GOOGLE_SAFE_BROWSING_KEY = os.environ.get("GOOGLE_SAFE_BROWSING_KEY", "")
GSB_API_URL = "https://safebrowsing.googleapis.com/v4/threatMatches:find"
TIMEOUT = 5


def check_google_safe_browsing(url):
    """Check a URL against Google Safe Browsing API v4.
    Returns dict with threat information or None if disabled/error.
    """
    result = {
        "checked": False,
        "is_threat": False,
        "threat_types": [],
        "platform_types": [],
        "source": "google_safe_browsing",
        "error": None,
    }

    if not GOOGLE_SAFE_BROWSING_KEY:
        result["error"] = "no_api_key"
        return result

    try:
        payload = {
            "client": {
                "clientId": "securelink",
                "clientVersion": "1.0"
            },
            "threatInfo": {
                "threatTypes": [
                    "MALWARE",
                    "SOCIAL_ENGINEERING",
                    "UNWANTED_SOFTWARE",
                    "POTENTIALLY_HARMFUL_APPLICATION",
                ],
                "platformTypes": ["ANY_PLATFORM"],
                "threatEntryTypes": ["URL"],
                "threatEntries": [{"url": url}]
            }
        }

        resp = requests.post(
            GSB_API_URL,
            params={"key": GOOGLE_SAFE_BROWSING_KEY},
            json=payload,
            timeout=TIMEOUT,
        )

        if resp.status_code == 200:
            data = resp.json()
            result["checked"] = True
            matches = data.get("matches", [])
            if matches:
                result["is_threat"] = True
                result["threat_types"] = list(set(m.get("threatType", "") for m in matches))
                result["platform_types"] = list(set(m.get("platformType", "") for m in matches))
        elif resp.status_code == 400:
            result["error"] = "invalid_request"
            logger.warning(f"Google Safe Browsing: invalid request for {url}")
        elif resp.status_code == 403:
            result["error"] = "api_key_invalid"
            logger.warning("Google Safe Browsing: API key invalid or quota exceeded")
        else:
            result["error"] = f"http_{resp.status_code}"
            logger.warning(f"Google Safe Browsing: HTTP {resp.status_code}")

    except requests.Timeout:
        result["error"] = "timeout"
    except Exception as e:
        result["error"] = str(e)[:100]
        logger.warning(f"Google Safe Browsing check failed: {e}")

    return result


# Threat type labels for display
THREAT_LABELS = {
    "MALWARE": {
        "fr": "Logiciel malveillant (malware)",
        "en": "Malware",
        "severity": "critical",
    },
    "SOCIAL_ENGINEERING": {
        "fr": "Ingenierie sociale / Phishing",
        "en": "Social Engineering / Phishing",
        "severity": "critical",
    },
    "UNWANTED_SOFTWARE": {
        "fr": "Logiciel indesirable",
        "en": "Unwanted Software",
        "severity": "high",
    },
    "POTENTIALLY_HARMFUL_APPLICATION": {
        "fr": "Application potentiellement dangereuse",
        "en": "Potentially Harmful Application",
        "severity": "high",
    },
}


def format_safe_browsing_result(sb_result):
    """Format the Safe Browsing result for frontend display."""
    if not sb_result or not sb_result.get("checked"):
        return None

    formatted = {
        "checked": True,
        "is_threat": sb_result["is_threat"],
        "threats": [],
    }

    for threat_type in sb_result.get("threat_types", []):
        label = THREAT_LABELS.get(threat_type, {})
        formatted["threats"].append({
            "type": threat_type,
            "label_fr": label.get("fr", threat_type),
            "label_en": label.get("en", threat_type),
            "severity": label.get("severity", "high"),
        })

    return formatted
