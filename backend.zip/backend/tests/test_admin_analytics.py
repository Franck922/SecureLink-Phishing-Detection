"""
Admin Analytics Dashboard Tests
Tests the new admin analytics endpoint and related features for iteration 6.
Features: 30-day analysis trends, detection rates, engagement KPIs, user growth.
"""
import pytest
import requests
import os

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', '').rstrip('/')

# Test credentials for admin user
ADMIN_EMAIL = "metricsadmin@test.com"
ADMIN_PASSWORD = "testpass123"


@pytest.fixture(scope="module")
def admin_token():
    """Get admin auth token"""
    response = requests.post(
        f"{BASE_URL}/api/auth/login",
        json={"email": ADMIN_EMAIL, "password": ADMIN_PASSWORD}
    )
    if response.status_code == 200:
        data = response.json()
        # Verify user is admin
        assert data.get("user", {}).get("is_admin") == True, "User should be admin"
        return data["token"]
    pytest.skip("Admin login failed - skipping admin tests")


@pytest.fixture
def admin_headers(admin_token):
    """Admin auth headers"""
    return {
        "Authorization": f"Bearer {admin_token}",
        "Content-Type": "application/json"
    }


class TestAdminAnalyticsEndpoint:
    """Tests for GET /api/admin/analytics endpoint"""

    def test_analytics_requires_auth(self):
        """Analytics endpoint should require authentication"""
        response = requests.get(f"{BASE_URL}/api/admin/analytics")
        assert response.status_code == 401, "Should return 401 without auth"

    def test_analytics_requires_admin(self):
        """Analytics endpoint should require admin privileges"""
        # First create a non-admin user
        test_email = f"nonadmin_test_{os.urandom(4).hex()}@test.com"
        reg_response = requests.post(
            f"{BASE_URL}/api/auth/register",
            json={"username": "nonadmin", "email": test_email, "password": "test123"}
        )
        if reg_response.status_code == 200:
            token = reg_response.json()["token"]
            response = requests.get(
                f"{BASE_URL}/api/admin/analytics",
                headers={"Authorization": f"Bearer {token}"}
            )
            assert response.status_code == 403, "Non-admin should get 403"

    def test_analytics_returns_daily_analyses(self, admin_headers):
        """Analytics should return 30 days of analysis data"""
        response = requests.get(f"{BASE_URL}/api/admin/analytics", headers=admin_headers)
        assert response.status_code == 200
        
        data = response.json()
        assert "daily_analyses" in data
        
        daily = data["daily_analyses"]
        assert len(daily) == 30, f"Expected 30 entries, got {len(daily)}"
        
        # Check structure of each entry
        for entry in daily:
            assert "date" in entry, "Each entry should have date"
            assert "total" in entry, "Each entry should have total"
            assert "safe" in entry, "Each entry should have safe count"
            assert "suspicious" in entry, "Each entry should have suspicious count"
            assert "dangerous" in entry, "Each entry should have dangerous count"
            
            # Verify counts are integers
            assert isinstance(entry["total"], int)
            assert isinstance(entry["safe"], int)
            assert isinstance(entry["suspicious"], int)
            assert isinstance(entry["dangerous"], int)

    def test_analytics_returns_detection_rates(self, admin_headers):
        """Analytics should return detection rate percentages"""
        response = requests.get(f"{BASE_URL}/api/admin/analytics", headers=admin_headers)
        assert response.status_code == 200
        
        data = response.json()
        assert "detection_rates" in data
        
        rates = data["detection_rates"]
        required_fields = ["total", "safe", "suspicious", "dangerous", "safe_pct", "suspicious_pct", "dangerous_pct"]
        for field in required_fields:
            assert field in rates, f"Missing field: {field}"
        
        # Verify percentages are reasonable (between 0 and 100)
        for pct_field in ["safe_pct", "suspicious_pct", "dangerous_pct"]:
            assert 0 <= rates[pct_field] <= 100, f"{pct_field} should be between 0 and 100"
        
        # If there are analyses, percentages should roughly sum to 100
        if rates["total"] > 0:
            total_pct = rates["safe_pct"] + rates["suspicious_pct"] + rates["dangerous_pct"]
            # Allow for rounding errors
            assert 99 <= total_pct <= 101, f"Percentages should sum to ~100, got {total_pct}"

    def test_analytics_returns_engagement_kpis(self, admin_headers):
        """Analytics should return engagement metrics"""
        response = requests.get(f"{BASE_URL}/api/admin/analytics", headers=admin_headers)
        assert response.status_code == 200
        
        data = response.json()
        assert "engagement" in data
        
        engagement = data["engagement"]
        required_fields = [
            "analyses_today", "analyses_yesterday", "analyses_trend",
            "total_simulations", "simulation_accuracy",
            "total_feedback", "feedback_this_week",
            "active_users_today"
        ]
        for field in required_fields:
            assert field in engagement, f"Missing engagement field: {field}"
        
        # Verify types
        assert isinstance(engagement["analyses_today"], int)
        assert isinstance(engagement["total_simulations"], int)
        assert isinstance(engagement["total_feedback"], int)
        assert isinstance(engagement["active_users_today"], int)
        
        # Verify trend calculation
        expected_trend = engagement["analyses_today"] - engagement["analyses_yesterday"]
        assert engagement["analyses_trend"] == expected_trend

    def test_analytics_returns_user_growth(self, admin_headers):
        """Analytics should return 30 days of user growth data"""
        response = requests.get(f"{BASE_URL}/api/admin/analytics", headers=admin_headers)
        assert response.status_code == 200
        
        data = response.json()
        assert "user_growth" in data
        
        growth = data["user_growth"]
        assert len(growth) == 30, f"Expected 30 entries, got {len(growth)}"
        
        # Check structure
        for entry in growth:
            assert "date" in entry
            assert "new_users" in entry
            assert isinstance(entry["new_users"], int)
            assert entry["new_users"] >= 0

    def test_analytics_returns_user_totals(self, admin_headers):
        """Analytics should return user totals summary"""
        response = requests.get(f"{BASE_URL}/api/admin/analytics", headers=admin_headers)
        assert response.status_code == 200
        
        data = response.json()
        assert "user_totals" in data
        
        totals = data["user_totals"]
        assert "total" in totals
        assert "last_7d" in totals
        assert "last_30d" in totals
        
        # last_7d should be <= last_30d <= total
        assert totals["last_7d"] <= totals["last_30d"]
        assert totals["last_30d"] <= totals["total"]


class TestAdminExportFeatures:
    """Tests for admin export functionality (CSV/PDF)"""

    def test_admin_export_analyses_csv(self, admin_headers):
        """Admin can export analyses as CSV"""
        response = requests.get(f"{BASE_URL}/api/admin/export/analyses/csv", headers=admin_headers)
        assert response.status_code == 200
        assert "text/csv" in response.headers.get("content-type", "")
        
        # Check CSV content
        content = response.text
        # Should have header row
        assert "URL" in content or "url" in content.lower()

    def test_admin_export_users_csv(self, admin_headers):
        """Admin can export users as CSV"""
        response = requests.get(f"{BASE_URL}/api/admin/export/users/csv", headers=admin_headers)
        assert response.status_code == 200
        assert "text/csv" in response.headers.get("content-type", "")
        
        # Check CSV content has user fields
        content = response.text
        assert "email" in content.lower() or "Email" in content

    def test_admin_export_report_pdf(self, admin_headers):
        """Admin can export full report as PDF"""
        response = requests.get(f"{BASE_URL}/api/admin/export/report/pdf", headers=admin_headers)
        assert response.status_code == 200
        assert "application/pdf" in response.headers.get("content-type", "")
        
        # PDF should start with %PDF
        assert response.content[:4] == b"%PDF"

    def test_export_requires_admin(self):
        """Export endpoints should require admin privileges"""
        # Test without auth
        for endpoint in ["analyses/csv", "users/csv", "report/pdf"]:
            response = requests.get(f"{BASE_URL}/api/admin/export/{endpoint}")
            assert response.status_code in [401, 403], f"Export {endpoint} should require auth"


class TestAdminTabsAndStats:
    """Tests for admin stats and tab data"""

    def test_admin_stats_endpoint(self, admin_headers):
        """Admin stats endpoint should return overview data"""
        response = requests.get(f"{BASE_URL}/api/admin/stats", headers=admin_headers)
        assert response.status_code == 200
        
        data = response.json()
        required_fields = [
            "total_users", "total_analyses", "total_contributions",
            "pending_contributions", "total_feedback", "training_samples",
            "analyses_by_risk", "weekly_analyses", "weekly_active_users",
            "model_accuracy"
        ]
        for field in required_fields:
            assert field in data, f"Missing stat field: {field}"

    def test_admin_users_endpoint(self, admin_headers):
        """Admin users endpoint should return paginated user list"""
        response = requests.get(f"{BASE_URL}/api/admin/users", headers=admin_headers)
        assert response.status_code == 200
        
        data = response.json()
        assert "users" in data
        assert "total" in data
        assert "page" in data
        assert "pages" in data
        
        # Check user structure
        if data["users"]:
            user = data["users"][0]
            assert "username" in user
            assert "email" in user
            assert "xp" in user
            assert "is_admin" in user

    def test_admin_contributions_endpoint(self, admin_headers):
        """Admin contributions endpoint should return filtered list"""
        response = requests.get(
            f"{BASE_URL}/api/admin/contributions?status_filter=pending",
            headers=admin_headers
        )
        assert response.status_code == 200
        
        data = response.json()
        assert "contributions" in data
        assert "total" in data

    def test_admin_analyses_endpoint(self, admin_headers):
        """Admin analyses endpoint should return filtered list"""
        response = requests.get(f"{BASE_URL}/api/admin/analyses", headers=admin_headers)
        assert response.status_code == 200
        
        data = response.json()
        assert "analyses" in data
        assert "total" in data
        
        # Test with risk filter
        for risk_level in ["SAFE", "SUSPICIOUS", "DANGEROUS"]:
            filtered = requests.get(
                f"{BASE_URL}/api/admin/analyses?risk_filter={risk_level}",
                headers=admin_headers
            )
            assert filtered.status_code == 200


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
