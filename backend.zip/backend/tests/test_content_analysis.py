"""
SecureLink Content Analysis Tests - Phase 4
Tests for web page content analysis integration:
- content_score field in API response
- content_findings array
- content_details object with page_fetched, has_login_form, brand_impersonation, suspicious_scripts_count, external_domains_count
- Hybrid scoring formula (40% ML + 25% Rules + 15% Network + 20% Content)
"""
import pytest
import requests
import os
import time

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', '').rstrip('/')

class TestContentAnalysisBackend:
    """Backend tests for content analysis feature"""
    
    def test_health_check(self):
        """Verify API is healthy"""
        response = requests.get(f"{BASE_URL}/api/health")
        assert response.status_code == 200
        data = response.json()
        assert data.get("status") == "healthy"
        print("✓ Health check passed")
    
    def test_analyze_returns_content_score(self):
        """POST /api/analyze returns content_score field"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "google.com"},
            timeout=30
        )
        assert response.status_code == 200
        data = response.json()
        assert "content_score" in data, "content_score field missing from response"
        assert isinstance(data["content_score"], (int, float)), "content_score should be numeric"
        print(f"✓ content_score returned: {data['content_score']}")
    
    def test_analyze_returns_content_findings(self):
        """POST /api/analyze returns content_findings array"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "google.com"},
            timeout=30
        )
        assert response.status_code == 200
        data = response.json()
        assert "content_findings" in data, "content_findings field missing from response"
        assert isinstance(data["content_findings"], list), "content_findings should be a list"
        print(f"✓ content_findings returned: {len(data['content_findings'])} findings")
    
    def test_analyze_returns_content_details(self):
        """POST /api/analyze returns content_details object with all required fields"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "google.com"},
            timeout=30
        )
        assert response.status_code == 200
        data = response.json()
        
        assert "content_details" in data, "content_details field missing from response"
        cd = data["content_details"]
        
        # Check all required fields
        assert "page_fetched" in cd, "page_fetched missing from content_details"
        assert "has_login_form" in cd, "has_login_form missing from content_details"
        assert "brand_impersonation" in cd, "brand_impersonation missing from content_details"
        assert "suspicious_scripts_count" in cd, "suspicious_scripts_count missing from content_details"
        assert "external_domains_count" in cd, "external_domains_count missing from content_details"
        
        # Check types
        assert isinstance(cd["page_fetched"], bool), "page_fetched should be boolean"
        assert isinstance(cd["has_login_form"], bool), "has_login_form should be boolean"
        assert isinstance(cd["suspicious_scripts_count"], int), "suspicious_scripts_count should be int"
        assert isinstance(cd["external_domains_count"], int), "external_domains_count should be int"
        
        print(f"✓ content_details returned with all fields: {cd}")
    
    def test_google_com_safe_analysis(self):
        """google.com analysis returns SAFE with content_score=0 and page_fetched=true"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "google.com"},
            timeout=30
        )
        assert response.status_code == 200
        data = response.json()
        
        # Check risk level is SAFE
        assert data.get("risk_level") == "SAFE", f"Expected SAFE, got {data.get('risk_level')}"
        
        # Check content_score is 0 (no suspicious content)
        assert data.get("content_score") == 0, f"Expected content_score=0, got {data.get('content_score')}"
        
        # Check page was fetched
        cd = data.get("content_details", {})
        assert cd.get("page_fetched") == True, f"Expected page_fetched=true, got {cd.get('page_fetched')}"
        
        print(f"✓ google.com: SAFE, content_score=0, page_fetched=true")
    
    def test_suspicious_xyz_domain_elevated_score(self):
        """A suspicious URL with .xyz TLD shows elevated score"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "suspicious-login-verify.xyz"},
            timeout=30
        )
        assert response.status_code == 200
        data = response.json()
        
        # Check elevated score (should be SUSPICIOUS or DANGEROUS)
        assert data.get("risk_level") in ["SUSPICIOUS", "DANGEROUS"], \
            f"Expected SUSPICIOUS or DANGEROUS, got {data.get('risk_level')}"
        
        # Check final_score is elevated (>30)
        assert data.get("final_score", 0) > 30, \
            f"Expected elevated score >30, got {data.get('final_score')}"
        
        print(f"✓ suspicious-login-verify.xyz: {data.get('risk_level')}, final_score={data.get('final_score')}")
    
    def test_hybrid_scoring_formula(self):
        """Verify hybrid scoring includes content_score (40% ML + 25% Rules + 15% Network + 20% Content)"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "google.com"},
            timeout=30
        )
        assert response.status_code == 200
        data = response.json()
        
        # Verify all score components are present
        assert "ml_score" in data, "ml_score missing"
        assert "rules_score" in data, "rules_score missing"
        assert "network_score" in data, "network_score missing"
        assert "content_score" in data, "content_score missing"
        assert "final_score" in data, "final_score missing"
        
        print(f"✓ Hybrid scoring components: ml={data['ml_score']}, rules={data['rules_score']}, network={data['network_score']}, content={data['content_score']}, final={data['final_score']}")
    
    def test_content_findings_structure(self):
        """Verify content_findings items have correct structure when present"""
        # Test with a URL that might have findings (or verify empty array structure)
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "google.com"},
            timeout=30
        )
        assert response.status_code == 200
        data = response.json()
        
        findings = data.get("content_findings", [])
        # For google.com, findings should be empty
        assert isinstance(findings, list), "content_findings should be a list"
        
        # If there are findings, verify structure
        for finding in findings:
            assert "id" in finding, "Finding missing 'id' field"
            assert "severity" in finding, "Finding missing 'severity' field"
            assert "description_fr" in finding, "Finding missing 'description_fr' field"
            assert "description_en" in finding, "Finding missing 'description_en' field"
        
        print(f"✓ content_findings structure verified ({len(findings)} findings)")
    
    def test_final_url_in_content_details(self):
        """Verify final_url is included in content_details (for redirect detection)"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "google.com"},
            timeout=30
        )
        assert response.status_code == 200
        data = response.json()
        
        cd = data.get("content_details", {})
        assert "final_url" in cd, "final_url missing from content_details"
        # Google redirects to www.google.com
        assert "google.com" in cd.get("final_url", "").lower(), \
            f"Expected google.com in final_url, got {cd.get('final_url')}"
        
        print(f"✓ final_url in content_details: {cd.get('final_url')}")
    
    def test_page_not_fetched_for_nonexistent_domain(self):
        """Verify page_fetched=false for non-existent domains"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "this-domain-definitely-does-not-exist-12345.xyz"},
            timeout=30
        )
        assert response.status_code == 200
        data = response.json()
        
        cd = data.get("content_details", {})
        # Page should not be fetched for non-existent domain
        assert cd.get("page_fetched") == False, \
            f"Expected page_fetched=false for non-existent domain, got {cd.get('page_fetched')}"
        
        print(f"✓ page_fetched=false for non-existent domain")
    
    def test_content_score_range(self):
        """Verify content_score is within valid range (0-100)"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "google.com"},
            timeout=30
        )
        assert response.status_code == 200
        data = response.json()
        
        content_score = data.get("content_score", -1)
        assert 0 <= content_score <= 100, \
            f"content_score should be 0-100, got {content_score}"
        
        print(f"✓ content_score in valid range: {content_score}")


class TestContentAnalysisIntegration:
    """Integration tests for content analysis with other features"""
    
    def test_authenticated_analysis_with_content(self):
        """Verify authenticated analysis includes content analysis"""
        # Login first
        login_response = requests.post(
            f"{BASE_URL}/api/auth/login",
            json={"email": "demo@test.com", "password": "demo123"}
        )
        
        if login_response.status_code != 200:
            pytest.skip("Demo user login failed - skipping authenticated test")
        
        token = login_response.json().get("token")
        headers = {"Authorization": f"Bearer {token}"}
        
        # Analyze with auth
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "google.com"},
            headers=headers,
            timeout=30
        )
        assert response.status_code == 200
        data = response.json()
        
        # Verify content analysis fields present
        assert "content_score" in data
        assert "content_findings" in data
        assert "content_details" in data
        
        print(f"✓ Authenticated analysis includes content analysis")
    
    def test_analysis_history_includes_content_score(self):
        """Verify analysis history includes content_score"""
        # Login first
        login_response = requests.post(
            f"{BASE_URL}/api/auth/login",
            json={"email": "demo@test.com", "password": "demo123"}
        )
        
        if login_response.status_code != 200:
            pytest.skip("Demo user login failed - skipping history test")
        
        token = login_response.json().get("token")
        headers = {"Authorization": f"Bearer {token}"}
        
        # Get history
        response = requests.get(
            f"{BASE_URL}/api/history",
            headers=headers
        )
        
        if response.status_code == 200:
            data = response.json()
            if isinstance(data, list) and len(data) > 0:
                # Check if recent analyses have content_score
                recent = data[0]
                # content_score may or may not be stored in history depending on implementation
                print(f"✓ History endpoint accessible, {len(data)} analyses found")
            else:
                print(f"✓ History endpoint accessible, no analyses yet")
        else:
            print(f"⚠ History endpoint returned {response.status_code}")


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
