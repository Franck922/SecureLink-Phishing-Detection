"""
Test API contract for browser extensions (Chrome/Firefox)
Tests that POST /api/analyze returns all required fields expected by popup.js
"""
import pytest
import requests
import os

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', '').rstrip('/')

class TestAnalyzeAPIContract:
    """Tests for POST /api/analyze endpoint - API contract for browser extensions"""
    
    def test_analyze_safe_url_returns_correct_fields(self):
        """Test that analyzing a safe URL returns all required fields for extensions"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "https://google.com"},
            headers={"Content-Type": "application/json"}
        )
        
        assert response.status_code == 200, f"Expected 200, got {response.status_code}: {response.text}"
        data = response.json()
        
        # Core fields required by extension popup.js
        assert "traffic_light" in data, "Missing traffic_light field"
        assert "final_score" in data, "Missing final_score field"
        assert "risk_level" in data, "Missing risk_level field"
        
        # traffic_light should be green/yellow/red
        assert data["traffic_light"] in ["green", "yellow", "red"], f"Invalid traffic_light: {data['traffic_light']}"
        
        # For google.com, expect green/safe
        assert data["traffic_light"] == "green", f"Expected green for google.com, got {data['traffic_light']}"
        assert data["risk_level"] == "SAFE", f"Expected SAFE for google.com, got {data['risk_level']}"
        
        # Network checks structure
        assert "network_checks" in data, "Missing network_checks field"
        nc = data["network_checks"]
        
        # SSL check
        assert "ssl" in nc, "Missing network_checks.ssl"
        assert "valid" in nc["ssl"], "Missing network_checks.ssl.valid"
        
        # WHOIS check
        assert "whois" in nc, "Missing network_checks.whois"
        assert "domain_age_days" in nc["whois"], "Missing network_checks.whois.domain_age_days"
        
        # Safe Browsing
        assert "safe_browsing" in data, "Missing safe_browsing field"
        sb = data["safe_browsing"]
        assert "checked" in sb, "Missing safe_browsing.checked"
        assert "is_threat" in sb, "Missing safe_browsing.is_threat"
        
        # Phishing kit detection
        assert "phishing_kit" in data, "Missing phishing_kit field"
        pk = data["phishing_kit"]
        assert "detected" in pk, "Missing phishing_kit.detected"
        assert "kits" in pk, "Missing phishing_kit.kits"
        
        # Content findings
        assert "content_findings" in data, "Missing content_findings field"
        assert isinstance(data["content_findings"], list), "content_findings should be a list"
        
        # Content details
        assert "content_details" in data, "Missing content_details field"
        cd = data["content_details"]
        assert "page_fetched" in cd, "Missing content_details.page_fetched"
        
        # Typosquatting
        assert "typosquatting_target" in data, "Missing typosquatting_target field"
        
        print(f"PASS: Safe URL (google.com) returns all required fields")
        print(f"  - traffic_light: {data['traffic_light']}")
        print(f"  - final_score: {data['final_score']}")
        print(f"  - risk_level: {data['risk_level']}")
        print(f"  - ssl.valid: {nc['ssl'].get('valid')}")
        print(f"  - whois.domain_age_days: {nc['whois'].get('domain_age_days')}")
        print(f"  - safe_browsing.checked: {sb.get('checked')}")
        print(f"  - phishing_kit.detected: {pk.get('detected')}")
    
    def test_analyze_suspicious_url_returns_correct_fields(self):
        """Test that analyzing a suspicious URL returns yellow or red traffic_light"""
        # Using a URL with suspicious characteristics (HTTP, suspicious keywords)
        # Using a real domain that exists but has suspicious URL patterns
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "http://192.168.1.1/login/verify/secure"},
            headers={"Content-Type": "application/json"}
        )
        
        assert response.status_code == 200, f"Expected 200, got {response.status_code}: {response.text}"
        data = response.json()
        
        # Core fields
        assert "traffic_light" in data, "Missing traffic_light field"
        assert "final_score" in data, "Missing final_score field"
        assert "risk_level" in data, "Missing risk_level field"
        
        # For suspicious URL, expect yellow or red
        assert data["traffic_light"] in ["yellow", "red"], f"Expected yellow/red for suspicious URL, got {data['traffic_light']}"
        assert data["risk_level"] in ["SUSPICIOUS", "DANGEROUS"], f"Expected SUSPICIOUS/DANGEROUS, got {data['risk_level']}"
        
        # Verify all extension-required fields are present
        assert "network_checks" in data
        assert "safe_browsing" in data
        assert "phishing_kit" in data
        assert "content_findings" in data
        assert "content_details" in data
        assert "typosquatting_target" in data
        
        print(f"PASS: Suspicious URL returns correct verdict")
        print(f"  - traffic_light: {data['traffic_light']}")
        print(f"  - final_score: {data['final_score']}")
        print(f"  - risk_level: {data['risk_level']}")
    
    def test_analyze_typosquatting_url(self):
        """Test that typosquatting URLs are detected and return official_site"""
        # g00gle.com is a classic typosquatting example
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "http://g00gle.com"},
            headers={"Content-Type": "application/json"}
        )
        
        assert response.status_code == 200, f"Expected 200, got {response.status_code}: {response.text}"
        data = response.json()
        
        # Check typosquatting detection
        assert "typosquatting_target" in data, "Missing typosquatting_target field"
        
        # If typosquatting is detected, official_site should be present
        if data["typosquatting_target"]:
            assert "official_site" in data, "Missing official_site when typosquatting detected"
            print(f"PASS: Typosquatting detected")
            print(f"  - typosquatting_target: {data['typosquatting_target']}")
            print(f"  - official_site: {data.get('official_site')}")
        else:
            print(f"INFO: Typosquatting not detected for g00gle.com (may be expected)")
        
        # Verify traffic_light is not green for typosquatting
        if data["typosquatting_target"]:
            assert data["traffic_light"] in ["yellow", "red"], f"Typosquatting should not be green"
    
    def test_analyze_http_url_no_https(self):
        """Test that HTTP URLs without HTTPS are flagged appropriately"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "http://example.com"},
            headers={"Content-Type": "application/json"}
        )
        
        assert response.status_code == 200, f"Expected 200, got {response.status_code}: {response.text}"
        data = response.json()
        
        # Verify feature_details has has_https = 0 for HTTP URL
        if "feature_details" in data:
            fd = data["feature_details"]
            if "has_https" in fd:
                assert fd["has_https"] == 0, f"Expected has_https=0 for HTTP URL"
                print(f"PASS: HTTP URL correctly identified (has_https=0)")
        
        print(f"  - traffic_light: {data['traffic_light']}")
        print(f"  - final_score: {data['final_score']}")
    
    def test_analyze_returns_content_findings_structure(self):
        """Test that content_findings has correct structure for extension"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "https://example.com"},
            headers={"Content-Type": "application/json"}
        )
        
        assert response.status_code == 200
        data = response.json()
        
        # content_findings should be a list
        assert "content_findings" in data
        assert isinstance(data["content_findings"], list)
        
        # If there are findings, check structure
        for finding in data["content_findings"]:
            # Each finding should have description_fr or description_en
            assert "description_fr" in finding or "description_en" in finding, \
                f"Finding missing description: {finding}"
            # Severity is used by extension to filter
            if "severity" in finding:
                assert finding["severity"] in ["low", "medium", "high", "critical"], \
                    f"Invalid severity: {finding['severity']}"
        
        print(f"PASS: content_findings has correct structure")
        print(f"  - Number of findings: {len(data['content_findings'])}")
    
    def test_analyze_empty_url_returns_400(self):
        """Test that empty URL returns 400 error"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": ""},
            headers={"Content-Type": "application/json"}
        )
        
        assert response.status_code == 400, f"Expected 400 for empty URL, got {response.status_code}"
        print("PASS: Empty URL correctly returns 400")
    
    def test_analyze_invalid_chars_returns_400(self):
        """Test that URL with invalid characters returns 400"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "https://example.com/<script>"},
            headers={"Content-Type": "application/json"}
        )
        
        assert response.status_code == 400, f"Expected 400 for invalid URL, got {response.status_code}"
        print("PASS: Invalid URL characters correctly returns 400")


class TestAnalyzeAPIScoreRanges:
    """Test that scores are in expected ranges"""
    
    def test_final_score_range(self):
        """Test that final_score is between 0 and 100"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "https://google.com"},
            headers={"Content-Type": "application/json"}
        )
        
        assert response.status_code == 200
        data = response.json()
        
        score = data["final_score"]
        assert 0 <= score <= 100, f"final_score {score} out of range [0, 100]"
        print(f"PASS: final_score {score} is in valid range [0, 100]")
    
    def test_ml_score_present(self):
        """Test that ml_score is present and valid"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "https://google.com"},
            headers={"Content-Type": "application/json"}
        )
        
        assert response.status_code == 200
        data = response.json()
        
        assert "ml_score" in data, "Missing ml_score field"
        ml_score = data["ml_score"]
        assert 0 <= ml_score <= 100, f"ml_score {ml_score} out of range [0, 100]"
        print(f"PASS: ml_score {ml_score} is present and valid")


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
