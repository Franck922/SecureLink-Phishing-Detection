"""
Test Phase B Features: Google Safe Browsing API Integration and Phishing Kit Fingerprinting Detection
Tests for POST /api/analyze endpoint returning safe_browsing and phishing_kit fields
"""
import pytest
import requests
import os
import time

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', '').rstrip('/')

class TestPhaseBFeatures:
    """Test Google Safe Browsing and Phishing Kit Detection features"""
    
    def test_health_check(self):
        """Verify backend is running"""
        response = requests.get(f"{BASE_URL}/api/health")
        assert response.status_code == 200
        data = response.json()
        assert data.get("status") == "healthy"
        print("PASS: Health check returns 200")
    
    def test_analyze_returns_safe_browsing_field(self):
        """POST /api/analyze returns safe_browsing field (null when no API key)"""
        response = requests.post(f"{BASE_URL}/api/analyze", json={"url": "google.com"}, timeout=60)
        assert response.status_code == 200
        data = response.json()
        
        # safe_browsing field should be present (null when no API key configured)
        assert "safe_browsing" in data, "safe_browsing field missing from response"
        
        # Since no API key is configured, safe_browsing should be null
        sb = data.get("safe_browsing")
        if sb is None:
            print("PASS: safe_browsing is null (no API key configured - expected)")
        else:
            # If API key is configured, it should have checked field
            assert "checked" in sb, "safe_browsing should have 'checked' field when present"
            print(f"PASS: safe_browsing field present with checked={sb.get('checked')}")
    
    def test_analyze_returns_phishing_kit_field(self):
        """POST /api/analyze returns phishing_kit field with detected, kits, structural_findings"""
        response = requests.post(f"{BASE_URL}/api/analyze", json={"url": "google.com"}, timeout=60)
        assert response.status_code == 200
        data = response.json()
        
        # phishing_kit field should always be present
        assert "phishing_kit" in data, "phishing_kit field missing from response"
        
        kit = data.get("phishing_kit")
        assert kit is not None, "phishing_kit should not be null"
        
        # Verify structure
        assert "detected" in kit, "phishing_kit should have 'detected' field"
        assert "kits" in kit, "phishing_kit should have 'kits' field"
        assert "structural_findings" in kit, "phishing_kit should have 'structural_findings' field"
        
        # Verify types
        assert isinstance(kit["detected"], bool), "detected should be boolean"
        assert isinstance(kit["kits"], list), "kits should be a list"
        assert isinstance(kit["structural_findings"], list), "structural_findings should be a list"
        
        print(f"PASS: phishing_kit field present with detected={kit['detected']}, kits={len(kit['kits'])}, structural_findings={len(kit['structural_findings'])}")
    
    def test_google_com_no_phishing_kit_detected(self):
        """Phishing kit detection correctly identifies no kit for google.com"""
        response = requests.post(f"{BASE_URL}/api/analyze", json={"url": "google.com"}, timeout=60)
        assert response.status_code == 200
        data = response.json()
        
        kit = data.get("phishing_kit", {})
        
        # google.com should NOT have any phishing kit detected
        assert kit.get("detected") == False, f"google.com should not have phishing kit detected, got: {kit.get('detected')}"
        assert len(kit.get("kits", [])) == 0, f"google.com should have no kits, got: {kit.get('kits')}"
        
        print("PASS: google.com correctly identified as having no phishing kit")
    
    def test_safe_url_analysis_complete_response(self):
        """Test complete analysis response for a safe URL (google.com)"""
        response = requests.post(f"{BASE_URL}/api/analyze", json={"url": "https://www.google.com"}, timeout=60)
        assert response.status_code == 200
        data = response.json()
        
        # Verify all expected fields are present
        required_fields = [
            "url", "final_score", "risk_level", "traffic_light",
            "ml_score", "rules_score", "network_score", "content_score",
            "safe_browsing", "phishing_kit",
            "network_checks", "network_risk_factors",
            "content_findings", "content_details",
            "triggered_rules", "top_risks", "safe_indicators",
            "feature_details", "model_accuracy"
        ]
        
        for field in required_fields:
            assert field in data, f"Missing required field: {field}"
        
        # google.com should be SAFE
        assert data["risk_level"] in ["SAFE", "SUSPICIOUS"], f"google.com should be SAFE or SUSPICIOUS, got: {data['risk_level']}"
        assert data["traffic_light"] in ["green", "yellow"], f"google.com should have green or yellow traffic light, got: {data['traffic_light']}"
        
        print(f"PASS: Complete response for google.com - risk_level={data['risk_level']}, score={data['final_score']}")
    
    def test_existing_features_still_work(self):
        """Verify existing analysis features still work (URL structure, SSL, DNS, Typosquatting, Redirects, Content)"""
        response = requests.post(f"{BASE_URL}/api/analyze", json={"url": "google.com"}, timeout=60)
        assert response.status_code == 200
        data = response.json()
        
        # URL structure analysis
        assert "feature_details" in data, "feature_details missing"
        fd = data.get("feature_details", {})
        assert "url_length" in fd, "url_length missing from feature_details"
        assert "has_https" in fd, "has_https missing from feature_details"
        print(f"  - URL structure: url_length={fd.get('url_length')}, has_https={fd.get('has_https')}")
        
        # SSL/Network checks
        assert "network_checks" in data, "network_checks missing"
        nc = data.get("network_checks", {})
        assert "ssl" in nc or "dns" in nc, "SSL or DNS checks missing from network_checks"
        print(f"  - Network checks: ssl={nc.get('ssl', {}).get('valid')}, dns_exists={nc.get('dns', {}).get('exists')}")
        
        # Content analysis
        assert "content_details" in data, "content_details missing"
        cd = data.get("content_details", {})
        assert "page_fetched" in cd, "page_fetched missing from content_details"
        print(f"  - Content: page_fetched={cd.get('page_fetched')}, has_login_form={cd.get('has_login_form')}")
        
        # Typosquatting
        assert "typosquatting_target" in data, "typosquatting_target missing"
        print(f"  - Typosquatting: target={data.get('typosquatting_target')}")
        
        # Redirects
        assert "redirect_chain" in cd, "redirect_chain missing from content_details"
        print(f"  - Redirects: chain_length={len(cd.get('redirect_chain', []))}")
        
        print("PASS: All existing features still work")
    
    def test_suspicious_url_analysis(self):
        """Test analysis of a potentially suspicious URL pattern"""
        # Use a URL with suspicious characteristics (but not actually malicious)
        response = requests.post(f"{BASE_URL}/api/analyze", json={"url": "http://example-login-verify.xyz"}, timeout=60)
        assert response.status_code == 200
        data = response.json()
        
        # Should have higher risk score due to suspicious TLD and keywords
        assert "final_score" in data
        assert "phishing_kit" in data
        assert "safe_browsing" in data
        
        print(f"PASS: Suspicious URL analysis - risk_level={data['risk_level']}, score={data['final_score']}")
    
    def test_phishing_kit_structure_for_safe_site(self):
        """Verify phishing_kit structure is correct for a safe site"""
        response = requests.post(f"{BASE_URL}/api/analyze", json={"url": "wikipedia.org"}, timeout=60)
        assert response.status_code == 200
        data = response.json()
        
        kit = data.get("phishing_kit", {})
        
        # For a safe site like wikipedia.org
        assert kit.get("detected") == False, "wikipedia.org should not have phishing kit detected"
        assert isinstance(kit.get("kits"), list), "kits should be a list"
        assert isinstance(kit.get("structural_findings"), list), "structural_findings should be a list"
        
        print(f"PASS: wikipedia.org phishing_kit structure correct - detected={kit['detected']}")
    
    def test_safe_browsing_structure_when_no_api_key(self):
        """Verify safe_browsing is null or has error when no API key configured"""
        response = requests.post(f"{BASE_URL}/api/analyze", json={"url": "google.com"}, timeout=60)
        assert response.status_code == 200
        data = response.json()
        
        sb = data.get("safe_browsing")
        
        # Without API key, safe_browsing should be null (format_safe_browsing_result returns None)
        # This is the expected behavior per the code
        if sb is None:
            print("PASS: safe_browsing is null when no API key (expected behavior)")
        else:
            # If somehow an API key is present, verify structure
            assert "checked" in sb, "safe_browsing should have 'checked' field"
            print(f"PASS: safe_browsing has structure - checked={sb.get('checked')}")
    
    def test_analysis_includes_all_score_components(self):
        """Verify analysis includes all score components including new ones"""
        response = requests.post(f"{BASE_URL}/api/analyze", json={"url": "google.com"}, timeout=60)
        assert response.status_code == 200
        data = response.json()
        
        # All score components should be present
        assert "ml_score" in data, "ml_score missing"
        assert "rules_score" in data, "rules_score missing"
        assert "network_score" in data, "network_score missing"
        assert "content_score" in data, "content_score missing"
        assert "final_score" in data, "final_score missing"
        
        # Verify scores are numeric
        assert isinstance(data["ml_score"], (int, float)), "ml_score should be numeric"
        assert isinstance(data["rules_score"], (int, float)), "rules_score should be numeric"
        assert isinstance(data["network_score"], (int, float)), "network_score should be numeric"
        assert isinstance(data["content_score"], (int, float)), "content_score should be numeric"
        assert isinstance(data["final_score"], (int, float)), "final_score should be numeric"
        
        print(f"PASS: All score components present - ml={data['ml_score']}, rules={data['rules_score']}, network={data['network_score']}, content={data['content_score']}, final={data['final_score']}")


class TestPhaseBIntegration:
    """Integration tests for Phase B features with existing functionality"""
    
    def test_authenticated_analysis_includes_phase_b_fields(self):
        """Verify authenticated analysis includes safe_browsing and phishing_kit"""
        # First login
        login_response = requests.post(f"{BASE_URL}/api/auth/login", json={
            "email": "demo@test.com",
            "password": "demo123"
        })
        
        if login_response.status_code != 200:
            pytest.skip("Demo user not available for authenticated test")
        
        token = login_response.json().get("token")
        headers = {"Authorization": f"Bearer {token}"}
        
        # Analyze with auth
        response = requests.post(f"{BASE_URL}/api/analyze", json={"url": "google.com"}, headers=headers, timeout=60)
        assert response.status_code == 200
        data = response.json()
        
        # Phase B fields should be present
        assert "safe_browsing" in data, "safe_browsing missing in authenticated analysis"
        assert "phishing_kit" in data, "phishing_kit missing in authenticated analysis"
        
        # User-specific fields should also be present
        assert "user_xp" in data or "user_id" in data, "User fields missing in authenticated analysis"
        
        print("PASS: Authenticated analysis includes Phase B fields")
    
    def test_multiple_urls_have_consistent_structure(self):
        """Test that multiple different URLs return consistent response structure"""
        urls = ["google.com", "github.com", "example.com"]
        
        for url in urls:
            response = requests.post(f"{BASE_URL}/api/analyze", json={"url": url}, timeout=60)
            assert response.status_code == 200
            data = response.json()
            
            # All should have Phase B fields
            assert "safe_browsing" in data, f"safe_browsing missing for {url}"
            assert "phishing_kit" in data, f"phishing_kit missing for {url}"
            
            # phishing_kit should have consistent structure
            kit = data.get("phishing_kit", {})
            assert "detected" in kit, f"phishing_kit.detected missing for {url}"
            assert "kits" in kit, f"phishing_kit.kits missing for {url}"
            assert "structural_findings" in kit, f"phishing_kit.structural_findings missing for {url}"
            
            print(f"  - {url}: risk_level={data['risk_level']}, kit_detected={kit['detected']}")
        
        print("PASS: Multiple URLs have consistent response structure")


class TestPhaseBEdgeCases:
    """Edge case tests for Phase B features"""
    
    def test_url_with_special_characters(self):
        """Test URL with query parameters"""
        response = requests.post(f"{BASE_URL}/api/analyze", json={"url": "https://www.google.com/search?q=test"}, timeout=60)
        assert response.status_code == 200
        data = response.json()
        
        assert "phishing_kit" in data
        assert "safe_browsing" in data
        
        print("PASS: URL with query parameters analyzed correctly")
    
    def test_url_without_protocol(self):
        """Test URL without http/https prefix"""
        response = requests.post(f"{BASE_URL}/api/analyze", json={"url": "google.com"}, timeout=60)
        assert response.status_code == 200
        data = response.json()
        
        assert "phishing_kit" in data
        assert "safe_browsing" in data
        
        print("PASS: URL without protocol analyzed correctly")
    
    def test_url_with_www_prefix(self):
        """Test URL with www prefix"""
        response = requests.post(f"{BASE_URL}/api/analyze", json={"url": "www.google.com"}, timeout=60)
        assert response.status_code == 200
        data = response.json()
        
        assert "phishing_kit" in data
        assert "safe_browsing" in data
        
        print("PASS: URL with www prefix analyzed correctly")


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
