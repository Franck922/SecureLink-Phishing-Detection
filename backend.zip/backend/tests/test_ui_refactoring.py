"""
Test UI Refactoring Features:
1. Homepage accordion with 5 steps
2. Result page verdict text-only (no numerical scores)
3. "Voir les détails de l'analyse" instead of "Mode Expert"
4. Detail sections with human-readable text
5. XP notification (+10 per analysis, +25 for danger)
6. Badge notifications on result page
"""
import pytest
import requests
import os

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL')


class TestAnalyzeEndpointXPAndBadges:
    """Tests for XP and badge integration in analyze endpoint"""
    
    @pytest.fixture(autouse=True)
    def setup(self):
        """Setup - get auth token"""
        login_response = requests.post(f"{BASE_URL}/api/auth/login", json={
            "email": "admin@test.com",
            "password": "admin123"
        })
        if login_response.status_code == 200:
            self.token = login_response.json().get("token")
            self.user_data = login_response.json().get("user", {})
            self.auth_headers = {"Authorization": f"Bearer {self.token}"}
        else:
            pytest.skip("Login failed - cannot test authenticated endpoints")
    
    def test_analyze_returns_user_xp_when_authenticated(self):
        """Analyze endpoint should return user_xp for logged-in users"""
        response = requests.post(f"{BASE_URL}/api/analyze", 
            json={"url": "https://example.com"},
            headers=self.auth_headers
        )
        assert response.status_code == 200
        data = response.json()
        
        # Must return user_xp field
        assert "user_xp" in data, "Response should include user_xp for authenticated user"
        assert isinstance(data["user_xp"], int), "user_xp should be an integer"
        
        # Must return new_badges field (even if empty)
        assert "new_badges" in data, "Response should include new_badges field"
        assert isinstance(data["new_badges"], list), "new_badges should be a list"
    
    def test_analyze_no_xp_for_anonymous(self):
        """Analyze endpoint should NOT return user_xp for anonymous users"""
        response = requests.post(f"{BASE_URL}/api/analyze", 
            json={"url": "https://example.com"}
        )
        assert response.status_code == 200
        data = response.json()
        
        # Should NOT have user_xp field
        assert "user_xp" not in data, "Anonymous user should not get user_xp in response"
    
    def test_analyze_response_has_traffic_light(self):
        """Analyze endpoint should return traffic_light for verdict display"""
        response = requests.post(f"{BASE_URL}/api/analyze", 
            json={"url": "https://google.com"},
            headers=self.auth_headers
        )
        assert response.status_code == 200
        data = response.json()
        
        # Traffic light should be present
        assert "traffic_light" in data, "Response should include traffic_light"
        assert data["traffic_light"] in ["green", "yellow", "red"], f"Invalid traffic_light: {data['traffic_light']}"
    
    def test_analyze_response_has_network_checks(self):
        """Analyze endpoint should return network_checks for detail sections"""
        response = requests.post(f"{BASE_URL}/api/analyze", 
            json={"url": "https://google.com"},
            headers=self.auth_headers
        )
        assert response.status_code == 200
        data = response.json()
        
        # Network checks should be present for detail sections
        assert "network_checks" in data, "Response should include network_checks"
        nc = data["network_checks"]
        
        # Should have ssl, dns sections for Certificate and Domain sections
        assert "ssl" in nc or "dns" in nc, "network_checks should include ssl or dns data"
    
    def test_analyze_response_has_feature_details(self):
        """Analyze endpoint should return feature_details for URL structure section"""
        response = requests.post(f"{BASE_URL}/api/analyze", 
            json={"url": "https://google.com"},
            headers=self.auth_headers
        )
        assert response.status_code == 200
        data = response.json()
        
        # Feature details should be present
        assert "feature_details" in data, "Response should include feature_details"
        fd = data["feature_details"]
        
        # Should have basic URL analysis features
        assert "has_https" in fd, "feature_details should include has_https"


class TestFeedbackEndpoint:
    """Tests for feedback functionality"""
    
    def test_feedback_endpoint_exists(self):
        """Feedback endpoint should accept submissions"""
        # First get an analysis ID
        analyze_resp = requests.post(f"{BASE_URL}/api/analyze", 
            json={"url": "https://test-feedback.com"}
        )
        assert analyze_resp.status_code == 200
        analysis_id = analyze_resp.json().get("id")
        
        # Submit feedback
        response = requests.post(f"{BASE_URL}/api/feedback", json={
            "analysis_id": analysis_id,
            "is_phishing": False
        })
        assert response.status_code == 200
        data = response.json()
        assert "message" in data
        assert "Feedback" in data["message"] or "submitted" in data["message"].lower()


class TestBadgesAndLevels:
    """Tests for gamification data needed by result page"""
    
    def test_badges_endpoint_returns_badge_list(self):
        """Badges endpoint should return list with id, name_fr, name_en"""
        response = requests.get(f"{BASE_URL}/api/gamification/badges")
        assert response.status_code == 200
        data = response.json()
        
        assert "badges" in data
        badges = data["badges"]
        assert len(badges) > 0, "Should have at least one badge"
        
        # Check badge structure for new_badges display
        badge = badges[0]
        assert "id" in badge, "Badge should have id"
        assert "name_fr" in badge, "Badge should have name_fr"
        assert "name_en" in badge, "Badge should have name_en"
    
    def test_first_scan_badge_exists(self):
        """First Scan badge should exist (Premier Scan in French)"""
        response = requests.get(f"{BASE_URL}/api/gamification/badges")
        assert response.status_code == 200
        badges = response.json().get("badges", [])
        
        first_scan_badge = next((b for b in badges if b["id"] == "first_scan"), None)
        assert first_scan_badge is not None, "first_scan badge should exist"
        assert first_scan_badge["name_fr"] == "Premier Scan", "Badge name_fr should be 'Premier Scan'"


class TestXPValues:
    """Tests for XP reward values"""
    
    @pytest.fixture(autouse=True)
    def setup(self):
        """Setup - get auth token"""
        login_response = requests.post(f"{BASE_URL}/api/auth/login", json={
            "email": "admin@test.com",
            "password": "admin123"
        })
        if login_response.status_code == 200:
            self.token = login_response.json().get("token")
            self.initial_xp = login_response.json().get("user", {}).get("xp", 0)
            self.auth_headers = {"Authorization": f"Bearer {self.token}"}
        else:
            pytest.skip("Login failed - cannot test XP values")
    
    def test_analyze_awards_10_xp(self):
        """Analysis should award 10 XP per scan"""
        # Get current XP
        me_response = requests.get(f"{BASE_URL}/api/auth/me", headers=self.auth_headers)
        initial_xp = me_response.json().get("xp", 0)
        
        # Analyze a URL
        requests.post(f"{BASE_URL}/api/analyze", 
            json={"url": "https://xp-test-" + str(initial_xp) + ".com"},
            headers=self.auth_headers
        )
        
        # Check new XP
        me_response2 = requests.get(f"{BASE_URL}/api/auth/me", headers=self.auth_headers)
        new_xp = me_response2.json().get("xp", 0)
        
        # XP should increase by 10
        xp_earned = new_xp - initial_xp
        assert xp_earned >= 10, f"Should award at least 10 XP, got {xp_earned}"


class TestResultPageDataRequirements:
    """Tests ensuring backend returns data needed by ResultPage"""
    
    def test_analyze_returns_all_required_fields(self):
        """Analyze endpoint must return all fields needed by ResultPage"""
        response = requests.post(f"{BASE_URL}/api/analyze", 
            json={"url": "https://complete-test.org"}
        )
        assert response.status_code == 200
        data = response.json()
        
        # Required for verdict display
        assert "traffic_light" in data, "Missing traffic_light"
        assert "risk_level" in data, "Missing risk_level"
        assert "url" in data, "Missing url"
        
        # Required for detail sections (buildDetailSections)
        assert "feature_details" in data, "Missing feature_details"
        assert "network_checks" in data, "Missing network_checks"
        
        # Required for summary (buildSimpleSummary)
        fd = data["feature_details"]
        assert "has_https" in fd, "Missing has_https in feature_details"
    
    def test_google_analysis_shows_domain_age(self):
        """Google.com analysis should show domain age ~28 years"""
        response = requests.post(f"{BASE_URL}/api/analyze", 
            json={"url": "https://google.com"}
        )
        assert response.status_code == 200
        data = response.json()
        
        nc = data.get("network_checks", {})
        whois = nc.get("whois", {})
        
        if whois and whois.get("domain_age_days"):
            age_years = whois["domain_age_days"] / 365
            assert age_years > 20, f"Google domain age should be >20 years, got {age_years}"


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
