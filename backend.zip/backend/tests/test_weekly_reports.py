"""
Test Weekly Reports Feature - Backend API Tests
Tests weekly report generation, listing, and PDF download endpoints.
"""
import pytest
import requests
import os
import json

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', '').rstrip('/')

# Admin credentials from review_request
ADMIN_EMAIL = "metricsadmin@test.com"
ADMIN_PASSWORD = "testpass123"


class TestWeeklyReportsAPI:
    """Weekly reports endpoint tests"""

    @pytest.fixture(autouse=True)
    def setup(self):
        """Setup test session with admin auth"""
        self.session = requests.Session()
        self.session.headers.update({"Content-Type": "application/json"})
        
        # Login as admin
        login_response = self.session.post(
            f"{BASE_URL}/api/auth/login",
            json={"email": ADMIN_EMAIL, "password": ADMIN_PASSWORD}
        )
        assert login_response.status_code == 200, f"Admin login failed: {login_response.text}"
        
        data = login_response.json()
        self.token = data.get("token")
        self.user = data.get("user")
        
        # Verify admin status
        assert self.user.get("is_admin") == True, f"User is not admin: {self.user}"
        
        self.auth_headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.token}"
        }

    # ========== AUTHENTICATION TESTS ==========
    
    def test_list_reports_requires_auth(self):
        """GET /api/admin/reports requires authentication (401)"""
        response = requests.get(f"{BASE_URL}/api/admin/reports")
        assert response.status_code == 401, f"Expected 401, got {response.status_code}"
        print("PASS: GET /api/admin/reports requires auth (401)")

    def test_generate_report_requires_auth(self):
        """POST /api/admin/reports/generate requires authentication (401)"""
        response = requests.post(f"{BASE_URL}/api/admin/reports/generate")
        assert response.status_code == 401, f"Expected 401, got {response.status_code}"
        print("PASS: POST /api/admin/reports/generate requires auth (401)")

    def test_download_report_requires_auth(self):
        """GET /api/admin/reports/{id}/pdf requires authentication (401)"""
        response = requests.get(f"{BASE_URL}/api/admin/reports/test_id/pdf")
        assert response.status_code == 401, f"Expected 401, got {response.status_code}"
        print("PASS: GET /api/admin/reports/{id}/pdf requires auth (401)")

    def test_list_reports_requires_admin(self):
        """GET /api/admin/reports requires admin privileges (403)"""
        # First, create a non-admin user or use existing test user
        # Try registering a new user or login as non-admin
        register_response = requests.post(
            f"{BASE_URL}/api/auth/register",
            json={
                "email": "TEST_weeklyreport_nonadmin@test.com",
                "username": "nonadminuser",
                "password": "testpass123"
            }
        )
        if register_response.status_code == 200:
            non_admin_token = register_response.json().get("token")
        else:
            # User already exists, login instead
            login_response = requests.post(
                f"{BASE_URL}/api/auth/login",
                json={"email": "TEST_weeklyreport_nonadmin@test.com", "password": "testpass123"}
            )
            if login_response.status_code == 200:
                non_admin_token = login_response.json().get("token")
            else:
                pytest.skip("Could not create/login non-admin user")
                return
        
        # Now try accessing admin endpoint with non-admin token
        response = requests.get(
            f"{BASE_URL}/api/admin/reports",
            headers={"Authorization": f"Bearer {non_admin_token}"}
        )
        assert response.status_code == 403, f"Expected 403 for non-admin, got {response.status_code}"
        print("PASS: GET /api/admin/reports requires admin (403)")

    # ========== GENERATE REPORT TESTS ==========

    def test_generate_report_success(self):
        """POST /api/admin/reports/generate creates weekly report with correct stats"""
        response = self.session.post(
            f"{BASE_URL}/api/admin/reports/generate",
            headers=self.auth_headers
        )
        assert response.status_code == 200, f"Report generation failed: {response.text}"
        
        data = response.json()
        
        # Verify response structure
        assert "id" in data, "Response missing 'id'"
        assert "week_start" in data, "Response missing 'week_start'"
        assert "week_end" in data, "Response missing 'week_end'"
        assert "generated_at" in data, "Response missing 'generated_at'"
        assert "stats" in data, "Response missing 'stats'"
        
        # Verify stats structure
        stats = data["stats"]
        expected_stat_keys = ["analyses", "safe", "suspicious", "dangerous", "new_users", "total_users", "feedback", "simulations", "contributions"]
        for key in expected_stat_keys:
            assert key in stats, f"Stats missing key: {key}"
            assert isinstance(stats[key], int), f"Stat '{key}' should be int, got {type(stats[key])}"
        
        # Store report ID for later tests
        self.report_id = data["id"]
        print(f"PASS: POST /api/admin/reports/generate returns valid report structure")
        print(f"  Report ID: {data['id']}")
        print(f"  Week: {data['week_start']} to {data['week_end']}")
        print(f"  Stats: analyses={stats['analyses']}, safe={stats['safe']}, suspicious={stats['suspicious']}, dangerous={stats['dangerous']}, new_users={stats['new_users']}")
        return data

    # ========== LIST REPORTS TESTS ==========

    def test_list_reports_success(self):
        """GET /api/admin/reports returns list of reports (without pdf_base64)"""
        # First generate a report to ensure there's at least one
        gen_response = self.session.post(
            f"{BASE_URL}/api/admin/reports/generate",
            headers=self.auth_headers
        )
        assert gen_response.status_code == 200, f"Failed to generate report: {gen_response.text}"
        
        # Now list reports
        response = self.session.get(
            f"{BASE_URL}/api/admin/reports",
            headers=self.auth_headers
        )
        assert response.status_code == 200, f"List reports failed: {response.text}"
        
        data = response.json()
        assert "reports" in data, "Response missing 'reports' key"
        assert isinstance(data["reports"], list), "Reports should be a list"
        assert len(data["reports"]) >= 1, "Should have at least 1 report"
        
        # Verify report structure (and that pdf_base64 is NOT included)
        report = data["reports"][0]
        assert "id" in report, "Report missing 'id'"
        assert "week_start" in report, "Report missing 'week_start'"
        assert "week_end" in report, "Report missing 'week_end'"
        assert "generated_at" in report, "Report missing 'generated_at'"
        assert "stats" in report, "Report missing 'stats'"
        assert "pdf_base64" not in report, "pdf_base64 should NOT be included in list response"
        
        print(f"PASS: GET /api/admin/reports returns {len(data['reports'])} reports (pdf_base64 excluded)")
        return data

    def test_list_reports_stats_structure(self):
        """GET /api/admin/reports returns reports with proper stats structure"""
        response = self.session.get(
            f"{BASE_URL}/api/admin/reports",
            headers=self.auth_headers
        )
        assert response.status_code == 200
        
        data = response.json()
        if len(data["reports"]) > 0:
            report = data["reports"][0]
            stats = report.get("stats", {})
            
            # Verify key stat fields exist
            assert "analyses" in stats
            assert "new_users" in stats
            assert "dangerous" in stats
            
            print(f"PASS: Report stats structure correct: analyses={stats.get('analyses')}, new_users={stats.get('new_users')}, dangerous={stats.get('dangerous')}")
        else:
            pytest.skip("No reports available to verify stats structure")

    # ========== DOWNLOAD PDF TESTS ==========

    def test_download_report_pdf_success(self):
        """GET /api/admin/reports/{report_id}/pdf returns PDF binary"""
        # First, get list of reports to find a valid report_id
        list_response = self.session.get(
            f"{BASE_URL}/api/admin/reports",
            headers=self.auth_headers
        )
        assert list_response.status_code == 200
        
        reports = list_response.json().get("reports", [])
        if len(reports) == 0:
            # Generate a report first
            gen_response = self.session.post(
                f"{BASE_URL}/api/admin/reports/generate",
                headers=self.auth_headers
            )
            assert gen_response.status_code == 200
            report_id = gen_response.json()["id"]
        else:
            report_id = reports[0]["id"]
        
        # Download PDF
        response = self.session.get(
            f"{BASE_URL}/api/admin/reports/{report_id}/pdf",
            headers=self.auth_headers
        )
        assert response.status_code == 200, f"PDF download failed: {response.text}"
        
        # Verify it's a PDF
        assert response.headers.get("content-type") == "application/pdf", f"Expected PDF content-type, got {response.headers.get('content-type')}"
        assert "attachment" in response.headers.get("content-disposition", ""), "Should have attachment disposition"
        
        # Verify PDF magic bytes (PDF starts with %PDF-)
        content = response.content
        assert content[:4] == b'%PDF', f"Content doesn't start with PDF magic bytes, got {content[:20]}"
        assert len(content) > 1000, f"PDF content too small: {len(content)} bytes"
        
        print(f"PASS: GET /api/admin/reports/{report_id}/pdf returns valid PDF ({len(content)} bytes)")

    def test_download_report_pdf_not_found(self):
        """GET /api/admin/reports/{invalid_id}/pdf returns 404"""
        response = self.session.get(
            f"{BASE_URL}/api/admin/reports/invalid_report_id_12345/pdf",
            headers=self.auth_headers
        )
        assert response.status_code == 404, f"Expected 404, got {response.status_code}"
        print("PASS: GET /api/admin/reports/{invalid_id}/pdf returns 404")


class TestExtensionFiles:
    """Verify Chrome extension file structure"""

    def test_manifest_exists_and_valid(self):
        """manifest.json exists and has correct manifest_version 3"""
        manifest_path = "/app/extension/manifest.json"
        assert os.path.exists(manifest_path), "manifest.json not found"
        
        with open(manifest_path, 'r') as f:
            manifest = json.load(f)
        
        # Required fields for manifest v3
        assert manifest.get("manifest_version") == 3, f"Expected manifest_version 3, got {manifest.get('manifest_version')}"
        assert "name" in manifest, "manifest missing 'name'"
        assert "version" in manifest, "manifest missing 'version'"
        assert "permissions" in manifest, "manifest missing 'permissions'"
        assert "action" in manifest, "manifest missing 'action' (required for popup)"
        assert "icons" in manifest, "manifest missing 'icons'"
        
        # Verify icons
        icons = manifest.get("icons", {})
        assert "16" in icons, "manifest missing 16px icon"
        assert "48" in icons, "manifest missing 48px icon"
        assert "128" in icons, "manifest missing 128px icon"
        
        print(f"PASS: manifest.json valid (v{manifest.get('manifest_version')}, name='{manifest.get('name')}')")

    def test_popup_files_exist(self):
        """popup.html, popup.js, popup.css exist"""
        files = ["popup.html", "popup.js", "popup.css"]
        for f in files:
            path = f"/app/extension/{f}"
            assert os.path.exists(path), f"{f} not found"
            assert os.path.getsize(path) > 0, f"{f} is empty"
        
        print("PASS: popup.html, popup.js, popup.css all exist and non-empty")

    def test_background_script_exists(self):
        """background.js exists"""
        path = "/app/extension/background.js"
        assert os.path.exists(path), "background.js not found"
        assert os.path.getsize(path) > 0, "background.js is empty"
        
        print("PASS: background.js exists")

    def test_icon_files_exist(self):
        """Icons exist at /app/extension/icons/ (icon16, icon48, icon128)"""
        icons_dir = "/app/extension/icons"
        assert os.path.isdir(icons_dir), "icons/ directory not found"
        
        required_icons = ["icon16.png", "icon48.png", "icon128.png"]
        for icon in required_icons:
            path = f"{icons_dir}/{icon}"
            assert os.path.exists(path), f"{icon} not found"
            assert os.path.getsize(path) > 0, f"{icon} is empty"
        
        print("PASS: icon16.png, icon48.png, icon128.png all exist")


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
