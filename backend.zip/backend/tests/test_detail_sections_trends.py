"""
Test suite for SecureLink detail sections (20 features) and trend alerts (7 alerts)
Tests the features requested in iteration 12:
1. Result page details covering ALL backend rules (20 features + 15 rules)
2. Educational tips in detail items
3. News/Veille page trend alerts for everyday office users
"""
import pytest
import requests
import os

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', '').rstrip('/')


class TestAnalyzeEndpoint:
    """Test URL analysis endpoint returning all feature details"""
    
    def test_analyze_google_returns_feature_details(self):
        """Test that google.com analysis returns all 20 feature_details"""
        response = requests.post(f"{BASE_URL}/api/analyze", json={"url": "google.com"})
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        
        data = response.json()
        feature_details = data.get("feature_details", {})
        
        # Verify all 20 features are returned
        expected_features = [
            'url_length', 'domain_length', 'has_https', 'num_dots', 'num_hyphens',
            'has_at', 'digits_in_domain', 'has_ip', 'suspicious_tld', 'domain_entropy',
            'path_length', 'query_length', 'has_port', 'subdomain_count', 'special_chars',
            'has_redirect', 'shortened_url', 'num_slashes', 'digits_in_path', 'suspicious_keywords'
        ]
        
        for feature in expected_features:
            assert feature in feature_details, f"Missing feature: {feature}"
        
        print(f"✅ All 20 features returned: {list(feature_details.keys())}")
    
    def test_google_safe_verdict(self):
        """Test google.com returns safe/green verdict"""
        response = requests.post(f"{BASE_URL}/api/analyze", json={"url": "google.com"})
        assert response.status_code == 200
        
        data = response.json()
        assert data.get("traffic_light") == "green", f"Expected green, got {data.get('traffic_light')}"
        assert data.get("risk_level") == "SAFE", f"Expected SAFE, got {data.get('risk_level')}"
        print(f"✅ google.com verdict: {data.get('traffic_light')} / {data.get('risk_level')}")
    
    def test_microsoft_login_suspicious_keywords(self):
        """Test microsoft.com/account/login triggers suspicious_keywords feature"""
        response = requests.post(f"{BASE_URL}/api/analyze", json={"url": "microsoft.com/account/login"})
        assert response.status_code == 200
        
        data = response.json()
        feature_details = data.get("feature_details", {})
        
        # Should have suspicious_keywords = 1 due to 'login' and 'account'
        assert feature_details.get("suspicious_keywords") == 1, \
            f"Expected suspicious_keywords=1, got {feature_details.get('suspicious_keywords')}"
        
        # Should be yellow/SUSPICIOUS due to suspicious keywords
        assert data.get("traffic_light") in ["yellow", "green"], \
            f"Expected yellow or green, got {data.get('traffic_light')}"
        
        print(f"✅ microsoft.com/account/login: suspicious_keywords={feature_details.get('suspicious_keywords')}")
    
    def test_network_checks_returned(self):
        """Test that network_checks are returned with dns, ssl, whois, rdns"""
        response = requests.post(f"{BASE_URL}/api/analyze", json={"url": "google.com"})
        assert response.status_code == 200
        
        data = response.json()
        network_checks = data.get("network_checks", {})
        
        # Should have dns, ssl, whois, rdns checks
        expected_checks = ["dns", "ssl", "whois", "rdns"]
        for check in expected_checks:
            assert check in network_checks, f"Missing network check: {check}"
        
        print(f"✅ Network checks returned: {list(network_checks.keys())}")
    
    def test_triggered_rules_include_tips(self):
        """Test that triggered rules include tip fields for educational content"""
        response = requests.post(f"{BASE_URL}/api/analyze", json={"url": "microsoft.com/account/login"})
        assert response.status_code == 200
        
        data = response.json()
        triggered_rules = data.get("triggered_rules", [])
        
        # Check that rules have tip_fr and tip_en fields
        for rule in triggered_rules:
            if rule.get("points", 0) > 0:  # Only positive (risky) rules should have tips
                assert "tip_fr" in rule, f"Rule {rule.get('id')} missing tip_fr"
                assert "tip_en" in rule, f"Rule {rule.get('id')} missing tip_en"
        
        print(f"✅ Triggered rules with tips: {[r['id'] for r in triggered_rules]}")


class TestNewsEndpoint:
    """Test /api/news endpoint for trend alerts"""
    
    def test_news_returns_7_trend_alerts(self):
        """Test that /api/news returns exactly 7 trend alerts"""
        response = requests.get(f"{BASE_URL}/api/news")
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        
        data = response.json()
        trends = data.get("trends", [])
        
        assert len(trends) == 7, f"Expected 7 trends, got {len(trends)}"
        print(f"✅ /api/news returns {len(trends)} trend alerts")
    
    def test_trend_alerts_have_required_fields(self):
        """Test that each trend alert has required fields"""
        response = requests.get(f"{BASE_URL}/api/news")
        assert response.status_code == 200
        
        data = response.json()
        trends = data.get("trends", [])
        
        required_fields = ["id", "title_fr", "title_en", "description_fr", "description_en", 
                          "severity", "category", "level", "date"]
        
        for trend in trends:
            for field in required_fields:
                assert field in trend, f"Trend {trend.get('id')} missing field: {field}"
        
        print(f"✅ All trend alerts have required fields")
    
    def test_trend_alerts_are_novice_level(self):
        """Test that all trend alerts are targeted at novice (everyday office) users"""
        response = requests.get(f"{BASE_URL}/api/news")
        assert response.status_code == 200
        
        data = response.json()
        trends = data.get("trends", [])
        
        for trend in trends:
            assert trend.get("level") == "novice", \
                f"Trend {trend.get('id')} should be novice level, got {trend.get('level')}"
        
        print(f"✅ All 7 trend alerts are novice level")
    
    def test_trend_alerts_cover_office_user_topics(self):
        """Test that trend alerts cover topics relevant to everyday office users"""
        response = requests.get(f"{BASE_URL}/api/news")
        assert response.status_code == 200
        
        data = response.json()
        trends = data.get("trends", [])
        
        # Expected topics for office/desktop users
        expected_topics = {
            "fake_delivery": ["Colissimo", "Chronopost", "livraison"],
            "fake_refund": ["Assurance Maladie", "Impôts", "remboursement"],
            "fake_invoice": ["facture", "paiement"],
            "fake_support": ["support Microsoft", "infecté", "ordinateur"],
            "fake_bank": ["banque", "identité"],
            "qr_scam": ["QR code", "contravention"],
            "password_scam": ["mot de passe", "compromis"]
        }
        
        all_text = " ".join([t.get("title_fr", "") + " " + t.get("description_fr", "") for t in trends])
        
        topics_found = []
        for topic_name, keywords in expected_topics.items():
            for keyword in keywords:
                if keyword.lower() in all_text.lower():
                    topics_found.append(topic_name)
                    break
        
        assert len(set(topics_found)) == 7, f"Expected 7 topics, found {len(set(topics_found))}: {set(topics_found)}"
        print(f"✅ All 7 office user topics covered: {set(topics_found)}")
    
    def test_trend_alerts_have_practical_advice(self):
        """Test that trend alerts include practical advice for non-technical users"""
        response = requests.get(f"{BASE_URL}/api/news")
        assert response.status_code == 200
        
        data = response.json()
        trends = data.get("trends", [])
        
        # Practical advice keywords that should appear in descriptions
        advice_keywords = [
            "Ne cliquez pas",      # Don't click
            "C'est une arnaque",   # It's a scam  
            "Fermez",              # Close
            "Allez directement",   # Go directly
            "Vérifiez",            # Verify
            "Ne scannez",          # Don't scan
            "En cas de doute"      # When in doubt
        ]
        
        all_descriptions = " ".join([t.get("description_fr", "") for t in trends])
        
        found_advice = []
        for advice in advice_keywords:
            if advice.lower() in all_descriptions.lower():
                found_advice.append(advice)
        
        # At least 5 practical advice phrases should appear
        assert len(found_advice) >= 5, f"Expected at least 5 advice phrases, found {len(found_advice)}: {found_advice}"
        print(f"✅ Practical advice found: {found_advice}")
    
    def test_trend_alerts_severity_distribution(self):
        """Test that trend alerts have appropriate severity levels"""
        response = requests.get(f"{BASE_URL}/api/news")
        assert response.status_code == 200
        
        data = response.json()
        trends = data.get("trends", [])
        
        high_count = sum(1 for t in trends if t.get("severity") == "high")
        medium_count = sum(1 for t in trends if t.get("severity") == "medium")
        
        assert high_count >= 4, f"Expected at least 4 high severity alerts, got {high_count}"
        assert medium_count >= 3, f"Expected at least 3 medium severity alerts, got {medium_count}"
        
        print(f"✅ Severity distribution: {high_count} high, {medium_count} medium")
    
    def test_trend_alerts_category_distribution(self):
        """Test that trend alerts cover various attack categories"""
        response = requests.get(f"{BASE_URL}/api/news")
        assert response.status_code == 200
        
        data = response.json()
        trends = data.get("trends", [])
        
        categories = set(t.get("category") for t in trends)
        
        # Should cover multiple attack types
        expected_categories = {"phishing", "smishing", "vishing", "quishing"}
        found_categories = categories & expected_categories
        
        assert len(found_categories) >= 3, f"Expected at least 3 categories, got {len(found_categories)}: {found_categories}"
        print(f"✅ Attack categories covered: {categories}")


class TestTrendsEndpoint:
    """Test /api/trends endpoint specifically"""
    
    def test_trends_endpoint_returns_alerts(self):
        """Test that /api/trends endpoint returns trend alerts"""
        response = requests.get(f"{BASE_URL}/api/trends")
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        
        data = response.json()
        trends = data.get("trends", [])
        
        assert len(trends) == 7, f"Expected 7 trends from /api/trends, got {len(trends)}"
        print(f"✅ /api/trends returns {len(trends)} alerts")


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
