"""
SecureLink New Features Test Suite
Tests for: Simulation, Notifications, Export APIs (Iteration 5)

Features tested:
- Phishing simulation mode (GET /api/simulation/scenarios, POST /api/simulation/answer)
- Notification system (GET /api/notifications, POST /api/notifications/read)
- User export (GET /api/export/analyses/csv, GET /api/export/analyses/pdf)
- Admin export (GET /api/admin/export/analyses/csv, GET /api/admin/export/users/csv, GET /api/admin/export/report/pdf)
"""
import pytest
import requests
import os
import time

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', 'http://localhost:8001')

# Test credentials
TEST_USER = {
    "username": "testuser_sim",
    "email": "testsim@test.com",
    "password": "testpassword123"
}

ADMIN_EMAIL = TEST_USER["email"]


class TestApiHealth:
    """Basic API health check"""
    
    def test_api_root(self):
        """Test API root endpoint is accessible"""
        response = requests.get(f"{BASE_URL}/api/")
        assert response.status_code == 200
        data = response.json()
        assert "message" in data
        assert "status" in data
        print(f"✓ API root accessible: {data.get('status')}")


class TestSimulationScenarios:
    """Tests for GET /api/simulation/scenarios"""
    
    def test_get_scenarios_default(self):
        """Test fetching default 5 scenarios"""
        response = requests.get(f"{BASE_URL}/api/simulation/scenarios")
        assert response.status_code == 200
        data = response.json()
        assert "scenarios" in data
        scenarios = data["scenarios"]
        assert isinstance(scenarios, list)
        assert len(scenarios) <= 5
        print(f"✓ Default scenarios returned: {len(scenarios)}")
        
        # Verify scenario structure
        if scenarios:
            s = scenarios[0]
            assert "id" in s
            assert "is_phishing" in s
            assert "difficulty" in s
            assert "sender_name" in s
            assert "sender_email" in s
            assert "subject_fr" in s
            assert "subject_en" in s
            assert "body_fr" in s
            assert "body_en" in s
            # Indicators should NOT be in response (revealed after answering)
            assert "indicators_fr" not in s
            assert "indicators_en" not in s
            print(f"✓ Scenario structure valid: id={s['id']}, difficulty={s['difficulty']}")
    
    def test_get_scenarios_with_count(self):
        """Test fetching specific number of scenarios"""
        response = requests.get(f"{BASE_URL}/api/simulation/scenarios?count=3")
        assert response.status_code == 200
        data = response.json()
        assert len(data["scenarios"]) <= 3
        print(f"✓ Count parameter works: got {len(data['scenarios'])} scenarios")
    
    def test_get_scenarios_with_difficulty_filter(self):
        """Test filtering scenarios by difficulty"""
        for difficulty in [1, 2, 3]:
            response = requests.get(f"{BASE_URL}/api/simulation/scenarios?count=5&difficulty={difficulty}")
            assert response.status_code == 200
            data = response.json()
            scenarios = data["scenarios"]
            # Check all returned scenarios match difficulty (or fallback to all if none available)
            for s in scenarios:
                assert s["difficulty"] == difficulty or len([sc for sc in scenarios if sc["difficulty"] == difficulty]) == 0
            print(f"✓ Difficulty filter {difficulty} works: {len(scenarios)} scenarios")


class TestSimulationAnswers:
    """Tests for POST /api/simulation/answer"""
    
    @pytest.fixture(autouse=True)
    def setup(self):
        """Get a scenario ID for testing"""
        response = requests.get(f"{BASE_URL}/api/simulation/scenarios?count=1")
        if response.status_code == 200 and response.json().get("scenarios"):
            self.scenario = response.json()["scenarios"][0]
        else:
            self.scenario = None
    
    def test_answer_scenario_anonymous(self):
        """Test answering a scenario without auth"""
        if not self.scenario:
            pytest.skip("No scenario available")
        
        response = requests.post(f"{BASE_URL}/api/simulation/answer", json={
            "scenario_id": self.scenario["id"],
            "user_answer": True  # Guessing it's phishing
        })
        assert response.status_code == 200
        data = response.json()
        assert "correct" in data
        assert "is_phishing" in data
        assert "indicators_fr" in data
        assert "indicators_en" in data
        assert isinstance(data["indicators_fr"], list)
        assert isinstance(data["indicators_en"], list)
        print(f"✓ Anonymous answer submitted: correct={data['correct']}, is_phishing={data['is_phishing']}")
        print(f"✓ Indicators revealed: {len(data['indicators_fr'])} FR, {len(data['indicators_en'])} EN")
    
    def test_answer_scenario_invalid_id(self):
        """Test answering with invalid scenario ID"""
        response = requests.post(f"{BASE_URL}/api/simulation/answer", json={
            "scenario_id": "invalid_id_12345",
            "user_answer": True
        })
        assert response.status_code == 404
        print("✓ Invalid scenario ID returns 404")


class TestAuthentication:
    """Test user authentication for protected features"""
    
    @pytest.fixture(scope="class")
    def auth_token(self):
        """Register or login test user and return token"""
        # Try to register first
        register_response = requests.post(f"{BASE_URL}/api/auth/register", json=TEST_USER)
        if register_response.status_code == 200:
            print(f"✓ Registered new user: {TEST_USER['email']}")
            return register_response.json()["token"]
        elif register_response.status_code == 400:  # Already exists
            # Login instead
            login_response = requests.post(f"{BASE_URL}/api/auth/login", json={
                "email": TEST_USER["email"],
                "password": TEST_USER["password"]
            })
            assert login_response.status_code == 200, f"Login failed: {login_response.text}"
            print(f"✓ Logged in existing user: {TEST_USER['email']}")
            return login_response.json()["token"]
        else:
            pytest.fail(f"Auth failed: {register_response.text}")
    
    def test_auth_token_valid(self, auth_token):
        """Verify auth token is valid"""
        response = requests.get(f"{BASE_URL}/api/auth/me", headers={
            "Authorization": f"Bearer {auth_token}"
        })
        assert response.status_code == 200
        data = response.json()
        assert data["email"] == TEST_USER["email"]
        print(f"✓ Auth token valid for user: {data['username']}")


class TestNotifications:
    """Tests for notification endpoints"""
    
    def test_get_notifications_anonymous(self):
        """Test fetching notifications without auth"""
        response = requests.get(f"{BASE_URL}/api/notifications")
        assert response.status_code == 200
        data = response.json()
        assert "notifications" in data
        assert "unread_count" in data
        notifications = data["notifications"]
        assert isinstance(notifications, list)
        print(f"✓ Notifications fetched (anonymous): {len(notifications)} alerts, {data['unread_count']} unread")
        
        # Verify notification structure
        if notifications:
            n = notifications[0]
            assert "id" in n
            assert "type" in n
            assert "title_fr" in n
            assert "title_en" in n
            assert "description_fr" in n
            assert "description_en" in n
            assert "severity" in n
            assert "read" in n
            print(f"✓ Notification structure valid: {n['id']}, severity={n['severity']}")
    
    def test_get_notifications_authenticated(self):
        """Test fetching notifications with auth (for read tracking)"""
        # Get token
        login_response = requests.post(f"{BASE_URL}/api/auth/login", json={
            "email": TEST_USER["email"],
            "password": TEST_USER["password"]
        })
        if login_response.status_code != 200:
            # Register
            reg_response = requests.post(f"{BASE_URL}/api/auth/register", json=TEST_USER)
            token = reg_response.json()["token"]
        else:
            token = login_response.json()["token"]
        
        response = requests.get(f"{BASE_URL}/api/notifications", headers={
            "Authorization": f"Bearer {token}"
        })
        assert response.status_code == 200
        data = response.json()
        assert "unread_count" in data
        print(f"✓ Notifications fetched (auth): {data['unread_count']} unread")
    
    def test_mark_notifications_read(self):
        """Test marking notifications as read"""
        # Get token
        login_response = requests.post(f"{BASE_URL}/api/auth/login", json={
            "email": TEST_USER["email"],
            "password": TEST_USER["password"]
        })
        if login_response.status_code != 200:
            reg_response = requests.post(f"{BASE_URL}/api/auth/register", json=TEST_USER)
            token = reg_response.json()["token"]
        else:
            token = login_response.json()["token"]
        
        # Mark all as read
        response = requests.post(f"{BASE_URL}/api/notifications/read", 
            json={"notification_ids": []},  # Empty = mark all
            headers={"Authorization": f"Bearer {token}"}
        )
        assert response.status_code == 200
        data = response.json()
        assert "message" in data
        print(f"✓ Notifications marked as read: {data['message']}")
        
        # Verify unread count is now 0
        notif_response = requests.get(f"{BASE_URL}/api/notifications", headers={
            "Authorization": f"Bearer {token}"
        })
        assert notif_response.status_code == 200
        assert notif_response.json()["unread_count"] == 0
        print("✓ Unread count is now 0 after marking read")
    
    def test_mark_notifications_read_unauthorized(self):
        """Test marking notifications without auth fails"""
        response = requests.post(f"{BASE_URL}/api/notifications/read", 
            json={"notification_ids": []}
        )
        assert response.status_code == 401
        print("✓ Mark notifications read requires auth (401)")


class TestUserExport:
    """Tests for user export endpoints (auth required)"""
    
    @pytest.fixture(scope="class")
    def auth_token(self):
        """Get auth token"""
        login_response = requests.post(f"{BASE_URL}/api/auth/login", json={
            "email": TEST_USER["email"],
            "password": TEST_USER["password"]
        })
        if login_response.status_code != 200:
            reg_response = requests.post(f"{BASE_URL}/api/auth/register", json=TEST_USER)
            return reg_response.json()["token"]
        return login_response.json()["token"]
    
    def test_export_csv_unauthorized(self):
        """Test CSV export without auth fails"""
        response = requests.get(f"{BASE_URL}/api/export/analyses/csv")
        assert response.status_code == 401
        print("✓ CSV export requires auth (401)")
    
    def test_export_pdf_unauthorized(self):
        """Test PDF export without auth fails"""
        response = requests.get(f"{BASE_URL}/api/export/analyses/pdf")
        assert response.status_code == 401
        print("✓ PDF export requires auth (401)")
    
    def test_export_csv_authorized(self, auth_token):
        """Test CSV export with auth succeeds"""
        response = requests.get(f"{BASE_URL}/api/export/analyses/csv", headers={
            "Authorization": f"Bearer {auth_token}"
        })
        assert response.status_code == 200
        assert "text/csv" in response.headers.get("content-type", "")
        content = response.text
        # Check CSV has headers
        assert "URL" in content or "Niveau de risque" in content or "Risk Level" in content
        print(f"✓ CSV export successful: {len(content)} bytes")
    
    def test_export_pdf_authorized(self, auth_token):
        """Test PDF export with auth succeeds"""
        response = requests.get(f"{BASE_URL}/api/export/analyses/pdf", headers={
            "Authorization": f"Bearer {auth_token}"
        })
        assert response.status_code == 200
        assert "application/pdf" in response.headers.get("content-type", "")
        assert len(response.content) > 100  # PDF should have content
        # Check PDF magic bytes
        assert response.content[:4] == b'%PDF'
        print(f"✓ PDF export successful: {len(response.content)} bytes")


class TestAdminExport:
    """Tests for admin export endpoints"""
    
    @pytest.fixture(scope="class")
    def admin_token(self):
        """Get admin auth token"""
        # Login/register
        login_response = requests.post(f"{BASE_URL}/api/auth/login", json={
            "email": TEST_USER["email"],
            "password": TEST_USER["password"]
        })
        if login_response.status_code != 200:
            reg_response = requests.post(f"{BASE_URL}/api/auth/register", json=TEST_USER)
            token = reg_response.json()["token"]
        else:
            token = login_response.json()["token"]
        
        # Promote to admin
        requests.post(f"{BASE_URL}/api/admin/promote", json={"email": TEST_USER["email"]})
        return token
    
    def test_admin_export_analyses_csv_unauthorized(self):
        """Test admin CSV export without admin fails"""
        response = requests.get(f"{BASE_URL}/api/admin/export/analyses/csv")
        assert response.status_code == 401
        print("✓ Admin analyses CSV requires auth (401)")
    
    def test_admin_export_users_csv_unauthorized(self):
        """Test admin users CSV export without admin fails"""
        response = requests.get(f"{BASE_URL}/api/admin/export/users/csv")
        assert response.status_code == 401
        print("✓ Admin users CSV requires auth (401)")
    
    def test_admin_export_report_pdf_unauthorized(self):
        """Test admin report PDF without admin fails"""
        response = requests.get(f"{BASE_URL}/api/admin/export/report/pdf")
        assert response.status_code == 401
        print("✓ Admin report PDF requires auth (401)")
    
    def test_admin_export_analyses_csv(self, admin_token):
        """Test admin analyses CSV export"""
        response = requests.get(f"{BASE_URL}/api/admin/export/analyses/csv", headers={
            "Authorization": f"Bearer {admin_token}"
        })
        assert response.status_code == 200
        assert "text/csv" in response.headers.get("content-type", "")
        print(f"✓ Admin analyses CSV export: {len(response.text)} bytes")
    
    def test_admin_export_users_csv(self, admin_token):
        """Test admin users CSV export"""
        response = requests.get(f"{BASE_URL}/api/admin/export/users/csv", headers={
            "Authorization": f"Bearer {admin_token}"
        })
        assert response.status_code == 200
        assert "text/csv" in response.headers.get("content-type", "")
        content = response.text
        # Should have user headers
        assert "Username" in content or "Utilisateur" in content or "Email" in content
        print(f"✓ Admin users CSV export: {len(content)} bytes")
    
    def test_admin_export_report_pdf(self, admin_token):
        """Test admin report PDF export"""
        response = requests.get(f"{BASE_URL}/api/admin/export/report/pdf", headers={
            "Authorization": f"Bearer {admin_token}"
        })
        assert response.status_code == 200
        assert "application/pdf" in response.headers.get("content-type", "")
        assert response.content[:4] == b'%PDF'
        print(f"✓ Admin report PDF export: {len(response.content)} bytes")


class TestSimulationWithAuth:
    """Tests for simulation with authenticated user (XP tracking)"""
    
    @pytest.fixture(scope="class")
    def auth_token(self):
        """Get auth token"""
        login_response = requests.post(f"{BASE_URL}/api/auth/login", json={
            "email": TEST_USER["email"],
            "password": TEST_USER["password"]
        })
        if login_response.status_code != 200:
            reg_response = requests.post(f"{BASE_URL}/api/auth/register", json=TEST_USER)
            return reg_response.json()["token"]
        return login_response.json()["token"]
    
    def test_answer_with_auth_earns_xp(self, auth_token):
        """Test answering correctly earns XP"""
        # Get a scenario
        scenarios_response = requests.get(f"{BASE_URL}/api/simulation/scenarios?count=1")
        scenario = scenarios_response.json()["scenarios"][0]
        
        # Submit answer (we'll try both to ensure one is correct)
        response = requests.post(f"{BASE_URL}/api/simulation/answer", 
            json={
                "scenario_id": scenario["id"],
                "user_answer": scenario["is_phishing"]  # We know the correct answer
            },
            headers={"Authorization": f"Bearer {auth_token}"}
        )
        assert response.status_code == 200
        data = response.json()
        assert data["correct"] == True
        # XP should be awarded for correct answer
        if "xp_earned" in data:
            assert data["xp_earned"] > 0
            print(f"✓ Correct answer earned XP: {data['xp_earned']}")
        else:
            print("✓ Answer submitted correctly (XP tracking works)")
    
    def test_simulation_stats(self, auth_token):
        """Test getting simulation stats"""
        response = requests.get(f"{BASE_URL}/api/simulation/stats", headers={
            "Authorization": f"Bearer {auth_token}"
        })
        assert response.status_code == 200
        data = response.json()
        assert "total_attempts" in data
        assert "correct_answers" in data
        assert "accuracy" in data
        assert "recent_results" in data
        print(f"✓ Simulation stats: {data['total_attempts']} attempts, {data['accuracy']}% accuracy")
    
    def test_simulation_stats_unauthorized(self):
        """Test simulation stats requires auth"""
        response = requests.get(f"{BASE_URL}/api/simulation/stats")
        assert response.status_code == 401
        print("✓ Simulation stats requires auth (401)")


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
