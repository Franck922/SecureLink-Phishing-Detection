"""
Backend tests for UX Refactoring features:
- E-Learning rename (Académie → E-Learning)
- French accents verification
- Level filter on News/Veille page
- Feedback endpoint
"""
import pytest
import requests
import os

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', '').rstrip('/')

class TestNewsAPILevelFilter:
    """Test News API returns articles and trends with level fields"""

    def test_news_api_returns_articles_with_source_level(self):
        """Verify articles have source_level field (novice/expert)"""
        response = requests.get(f"{BASE_URL}/api/news")
        assert response.status_code == 200
        data = response.json()
        
        assert "articles" in data
        articles = data["articles"]
        assert len(articles) > 0, "No articles returned"
        
        # Check first few articles have source_level field
        levels_found = set()
        for article in articles[:10]:
            assert "source_level" in article, f"Article missing source_level: {article.get('title', '')}"
            level = article["source_level"]
            assert level in ["novice", "expert"], f"Invalid source_level: {level}"
            levels_found.add(level)
        
        print(f"✓ Articles have source_level field. Levels found: {levels_found}")

    def test_news_api_returns_trends_with_level(self):
        """Verify trends/alerts have level field (novice/expert)"""
        response = requests.get(f"{BASE_URL}/api/news")
        assert response.status_code == 200
        data = response.json()
        
        assert "trends" in data
        trends = data["trends"]
        assert len(trends) > 0, "No trends returned"
        
        levels_found = set()
        for trend in trends:
            assert "level" in trend, f"Trend missing level: {trend.get('title_fr', '')}"
            level = trend["level"]
            assert level in ["novice", "expert"], f"Invalid trend level: {level}"
            levels_found.add(level)
        
        print(f"✓ Trends have level field. Levels found: {levels_found}")

    def test_news_has_diverse_feeds(self):
        """Verify we have diverse RSS feeds (FR/EN, novice/expert)"""
        response = requests.get(f"{BASE_URL}/api/news")
        assert response.status_code == 200
        data = response.json()
        
        articles = data.get("articles", [])
        
        # Check language diversity
        langs = set(a.get("source_lang") for a in articles)
        print(f"Languages found in articles: {langs}")
        
        # Check level diversity
        levels = set(a.get("source_level") for a in articles)
        print(f"Levels found in articles: {levels}")
        
        # Check source diversity
        sources = set(a.get("source_name") for a in articles)
        print(f"Sources found: {sources}")
        
        assert len(sources) >= 2, "Should have multiple news sources"


class TestTrainingModulesFrenchAccents:
    """Test training modules have proper French accents"""

    def test_modules_have_french_accents(self):
        """Verify training module titles/descriptions have proper accents"""
        response = requests.get(f"{BASE_URL}/api/training/modules")
        assert response.status_code == 200
        data = response.json()
        
        modules = data.get("modules", [])
        assert len(modules) > 0, "No modules returned"
        
        # Check for specific French accents in titles
        accent_checks = {
            "Qu'est-ce que le phishing ?": False,
            "Reconnaître": False,
            "Se protéger": False,
            "avancées": False,
            "Réagir": False,
        }
        
        for module in modules:
            title_fr = module.get("title_fr", "")
            desc_fr = module.get("description_fr", "")
            combined = title_fr + " " + desc_fr
            
            for accent_text in accent_checks.keys():
                if accent_text in combined:
                    accent_checks[accent_text] = True
                    print(f"✓ Found: '{accent_text}' in module")
        
        # Verify key accents are present
        missing = [k for k, v in accent_checks.items() if not v]
        assert len(missing) == 0, f"Missing French accents: {missing}"


class TestFeedbackEndpoint:
    """Test feedback endpoint works end-to-end"""

    def test_feedback_submission_anonymous(self):
        """Test anonymous feedback submission works"""
        # First create an analysis to get an ID
        analyze_response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "https://www.google.com"}
        )
        assert analyze_response.status_code == 200
        analysis_id = analyze_response.json().get("id")
        assert analysis_id, "No analysis_id returned"
        
        # Submit feedback
        feedback_response = requests.post(
            f"{BASE_URL}/api/feedback",
            json={"analysis_id": analysis_id, "is_phishing": False}
        )
        assert feedback_response.status_code == 200
        
        feedback_data = feedback_response.json()
        assert "message" in feedback_data
        assert feedback_data["message"] == "Feedback submitted"
        assert "id" in feedback_data
        print(f"✓ Feedback submitted successfully with ID: {feedback_data['id']}")

    def test_feedback_requires_analysis_id(self):
        """Test feedback endpoint validates input"""
        response = requests.post(
            f"{BASE_URL}/api/feedback",
            json={"is_phishing": True}  # Missing analysis_id
        )
        # Should fail validation - pydantic will reject missing required field
        assert response.status_code in [422, 400]


class TestBadgesAndLevelsFrenchAccents:
    """Test badges and levels have proper French accents"""

    def test_badges_endpoint_has_accents(self):
        """Verify badges have proper French accents"""
        response = requests.get(f"{BASE_URL}/api/gamification/badges")
        assert response.status_code == 200
        data = response.json()
        
        badges = data.get("badges", [])
        assert len(badges) > 0
        
        # Check for accented badge names
        accented_badges = []
        for badge in badges:
            name_fr = badge.get("name_fr", "")
            desc_fr = badge.get("description_fr", "")
            if any(c in name_fr + desc_fr for c in "éèêëàâäùûüôöîïç"):
                accented_badges.append(name_fr)
        
        assert len(accented_badges) > 0, "No accented badge names found"
        print(f"✓ Badges with French accents: {accented_badges}")

    def test_levels_have_accents(self):
        """Verify levels have proper French accents"""
        response = requests.get(f"{BASE_URL}/api/gamification/badges")
        assert response.status_code == 200
        data = response.json()
        
        levels = data.get("levels", [])
        assert len(levels) > 0
        
        # Check for specific accented levels
        expected_accented = ["Débutant", "Légende", "Maître"]
        found = []
        
        for level in levels:
            name_fr = level.get("name_fr", "")
            for expected in expected_accented:
                if expected in name_fr:
                    found.append(expected)
        
        assert len(found) >= 2, f"Missing accented levels. Found: {found}"
        print(f"✓ Found accented level names: {found}")


class TestResourcesPageLink:
    """Test resources page has E-Learning references"""

    def test_resources_endpoint_works(self):
        """Verify resources endpoint returns data"""
        response = requests.get(f"{BASE_URL}/api/resources")
        assert response.status_code == 200
        data = response.json()
        
        resources = data.get("resources", [])
        assert len(resources) > 0, "No resources returned"
        
        # Verify resource structure
        sample = resources[0]
        required_fields = ["id", "title_fr", "title_en", "url", "source"]
        for field in required_fields:
            assert field in sample, f"Missing field: {field}"
        
        print(f"✓ Resources endpoint returns {len(resources)} resources")


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
