"""
Test suite for SecureBot Chat Widget feature
Tests: POST /api/assistant/chat, GET /api/assistant/topics, chat_messages collection
"""
import pytest
import requests
import os
import time

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', '').rstrip('/')

class TestChatbotTopics:
    """Tests for GET /api/assistant/topics endpoint"""
    
    def test_topics_returns_200(self):
        """GET /api/assistant/topics returns 200"""
        response = requests.get(f"{BASE_URL}/api/assistant/topics")
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        print("PASS: GET /api/assistant/topics returns 200")
    
    def test_topics_returns_5_topics(self):
        """GET /api/assistant/topics returns 5 suggested topics"""
        response = requests.get(f"{BASE_URL}/api/assistant/topics")
        data = response.json()
        assert "topics" in data, "Response should have 'topics' field"
        assert len(data["topics"]) == 5, f"Expected 5 topics, got {len(data['topics'])}"
        print(f"PASS: GET /api/assistant/topics returns 5 topics")
    
    def test_topics_have_required_fields(self):
        """Each topic has id, label_fr, label_en, icon"""
        response = requests.get(f"{BASE_URL}/api/assistant/topics")
        data = response.json()
        for topic in data["topics"]:
            assert "id" in topic, "Topic should have 'id'"
            assert "label_fr" in topic, "Topic should have 'label_fr'"
            assert "label_en" in topic, "Topic should have 'label_en'"
            assert "icon" in topic, "Topic should have 'icon'"
        print("PASS: All topics have required fields (id, label_fr, label_en, icon)")


class TestChatbotChat:
    """Tests for POST /api/assistant/chat endpoint"""
    
    def test_chat_returns_200_for_valid_message(self):
        """POST /api/assistant/chat returns 200 for valid message"""
        response = requests.post(
            f"{BASE_URL}/api/assistant/chat",
            json={"message": "C'est quoi le phishing ?"},
            timeout=30
        )
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        print("PASS: POST /api/assistant/chat returns 200 for valid message")
    
    def test_chat_returns_session_id(self):
        """POST /api/assistant/chat returns session_id"""
        response = requests.post(
            f"{BASE_URL}/api/assistant/chat",
            json={"message": "Bonjour"},
            timeout=30
        )
        data = response.json()
        assert "session_id" in data, "Response should have 'session_id'"
        assert isinstance(data["session_id"], str), "session_id should be a string"
        assert len(data["session_id"]) > 0, "session_id should not be empty"
        print(f"PASS: POST /api/assistant/chat returns session_id: {data['session_id'][:8]}...")
    
    def test_chat_returns_response_with_message(self):
        """POST /api/assistant/chat returns response with message field"""
        response = requests.post(
            f"{BASE_URL}/api/assistant/chat",
            json={"message": "Comment me proteger ?"},
            timeout=30
        )
        data = response.json()
        assert "response" in data, "Response should have 'response' field"
        assert "message" in data["response"], "Response should have 'message' field"
        assert isinstance(data["response"]["message"], str), "message should be a string"
        assert len(data["response"]["message"]) > 0, "message should not be empty"
        print(f"PASS: POST /api/assistant/chat returns response with message field")
    
    def test_chat_returns_is_analysis_false_for_question(self):
        """POST /api/assistant/chat returns is_analysis: false for simple question"""
        response = requests.post(
            f"{BASE_URL}/api/assistant/chat",
            json={"message": "C'est quoi le phishing ?"},
            timeout=30
        )
        data = response.json()
        assert "response" in data
        assert "is_analysis" in data["response"], "Response should have 'is_analysis' field"
        # For a simple question, is_analysis should be false
        print(f"PASS: POST /api/assistant/chat returns is_analysis field: {data['response']['is_analysis']}")
    
    def test_chat_empty_message_returns_400(self):
        """POST /api/assistant/chat returns 400 for empty message"""
        response = requests.post(
            f"{BASE_URL}/api/assistant/chat",
            json={"message": ""},
            timeout=30
        )
        assert response.status_code == 400, f"Expected 400, got {response.status_code}"
        print("PASS: POST /api/assistant/chat returns 400 for empty message")
    
    def test_chat_whitespace_message_returns_400(self):
        """POST /api/assistant/chat returns 400 for whitespace-only message"""
        response = requests.post(
            f"{BASE_URL}/api/assistant/chat",
            json={"message": "   "},
            timeout=30
        )
        assert response.status_code == 400, f"Expected 400, got {response.status_code}"
        print("PASS: POST /api/assistant/chat returns 400 for whitespace-only message")
    
    def test_chat_multi_turn_with_session_id(self):
        """POST /api/assistant/chat supports multi-turn conversation with session_id"""
        # First message
        response1 = requests.post(
            f"{BASE_URL}/api/assistant/chat",
            json={"message": "Bonjour, je suis nouveau"},
            timeout=30
        )
        data1 = response1.json()
        session_id = data1["session_id"]
        
        # Second message with same session_id
        response2 = requests.post(
            f"{BASE_URL}/api/assistant/chat",
            json={"message": "Peux-tu m'expliquer le phishing ?", "session_id": session_id},
            timeout=30
        )
        data2 = response2.json()
        assert data2["session_id"] == session_id, "Session ID should be preserved"
        assert "response" in data2
        assert "message" in data2["response"]
        print(f"PASS: Multi-turn conversation works with session_id: {session_id[:8]}...")


class TestChatbotAnalysis:
    """Tests for phishing analysis mode in chat"""
    
    def test_chat_analysis_for_suspicious_email(self):
        """POST /api/assistant/chat returns analysis for suspicious email content"""
        suspicious_email = """
        Objet: URGENT - Votre colis est en attente de livraison
        
        Cher client,
        
        Votre colis n'a pas pu etre livre car les frais de port n'ont pas ete payes.
        Veuillez cliquer sur le lien ci-dessous pour payer les frais de 1.99 EUR et recevoir votre colis:
        
        https://la-poste-livraison-fr.tk/paiement?id=12345
        
        Attention: Si vous ne payez pas dans les 24h, votre colis sera retourne a l'expediteur.
        
        Cordialement,
        Service Livraison La Poste
        """
        
        response = requests.post(
            f"{BASE_URL}/api/assistant/chat",
            json={"message": suspicious_email},
            timeout=45  # LLM calls can take longer
        )
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        data = response.json()
        
        assert "response" in data
        resp = data["response"]
        
        # Check is_analysis is true for suspicious content
        assert "is_analysis" in resp, "Response should have 'is_analysis' field"
        
        if resp["is_analysis"]:
            assert "analysis" in resp, "Response should have 'analysis' when is_analysis is true"
            analysis = resp["analysis"]
            
            # Check verdict
            assert "verdict" in analysis, "Analysis should have 'verdict'"
            assert analysis["verdict"] in ["dangereux", "suspect", "normal"], f"Invalid verdict: {analysis['verdict']}"
            print(f"PASS: Analysis verdict: {analysis['verdict']}")
            
            # Check other fields
            if "red_flags" in analysis:
                assert isinstance(analysis["red_flags"], list), "red_flags should be a list"
                print(f"PASS: red_flags found: {len(analysis['red_flags'])} items")
            
            if "techniques_detected" in analysis:
                assert isinstance(analysis["techniques_detected"], list), "techniques_detected should be a list"
                print(f"PASS: techniques_detected found: {len(analysis['techniques_detected'])} items")
            
            if "urls_found" in analysis:
                assert isinstance(analysis["urls_found"], list), "urls_found should be a list"
                print(f"PASS: urls_found: {analysis['urls_found']}")
            
            if "immediate_actions" in analysis:
                assert isinstance(analysis["immediate_actions"], list), "immediate_actions should be a list"
                print(f"PASS: immediate_actions found: {len(analysis['immediate_actions'])} items")
            
            if "educational_tip" in analysis:
                assert isinstance(analysis["educational_tip"], str), "educational_tip should be a string"
                print(f"PASS: educational_tip present")
        else:
            print(f"INFO: LLM did not trigger analysis mode for this message (is_analysis: false)")
            print(f"INFO: Response message: {resp.get('message', '')[:100]}...")


class TestChatbotAuthenticated:
    """Tests for authenticated chat features"""
    
    @pytest.fixture
    def auth_token(self):
        """Get authentication token for demo user"""
        response = requests.post(
            f"{BASE_URL}/api/auth/login",
            json={"email": "demo@test.com", "password": "demo123"}
        )
        if response.status_code == 200:
            return response.json().get("token")
        pytest.skip("Demo user login failed - skipping authenticated tests")
    
    def test_chat_stores_message_for_authenticated_user(self, auth_token):
        """POST /api/assistant/chat stores message in chat_messages collection for authenticated user"""
        headers = {"Authorization": f"Bearer {auth_token}"}
        
        # Send a chat message
        response = requests.post(
            f"{BASE_URL}/api/assistant/chat",
            json={"message": "Test message for storage verification"},
            headers=headers,
            timeout=30
        )
        assert response.status_code == 200
        data = response.json()
        session_id = data["session_id"]
        
        # Verify message is stored by checking history
        history_response = requests.get(
            f"{BASE_URL}/api/assistant/history",
            headers=headers
        )
        assert history_response.status_code == 200
        history = history_response.json()
        assert "messages" in history
        
        # Check if our message is in history
        found = any(
            msg.get("session_id") == session_id 
            for msg in history["messages"]
        )
        assert found, "Message should be stored in chat_messages collection"
        print(f"PASS: Chat message stored in chat_messages collection for authenticated user")
    
    def test_history_requires_authentication(self):
        """GET /api/assistant/history requires authentication"""
        response = requests.get(f"{BASE_URL}/api/assistant/history")
        assert response.status_code == 401, f"Expected 401, got {response.status_code}"
        print("PASS: GET /api/assistant/history requires authentication (401)")


class TestOldAssistantRouteRemoved:
    """Tests to verify old /assistant route is removed"""
    
    def test_old_analyze_endpoint_not_found(self):
        """POST /api/assistant/analyze should not exist (old endpoint)"""
        response = requests.post(
            f"{BASE_URL}/api/assistant/analyze",
            json={"message": "test"}
        )
        # Should return 404 or 405 (method not allowed) since the endpoint doesn't exist
        assert response.status_code in [404, 405, 422], f"Old /api/assistant/analyze should not exist, got {response.status_code}"
        print(f"PASS: Old /api/assistant/analyze endpoint returns {response.status_code} (not found/not allowed)")


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
