"""
Test UX Simplification Features (Iteration 22)
- POST /api/analyze returns all analysis data (safe_browsing, phishing_kit, etc.)
- Verify response structure for google.com (should be green/safe)
"""
import pytest
import requests
import os

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', '').rstrip('/')

class TestAnalyzeEndpoint:
    """Test /api/analyze endpoint returns all required data"""
    
    def test_health_check(self):
        """Verify API is accessible"""
        response = requests.get(f"{BASE_URL}/api/health")
        assert response.status_code == 200
        print("✓ Health check passed")
    
    def test_analyze_google_returns_green(self):
        """Analyze google.com should return green verdict"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "https://google.com"},
            headers={"Content-Type": "application/json"}
        )
        assert response.status_code == 200
        data = response.json()
        
        # Verify traffic light is green for google.com
        assert data.get("traffic_light") == "green", f"Expected green, got {data.get('traffic_light')}"
        print(f"✓ google.com returns green verdict")
    
    def test_analyze_returns_safe_browsing(self):
        """Verify safe_browsing field is present in response"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "https://google.com"},
            headers={"Content-Type": "application/json"}
        )
        assert response.status_code == 200
        data = response.json()
        
        # Verify safe_browsing field exists
        assert "safe_browsing" in data, "safe_browsing field missing"
        sb = data["safe_browsing"]
        assert "checked" in sb, "safe_browsing.checked field missing"
        print(f"✓ safe_browsing field present: checked={sb.get('checked')}")
    
    def test_analyze_returns_phishing_kit(self):
        """Verify phishing_kit field is present in response"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "https://google.com"},
            headers={"Content-Type": "application/json"}
        )
        assert response.status_code == 200
        data = response.json()
        
        # Verify phishing_kit field exists
        assert "phishing_kit" in data, "phishing_kit field missing"
        pk = data["phishing_kit"]
        assert "detected" in pk, "phishing_kit.detected field missing"
        print(f"✓ phishing_kit field present: detected={pk.get('detected')}")
    
    def test_analyze_returns_network_checks(self):
        """Verify network_checks field is present with all sub-fields"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "https://google.com"},
            headers={"Content-Type": "application/json"}
        )
        assert response.status_code == 200
        data = response.json()
        
        # Verify network_checks field exists
        assert "network_checks" in data, "network_checks field missing"
        nc = data["network_checks"]
        
        # Check required sub-fields
        expected_fields = ["dns", "ssl", "whois"]
        for field in expected_fields:
            assert field in nc, f"network_checks.{field} field missing"
        
        print(f"✓ network_checks field present with: {list(nc.keys())}")
    
    def test_analyze_returns_feature_details(self):
        """Verify feature_details field is present"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "https://google.com"},
            headers={"Content-Type": "application/json"}
        )
        assert response.status_code == 200
        data = response.json()
        
        # Verify feature_details field exists
        assert "feature_details" in data, "feature_details field missing"
        fd = data["feature_details"]
        
        # Check some expected fields
        expected_fields = ["url_length", "has_https", "domain_length"]
        for field in expected_fields:
            assert field in fd, f"feature_details.{field} field missing"
        
        print(f"✓ feature_details field present with {len(fd)} features")
    
    def test_analyze_returns_all_required_fields(self):
        """Verify all required top-level fields are present"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "https://google.com"},
            headers={"Content-Type": "application/json"}
        )
        assert response.status_code == 200
        data = response.json()
        
        # Check all required top-level fields
        required_fields = [
            "id", "url", "final_score", "risk_level", "traffic_light",
            "safe_browsing", "phishing_kit", "network_checks", "feature_details"
        ]
        
        for field in required_fields:
            assert field in data, f"Required field '{field}' missing from response"
        
        print(f"✓ All required fields present: {required_fields}")
    
    def test_analyze_suspicious_url(self):
        """Test analysis of a potentially suspicious URL pattern"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "http://example.xyz/login/verify"},
            headers={"Content-Type": "application/json"}
        )
        assert response.status_code == 200
        data = response.json()
        
        # Should have some risk indicators
        assert "traffic_light" in data
        assert "feature_details" in data
        
        # Check that suspicious keywords are detected
        fd = data.get("feature_details", {})
        print(f"✓ Suspicious URL analyzed: traffic_light={data.get('traffic_light')}, suspicious_keywords={fd.get('suspicious_keywords')}")


class TestFeedbackEndpoint:
    """Test feedback endpoint works"""
    
    def test_feedback_submission(self):
        """Test that feedback can be submitted"""
        # First analyze a URL to get an analysis_id
        analyze_response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "https://example.com"},
            headers={"Content-Type": "application/json"}
        )
        assert analyze_response.status_code == 200
        analysis_id = analyze_response.json().get("id")
        
        # Submit feedback
        feedback_response = requests.post(
            f"{BASE_URL}/api/feedback",
            json={"analysis_id": analysis_id, "is_phishing": False},
            headers={"Content-Type": "application/json"}
        )
        assert feedback_response.status_code == 200
        data = feedback_response.json()
        assert "message" in data
        print(f"✓ Feedback submitted successfully: {data.get('message')}")


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
