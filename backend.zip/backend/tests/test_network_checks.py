"""
Test suite for Network Verification Checks in URL Analysis
Tests: DNS resolution, SSL/TLS verification, WHOIS domain age, Reverse DNS
Feature: Network checks contribute 20% to final scoring formula (50% ML + 30% Rules + 20% Network)
"""
import pytest
import requests
import os
import time

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL').rstrip('/')


class TestNetworkChecksStructure:
    """Tests that /api/analyze response includes proper network_checks structure"""

    def test_analyze_returns_network_checks_object(self):
        """POST /api/analyze returns network_checks object with dns, ssl, whois, rdns sub-objects"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "https://google.com"},
            timeout=20
        )
        assert response.status_code == 200
        data = response.json()
        
        # Check network_checks object exists
        assert "network_checks" in data, "Response missing network_checks"
        nc = data["network_checks"]
        
        # Check all 4 sub-objects exist
        assert "dns" in nc, "network_checks missing dns"
        assert "ssl" in nc, "network_checks missing ssl"
        assert "whois" in nc, "network_checks missing whois"
        assert "rdns" in nc, "network_checks missing rdns"
        print(f"PASS: network_checks contains dns, ssl, whois, rdns")

    def test_analyze_returns_network_score(self):
        """POST /api/analyze returns network_score field"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "https://google.com"},
            timeout=20
        )
        assert response.status_code == 200
        data = response.json()
        
        assert "network_score" in data, "Response missing network_score"
        assert isinstance(data["network_score"], (int, float)), "network_score should be numeric"
        print(f"PASS: network_score = {data['network_score']}")

    def test_analyze_returns_network_risk_factors(self):
        """POST /api/analyze returns network_risk_factors array"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "https://google.com"},
            timeout=20
        )
        assert response.status_code == 200
        data = response.json()
        
        assert "network_risk_factors" in data, "Response missing network_risk_factors"
        assert isinstance(data["network_risk_factors"], list), "network_risk_factors should be array"
        print(f"PASS: network_risk_factors count = {len(data['network_risk_factors'])}")


class TestDNSChecks:
    """Tests for DNS resolution verification"""

    def test_google_dns_resolves(self):
        """google.com resolves DNS with IP addresses"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "https://google.com"},
            timeout=20
        )
        assert response.status_code == 200
        data = response.json()
        
        dns = data["network_checks"]["dns"]
        assert dns["exists"] == True, "google.com should resolve"
        assert dns["status"] == "resolved", f"Expected 'resolved', got '{dns['status']}'"
        assert len(dns["ip_addresses"]) > 0, "Should have IP addresses"
        print(f"PASS: google.com resolved to {dns['ip_addresses']}")

    def test_nonexistent_domain_no_dns(self):
        """Non-existent domain shows no DNS resolution"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "http://nonexistent-domain-xyz123.xyz"},
            timeout=20
        )
        assert response.status_code == 200
        data = response.json()
        
        dns = data["network_checks"]["dns"]
        assert dns["exists"] == False, "Non-existent domain should not resolve"
        assert dns["status"] in ["not_found", "no_record"], f"Expected not_found/no_record, got '{dns['status']}'"
        assert len(dns.get("ip_addresses", [])) == 0, "Should have no IP addresses"
        print(f"PASS: Non-existent domain DNS status = {dns['status']}")


class TestSSLChecks:
    """Tests for SSL/TLS certificate verification"""

    def test_google_has_valid_ssl(self):
        """google.com has valid SSL certificate with issuer and expiry"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "https://google.com"},
            timeout=20
        )
        assert response.status_code == 200
        data = response.json()
        
        ssl_data = data["network_checks"]["ssl"]
        assert ssl_data["valid"] == True, "google.com should have valid SSL"
        assert ssl_data["status"] == "valid", f"Expected 'valid', got '{ssl_data['status']}'"
        assert ssl_data["issuer"] is not None, "Should have issuer"
        assert ssl_data["expires"] is not None, "Should have expiry date"
        assert ssl_data["days_until_expiry"] is not None, "Should have days_until_expiry"
        assert ssl_data["protocol"] is not None, "Should have protocol (TLSv1.3 etc)"
        print(f"PASS: google.com SSL issuer={ssl_data['issuer']}, expires={ssl_data['expires']}, protocol={ssl_data['protocol']}")

    def test_http_domain_no_ssl(self):
        """Domain without HTTPS shows no_ssl or error"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "http://paypa1-secure.xyz"},
            timeout=20
        )
        assert response.status_code == 200
        data = response.json()
        
        ssl_data = data["network_checks"]["ssl"]
        assert ssl_data["valid"] == False, "Suspicious domain should not have valid SSL"
        assert ssl_data["status"] in ["no_ssl", "invalid", "error", "timeout"], f"Expected no_ssl/invalid/error, got '{ssl_data['status']}'"
        print(f"PASS: http domain SSL status = {ssl_data['status']}")


class TestWHOISChecks:
    """Tests for WHOIS domain age lookup"""

    def test_google_old_whois_domain(self):
        """google.com shows old domain age in WHOIS"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "https://google.com"},
            timeout=20
        )
        assert response.status_code == 200
        data = response.json()
        
        whois = data["network_checks"]["whois"]
        assert whois["status"] == "found", f"Expected 'found', got '{whois['status']}'"
        assert whois["creation_date"] is not None, "Should have creation_date"
        assert whois["domain_age_days"] is not None, "Should have domain_age_days"
        # Google was registered in 1997, should be > 9000 days old
        assert whois["domain_age_days"] > 9000, f"google.com should be very old, got {whois['domain_age_days']} days"
        print(f"PASS: google.com WHOIS age = {whois['domain_age_days']} days, created {whois['creation_date']}")

    def test_nonexistent_domain_whois_no_data(self):
        """Non-existent domain shows no WHOIS data"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "http://nonexistent-domain-xyz123.xyz"},
            timeout=20
        )
        assert response.status_code == 200
        data = response.json()
        
        whois = data["network_checks"]["whois"]
        # Non-existent domains either have no_data or error
        assert whois["status"] in ["no_data", "error", "timeout"], f"Expected no_data/error, got '{whois['status']}'"
        print(f"PASS: Non-existent domain WHOIS status = {whois['status']}")


class TestReverseDNSChecks:
    """Tests for Reverse DNS lookup"""

    def test_google_consistent_rdns(self):
        """google.com has consistent rDNS (matches or is CDN)"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "https://google.com"},
            timeout=20
        )
        assert response.status_code == 200
        data = response.json()
        
        rdns = data["network_checks"]["rdns"]
        assert rdns["status"] != "skipped", "rDNS should not be skipped for google.com"
        assert rdns["reverse_hostname"] is not None, "Should have reverse_hostname"
        # Google uses 1e100.net which is whitelisted as CDN
        assert rdns["consistent"] == True, f"Expected consistent=True, got {rdns['consistent']}"
        print(f"PASS: google.com rDNS = {rdns['reverse_hostname']}, consistent={rdns['consistent']}")

    def test_nonexistent_domain_rdns_skipped(self):
        """Non-existent domain has rDNS skipped (no IP to check)"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "http://nonexistent-domain-xyz123.xyz"},
            timeout=20
        )
        assert response.status_code == 200
        data = response.json()
        
        rdns = data["network_checks"]["rdns"]
        assert rdns["status"] == "skipped", f"Expected 'skipped', got '{rdns['status']}'"
        print(f"PASS: Non-existent domain rDNS status = skipped")


class TestNetworkScoring:
    """Tests for network-based scoring adjustments"""

    def test_google_low_final_score(self):
        """google.com gets low final_score (near 0) with network bonuses"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "https://google.com"},
            timeout=20
        )
        assert response.status_code == 200
        data = response.json()
        
        # Google should be very safe
        assert data["final_score"] < 15, f"Expected final_score < 15, got {data['final_score']}"
        assert data["risk_level"] == "SAFE", f"Expected SAFE, got {data['risk_level']}"
        assert data["traffic_light"] == "green", f"Expected green, got {data['traffic_light']}"
        # Network score should be negative (bonus for old domain, valid SSL)
        assert data["network_score"] <= 0, f"Expected negative network_score, got {data['network_score']}"
        print(f"PASS: google.com final_score={data['final_score']}, network_score={data['network_score']}")

    def test_suspicious_domain_high_score_with_network_factors(self):
        """Suspicious domain gets high score with network risk factors"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "http://paypa1-secure.xyz"},
            timeout=20
        )
        assert response.status_code == 200
        data = response.json()
        
        # Suspicious domain should have elevated score
        assert data["final_score"] > 30, f"Expected final_score > 30, got {data['final_score']}"
        # Network score should be positive (penalty for no DNS, no SSL)
        assert data["network_score"] > 0, f"Expected positive network_score, got {data['network_score']}"
        # Should have network risk factors
        assert len(data["network_risk_factors"]) > 0, "Should have network_risk_factors"
        
        risk_ids = [r["id"] for r in data["network_risk_factors"]]
        assert "NET_NO_DNS" in risk_ids, "Should have NET_NO_DNS risk factor"
        print(f"PASS: suspicious domain final_score={data['final_score']}, network_risk_factors={risk_ids}")

    def test_scoring_formula_components(self):
        """Verify scoring formula has 3 components: ml_score, rules_score, network_score"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "https://github.com"},
            timeout=20
        )
        assert response.status_code == 200
        data = response.json()
        
        # All three scoring components should be present
        assert "ml_score" in data, "Response should have ml_score"
        assert "rules_score" in data, "Response should have rules_score"
        assert "network_score" in data, "Response should have network_score"
        assert "final_score" in data, "Response should have final_score"
        
        # Verify they're all numeric
        assert isinstance(data["ml_score"], (int, float)), "ml_score should be numeric"
        assert isinstance(data["rules_score"], (int, float)), "rules_score should be numeric"
        assert isinstance(data["network_score"], (int, float)), "network_score should be numeric"
        
        print(f"PASS: Scoring components - ML={data['ml_score']}, Rules={data['rules_score']}, Network={data['network_score']}, Final={data['final_score']}")


class TestNetworkRiskFactors:
    """Tests for network-specific risk factors in response"""

    def test_no_dns_risk_factor(self):
        """NET_NO_DNS risk factor appears for non-resolving domains"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "http://nonexistent-domain-xyz123.xyz"},
            timeout=20
        )
        assert response.status_code == 200
        data = response.json()
        
        risk_ids = [r["id"] for r in data.get("network_risk_factors", [])]
        assert "NET_NO_DNS" in risk_ids, f"Should have NET_NO_DNS, got {risk_ids}"
        
        # Find the risk factor and verify it has proper structure
        net_no_dns = next(r for r in data["network_risk_factors"] if r["id"] == "NET_NO_DNS")
        assert "severity" in net_no_dns, "Risk factor should have severity"
        assert "description_fr" in net_no_dns, "Risk factor should have French description"
        assert "description_en" in net_no_dns, "Risk factor should have English description"
        print(f"PASS: NET_NO_DNS risk factor with severity={net_no_dns['severity']}")

    def test_no_ssl_risk_factor(self):
        """NET_NO_SSL risk factor appears for domains without SSL"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "http://paypa1-secure.xyz"},
            timeout=20
        )
        assert response.status_code == 200
        data = response.json()
        
        risk_ids = [r["id"] for r in data.get("network_risk_factors", [])]
        assert "NET_NO_SSL" in risk_ids, f"Should have NET_NO_SSL, got {risk_ids}"
        print(f"PASS: NET_NO_SSL risk factor present")

    def test_safe_domain_no_network_risk_factors(self):
        """Safe domains like google.com have no network risk factors"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "https://google.com"},
            timeout=20
        )
        assert response.status_code == 200
        data = response.json()
        
        assert len(data.get("network_risk_factors", [])) == 0, f"google.com should have no network_risk_factors, got {data['network_risk_factors']}"
        print(f"PASS: google.com has no network risk factors")


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
