"""
Test Balance Safeguard Feature for ML Model Retraining
Tests the new balance check that prevents dataset imbalance bias.
"""
import pytest
import requests
import os

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL').rstrip('/')

# Test credentials
ADMIN_EMAIL = "admin@test.com"
ADMIN_PASSWORD = "admin123"


class TestBalanceSafeguard:
    """Tests for the ML model balance safeguard feature"""
    
    @pytest.fixture(autouse=True)
    def setup(self):
        """Login as admin and get token"""
        # Login as admin
        response = requests.post(f"{BASE_URL}/api/auth/login", json={
            "email": ADMIN_EMAIL,
            "password": ADMIN_PASSWORD
        })
        if response.status_code == 200:
            self.token = response.json().get("token")
            self.headers = {"Authorization": f"Bearer {self.token}"}
        else:
            pytest.skip(f"Admin login failed with status {response.status_code}")
    
    # ==================== GET /api/admin/dataset/stats ====================
    
    def test_dataset_stats_returns_balance_info(self):
        """GET /api/admin/dataset/stats should return balance object with required fields"""
        response = requests.get(f"{BASE_URL}/api/admin/dataset/stats", headers=self.headers)
        
        assert response.status_code == 200, f"Expected 200, got {response.status_code}: {response.text}"
        
        data = response.json()
        
        # Check balance object exists
        assert "balance" in data, "Response should contain 'balance' object"
        balance = data["balance"]
        
        # Validate required balance fields
        required_fields = ["phishing_ratio", "legit_ratio", "is_balanced", "max_ratio", "threshold"]
        for field in required_fields:
            assert field in balance, f"Balance object missing '{field}' field"
        
        # Validate field types
        assert isinstance(balance["phishing_ratio"], (int, float)), "phishing_ratio should be a number"
        assert isinstance(balance["legit_ratio"], (int, float)), "legit_ratio should be a number"
        assert isinstance(balance["is_balanced"], bool), "is_balanced should be a boolean"
        assert isinstance(balance["max_ratio"], (int, float)), "max_ratio should be a number"
        assert isinstance(balance["threshold"], int), "threshold should be an integer"
        
        # Validate threshold is 65%
        assert balance["threshold"] == 65, f"Threshold should be 65, got {balance['threshold']}"
        
        # Validate ratios are consistent
        total_ratio = balance["phishing_ratio"] + balance["legit_ratio"]
        if total_ratio > 0:  # If there's data
            assert 99 <= total_ratio <= 101, f"Ratios should sum to ~100%, got {total_ratio}%"
        
        print(f"✓ Dataset stats returned balance info: phishing={balance['phishing_ratio']}%, legit={balance['legit_ratio']}%, balanced={balance['is_balanced']}")
    
    def test_dataset_stats_has_counts(self):
        """GET /api/admin/dataset/stats should include total phishing and legit counts"""
        response = requests.get(f"{BASE_URL}/api/admin/dataset/stats", headers=self.headers)
        
        assert response.status_code == 200
        
        data = response.json()
        balance = data.get("balance", {})
        
        # Check count fields exist
        assert "total_phishing" in balance, "Balance should have total_phishing count"
        assert "total_legit" in balance, "Balance should have total_legit count"
        
        assert isinstance(balance["total_phishing"], int), "total_phishing should be integer"
        assert isinstance(balance["total_legit"], int), "total_legit should be integer"
        
        print(f"✓ Dataset counts: {balance['total_phishing']} phishing, {balance['total_legit']} legit")
    
    # ==================== POST /api/admin/retrain ====================
    
    def test_retrain_balanced_dataset_succeeds(self):
        """POST /api/admin/retrain with balanced dataset should succeed and return balance info"""
        response = requests.post(f"{BASE_URL}/api/admin/retrain", headers=self.headers, json={})
        
        assert response.status_code == 200, f"Expected 200, got {response.status_code}: {response.text}"
        
        data = response.json()
        
        # Check if blocked or succeeded
        if data.get("blocked"):
            # Dataset is currently imbalanced - this is acceptable for this test
            print(f"⚠ Retrain blocked due to imbalanced dataset: {data.get('message')}")
            assert "balance" in data, "Blocked response should include balance info"
            assert data["balance"]["max_ratio"] > 65, "Blocked implies max_ratio > 65%"
        else:
            # Retrain succeeded
            assert "accuracy" in data, "Successful retrain should return accuracy"
            assert "balance" in data, "Successful retrain should return balance info"
            assert data["balance"]["is_balanced"] == True or data.get("forced"), "Should be balanced or forced"
            print(f"✓ Retrain succeeded: accuracy={data.get('accuracy')}%, balanced={data['balance']['is_balanced']}")
    
    def test_retrain_returns_balance_info(self):
        """POST /api/admin/retrain should always return balance information"""
        response = requests.post(f"{BASE_URL}/api/admin/retrain", headers=self.headers, json={})
        
        assert response.status_code == 200
        
        data = response.json()
        
        # Balance info should always be present
        assert "balance" in data, "Retrain response should always include balance info"
        
        balance = data["balance"]
        required_fields = ["phishing_ratio", "legit_ratio", "is_balanced", "max_ratio", "threshold"]
        for field in required_fields:
            assert field in balance, f"Balance missing '{field}'"
        
        print(f"✓ Retrain returned balance info: max_ratio={balance['max_ratio']}%, is_balanced={balance['is_balanced']}")
    
    def test_retrain_with_force_flag(self):
        """POST /api/admin/retrain with force:true should proceed regardless of balance"""
        response = requests.post(f"{BASE_URL}/api/admin/retrain", headers=self.headers, json={"force": True})
        
        assert response.status_code == 200, f"Expected 200, got {response.status_code}: {response.text}"
        
        data = response.json()
        
        # With force=true, should not be blocked
        assert data.get("blocked") != True, "Force retrain should not be blocked"
        
        # Should have accuracy (training happened)
        assert "accuracy" in data, "Forced retrain should return accuracy"
        assert "balance" in data, "Forced retrain should return balance info"
        
        # Check forced flag if dataset was imbalanced
        if not data["balance"]["is_balanced"]:
            assert data.get("forced") == True, "Should indicate it was forced when imbalanced"
            print(f"✓ Force retrain succeeded despite imbalance: accuracy={data.get('accuracy')}%, forced=True")
        else:
            print(f"✓ Force retrain succeeded (dataset balanced): accuracy={data.get('accuracy')}%")
    
    def test_retrain_without_auth_fails(self):
        """POST /api/admin/retrain without auth should return 401"""
        response = requests.post(f"{BASE_URL}/api/admin/retrain", json={})
        
        assert response.status_code == 401, f"Expected 401, got {response.status_code}"
        print("✓ Retrain requires authentication")
    
    # ==================== POST /api/admin/dataset/fetch-and-train ====================
    
    def test_fetch_and_train_has_balance_guard(self):
        """POST /api/admin/dataset/fetch-and-train should have balance guard"""
        # This is a longer operation - just test that it has the balance guard structure
        response = requests.post(f"{BASE_URL}/api/admin/dataset/fetch-and-train", headers=self.headers, json={}, timeout=120)
        
        assert response.status_code == 200, f"Expected 200, got {response.status_code}: {response.text}"
        
        data = response.json()
        
        # Should have fetch and train sections
        assert "fetch" in data, "Response should have 'fetch' section"
        assert "train" in data, "Response should have 'train' section"
        
        train = data["train"]
        
        # Train section should have balance info
        if train.get("blocked"):
            # Blocked due to imbalance
            assert "balance" in train, "Blocked response should have balance info"
            assert train["balance"]["max_ratio"] > 65, "Blocked means max_ratio > 65%"
            print(f"✓ Fetch-and-train blocked due to imbalance: {train.get('message')}")
        else:
            # Succeeded
            assert "balance" in train, "Successful response should have balance info"
            print(f"✓ Fetch-and-train succeeded: accuracy={train.get('accuracy')}%")
    
    def test_fetch_and_train_force_flag(self):
        """POST /api/admin/dataset/fetch-and-train with force:true should bypass balance check"""
        response = requests.post(f"{BASE_URL}/api/admin/dataset/fetch-and-train", headers=self.headers, json={"force": True}, timeout=120)
        
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        
        data = response.json()
        train = data.get("train", {})
        
        # Should not be blocked with force=true
        assert train.get("blocked") != True, "Force should bypass balance check"
        
        # Should have accuracy
        assert "accuracy" in train, "Should return accuracy after training"
        
        print(f"✓ Fetch-and-train with force succeeded: accuracy={train.get('accuracy')}%")


class TestAdminAccess:
    """Test admin access requirements"""
    
    def test_dataset_stats_requires_admin(self):
        """GET /api/admin/dataset/stats should require admin auth"""
        # Without auth
        response = requests.get(f"{BASE_URL}/api/admin/dataset/stats")
        assert response.status_code == 401, f"Expected 401 without auth, got {response.status_code}"
        
        # With non-admin user (create new user)
        reg_response = requests.post(f"{BASE_URL}/api/auth/register", json={
            "email": "TEST_nonadmin@test.com",
            "username": "testnonadmin",
            "password": "test123"
        })
        
        if reg_response.status_code == 200:
            token = reg_response.json().get("token")
            headers = {"Authorization": f"Bearer {token}"}
            
            response = requests.get(f"{BASE_URL}/api/admin/dataset/stats", headers=headers)
            assert response.status_code == 403, f"Expected 403 for non-admin, got {response.status_code}"
            print("✓ Dataset stats endpoint properly requires admin access")
        else:
            # User already exists or registration failed - skip this specific check
            print("⚠ Could not test non-admin access (registration issue)")


class TestFrenchTranslations:
    """Test French accent corrections in admin page"""
    
    @pytest.fixture(autouse=True)
    def setup(self):
        """Login as admin"""
        response = requests.post(f"{BASE_URL}/api/auth/login", json={
            "email": ADMIN_EMAIL,
            "password": ADMIN_PASSWORD
        })
        if response.status_code == 200:
            self.token = response.json().get("token")
            self.headers = {"Authorization": f"Bearer {self.token}"}
        else:
            pytest.skip("Admin login failed")
    
    def test_retrain_blocked_message_has_french(self):
        """POST /api/admin/retrain blocked response should have French message with accents"""
        # First check current balance
        stats_response = requests.get(f"{BASE_URL}/api/admin/dataset/stats", headers=self.headers)
        stats = stats_response.json()
        
        # Try retrain to see the message format
        response = requests.post(f"{BASE_URL}/api/admin/retrain", headers=self.headers, json={})
        data = response.json()
        
        if data.get("blocked"):
            # Check French message has proper accents
            message = data.get("message", "")
            assert "déséquilibré" in message.lower() or "Dataset" in message, f"French message should mention imbalance"
            assert "message_en" in data, "Should have English message too"
            print(f"✓ Blocked message in French: {message[:80]}...")
        else:
            # Not blocked - dataset is balanced
            print(f"✓ Dataset is balanced, no block message (accuracy={data.get('accuracy')}%)")


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
