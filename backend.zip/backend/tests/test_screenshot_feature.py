"""
Test Suite for Screenshot Feature (Iteration 20)
Tests:
- POST /api/screenshot endpoint returns captured:true with image_base64 for google.com
- POST /api/screenshot endpoint returns error for private IP (SSRF protection)
- POST /api/analyze includes safe_browsing and phishing_kit fields in response
- POST /api/analyze returns official_site when typosquatting is detected
"""
import pytest
import requests
import os
import time

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', '').rstrip('/')

class TestScreenshotEndpoint:
    """Tests for POST /api/screenshot endpoint"""
    
    def test_health_check(self):
        """Verify API is accessible"""
        response = requests.get(f"{BASE_URL}/api/health")
        assert response.status_code == 200, f"Health check failed: {response.status_code}"
        print("✓ Health check passed")
    
    def test_screenshot_google_com(self):
        """POST /api/screenshot returns captured:true with image_base64 for google.com"""
        response = requests.post(
            f"{BASE_URL}/api/screenshot",
            json={"url": "https://www.google.com"},
            timeout=30  # Screenshot takes 5-10s
        )
        assert response.status_code == 200, f"Screenshot endpoint failed: {response.status_code}"
        data = response.json()
        
        # Verify response structure
        assert "captured" in data, "Response missing 'captured' field"
        assert "image_base64" in data, "Response missing 'image_base64' field"
        assert "error" in data, "Response missing 'error' field"
        
        # Verify successful capture
        assert data["captured"] == True, f"Screenshot not captured: {data.get('error')}"
        assert data["image_base64"] is not None, "image_base64 is None"
        assert len(data["image_base64"]) > 1000, "image_base64 seems too short for a valid image"
        assert data["error"] is None, f"Unexpected error: {data.get('error')}"
        
        print(f"✓ Screenshot captured for google.com (base64 length: {len(data['image_base64'])})")
    
    def test_screenshot_ssrf_protection_localhost(self):
        """POST /api/screenshot returns error for localhost (SSRF protection)"""
        response = requests.post(
            f"{BASE_URL}/api/screenshot",
            json={"url": "http://localhost"},
            timeout=15
        )
        assert response.status_code == 200, f"Endpoint failed: {response.status_code}"
        data = response.json()
        
        assert data["captured"] == False, "Should not capture localhost"
        assert data["error"] == "blocked_private_ip", f"Expected 'blocked_private_ip' error, got: {data.get('error')}"
        assert data["image_base64"] is None, "image_base64 should be None for blocked URL"
        
        print("✓ SSRF protection works for localhost")
    
    def test_screenshot_ssrf_protection_127_0_0_1(self):
        """POST /api/screenshot returns error for 127.0.0.1 (SSRF protection)"""
        response = requests.post(
            f"{BASE_URL}/api/screenshot",
            json={"url": "http://127.0.0.1"},
            timeout=15
        )
        assert response.status_code == 200, f"Endpoint failed: {response.status_code}"
        data = response.json()
        
        assert data["captured"] == False, "Should not capture 127.0.0.1"
        assert data["error"] == "blocked_private_ip", f"Expected 'blocked_private_ip' error, got: {data.get('error')}"
        
        print("✓ SSRF protection works for 127.0.0.1")
    
    def test_screenshot_ssrf_protection_private_ip(self):
        """POST /api/screenshot returns error for private IP 192.168.x.x (SSRF protection)"""
        response = requests.post(
            f"{BASE_URL}/api/screenshot",
            json={"url": "http://192.168.1.1"},
            timeout=15
        )
        assert response.status_code == 200, f"Endpoint failed: {response.status_code}"
        data = response.json()
        
        assert data["captured"] == False, "Should not capture private IP"
        assert data["error"] == "blocked_private_ip", f"Expected 'blocked_private_ip' error, got: {data.get('error')}"
        
        print("✓ SSRF protection works for private IP 192.168.1.1")
    
    def test_screenshot_ssrf_protection_10_x_x_x(self):
        """POST /api/screenshot returns error for private IP 10.x.x.x (SSRF protection)"""
        response = requests.post(
            f"{BASE_URL}/api/screenshot",
            json={"url": "http://10.0.0.1"},
            timeout=15
        )
        assert response.status_code == 200, f"Endpoint failed: {response.status_code}"
        data = response.json()
        
        assert data["captured"] == False, "Should not capture private IP 10.x.x.x"
        assert data["error"] == "blocked_private_ip", f"Expected 'blocked_private_ip' error, got: {data.get('error')}"
        
        print("✓ SSRF protection works for private IP 10.0.0.1")


class TestAnalyzeEndpointPhaseB:
    """Tests for POST /api/analyze - safe_browsing and phishing_kit fields"""
    
    def test_analyze_includes_safe_browsing_field(self):
        """POST /api/analyze includes safe_browsing field in response"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "https://www.google.com"},
            timeout=30
        )
        assert response.status_code == 200, f"Analyze endpoint failed: {response.status_code}"
        data = response.json()
        
        # safe_browsing field should be present
        assert "safe_browsing" in data, "Response missing 'safe_browsing' field"
        
        # If API key is configured, it should have structure
        sb = data["safe_browsing"]
        if sb is not None:
            assert "checked" in sb, "safe_browsing missing 'checked' field"
            assert "is_threat" in sb, "safe_browsing missing 'is_threat' field"
            print(f"✓ safe_browsing field present with checked={sb.get('checked')}, is_threat={sb.get('is_threat')}")
        else:
            print("✓ safe_browsing field present (null - API key may not be configured)")
    
    def test_analyze_includes_phishing_kit_field(self):
        """POST /api/analyze includes phishing_kit field in response"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "https://www.google.com"},
            timeout=30
        )
        assert response.status_code == 200, f"Analyze endpoint failed: {response.status_code}"
        data = response.json()
        
        # phishing_kit field should be present
        assert "phishing_kit" in data, "Response missing 'phishing_kit' field"
        
        pk = data["phishing_kit"]
        assert "detected" in pk, "phishing_kit missing 'detected' field"
        assert "kits" in pk, "phishing_kit missing 'kits' field"
        assert "structural_findings" in pk, "phishing_kit missing 'structural_findings' field"
        
        # For google.com, no kit should be detected
        assert pk["detected"] == False, f"Unexpected kit detected for google.com: {pk}"
        assert isinstance(pk["kits"], list), "kits should be a list"
        assert isinstance(pk["structural_findings"], list), "structural_findings should be a list"
        
        print(f"✓ phishing_kit field present: detected={pk['detected']}, kits={pk['kits']}")


class TestTyposquattingDetection:
    """Tests for typosquatting detection and official_site field"""
    
    def test_analyze_typosquatting_go0gle(self):
        """POST /api/analyze returns official_site when typosquatting is detected (go0gle)"""
        # Note: go0gle.com may not exist, but the typosquatting detection should still work
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "https://go0gle.com"},
            timeout=30
        )
        assert response.status_code == 200, f"Analyze endpoint failed: {response.status_code}"
        data = response.json()
        
        # Check typosquatting detection
        typosquat_target = data.get("typosquatting_target")
        official_site = data.get("official_site")
        
        # Either typosquatting_target or content_details.typosquatting should indicate detection
        content_typo = data.get("content_details", {}).get("typosquatting", {})
        
        if typosquat_target:
            print(f"✓ Typosquatting detected via typosquatting_target: {typosquat_target}")
            assert official_site is not None, "official_site should be set when typosquatting detected"
            assert "google" in official_site.lower(), f"official_site should point to google: {official_site}"
            print(f"✓ official_site field present: {official_site}")
        elif content_typo.get("is_typosquatting"):
            print(f"✓ Typosquatting detected via content_details: {content_typo.get('target_brand')}")
            legit_domains = content_typo.get("legitimate_domains", [])
            assert len(legit_domains) > 0, "legitimate_domains should be populated"
            print(f"✓ legitimate_domains: {legit_domains}")
        else:
            # The domain might not resolve, check if analysis still works
            print(f"⚠ Typosquatting not detected for go0gle.com (domain may not resolve)")
            print(f"  Response keys: {list(data.keys())}")
            print(f"  risk_level: {data.get('risk_level')}")
    
    def test_analyze_typosquatting_amaz0n(self):
        """POST /api/analyze returns official_site when typosquatting is detected (amaz0n)"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "https://amaz0n.com"},
            timeout=30
        )
        assert response.status_code == 200, f"Analyze endpoint failed: {response.status_code}"
        data = response.json()
        
        typosquat_target = data.get("typosquatting_target")
        official_site = data.get("official_site")
        content_typo = data.get("content_details", {}).get("typosquatting", {})
        
        if typosquat_target:
            print(f"✓ Typosquatting detected: {typosquat_target}")
            assert official_site is not None, "official_site should be set"
            assert "amazon" in official_site.lower(), f"official_site should point to amazon: {official_site}"
            print(f"✓ official_site: {official_site}")
        elif content_typo.get("is_typosquatting"):
            print(f"✓ Typosquatting detected via content: {content_typo.get('target_brand')}")
        else:
            print(f"⚠ Typosquatting not detected for amaz0n.com")
            print(f"  risk_level: {data.get('risk_level')}")
    
    def test_analyze_legitimate_google_no_typosquatting(self):
        """POST /api/analyze does NOT flag legitimate google.com as typosquatting"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "https://www.google.com"},
            timeout=30
        )
        assert response.status_code == 200, f"Analyze endpoint failed: {response.status_code}"
        data = response.json()
        
        typosquat_target = data.get("typosquatting_target")
        official_site = data.get("official_site")
        
        # Legitimate google.com should NOT be flagged as typosquatting
        assert typosquat_target is None, f"google.com should not be flagged as typosquatting: {typosquat_target}"
        assert official_site is None, f"official_site should be None for legitimate site: {official_site}"
        
        print("✓ Legitimate google.com not flagged as typosquatting")


class TestAnalyzeResponseStructure:
    """Tests for complete analyze response structure"""
    
    def test_analyze_complete_response_structure(self):
        """POST /api/analyze returns all required fields"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "https://www.wikipedia.org"},
            timeout=30
        )
        assert response.status_code == 200, f"Analyze endpoint failed: {response.status_code}"
        data = response.json()
        
        # Required fields
        required_fields = [
            "url", "final_score", "risk_level", "traffic_light",
            "ml_score", "rules_score", "network_score", "content_score",
            "safe_browsing", "phishing_kit",
            "network_checks", "network_risk_factors",
            "content_findings", "content_details",
            "triggered_rules", "top_risks", "safe_indicators",
            "feature_details", "model_accuracy",
            "simple_explanation_fr", "simple_explanation_en"
        ]
        
        for field in required_fields:
            assert field in data, f"Response missing required field: {field}"
        
        print(f"✓ All {len(required_fields)} required fields present in response")
        print(f"  risk_level: {data['risk_level']}, final_score: {data['final_score']}")


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
