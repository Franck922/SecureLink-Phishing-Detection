"""
SecureLink Company Verification Tests (Iteration 18)
Tests the Pappers API integration for French company verification.
Features tested:
- company_verification object in /api/analyze response
- Verified French companies (societe-generale.fr, orange.fr, bnpparibas.com)
- Unverified domains (random/fake domains)
- Risk score reduction by 20 for verified companies
- Company cache in MongoDB
- Frontend display of 'Entreprise verifiee' card
"""
import pytest
import requests
import os
import time

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', '').rstrip('/')

class TestCompanyVerificationBackend:
    """Backend API tests for company verification feature"""
    
    def test_health_check(self):
        """Verify API is accessible"""
        response = requests.get(f"{BASE_URL}/api/health", timeout=10)
        assert response.status_code == 200, f"Health check failed: {response.status_code}"
        print("✓ Health check passed")
    
    def test_analyze_returns_company_verification_object(self):
        """POST /api/analyze returns company_verification object with verified, company, and source fields"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "google.com"},
            timeout=30
        )
        assert response.status_code == 200, f"Analyze failed: {response.status_code}"
        data = response.json()
        
        # Check company_verification object exists
        assert "company_verification" in data, "company_verification field missing from response"
        cv = data["company_verification"]
        
        # Check required fields
        assert "verified" in cv, "verified field missing from company_verification"
        assert "company" in cv, "company field missing from company_verification"
        assert "source" in cv, "source field missing from company_verification"
        
        # Verify types
        assert isinstance(cv["verified"], bool), "verified should be boolean"
        assert cv["source"] in ["pappers", "cache", "none", "error"], f"Unexpected source: {cv['source']}"
        
        print(f"✓ google.com company_verification: verified={cv['verified']}, source={cv['source']}")
    
    def test_societe_generale_verified(self):
        """societe-generale.fr is verified as a French company with SIREN"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "societe-generale.fr"},
            timeout=30
        )
        assert response.status_code == 200, f"Analyze failed: {response.status_code}"
        data = response.json()
        
        cv = data.get("company_verification", {})
        assert cv.get("verified") == True, f"societe-generale.fr should be verified, got: {cv}"
        
        company = cv.get("company", {})
        assert company is not None, "company object should not be None for verified domain"
        assert company.get("siren"), f"SIREN should be present for verified company: {company}"
        assert company.get("name"), f"Company name should be present: {company}"
        
        print(f"✓ societe-generale.fr verified: {company.get('name')} (SIREN: {company.get('siren')})")
    
    def test_orange_verified(self):
        """orange.fr is verified as ORANGE company"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "orange.fr"},
            timeout=30
        )
        assert response.status_code == 200, f"Analyze failed: {response.status_code}"
        data = response.json()
        
        cv = data.get("company_verification", {})
        assert cv.get("verified") == True, f"orange.fr should be verified, got: {cv}"
        
        company = cv.get("company", {})
        assert company is not None, "company object should not be None"
        assert "orange" in company.get("name", "").lower() or "orange" in company.get("denomination", "").lower(), \
            f"Company name should contain 'orange': {company}"
        
        print(f"✓ orange.fr verified: {company.get('name')} (SIREN: {company.get('siren')})")
    
    def test_bnpparibas_compound_name_splitting(self):
        """bnpparibas.com is verified as BNP PARIBAS (compound name splitting)"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "bnpparibas.com"},
            timeout=30
        )
        assert response.status_code == 200, f"Analyze failed: {response.status_code}"
        data = response.json()
        
        cv = data.get("company_verification", {})
        assert cv.get("verified") == True, f"bnpparibas.com should be verified (compound name split), got: {cv}"
        
        company = cv.get("company", {})
        assert company is not None, "company object should not be None"
        name = (company.get("name", "") + " " + company.get("denomination", "")).lower()
        assert "bnp" in name or "paribas" in name, f"Company name should contain 'bnp' or 'paribas': {company}"
        
        print(f"✓ bnpparibas.com verified (compound split): {company.get('name')} (SIREN: {company.get('siren')})")
    
    def test_random_domain_not_verified(self):
        """A random/fake domain (e.g. randomsite123456.xyz) returns verified: false"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "randomsite123456.xyz"},
            timeout=30
        )
        assert response.status_code == 200, f"Analyze failed: {response.status_code}"
        data = response.json()
        
        cv = data.get("company_verification", {})
        assert cv.get("verified") == False, f"Random domain should NOT be verified, got: {cv}"
        assert cv.get("company") is None, f"company should be None for unverified domain: {cv}"
        
        print(f"✓ randomsite123456.xyz not verified (as expected)")
    
    def test_verified_company_reduces_risk_score(self):
        """Company verification reduces risk score by 20 for verified companies"""
        # Test with a known verified French company
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "orange.fr"},
            timeout=30
        )
        assert response.status_code == 200, f"Analyze failed: {response.status_code}"
        data = response.json()
        
        cv = data.get("company_verification", {})
        if cv.get("verified"):
            # For verified companies, the final_score should be reduced
            # We can't directly test the 20-point reduction without knowing the original score,
            # but we can verify the score is reasonable for a legitimate company
            final_score = data.get("final_score", 100)
            risk_level = data.get("risk_level", "")
            
            # A verified major company like Orange should have a low risk score
            assert final_score < 60, f"Verified company should have reduced risk score, got: {final_score}"
            print(f"✓ orange.fr risk score reduced: final_score={final_score}, risk_level={risk_level}")
        else:
            pytest.skip("orange.fr not verified in this run - may be API issue")
    
    def test_company_cache_source(self):
        """Company cache in MongoDB stores results to avoid repeated API calls"""
        # First request - should hit Pappers API
        response1 = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "societe-generale.fr"},
            timeout=30
        )
        assert response1.status_code == 200
        data1 = response1.json()
        cv1 = data1.get("company_verification", {})
        source1 = cv1.get("source", "")
        
        # Second request - should hit cache
        response2 = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "societe-generale.fr"},
            timeout=30
        )
        assert response2.status_code == 200
        data2 = response2.json()
        cv2 = data2.get("company_verification", {})
        source2 = cv2.get("source", "")
        
        # At least one should be from cache (if first was pappers, second should be cache)
        # Or both could be cache if already cached from previous tests
        assert source2 in ["cache", "pappers"], f"Second request source should be cache or pappers: {source2}"
        
        # Verify both return same verification status
        assert cv1.get("verified") == cv2.get("verified"), "Cache should return same verification status"
        
        print(f"✓ Company cache working: first={source1}, second={source2}")
    
    def test_company_verification_fields_complete(self):
        """Verify company object has all expected fields when verified"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "orange.fr"},
            timeout=30
        )
        assert response.status_code == 200
        data = response.json()
        
        cv = data.get("company_verification", {})
        if cv.get("verified") and cv.get("company"):
            company = cv["company"]
            
            # Check expected fields exist (may be empty but should be present)
            expected_fields = ["name", "siren", "activity", "city"]
            for field in expected_fields:
                assert field in company, f"Field '{field}' missing from company object: {company}"
            
            print(f"✓ Company fields complete: name={company.get('name')}, siren={company.get('siren')}, activity={company.get('activity')}, city={company.get('city')}")
        else:
            pytest.skip("orange.fr not verified - cannot test company fields")
    
    def test_authenticated_analysis_includes_company_verification(self):
        """Authenticated analysis also includes company verification"""
        # Login first
        login_response = requests.post(
            f"{BASE_URL}/api/auth/login",
            json={"email": "demo@test.com", "password": "demo123"},
            timeout=10
        )
        
        if login_response.status_code != 200:
            pytest.skip("Demo user login failed - skipping authenticated test")
        
        token = login_response.json().get("token")
        headers = {"Authorization": f"Bearer {token}"}
        
        # Analyze with auth
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "orange.fr"},
            headers=headers,
            timeout=30
        )
        assert response.status_code == 200
        data = response.json()
        
        assert "company_verification" in data, "Authenticated analysis should include company_verification"
        cv = data["company_verification"]
        assert "verified" in cv, "verified field should be present"
        
        print(f"✓ Authenticated analysis includes company_verification: verified={cv.get('verified')}")


class TestCompanyVerificationEdgeCases:
    """Edge case tests for company verification"""
    
    def test_www_prefix_handled(self):
        """Domain with www prefix should still be verified"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "www.orange.fr"},
            timeout=30
        )
        assert response.status_code == 200
        data = response.json()
        
        cv = data.get("company_verification", {})
        # www.orange.fr should resolve to same company as orange.fr
        print(f"✓ www.orange.fr company_verification: verified={cv.get('verified')}")
    
    def test_https_url_handled(self):
        """Full HTTPS URL should be handled correctly"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "https://orange.fr"},
            timeout=30
        )
        assert response.status_code == 200
        data = response.json()
        
        cv = data.get("company_verification", {})
        assert "verified" in cv, "company_verification should be present for https URL"
        print(f"✓ https://orange.fr company_verification: verified={cv.get('verified')}")
    
    def test_subdomain_handled(self):
        """Subdomain should extract main domain for verification"""
        response = requests.post(
            f"{BASE_URL}/api/analyze",
            json={"url": "www.particuliers.societegenerale.fr"},
            timeout=30
        )
        assert response.status_code == 200
        data = response.json()
        
        cv = data.get("company_verification", {})
        # Should still attempt verification based on domain
        assert "verified" in cv, "company_verification should be present"
        print(f"✓ Subdomain handled: verified={cv.get('verified')}")


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
