"""
SecureLink Network Checks Module
Performs DNS resolution, SSL/TLS verification, WHOIS lookup, and reverse DNS.
"""
import socket
import ssl
import logging
from urllib.parse import urlparse
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor, as_completed

logger = logging.getLogger(__name__)

TIMEOUT = 4  # seconds per check


def _parse_domain(url):
    """Extract domain from URL."""
    if not url.startswith(("http://", "https://")):
        url = "http://" + url
    parsed = urlparse(url)
    domain = parsed.netloc.split(":")[0].strip()
    return domain


def check_dns(domain):
    """Check if domain resolves via DNS."""
    result = {
        "check": "dns",
        "status": "unknown",
        "exists": False,
        "ip_addresses": [],
        "error": None,
    }
    try:
        ips = socket.getaddrinfo(domain, None, socket.AF_UNSPEC, socket.SOCK_STREAM)
        unique_ips = list(set(addr[4][0] for addr in ips))
        result["exists"] = len(unique_ips) > 0
        result["ip_addresses"] = unique_ips[:5]
        result["status"] = "resolved" if unique_ips else "no_record"
    except socket.gaierror:
        result["status"] = "not_found"
        result["error"] = "Domain does not resolve"
    except Exception as e:
        result["status"] = "error"
        result["error"] = str(e)[:100]
    return result


def check_ssl(domain):
    """Verify SSL/TLS certificate and analyze certificate chain."""
    result = {
        "check": "ssl",
        "status": "unknown",
        "valid": False,
        "issuer": None,
        "expires": None,
        "days_until_expiry": None,
        "protocol": None,
        "error": None,
        "chain": None,
    }
    try:
        ctx = ssl.create_default_context()
        with socket.create_connection((domain, 443), timeout=TIMEOUT) as sock:
            with ctx.wrap_socket(sock, server_hostname=domain) as ssock:
                cert = ssock.getpeercert()
                result["valid"] = True
                result["status"] = "valid"
                result["protocol"] = ssock.version()

                issuer_dict = dict(x[0] for x in cert.get("issuer", []))
                result["issuer"] = issuer_dict.get("organizationName", issuer_dict.get("commonName", "Unknown"))

                not_after = cert.get("notAfter", "")
                if not_after:
                    exp_date = datetime.strptime(not_after, "%b %d %H:%M:%S %Y %Z").replace(tzinfo=timezone.utc)
                    result["expires"] = exp_date.strftime("%Y-%m-%d")
                    result["days_until_expiry"] = (exp_date - datetime.now(timezone.utc)).days

                result["chain"] = _analyze_certificate_chain(cert, domain)

    except ssl.SSLCertVerificationError:
        result["status"] = "invalid"
        result["error"] = "Invalid certificate"
    except (socket.timeout, ConnectionRefusedError, OSError):
        result["status"] = "no_ssl"
        result["error"] = "No SSL/TLS on port 443"
    except Exception as e:
        result["status"] = "error"
        result["error"] = str(e)[:100]
    return result


def _analyze_certificate_chain(cert, domain):
    """Analyze the leaf certificate for chain-level anomalies."""
    chain_info = {
        "subject": None,
        "issuer_cn": None,
        "issuer_org": None,
        "self_signed": False,
        "san_count": 0,
        "san_domains": [],
        "wildcard": False,
        "cert_type": "unknown",
        "validity_days": None,
        "anomalies": [],
    }

    subject_dict = dict(x[0] for x in cert.get("subject", []))
    issuer_dict = dict(x[0] for x in cert.get("issuer", []))

    subject_cn = subject_dict.get("commonName", "")
    issuer_cn = issuer_dict.get("commonName", "")
    issuer_org = issuer_dict.get("organizationName", "")

    chain_info["subject"] = subject_cn
    chain_info["issuer_cn"] = issuer_cn
    chain_info["issuer_org"] = issuer_org

    if subject_cn == issuer_cn and not issuer_org:
        chain_info["self_signed"] = True
        chain_info["anomalies"].append({
            "id": "CHAIN_SELF_SIGNED",
            "severity": "high",
            "description_fr": "Certificat auto-signe : aucune autorite de certification n'a verifie ce site.",
            "description_en": "Self-signed certificate: no certificate authority has verified this site.",
        })

    san_entries = cert.get("subjectAltName", ())
    dns_names = [name for typ, name in san_entries if typ == "DNS"]
    chain_info["san_count"] = len(dns_names)
    chain_info["san_domains"] = dns_names[:10]

    if any(name.startswith("*.") for name in dns_names):
        chain_info["wildcard"] = True

    EV_ISSUERS = {"DigiCert", "GlobalSign", "Sectigo", "Entrust", "Comodo"}
    DV_FREE_ISSUERS = {"Let's Encrypt", "ZeroSSL", "Buypass", "Google Trust Services"}

    if any(ev in issuer_org for ev in EV_ISSUERS):
        chain_info["cert_type"] = "OV/EV"
    elif any(dv in issuer_org or dv in issuer_cn for dv in DV_FREE_ISSUERS):
        chain_info["cert_type"] = "DV"
    else:
        chain_info["cert_type"] = "DV"

    not_before = cert.get("notBefore", "")
    not_after = cert.get("notAfter", "")
    if not_before and not_after:
        try:
            start = datetime.strptime(not_before, "%b %d %H:%M:%S %Y %Z").replace(tzinfo=timezone.utc)
            end = datetime.strptime(not_after, "%b %d %H:%M:%S %Y %Z").replace(tzinfo=timezone.utc)
            chain_info["validity_days"] = (end - start).days

            if chain_info["validity_days"] < 30:
                chain_info["anomalies"].append({
                    "id": "CHAIN_SHORT_LIVED",
                    "severity": "medium",
                    "description_fr": f"Certificat a duree tres courte ({chain_info['validity_days']} jours) — typique des sites ephemeres de phishing.",
                    "description_en": f"Very short-lived certificate ({chain_info['validity_days']} days) — typical of ephemeral phishing sites.",
                })

            now = datetime.now(timezone.utc)
            if now < start:
                chain_info["anomalies"].append({
                    "id": "CHAIN_NOT_YET_VALID",
                    "severity": "high",
                    "description_fr": "Le certificat n'est pas encore valide (date de debut dans le futur).",
                    "description_en": "Certificate is not yet valid (start date is in the future).",
                })
        except ValueError:
            pass

    if chain_info["san_count"] > 200:
        chain_info["anomalies"].append({
            "id": "CHAIN_EXCESSIVE_SANS",
            "severity": "low",
            "description_fr": f"Certificat couvrant un nombre anormalement eleve de domaines ({chain_info['san_count']} SANs).",
            "description_en": f"Certificate covers abnormally many domains ({chain_info['san_count']} SANs).",
        })

    domain_lower = domain.lower()
    if dns_names and domain_lower:
        matched = False
        for san in dns_names:
            san_l = san.lower()
            if san_l == domain_lower:
                matched = True
                break
            if san_l.startswith("*."):
                wildcard_base = san_l[2:]
                if domain_lower.endswith(wildcard_base):
                    matched = True
                    break
        if not matched:
            chain_info["anomalies"].append({
                "id": "CHAIN_SAN_MISMATCH",
                "severity": "high",
                "description_fr": f"Le domaine {domain} ne figure pas dans les noms alternatifs du certificat.",
                "description_en": f"Domain {domain} is not listed in the certificate's Subject Alternative Names.",
            })

    return chain_info


def check_whois(domain):
    """Look up WHOIS data for domain age."""
    result = {
        "check": "whois",
        "status": "unknown",
        "creation_date": None,
        "domain_age_days": None,
        "registrar": None,
        "error": None,
    }
    try:
        import whois
        w = whois.whois(domain)
        creation = w.creation_date
        if isinstance(creation, list):
            creation = creation[0]
        if creation:
            if not creation.tzinfo:
                creation = creation.replace(tzinfo=timezone.utc)
            result["creation_date"] = creation.strftime("%Y-%m-%d")
            result["domain_age_days"] = (datetime.now(timezone.utc) - creation).days
            result["status"] = "found"
        else:
            result["status"] = "no_data"

        registrar = w.registrar
        if registrar:
            result["registrar"] = str(registrar)[:80]
    except Exception as e:
        result["status"] = "error"
        result["error"] = str(e)[:100]
    return result


def check_reverse_dns(ip):
    """Perform reverse DNS lookup."""
    result = {
        "check": "rdns",
        "status": "unknown",
        "ip": ip,
        "reverse_hostname": None,
        "consistent": None,
        "error": None,
    }
    try:
        hostname, _, _ = socket.gethostbyaddr(ip)
        result["reverse_hostname"] = hostname
        result["status"] = "found"
    except socket.herror:
        result["status"] = "no_record"
        result["error"] = "No reverse DNS record"
    except Exception as e:
        result["status"] = "error"
        result["error"] = str(e)[:100]
    return result


def run_network_checks(url):
    """Run all network checks in parallel. Returns dict of results + risk score adjustment."""
    domain = _parse_domain(url)
    if not domain:
        return {"checks": {}, "network_score": 0, "network_risk_factors": []}

    checks = {}
    risk_factors = []
    score_adjustment = 0

    # Run DNS, SSL, WHOIS in parallel threads
    with ThreadPoolExecutor(max_workers=3) as executor:
        futures = {
            executor.submit(check_dns, domain): "dns",
            executor.submit(check_ssl, domain): "ssl",
            executor.submit(check_whois, domain): "whois",
        }
        try:
            for future in as_completed(futures, timeout=10):
                name = futures[future]
                try:
                    checks[name] = future.result()
                except Exception:
                    checks[name] = {"check": name, "status": "timeout", "error": "Check timed out"}
        except TimeoutError:
            for future, name in futures.items():
                if name not in checks:
                    checks[name] = {"check": name, "status": "timeout", "error": "Check timed out"}

    # Reverse DNS (needs IP from DNS result)
    dns_result = checks.get("dns", {})
    if dns_result.get("ip_addresses"):
        ip = dns_result["ip_addresses"][0]
        rdns = check_reverse_dns(ip)
        if rdns.get("reverse_hostname"):
            rhost = rdns["reverse_hostname"].lower()
            domain_lower = domain.lower()
            domain_parts = domain_lower.split(".")
            base = domain_parts[-2] if len(domain_parts) >= 2 else domain_lower
            # Known CDN/cloud reverse DNS patterns (not suspicious)
            cdn_patterns = ["1e100.net", "cloudfront.net", "akamai", "fastly", "cloudflare",
                            "amazonaws.com", "azure", "googleusercontent", "google.com",
                            "fbcdn.net", "edgekey.net", "msedge.net", "github.io"]
            is_cdn = any(p in rhost for p in cdn_patterns)
            rdns["consistent"] = (base in rhost) or (domain_lower in rhost) or is_cdn
        checks["rdns"] = rdns
    else:
        checks["rdns"] = {"check": "rdns", "status": "skipped", "error": "No IP to check"}

    # --- Scoring based on network checks ---

    # DNS: domain doesn't exist = very suspicious
    if not dns_result.get("exists"):
        score_adjustment += 20
        risk_factors.append({
            "id": "NET_NO_DNS",
            "severity": "high",
            "description_fr": "Le domaine ne resout pas en DNS — ce site n'existe pas ou a ete desactive.",
            "description_en": "Domain does not resolve in DNS — this site doesn't exist or was taken down.",
        })

    # SSL: no valid certificate
    ssl_result = checks.get("ssl", {})
    if ssl_result.get("status") == "invalid":
        score_adjustment += 15
        risk_factors.append({
            "id": "NET_INVALID_SSL",
            "severity": "high",
            "description_fr": "Le certificat SSL est invalide — la connexion n'est pas securisee.",
            "description_en": "SSL certificate is invalid — the connection is not secure.",
        })
    elif ssl_result.get("status") == "no_ssl":
        score_adjustment += 10
        risk_factors.append({
            "id": "NET_NO_SSL",
            "severity": "medium",
            "description_fr": "Aucun certificat SSL detecte sur le port 443.",
            "description_en": "No SSL certificate detected on port 443.",
        })
    elif ssl_result.get("valid") and ssl_result.get("days_until_expiry") is not None:
        if ssl_result["days_until_expiry"] < 7:
            score_adjustment += 5
            risk_factors.append({
                "id": "NET_SSL_EXPIRING",
                "severity": "low",
                "description_fr": f"Le certificat SSL expire dans {ssl_result['days_until_expiry']} jour(s).",
                "description_en": f"SSL certificate expires in {ssl_result['days_until_expiry']} day(s).",
            })
        elif ssl_result["days_until_expiry"] > 30:
            score_adjustment -= 5  # Good sign

    # WHOIS: very young domain
    whois_result = checks.get("whois", {})
    age = whois_result.get("domain_age_days")
    if age is not None:
        if age < 30:
            score_adjustment += 20
            risk_factors.append({
                "id": "NET_NEW_DOMAIN",
                "severity": "high",
                "description_fr": f"Domaine cree il y a seulement {age} jour(s) — les domaines de phishing sont souvent tres recents.",
                "description_en": f"Domain created only {age} day(s) ago — phishing domains are often very new.",
            })
        elif age < 180:
            score_adjustment += 10
            risk_factors.append({
                "id": "NET_YOUNG_DOMAIN",
                "severity": "medium",
                "description_fr": f"Domaine relativement recent ({age} jours).",
                "description_en": f"Relatively new domain ({age} days old).",
            })
        elif age > 365 * 3:
            score_adjustment -= 5  # Established domain

    # Reverse DNS: inconsistent
    rdns_result = checks.get("rdns", {})
    if rdns_result.get("consistent") is False:
        score_adjustment += 5
        risk_factors.append({
            "id": "NET_RDNS_MISMATCH",
            "severity": "low",
            "description_fr": "Le DNS inverse ne correspond pas au domaine — hebergement suspect.",
            "description_en": "Reverse DNS doesn't match the domain — suspicious hosting.",
        })

    # Certificate chain anomalies
    chain_data = ssl_result.get("chain")
    if chain_data and chain_data.get("anomalies"):
        for anomaly in chain_data["anomalies"]:
            risk_factors.append(anomaly)
            if anomaly["severity"] == "high":
                score_adjustment += 15
            elif anomaly["severity"] == "medium":
                score_adjustment += 8
            elif anomaly["severity"] == "low":
                score_adjustment += 3

    return {
        "checks": checks,
        "network_score": max(-15, min(40, score_adjustment)),
        "network_risk_factors": risk_factors,
    }
