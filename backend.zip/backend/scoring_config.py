"""
Configuration centralisee du scoring SecureLink.
Tous les poids, seuils et constantes du moteur hybride sont definis ici.
"""

# Poids de la formule hybride (total = 1.0)
WEIGHTS = {
    "ml": 0.35,
    "rules": 0.20,
    "network": 0.15,
    "content": 0.15,
    "safe_browsing": 0.10,
    "kit_detection": 0.05,
}

# Seuils du feu tricolore
THRESHOLDS = {
    "suspicious": 30,
    "dangerous": 55,
}

# Seuils pour declarer un site "hors ligne" (inexistant)
# DNS echoue ET aucun signal fort de phishing
OFFLINE_DETECTION = {
    "max_rules_score": 20,
    "max_ml_score": 40,
}

# Hard overrides (planchers de score)
OVERRIDES = {
    "safe_browsing_threat": 75,
    "kit_with_login": 70,
    "typosquatting": 70,
}

# Penalites de redirection
REDIRECT = {
    "cross_domain_penalty": 15,
    "multi_hop_penalty": 10,
    "multi_hop_threshold": 3,
}

# Penalite SPA (page JS-only)
SPA = {
    "min_visible_text": 200,
    "min_html_size": 5000,
    "penalty": 5,
}

# Bonus de legitimite
LEGITIMACY = {
    "min_trust_signals": 3,
    "domain_age_strong_days": 730,
    "domain_age_strong_bonus": -15,
    "domain_age_moderate_days": 365,
    "domain_age_moderate_bonus": -5,
    "ssl_tls_bonus": -5,
    "safe_browsing_clean_bonus": -5,
    "whitelist_bonus": -20,
    "whitelist_trust_signals": 2,
}

# Raccourcisseurs d'URL connus
URL_SHORTENERS = {
    "bit.ly", "t.co", "tinyurl.com", "goo.gl", "ow.ly", "is.gd",
    "buff.ly", "adf.ly", "j.mp", "soo.gd", "s.id", "rb.gy",
    "cutt.ly", "shorturl.at", "tiny.cc", "lnkd.in",
}
