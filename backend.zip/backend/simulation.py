"""
SecureLink Phishing Simulation Module
Provides realistic phishing email scenarios for interactive training.
"""
import random

SIMULATION_SCENARIOS = [
    # === PHISHING EMAILS ===
    {
        "id": "sim_01",
        "is_phishing": True,
        "difficulty": 1,
        "sender_name": "Service Client PayPaI",
        "sender_email": "security@paypa1-verify.com",
        "subject_fr": "Action requise: Verifiez votre compte immediatement",
        "subject_en": "Action required: Verify your account immediately",
        "body_fr": "Cher utilisateur,\n\nNous avons detecte une activite suspecte sur votre compte. Pour eviter la suspension de votre compte, veuillez verifier vos informations en cliquant sur le lien ci-dessous dans les 24 heures.\n\nVerifier mon compte: http://paypa1-verify.com/secure/login\n\nSi vous ne verificz pas votre compte, il sera suspendu definitivement.\n\nCordialement,\nL'equipe de securite PayPaI",
        "body_en": "Dear user,\n\nWe have detected suspicious activity on your account. To avoid account suspension, please verify your information by clicking the link below within 24 hours.\n\nVerify my account: http://paypa1-verify.com/secure/login\n\nIf you do not verify your account, it will be permanently suspended.\n\nBest regards,\nPayPaI Security Team",
        "indicators_fr": [
            "L'expediteur utilise 'PayPaI' (avec un I majuscule) au lieu de 'PayPal'",
            "Le domaine 'paypa1-verify.com' n'est pas le domaine officiel paypal.com",
            "Urgence artificielle: menace de suspension dans 24h",
            "Le lien utilise HTTP au lieu de HTTPS",
            "Faute d'orthographe: 'verificz' au lieu de 'verifiez'",
        ],
        "indicators_en": [
            "The sender uses 'PayPaI' (with capital I) instead of 'PayPal'",
            "The domain 'paypa1-verify.com' is not the official paypal.com domain",
            "Artificial urgency: threat of suspension within 24h",
            "The link uses HTTP instead of HTTPS",
            "The email creates fear to push immediate action",
        ],
    },
    {
        "id": "sim_02",
        "is_phishing": True,
        "difficulty": 2,
        "sender_name": "Amazon Customer Service",
        "sender_email": "order-update@amazn-delivery.net",
        "subject_fr": "Votre commande #AMZ-38291 ne peut pas etre livree",
        "subject_en": "Your order #AMZ-38291 cannot be delivered",
        "body_fr": "Bonjour,\n\nNous n'avons pas pu livrer votre commande #AMZ-38291 en raison d'une adresse incomplete. Veuillez mettre a jour vos informations de livraison pour recevoir votre colis.\n\nMettre a jour l'adresse: https://amazn-delivery.net/update-address?ref=38291\n\nSi nous ne recevons pas de reponse sous 48h, votre commande sera retournee a l'expediteur.\n\nMerci,\nAmazon Service Client",
        "body_en": "Hello,\n\nWe were unable to deliver your order #AMZ-38291 due to an incomplete address. Please update your delivery information to receive your package.\n\nUpdate address: https://amazn-delivery.net/update-address?ref=38291\n\nIf we don't receive a response within 48h, your order will be returned to the sender.\n\nThank you,\nAmazon Customer Service",
        "indicators_fr": [
            "Le domaine 'amazn-delivery.net' n'est pas amazon.com ou amazon.fr",
            "Vous n'avez probablement pas passe cette commande",
            "Urgence: menace de retour sous 48h",
            "Le numero de commande ne suit pas le format Amazon standard",
        ],
        "indicators_en": [
            "The domain 'amazn-delivery.net' is not amazon.com",
            "You probably didn't place this order",
            "Urgency: threat of return within 48h",
            "The order number doesn't follow Amazon's standard format",
        ],
    },
    {
        "id": "sim_03",
        "is_phishing": True,
        "difficulty": 2,
        "sender_name": "Direction des Finances Publiques",
        "sender_email": "remboursement@impots-gouv.info",
        "subject_fr": "Remboursement de 387,50 EUR en votre faveur",
        "subject_en": "Tax refund of 387.50 EUR in your favor",
        "body_fr": "Madame, Monsieur,\n\nApres le dernier calcul de votre activite fiscale, nous avons determine que vous etes eligible pour un remboursement de 387,50 EUR.\n\nPour recevoir votre remboursement rapidement, veuillez remplir le formulaire de remboursement:\nhttps://impots-gouv.info/remboursement/formulaire\n\nVous devrez fournir vos coordonnees bancaires pour le virement.\n\nCordialement,\nDirection Generale des Finances Publiques",
        "body_en": "Dear Sir/Madam,\n\nAfter the last calculation of your tax activity, we have determined that you are eligible for a refund of 387.50 EUR.\n\nTo receive your refund quickly, please fill out the refund form:\nhttps://impots-gouv.info/remboursement/formulaire\n\nYou will need to provide your bank details for the transfer.\n\nBest regards,\nGeneral Directorate of Public Finances",
        "indicators_fr": [
            "Le domaine 'impots-gouv.info' n'est pas le site officiel impots.gouv.fr",
            "Les impots ne demandent jamais vos coordonnees bancaires par email",
            "Montant precis pour creer un sentiment de legitimite",
            "L'administration fiscale utilise votre espace personnel, pas des emails",
        ],
        "indicators_en": [
            "The domain 'impots-gouv.info' is not the official impots.gouv.fr",
            "Tax authorities never ask for bank details via email",
            "Precise amount to create a sense of legitimacy",
            "Tax administration uses your personal space, not emails",
        ],
    },
    {
        "id": "sim_04",
        "is_phishing": True,
        "difficulty": 3,
        "sender_name": "Microsoft 365",
        "sender_email": "no-reply@microsoft-365-security.com",
        "subject_fr": "Alerte de securite: connexion inhabituelle detectee",
        "subject_en": "Security alert: unusual sign-in detected",
        "body_fr": "Bonjour,\n\nNous avons detecte une connexion a votre compte Microsoft depuis un appareil non reconnu:\n\nLocalisation: Lagos, Nigeria\nAppareil: Chrome sur Windows\nHeure: Aujourd'hui a 03:42 UTC\n\nSi ce n'est pas vous, securisez votre compte immediatement:\nhttps://microsoft-365-security.com/account/verify\n\nSi c'etait bien vous, ignorez ce message.\n\nMicrosoft Security Team",
        "body_en": "Hello,\n\nWe detected a sign-in to your Microsoft account from an unrecognized device:\n\nLocation: Lagos, Nigeria\nDevice: Chrome on Windows\nTime: Today at 03:42 UTC\n\nIf this wasn't you, secure your account immediately:\nhttps://microsoft-365-security.com/account/verify\n\nIf this was you, please disregard this message.\n\nMicrosoft Security Team",
        "indicators_fr": [
            "Le domaine 'microsoft-365-security.com' n'est pas microsoft.com",
            "Microsoft utilise account.live.com ou login.microsoftonline.com",
            "L'email cree de la panique avec une localisation alarmante",
            "Les vraies alertes Microsoft dirigent vers votre portail de securite",
        ],
        "indicators_en": [
            "The domain 'microsoft-365-security.com' is not microsoft.com",
            "Microsoft uses account.live.com or login.microsoftonline.com",
            "The email creates panic with an alarming location",
            "Real Microsoft alerts direct to your security portal",
        ],
    },
    {
        "id": "sim_05",
        "is_phishing": True,
        "difficulty": 3,
        "sender_name": "La Banque Postale",
        "sender_email": "service@labanquepostale-secure.fr",
        "subject_fr": "Mise a jour obligatoire de votre espace client",
        "subject_en": "Mandatory update of your client area",
        "body_fr": "Cher(e) client(e),\n\nSuite aux nouvelles reglementations europeennes DSP2, nous vous demandons de mettre a jour vos informations de securite avant le 15 du mois.\n\nSans cette mise a jour, l'acces a votre espace client sera temporairement restreint.\n\nProceder a la mise a jour: https://labanquepostale-secure.fr/dsp2/update\n\nNous vous remercions de votre comprehension.\n\nLa Banque Postale - Service Securite",
        "body_en": "Dear customer,\n\nFollowing the new European DSP2 regulations, we ask you to update your security information before the 15th of the month.\n\nWithout this update, access to your client area will be temporarily restricted.\n\nProceed with the update: https://labanquepostale-secure.fr/dsp2/update\n\nThank you for your understanding.\n\nLa Banque Postale - Security Service",
        "indicators_fr": [
            "Le domaine 'labanquepostale-secure.fr' n'est pas labanquepostale.fr",
            "Les banques ne demandent pas de mises a jour par email",
            "Reference a DSP2 pour paraitre legitime (technique courante)",
            "Menace de restriction d'acces pour creer l'urgence",
        ],
        "indicators_en": [
            "The domain 'labanquepostale-secure.fr' is not labanquepostale.fr",
            "Banks do not request updates via email",
            "DSP2 reference to appear legitimate (common technique)",
            "Threat of access restriction to create urgency",
        ],
    },
    # === LEGITIMATE EMAILS ===
    {
        "id": "sim_06",
        "is_phishing": False,
        "difficulty": 1,
        "sender_name": "GitHub",
        "sender_email": "noreply@github.com",
        "subject_fr": "[GitHub] Nouvelle pull request sur votre repository",
        "subject_en": "[GitHub] New pull request on your repository",
        "body_fr": "Bonjour,\n\nUne nouvelle pull request a ete ouverte sur votre repository 'my-project':\n\n#42 - Fix typo in README.md\nPar: johndoe\n\nVoir la pull request: https://github.com/username/my-project/pull/42\n\nVous recevez cette notification car vous etes le proprietaire de ce repository.\n\n--- \nGitHub, Inc. 88 Colin P Kelly Jr St, San Francisco, CA 94107",
        "body_en": "Hello,\n\nA new pull request was opened on your repository 'my-project':\n\n#42 - Fix typo in README.md\nBy: johndoe\n\nView the pull request: https://github.com/username/my-project/pull/42\n\nYou are receiving this because you are the owner of this repository.\n\n--- \nGitHub, Inc. 88 Colin P Kelly Jr St, San Francisco, CA 94107",
        "indicators_fr": [
            "Le domaine github.com est authentique",
            "Le lien pointe vers github.com directement",
            "Pas d'urgence ni de menace",
            "Contenu coherent avec l'activite GitHub",
            "Adresse physique de l'entreprise en bas de page",
        ],
        "indicators_en": [
            "The github.com domain is authentic",
            "The link points directly to github.com",
            "No urgency or threats",
            "Content consistent with GitHub activity",
            "Company physical address at the bottom",
        ],
    },
    {
        "id": "sim_07",
        "is_phishing": False,
        "difficulty": 1,
        "sender_name": "Netflix",
        "sender_email": "info@account.netflix.com",
        "subject_fr": "Votre recu de paiement Netflix",
        "subject_en": "Your Netflix payment receipt",
        "body_fr": "Bonjour,\n\nVotre paiement mensuel de 13,49 EUR a ete traite avec succes.\n\nDetails:\n- Plan: Standard\n- Date: 25 fevrier 2026\n- Moyen de paiement: Visa se terminant par 4829\n\nGerez votre compte sur https://www.netflix.com/youraccount\n\nCordialement,\nL'equipe Netflix",
        "body_en": "Hello,\n\nYour monthly payment of 13.49 EUR has been processed successfully.\n\nDetails:\n- Plan: Standard\n- Date: February 25, 2026\n- Payment method: Visa ending in 4829\n\nManage your account at https://www.netflix.com/youraccount\n\nBest regards,\nThe Netflix Team",
        "indicators_fr": [
            "Le domaine account.netflix.com est un sous-domaine officiel",
            "Le lien pointe vers netflix.com",
            "Information coherente avec un abonnement",
            "Pas de demande d'action urgente",
            "Montre uniquement les 4 derniers chiffres de la carte",
        ],
        "indicators_en": [
            "The domain account.netflix.com is an official subdomain",
            "The link points to netflix.com",
            "Information consistent with a subscription",
            "No urgent action request",
            "Only shows last 4 digits of the card",
        ],
    },
    {
        "id": "sim_08",
        "is_phishing": False,
        "difficulty": 2,
        "sender_name": "Google",
        "sender_email": "no-reply@accounts.google.com",
        "subject_fr": "Alerte de securite: nouvelle connexion a votre compte Google",
        "subject_en": "Security alert: New sign-in to your Google account",
        "body_fr": "Bonjour,\n\nUne nouvelle connexion a votre compte Google a ete detectee.\n\nAppareil: iPhone de l'utilisateur\nLocalisation: Paris, France\nHeure: 25 fevr. 2026, 14:23 CET\n\nSi c'etait vous, aucune action n'est necessaire.\n\nSi ce n'etait pas vous, consultez l'activite de votre compte:\nhttps://myaccount.google.com/notifications\n\nCordialement,\nL'equipe Google",
        "body_en": "Hello,\n\nA new sign-in to your Google Account was detected.\n\nDevice: User's iPhone\nLocation: Paris, France\nTime: Feb 25, 2026, 2:23 PM CET\n\nIf this was you, no action is needed.\n\nIf this wasn't you, review your account activity:\nhttps://myaccount.google.com/notifications\n\nBest regards,\nThe Google Team",
        "indicators_fr": [
            "Le domaine accounts.google.com est officiel",
            "Le lien pointe vers myaccount.google.com (domaine officiel)",
            "Pas de panique: 'si c'etait vous, aucune action n'est necessaire'",
            "Informations detaillees et coherentes",
        ],
        "indicators_en": [
            "The domain accounts.google.com is official",
            "The link points to myaccount.google.com (official domain)",
            "No panic: 'if this was you, no action is needed'",
            "Detailed and coherent information",
        ],
    },
    {
        "id": "sim_09",
        "is_phishing": True,
        "difficulty": 1,
        "sender_name": "WhatsApp Support",
        "sender_email": "support@whatsapp-verify.org",
        "subject_fr": "Votre compte WhatsApp sera desactive demain",
        "subject_en": "Your WhatsApp account will be deactivated tomorrow",
        "body_fr": "URGENT\n\nVotre numero de telephone n'a pas ete verifie. Votre compte WhatsApp sera desactive dans les prochaines 24 heures.\n\nCliquez ici pour verifier: http://whatsapp-verify.org/verify-now\n\nNe perdez pas vos messages et contacts!\n\nL'equipe WhatsApp",
        "body_en": "URGENT\n\nYour phone number has not been verified. Your WhatsApp account will be deactivated within the next 24 hours.\n\nClick here to verify: http://whatsapp-verify.org/verify-now\n\nDon't lose your messages and contacts!\n\nThe WhatsApp Team",
        "indicators_fr": [
            "WhatsApp ne contacte pas par email pour la verification",
            "Le domaine 'whatsapp-verify.org' n'est pas whatsapp.com",
            "Ton tres urgent: 'URGENT', 'dans les prochaines 24 heures'",
            "WhatsApp gere la verification directement dans l'app",
            "Utilise HTTP au lieu de HTTPS",
        ],
        "indicators_en": [
            "WhatsApp doesn't contact via email for verification",
            "The domain 'whatsapp-verify.org' is not whatsapp.com",
            "Very urgent tone: 'URGENT', 'within the next 24 hours'",
            "WhatsApp handles verification directly in the app",
            "Uses HTTP instead of HTTPS",
        ],
    },
    {
        "id": "sim_10",
        "is_phishing": False,
        "difficulty": 2,
        "sender_name": "LinkedIn",
        "sender_email": "messages-noreply@linkedin.com",
        "subject_fr": "Marie Dupont a consulte votre profil",
        "subject_en": "Marie Dupont viewed your profile",
        "body_fr": "Bonjour,\n\n1 personne a consulte votre profil cette semaine.\n\nMarie Dupont - Responsable RH chez TechCorp\n\nVoir qui a consulte votre profil:\nhttps://www.linkedin.com/me/profile-views/\n\nAmeliorez la visibilite de votre profil avec LinkedIn Premium.\n\nCordialement,\nL'equipe LinkedIn\n\nLinkedIn Ireland Unlimited Company, Wilton Place, Dublin 2, Irlande",
        "body_en": "Hello,\n\n1 person viewed your profile this week.\n\nMarie Dupont - HR Manager at TechCorp\n\nSee who viewed your profile:\nhttps://www.linkedin.com/me/profile-views/\n\nImprove your profile visibility with LinkedIn Premium.\n\nBest regards,\nThe LinkedIn Team\n\nLinkedIn Ireland Unlimited Company, Wilton Place, Dublin 2, Ireland",
        "indicators_fr": [
            "Le domaine linkedin.com est officiel",
            "Le lien pointe vers linkedin.com",
            "Contenu coherent avec les notifications LinkedIn",
            "Adresse physique de l'entreprise presente",
            "Pas d'urgence ni de menace",
        ],
        "indicators_en": [
            "The linkedin.com domain is official",
            "The link points to linkedin.com",
            "Content consistent with LinkedIn notifications",
            "Company physical address present",
            "No urgency or threats",
        ],
    },
    {
        "id": "sim_11",
        "is_phishing": True,
        "difficulty": 3,
        "sender_name": "Apple ID",
        "sender_email": "noreply@apple-id-support.com",
        "subject_fr": "Votre identifiant Apple a ete verrouille",
        "subject_en": "Your Apple ID has been locked",
        "body_fr": "Cher client Apple,\n\nPour votre protection, votre identifiant Apple a ete verrouille en raison de multiples tentatives de connexion echouees.\n\nPour deverrouiller votre compte, veuillez confirmer votre identite:\nhttps://apple-id-support.com/unlock\n\nSi vous ne deverrouillez pas votre compte dans les 12 heures, toutes vos donnees iCloud seront supprimees.\n\nSupport Apple",
        "body_en": "Dear Apple customer,\n\nFor your protection, your Apple ID has been locked due to multiple failed sign-in attempts.\n\nTo unlock your account, please verify your identity:\nhttps://apple-id-support.com/unlock\n\nIf you don't unlock your account within 12 hours, all your iCloud data will be deleted.\n\nApple Support",
        "indicators_fr": [
            "Le domaine 'apple-id-support.com' n'est pas apple.com ou icloud.com",
            "Apple ne menace jamais de supprimer vos donnees iCloud",
            "Urgence extreme: '12 heures' pour pousser a l'action",
            "Apple utilise appleid.apple.com pour la gestion de compte",
        ],
        "indicators_en": [
            "The domain 'apple-id-support.com' is not apple.com or icloud.com",
            "Apple never threatens to delete your iCloud data",
            "Extreme urgency: '12 hours' to push to action",
            "Apple uses appleid.apple.com for account management",
        ],
    },
    {
        "id": "sim_12",
        "is_phishing": False,
        "difficulty": 3,
        "sender_name": "Stripe",
        "sender_email": "receipts+acct@stripe.com",
        "subject_fr": "Recu de paiement - Facture #INV-2026-0892",
        "subject_en": "Payment receipt - Invoice #INV-2026-0892",
        "body_fr": "Votre paiement a ete traite.\n\nMontant: 29,99 EUR\nDescription: Abonnement Pro - Fevrier 2026\nDate: 25 fevrier 2026\nMethode: Mastercard se terminant par 1234\n\nTelecharger le recu: https://pay.stripe.com/receipts/INV-2026-0892\n\nQuestions? Contactez le marchand directement.\n\nStripe, 354 Oyster Point Blvd, South San Francisco, CA 94080",
        "body_en": "Your payment has been processed.\n\nAmount: 29.99 EUR\nDescription: Pro Subscription - February 2026\nDate: February 25, 2026\nMethod: Mastercard ending in 1234\n\nDownload receipt: https://pay.stripe.com/receipts/INV-2026-0892\n\nQuestions? Contact the merchant directly.\n\nStripe, 354 Oyster Point Blvd, South San Francisco, CA 94080",
        "indicators_fr": [
            "Le domaine stripe.com et pay.stripe.com sont officiels",
            "Format professionnel et coherent",
            "Adresse physique de l'entreprise",
            "Seuls les 4 derniers chiffres de la carte sont affiches",
            "Pas d'urgence ni de menace",
        ],
        "indicators_en": [
            "The stripe.com and pay.stripe.com domains are official",
            "Professional and consistent format",
            "Company physical address",
            "Only last 4 digits of the card displayed",
            "No urgency or threats",
        ],
    },
]


def get_random_scenarios(count=5, difficulty=None):
    """Get random simulation scenarios, balanced between phishing and legitimate."""
    pool = SIMULATION_SCENARIOS
    if difficulty:
        pool = [s for s in pool if s["difficulty"] == difficulty]
    if not pool:
        pool = SIMULATION_SCENARIOS

    # Try to balance phishing/legit
    phishing = [s for s in pool if s["is_phishing"]]
    legit = [s for s in pool if not s["is_phishing"]]

    count = min(count, len(pool))
    phishing_count = count // 2 + (count % 2)
    legit_count = count - phishing_count

    selected = random.sample(phishing, min(phishing_count, len(phishing)))
    selected += random.sample(legit, min(legit_count, len(legit)))
    random.shuffle(selected)

    # Return without indicators (those are revealed after answering)
    return [{k: v for k, v in s.items() if not k.startswith("indicators")} for s in selected]


def get_scenario_by_id(scenario_id):
    """Get a specific scenario with all indicators."""
    for s in SIMULATION_SCENARIOS:
        if s["id"] == scenario_id:
            return s
    return None
