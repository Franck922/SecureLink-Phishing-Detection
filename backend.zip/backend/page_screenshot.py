"""
SecureLink Page Screenshot Module
Captures a visual thumbnail of the analyzed page using a headless browser.
Returns a base64-encoded JPEG image.

Runs Playwright in a separate subprocess to avoid event loop conflicts
with uvicorn on Windows (Python 3.14+).
"""
import asyncio
import json
import logging
import socket
import subprocess
import sys
import ipaddress
from pathlib import Path
from urllib.parse import urlparse

logger = logging.getLogger(__name__)

BLOCKED_HOSTS = {"localhost", "127.0.0.1", "0.0.0.0", "::1", "[::1]"}
WORKER_SCRIPT = str(Path(__file__).parent / "screenshot_worker.py")
SUBPROCESS_TIMEOUT = 25  # seconds


def _is_private_ip(hostname):
    """SSRF protection: block private/loopback IPs."""
    if hostname in BLOCKED_HOSTS:
        return True
    try:
        addr = socket.gethostbyname(hostname)
        ip = ipaddress.ip_address(addr)
        return ip.is_private or ip.is_loopback or ip.is_reserved or ip.is_link_local
    except (socket.gaierror, ValueError):
        return False


def _run_worker(url):
    """Run the screenshot worker script as a separate process."""
    try:
        proc = subprocess.run(
            [sys.executable, WORKER_SCRIPT, url],
            capture_output=True,
            text=True,
            timeout=SUBPROCESS_TIMEOUT,
        )
        if proc.returncode == 0 and proc.stdout.strip():
            return json.loads(proc.stdout.strip())
        else:
            logger.warning(f"Screenshot worker failed: exit={proc.returncode}, stderr={proc.stderr[:200]}")
            return {"captured": False, "image_base64": None, "error": "worker_failed"}
    except subprocess.TimeoutExpired:
        return {"captured": False, "image_base64": None, "error": "timeout"}
    except Exception as e:
        logger.warning(f"Screenshot subprocess error: {e}")
        return {"captured": False, "image_base64": None, "error": "subprocess_error"}


async def capture_screenshot(url):
    """Capture a screenshot of the given URL.
    Returns dict with base64 image data or error info.
    """
    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    # SSRF protection
    try:
        parsed = urlparse(url)
        hostname = parsed.hostname or ""
        if _is_private_ip(hostname):
            return {"captured": False, "image_base64": None, "error": "blocked_private_ip"}
    except Exception:
        return {"captured": False, "image_base64": None, "error": "invalid_url"}

    # Run in thread to avoid blocking the async event loop
    return await asyncio.to_thread(_run_worker, url)
