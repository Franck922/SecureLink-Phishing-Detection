"""
SecureLink JWT Authentication Utilities
"""
import os
import jwt
import bcrypt
import logging
from datetime import datetime, timezone, timedelta
from fastapi import Request

logger = logging.getLogger(__name__)

SECRET_KEY = os.environ.get("JWT_SECRET")
if not SECRET_KEY:
    logger.warning("JWT_SECRET not set — using generated fallback. Set JWT_SECRET in .env for production.")
    import secrets
    SECRET_KEY = secrets.token_hex(32)
ALGORITHM = "HS256"
TOKEN_EXPIRY_HOURS = 72


def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')


def verify_password(password: str, hashed: str) -> bool:
    return bcrypt.checkpw(password.encode('utf-8'), hashed.encode('utf-8'))


def create_token(user_id: str, email: str) -> str:
    payload = {
        "user_id": user_id,
        "email": email,
        "exp": datetime.now(timezone.utc) + timedelta(hours=TOKEN_EXPIRY_HOURS),
        "iat": datetime.now(timezone.utc),
    }
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)


def decode_token(token: str) -> dict:
    try:
        return jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
    except jwt.ExpiredSignatureError:
        return None
    except jwt.InvalidTokenError:
        return None


async def get_current_user(request: Request, db) -> dict:
    """Extract and validate user from Authorization header. Returns None if not authenticated."""
    auth_header = request.headers.get("Authorization", "")
    if not auth_header.startswith("Bearer "):
        return None

    token = auth_header.split(" ")[1]
    payload = decode_token(token)
    if not payload:
        return None

    user = await db.users.find_one(
        {"id": payload.get("user_id")},
        {"_id": 0}
    )
    return user
