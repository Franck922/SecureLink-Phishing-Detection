"""
SecureLink Company Verifier
Checks if a domain belongs to a known registered French company using Pappers API.
Uses content-based signals (SIREN, company name from HTML) for accurate matching.
Falls back silently if no API key or no credits remaining.
Results are cached in MongoDB to minimize API calls.
"""
import os
import re
import logging
from datetime import datetime, timezone

import requests

logger = logging.getLogger(__name__)

PAPPERS_API_URL = "https://api.pappers.fr/v2/recherche"
PAPPERS_COMPANY_URL = "https://api.pappers.fr/v2/entreprise"
CACHE_TTL_DAYS = 30


def _get_api_key():
    """Get Pappers API key from environment."""
    key = os.environ.get("PAPPERS_API_KEY", "").strip()
    return key if key else None


def _extract_company_name_from_domain(domain):
    """Extract a likely company name from a domain."""
    domain = domain.lower().strip()
    parts = domain.split(".")
    if parts[0] == "www":
        parts = parts[1:]
    tlds = {"fr", "com", "net", "org", "eu", "io", "co", "uk", "de", "es", "it", "be", "ch"}
    while len(parts) > 1 and parts[-1] in tlds:
        parts.pop()
    name = " ".join(parts)
    name = re.sub(r"[-_]", " ", name)
    return name.strip()


def _split_compound_name(name):
    """Try to split a compound domain name into words."""
    KNOWN_SPLITS = {
        "bnpparibas": "bnp paribas",
        "creditagricole": "credit agricole",
        "creditlyonnais": "credit lyonnais",
        "caissedepargne": "caisse d epargne",
        "labanquepostale": "la banque postale",
        "societegenerale": "societe generale",
        "francetelecom": "france telecom",
        "airfrance": "air france",
    }
    clean = name.lower().replace(" ", "").replace("-", "")
    if clean in KNOWN_SPLITS:
        return KNOWN_SPLITS[clean]
    split = re.sub(r'([a-z])([A-Z])', r'\1 \2', name)
    if split != name:
        return split.lower()
    return None


def lookup_by_siren(siren, api_key):
    """Look up a company directly by SIREN number. Most reliable method."""
    try:
        resp = requests.get(
            PAPPERS_COMPANY_URL,
            params={"siren": siren, "api_token": api_key},
            timeout=5,
        )
        if resp.status_code == 401:
            logger.info("Pappers API: no credits remaining")
            return None
        if resp.status_code == 404:
            return {}  # SIREN not found
        if resp.status_code != 200:
            return None
        data = resp.json()
        return {
            "name": data.get("nom_entreprise", ""),
            "denomination": data.get("denomination", data.get("nom_entreprise", "")),
            "siren": data.get("siren", siren),
            "legal_form": data.get("forme_juridique", ""),
            "naf_code": data.get("code_naf", ""),
            "activity": data.get("libelle_code_naf", ""),
            "city": data.get("siege", {}).get("ville", "") if data.get("siege") else "",
            "creation_date": data.get("date_creation", ""),
            "employees": data.get("effectif"),
            "revenue": data.get("chiffre_affaires"),
            "is_active": data.get("statut_rcs") != "Radié",
        }
    except Exception as e:
        logger.warning(f"Pappers SIREN lookup failed for {siren}: {e}")
        return None


def search_company(query, api_key, naf_prefix=None):
    """Search for a company by name using Pappers paid API.
    Optionally filter by NAF code prefix for more precise results.
    """
    try:
        params = {"q": query, "api_token": api_key, "par_page": 5}
        if naf_prefix:
            params["code_naf"] = naf_prefix
        resp = requests.get(PAPPERS_API_URL, params=params, timeout=5)
        if resp.status_code == 401:
            logger.info("Pappers API: no credits remaining")
            return None
        if resp.status_code != 200:
            return None
        data = resp.json()
        results = data.get("resultats", [])
        companies = []
        for r in results[:5]:
            companies.append({
                "name": r.get("nom_entreprise", ""),
                "denomination": r.get("denomination", r.get("nom_entreprise", "")),
                "siren": r.get("siren", ""),
                "legal_form": r.get("forme_juridique", ""),
                "naf_code": r.get("code_naf", ""),
                "activity": r.get("libelle_code_naf", ""),
                "city": r.get("siege", {}).get("ville", "") if r.get("siege") else "",
                "creation_date": r.get("date_creation", ""),
                "employees": r.get("effectif"),
                "revenue": r.get("chiffre_affaires"),
                "is_active": r.get("statut_rcs") != "Radié",
            })
        return companies
    except Exception as e:
        logger.warning(f"Pappers search failed for '{query}': {e}")
        return None


def _name_similarity(domain_name, company_name):
    """Check similarity between domain name and company name."""
    dn = domain_name.lower().strip()
    cn = company_name.lower().strip()

    stopwords = {"sa", "sas", "sarl", "eurl", "se", "de", "la", "le", "les", "du", "des", "et", "the", "of", "inc", "ltd", "group", "groupe", "france"}

    cn_nospace = cn.replace(" ", "").replace("-", "").replace("'", "")
    dn_nospace = dn.replace(" ", "").replace("-", "").replace("'", "")

    # Short domain names (< 5 chars): strict matching
    if len(dn_nospace) < 5:
        if dn_nospace == cn_nospace:
            return 1.0
        cn_words = [w for w in cn.replace("-", " ").replace("'", " ").split() if w not in stopwords]
        if len(cn_words) == 1 and cn_words[0] == dn_nospace:
            return 1.0
        if cn_words and cn_words[0] == dn_nospace and len(cn_words) <= 3:
            return 0.8
        return 0.0

    # Longer names: substring match
    if len(dn_nospace) >= 4 and (dn_nospace in cn_nospace or cn_nospace in dn_nospace):
        return 1.0

    # Word-level overlap
    dn_words = set(dn.replace("-", " ").split()) - stopwords
    cn_words = set(cn.replace("-", " ").replace("'", " ").split()) - stopwords
    if not cn_words or not dn_words:
        return 0
    intersection = dn_words & cn_words
    return len(intersection) / max(len(dn_words), 1)


async def verify_company(domain, db, content_signals=None):
    """Verify if a domain belongs to a known registered French company.
    
    Strategy:
    1. If SIREN found in page content → direct Pappers lookup (most reliable)
    2. If company name found in content → search Pappers with exact name
    3. Fallback: search by domain name (least reliable, only for longer names)
    
    Only triggers Pappers API when content signals are relevant.
    """
    domain = domain.lower().strip()
    if not domain:
        return {"verified": False, "company": None, "source": "none"}

    api_key = _get_api_key()
    if not api_key:
        return {"verified": False, "company": None, "source": "no_key"}

    signals = content_signals or {}
    signal_confidence = signals.get("confidence", 0)

    # Check cache first
    cached = await db.company_cache.find_one({"domain": domain}, {"_id": 0})
    if cached:
        cache_date = datetime.fromisoformat(cached["cached_at"]) if cached.get("cached_at") else None
        if cache_date and (datetime.now(timezone.utc) - cache_date).days < CACHE_TTL_DAYS:
            return {
                "verified": cached.get("verified", False),
                "company": cached.get("company"),
                "source": "cache",
            }

    verified = False
    matched_company = None
    method_used = "none"
    naf_prefix = signals.get("naf_prefix")
    sector_label = signals.get("activity_sector", "")

    # --- Strategy 1: Direct SIREN lookup (highest confidence) ---
    if signals.get("siren"):
        siren = signals["siren"]
        logger.info(f"Company verification: SIREN {siren} found in page content for {domain}")
        company = lookup_by_siren(siren, api_key)
        if company is None:
            # API error or no credits
            return {"verified": False, "company": None, "source": "api_unavailable"}
        if company and company.get("is_active"):
            verified = True
            matched_company = company
            method_used = "siren_from_content"

    # --- Strategy 2: Search by company name from content (with NAF filter) ---
    if not verified and signals.get("company_name"):
        content_name = signals["company_name"]
        logger.info(f"Company verification: name '{content_name}' + sector '{sector_label}' for {domain}")
        # First try with NAF filter for precision
        results = None
        if naf_prefix:
            results = search_company(content_name, api_key, naf_prefix=naf_prefix)
            if results is None:
                return {"verified": False, "company": None, "source": "api_unavailable"}
        # Fallback without NAF filter if no results with filter
        if not results:
            results = search_company(content_name, api_key)
        if results is None:
            return {"verified": False, "company": None, "source": "api_unavailable"}
        # Match: check if any result closely matches the name from content
        for company in (results or []):
            if not company.get("is_active"):
                continue
            names_to_check = [company.get("name", ""), company.get("denomination", "")]
            for name in names_to_check:
                if not name:
                    continue
                # More lenient matching since the name came from the page itself
                cn = name.lower().strip()
                qn = content_name.lower().strip()
                cn_clean = cn.replace(" ", "").replace("-", "").replace("'", "")
                qn_clean = qn.lower().replace(" ", "").replace("-", "").replace("'", "")
                if qn_clean in cn_clean or cn_clean in qn_clean:
                    verified = True
                    matched_company = company
                    method_used = "name_from_content"
                    break
                # Also check word overlap
                score = _name_similarity(qn, name)
                if score >= 0.6:
                    verified = True
                    matched_company = company
                    method_used = "name_from_content"
                    break
            if verified:
                break

    # --- Strategy 3: Fallback - search by domain name ---
    # Only for domains with enough characters (>= 5) and when content had some signals
    if not verified and signal_confidence >= 10:
        company_query = _extract_company_name_from_domain(domain)
        if company_query and len(company_query) >= 5:
            # Use NAF filter if detected from content
            results = search_company(company_query, api_key, naf_prefix=naf_prefix)
            if results is None:
                return {"verified": False, "company": None, "source": "api_unavailable"}
            if not results:
                split_query = _split_compound_name(company_query)
                if split_query:
                    results = search_company(split_query, api_key)
                    if results is None:
                        return {"verified": False, "company": None, "source": "api_unavailable"}
                    if results:
                        company_query = split_query

            best_score = 0
            for company in (results or []):
                if not company.get("is_active"):
                    continue
                names_to_check = [company.get("name", ""), company.get("denomination", "")]
                for name in names_to_check:
                    if not name:
                        continue
                    score = _name_similarity(company_query, name)
                    if score < 0.5:
                        continue
                    try:
                        if company.get("employees") and int(str(company["employees"])) > 50:
                            score += 0.1
                    except (ValueError, TypeError):
                        pass
                    if score > best_score:
                        best_score = score
                        verified = True
                        matched_company = company
                        method_used = "domain_name_fallback"

    # Cache the result
    cache_record = {
        "domain": domain,
        "verified": verified,
        "company": matched_company,
        "method": method_used,
        "cached_at": datetime.now(timezone.utc).isoformat(),
    }
    await db.company_cache.update_one(
        {"domain": domain},
        {"$set": cache_record},
        upsert=True,
    )

    return {
        "verified": verified,
        "company": matched_company,
        "source": "pappers",
        "method": method_used,
    }
