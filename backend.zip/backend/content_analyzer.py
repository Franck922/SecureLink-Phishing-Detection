"""
SecureLink Content Analyzer
Fetches and analyzes the HTML content of target pages for phishing indicators.
"""
import re
import socket
import ipaddress
import logging
from urllib.parse import urlparse
from concurrent.futures import ThreadPoolExecutor

import requests

logger = logging.getLogger(__name__)

TIMEOUT = 6
MAX_CONTENT_SIZE = 500_000  # 500KB max

KNOWN_BRANDS = [
    "paypal", "google", "facebook", "microsoft", "apple", "amazon",
    "netflix", "instagram", "twitter", "linkedin", "dropbox", "adobe",
    "outlook", "office365", "icloud", "chase", "wellsfargo", "bankofamerica",
    "citibank", "hsbc", "barclays", "bnp", "societe generale", "credit agricole",
    "la poste", "colissimo", "chronopost", "dhl", "ups", "fedex",
    "caf", "ameli", "impots", "free", "orange", "sfr", "bouygues",
]

SUSPICIOUS_JS_PATTERNS = [
    r"eval\s*\(",
    r"document\.write\s*\(",
    r"unescape\s*\(",
    r"fromCharCode",
    r"atob\s*\(",
    r"\.innerHTML\s*=",
    r"window\.location\s*=",
    r"document\.cookie",
    r"XMLHttpRequest",
    r"navigator\.credentials",
]

BLOCKED_HOSTS = {"localhost", "127.0.0.1", "0.0.0.0", "::1", "[::1]"}


def is_private_ip(hostname):
    """Check if a hostname resolves to a private/loopback IP (SSRF protection)."""
    if hostname in BLOCKED_HOSTS:
        return True
    try:
        addr = socket.gethostbyname(hostname)
        ip = ipaddress.ip_address(addr)
        return ip.is_private or ip.is_loopback or ip.is_reserved or ip.is_link_local
    except (socket.gaierror, ValueError):
        return False


def fetch_page(url):
    """Fetch the HTML content of a page with SSRF protection.
    Also tracks the full redirect chain.
    """
    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    redirect_chain = []

    try:
        parsed = urlparse(url)
        hostname = parsed.hostname or ""
        if is_private_ip(hostname):
            logger.warning(f"SSRF blocked: {hostname} resolves to private IP")
            return None, url, 0, redirect_chain

        # Follow redirects manually to track each hop
        current_url = url
        visited = set()
        max_redirects = 10

        for i in range(max_redirects):
            if current_url in visited:
                redirect_chain.append({
                    "step": i + 1,
                    "url": current_url,
                    "status": 0,
                    "note": "redirect_loop",
                })
                break
            visited.add(current_url)

            # SSRF check for each redirect destination
            hop_parsed = urlparse(current_url)
            hop_host = hop_parsed.hostname or ""
            if is_private_ip(hop_host):
                redirect_chain.append({
                    "step": i + 1,
                    "url": current_url,
                    "status": 0,
                    "note": "ssrf_blocked",
                })
                break

            resp = requests.get(
                current_url,
                timeout=TIMEOUT,
                headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) SecureLink/1.0"},
                allow_redirects=False,
                stream=True,
            )

            redirect_chain.append({
                "step": i + 1,
                "url": current_url,
                "status": resp.status_code,
                "domain": hop_host,
            })

            if resp.status_code in (301, 302, 303, 307, 308):
                next_url = resp.headers.get("Location", "")
                if not next_url:
                    break
                # Handle relative redirects
                if next_url.startswith("/"):
                    next_url = f"{hop_parsed.scheme}://{hop_host}{next_url}"
                current_url = next_url
            else:
                # Final destination - read content
                content_length = int(resp.headers.get("content-length", 0))
                if content_length > MAX_CONTENT_SIZE:
                    return None, current_url, resp.status_code, redirect_chain
                html = resp.text[:MAX_CONTENT_SIZE]
                return html, current_url, resp.status_code, redirect_chain

        # If we exhausted max redirects
        return None, current_url, 0, redirect_chain

    except Exception as e:
        logger.warning(f"Content fetch failed for {url}: {e}")
        return None, url, 0, redirect_chain


def check_login_forms(html):
    """Detect credential-harvesting forms."""
    findings = []
    password_inputs = len(re.findall(r'<input[^>]*type\s*=\s*["\']password["\']', html, re.I))
    email_inputs = len(re.findall(r'<input[^>]*type\s*=\s*["\']email["\']', html, re.I))
    text_inputs = len(re.findall(r'<input[^>]*type\s*=\s*["\']text["\']', html, re.I))

    if password_inputs > 0:
        findings.append({
            "id": "LOGIN_FORM",
            "severity": "high",
            "description_fr": "La page contient un formulaire de connexion avec champ mot de passe.",
            "description_en": "The page contains a login form with a password field.",
            "tip_fr": "Verifiez que vous etes bien sur le site officiel avant de saisir vos identifiants.",
            "tip_en": "Make sure you are on the official site before entering your credentials.",
        })

    forms_with_action = re.findall(r'<form[^>]*action\s*=\s*["\']([^"\']*)["\']', html, re.I)
    for action in forms_with_action:
        if action.startswith("http") and not action.startswith("https"):
            findings.append({
                "id": "INSECURE_FORM_ACTION",
                "severity": "high",
                "description_fr": "Le formulaire envoie vos donnees via une connexion non securisee (HTTP).",
                "description_en": "The form sends your data over an insecure connection (HTTP).",
                "tip_fr": "Ne saisissez jamais de mot de passe sur un formulaire HTTP.",
                "tip_en": "Never enter a password on an HTTP form.",
            })
            break

    return findings, password_inputs


def check_brand_impersonation(html, domain):
    """Check for known brand names that don't match the domain."""
    findings = []
    html_lower = html.lower()
    domain_lower = domain.lower()

    for brand in KNOWN_BRANDS:
        if brand in domain_lower:
            continue
        title_match = re.search(r'<title[^>]*>(.*?)</title>', html, re.I | re.S)
        title_text = title_match.group(1).lower() if title_match else ""

        count_in_page = html_lower.count(brand)
        in_title = brand in title_text

        if in_title and count_in_page >= 2:
            findings.append({
                "id": "BRAND_IMPERSONATION",
                "severity": "high",
                "description_fr": f"La page mentionne '{brand}' dans son titre alors que le domaine ne correspond pas.",
                "description_en": f"The page mentions '{brand}' in its title while the domain doesn't match.",
                "tip_fr": f"Le vrai site de {brand} n'utiliserait pas le domaine {domain}.",
                "tip_en": f"The real {brand} site would not use the domain {domain}.",
                "brand": brand,
            })
            break

    return findings


def check_suspicious_scripts(html):
    """Detect potentially malicious JavaScript patterns."""
    findings = []
    matches = 0
    for pattern in SUSPICIOUS_JS_PATTERNS:
        found = len(re.findall(pattern, html, re.I))
        matches += found

    if matches >= 5:
        findings.append({
            "id": "SUSPICIOUS_SCRIPTS",
            "severity": "medium",
            "description_fr": "La page contient des scripts potentiellement suspects.",
            "description_en": "The page contains potentially suspicious scripts.",
            "tip_fr": "Du code JavaScript suspect peut etre utilise pour voler vos donnees.",
            "tip_en": "Suspicious JavaScript code can be used to steal your data.",
        })

    return findings, matches


def check_hidden_elements(html):
    """Detect hidden iframes, forms, and inputs."""
    findings = []
    hidden_iframes = len(re.findall(r'<iframe[^>]*(?:style\s*=\s*["\'][^"\']*(?:display\s*:\s*none|visibility\s*:\s*hidden|width\s*:\s*0|height\s*:\s*0))', html, re.I))
    hidden_iframes += len(re.findall(r'<iframe[^>]*(?:width\s*=\s*["\']0|height\s*=\s*["\']0)', html, re.I))

    if hidden_iframes > 0:
        findings.append({
            "id": "HIDDEN_IFRAME",
            "severity": "high",
            "description_fr": "La page contient des elements caches (iframes invisibles).",
            "description_en": "The page contains hidden elements (invisible iframes).",
            "tip_fr": "Les iframes cachees peuvent charger du contenu malveillant a votre insu.",
            "tip_en": "Hidden iframes can load malicious content without your knowledge.",
        })

    return findings


def check_meta_redirect(html):
    """Detect auto-redirect via meta tags."""
    findings = []
    meta_refresh = re.findall(r'<meta[^>]*http-equiv\s*=\s*["\']refresh["\'][^>]*content\s*=\s*["\']([^"\']*)["\']', html, re.I)
    for content in meta_refresh:
        if "url=" in content.lower():
            findings.append({
                "id": "META_REDIRECT",
                "severity": "medium",
                "description_fr": "La page effectue une redirection automatique vers un autre site.",
                "description_en": "The page automatically redirects to another site.",
                "tip_fr": "Les redirections automatiques peuvent vous emmener vers un site malveillant.",
                "tip_en": "Auto-redirects can take you to a malicious site.",
            })
            break

    return findings


def check_external_resources(html, domain):
    """Count external resources loaded from different domains."""
    findings = []
    srcs = re.findall(r'(?:src|href)\s*=\s*["\']https?://([^/\s"\']+)', html, re.I)
    external_domains = set()
    for src_domain in srcs:
        src_clean = src_domain.lower().split(":")[0]
        if domain.lower() not in src_clean and src_clean not in domain.lower():
            external_domains.add(src_clean)

    if len(external_domains) > 15:
        findings.append({
            "id": "MANY_EXTERNAL_RESOURCES",
            "severity": "low",
            "description_fr": f"La page charge des ressources depuis {len(external_domains)} domaines externes differents.",
            "description_en": f"The page loads resources from {len(external_domains)} different external domains.",
            "tip_fr": "Un grand nombre de domaines externes peut indiquer du tracking ou du contenu malveillant.",
            "tip_en": "Many external domains may indicate tracking or malicious content.",
        })

    return findings, len(external_domains)


def _follow_mentions_legales(html, base_url, signals):
    """Find and follow the 'mentions légales' link to extract SIREN/SIRET."""
    if not base_url:
        return signals

    # Find the link
    ml_patterns = [
        r'<a[^>]*href\s*=\s*["\']([^"\']*)["\'][^>]*>.*?(?:mentions?\s*l[eé]gales?|informations?\s*l[eé]gales?).*?</a>',
        r'<a[^>]*>.*?(?:mentions?\s*l[eé]gales?|informations?\s*l[eé]gales?).*?</a[^>]*href\s*=\s*["\']([^"\']*)["\']',
    ]

    ml_url = None
    for pattern in ml_patterns:
        match = re.search(pattern, html, re.I | re.S)
        if match:
            href = match.group(1).strip()
            if href and href != "#" and not href.startswith("javascript:"):
                ml_url = href
                break

    # Also try simpler pattern: any link containing "mentions-legales" or "legal" in href
    if not ml_url:
        href_match = re.search(r'<a[^>]*href\s*=\s*["\']([^"\']*(?:mentions?[-_]?l[eé]gales?|legal[-_]?notice|cgv|cgu)[^"\']*)["\']', html, re.I)
        if href_match:
            ml_url = href_match.group(1).strip()

    if not ml_url:
        return signals

    # Resolve relative URL
    parsed_base = urlparse(base_url)
    if ml_url.startswith("/"):
        ml_url = f"{parsed_base.scheme}://{parsed_base.hostname}{ml_url}"
    elif not ml_url.startswith("http"):
        ml_url = f"{parsed_base.scheme}://{parsed_base.hostname}/{ml_url}"

    # SSRF check
    ml_parsed = urlparse(ml_url)
    if is_private_ip(ml_parsed.hostname or ""):
        return signals

    # Fetch the mentions légales page
    try:
        resp = requests.get(
            ml_url,
            timeout=TIMEOUT,
            headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) SecureLink/1.0"},
            allow_redirects=True,
        )
        if resp.status_code != 200:
            return signals
        ml_html = resp.text[:MAX_CONTENT_SIZE]
    except Exception as e:
        logger.warning(f"Failed to fetch mentions légales at {ml_url}: {e}")
        return signals

    # Extract SIREN/SIRET from the mentions légales page
    # SIRET (14 digits)
    siret_matches = re.findall(r'(?:siret|SIRET)\s*[:.]?\s*(\d[\d\s]{12,16}\d)', ml_html)
    for match in siret_matches:
        digits = re.sub(r'\s', '', match)
        if len(digits) == 14:
            signals["siret"] = digits
            signals["siren"] = digits[:9]
            signals["confidence"] += 40
            logger.info(f"SIREN {digits[:9]} found in mentions légales page")
            return signals

    # SIREN (9 digits)
    siren_matches = re.findall(r'(?:siren|SIREN)\s*[:.]?\s*(\d[\d\s]{7,11}\d)', ml_html)
    for match in siren_matches:
        digits = re.sub(r'\s', '', match)
        if len(digits) == 9:
            signals["siren"] = digits
            signals["confidence"] += 35
            logger.info(f"SIREN {digits} found in mentions légales page")
            return signals

    # RCS pattern (RCS Ville 123 456 789)
    rcs_matches = re.findall(r'(?:RCS|rcs|R\.C\.S\.?)\s+\w+\s+(\d[\d\s]{7,11}\d)', ml_html)
    for match in rcs_matches:
        digits = re.sub(r'\s', '', match)
        if len(digits) == 9:
            signals["siren"] = digits
            signals["confidence"] += 35
            logger.info(f"SIREN {digits} found via RCS in mentions légales page")
            return signals

    # Also try to extract company name if not already found
    if not signals["company_name"]:
        # Look for company name near legal identifiers (must be properly capitalized)
        name_context = re.search(
            r'(?:raison\s*sociale|d[ée]nomination|[ée]diteur|[ée]dit[ée]\s*par)\s*[:.]?\s*([A-ZÀ-Ü][A-ZÀ-Ü\s\-\.]{2,60})',
            ml_html
        )
        if name_context:
            name = name_context.group(1).strip()
            # Validate: at least 2 chars, not just common words
            if len(name) >= 2 and name.upper() == name:
                signals["company_name"] = name
                signals["confidence"] += 15

    return signals


def extract_company_signals(html, base_url=None):
    """Extract company-related signals from HTML content.
    Looks for SIREN/SIRET, legal forms, company names, and deduces activity sector
    from semantic analysis of page content.
    """
    signals = {
        "siren": None,
        "siret": None,
        "company_name": None,
        "legal_form": None,
        "has_mentions_legales": False,
        "address": None,
        "confidence": 0,
        "activity_sector": None,
        "naf_prefix": None,
    }
    if not html:
        return signals

    html_lower = html.lower()
    # Strip HTML tags for cleaner text analysis
    text_content = re.sub(r'<[^>]+>', ' ', html_lower)
    text_content = re.sub(r'\s+', ' ', text_content)

    # 1. Look for SIREN (9 digits) and SIRET (14 digits)
    # SIRET first (more specific)
    siret_patterns = re.findall(r'(?:siret|SIRET)\s*[:.]?\s*(\d[\d\s]{12,16}\d)', html)
    for match in siret_patterns:
        digits = re.sub(r'\s', '', match)
        if len(digits) == 14:
            signals["siret"] = digits
            signals["siren"] = digits[:9]
            signals["confidence"] += 40
            break

    # SIREN if no SIRET found
    if not signals["siren"]:
        siren_patterns = re.findall(r'(?:siren|SIREN|RCS|rcs)\s*[:.]?\s*(\d[\d\s]{7,11}\d)', html)
        for match in siren_patterns:
            digits = re.sub(r'\s', '', match)
            if len(digits) == 9:
                signals["siren"] = digits
                signals["confidence"] += 35
                break

    # Also try RCS patterns like "RCS Paris 552 120 222"
    if not signals["siren"]:
        rcs_patterns = re.findall(r'(?:RCS|rcs)\s+\w+\s+(\d[\d\s]{7,11}\d)', html)
        for match in rcs_patterns:
            digits = re.sub(r'\s', '', match)
            if len(digits) == 9:
                signals["siren"] = digits
                signals["confidence"] += 35
                break

    # 2. Look for legal form mentions
    legal_forms = {
        "sas": "SAS", "sarl": "SARL", "sa ": "SA", "eurl": "EURL",
        "sci": "SCI", "sasu": "SASU", "snc": "SNC", "scop": "SCOP",
    }
    for key, form in legal_forms.items():
        if re.search(r'\b' + re.escape(key) + r'\b', html_lower):
            signals["legal_form"] = form
            signals["confidence"] += 5
            break

    # 3. Check for "mentions légales" section
    if any(term in html_lower for term in ["mentions légales", "mentions legales", "legal notice", "informations légales", "informations legales"]):
        signals["has_mentions_legales"] = True
        signals["confidence"] += 10

    # 4. Extract company name from structured data or meta tags FIRST (most reliable)
    # Try structured data (JSON-LD)
    jsonld_matches = re.findall(r'<script[^>]*type\s*=\s*["\']application/ld\+json["\'][^>]*>(.*?)</script>', html, re.I | re.S)
    for jsonld in jsonld_matches:
        try:
            import json
            data = json.loads(jsonld)
            if isinstance(data, list):
                data = data[0] if data else {}
            org_name = data.get("name") or data.get("legalName")
            if not org_name and data.get("@type") in ("Organization", "Corporation", "LocalBusiness"):
                org_name = data.get("name")
            if org_name and len(org_name) > 2:
                signals["company_name"] = org_name
                signals["confidence"] += 20
                break
        except (json.JSONDecodeError, TypeError, IndexError):
            continue

    # Try Open Graph / meta tags
    if not signals["company_name"]:
        og_site = re.search(r'<meta[^>]*property\s*=\s*["\']og:site_name["\'][^>]*content\s*=\s*["\']([^"\']+)["\']', html, re.I)
        if not og_site:
            og_site = re.search(r'<meta[^>]*content\s*=\s*["\']([^"\']+)["\'][^>]*property\s*=\s*["\']og:site_name["\']', html, re.I)
        if og_site:
            name = og_site.group(1).strip()
            if len(name) > 2 and len(name) < 100:
                signals["company_name"] = name
                signals["confidence"] += 10

    # 5. Follow "mentions légales" link to extract SIREN (after name extraction)
    if not signals["siren"] and signals["has_mentions_legales"]:
        signals = _follow_mentions_legales(html, base_url, signals)

    # Try footer content for company name near SIREN/legal form
    if not signals["company_name"] and signals["siren"]:
        # Look for text around SIREN mention
        siren_context = re.search(r'([^<]{0,200}(?:siren|SIREN|RCS|rcs)[^<]{0,200})', html, re.I)
        if siren_context:
            context = siren_context.group(1)
            # Extract capitalized company name
            name_match = re.search(r'([A-Z][A-Z\s\-]{2,50}?)(?:\s*[-–]\s*|\s+(?:SAS|SARL|SA|EURL|SASU)\b)', context)
            if name_match:
                signals["company_name"] = name_match.group(1).strip()
                signals["confidence"] += 15

    # 6. Semantic analysis — deduce activity sector from page content keywords
    sector = _detect_activity_sector(text_content)
    if sector:
        signals["activity_sector"] = sector["domain"]
        signals["naf_prefix"] = sector["naf_prefix"]
        signals["confidence"] += 10

    return signals


# Sector detection: keyword groups mapped to Pappers domaine_activite and NAF prefixes
SECTOR_KEYWORDS = [
    {
        "domain": "Enseignement",
        "naf_prefix": "85",
        "keywords": ["école", "ecole", "université", "universite", "campus", "étudiant", "etudiant",
                      "formation", "diplôme", "diplome", "licence", "master", "ingénieur", "ingenieur",
                      "pédagogie", "pedagogie", "enseignement", "apprentissage", "bac+", "admission",
                      "scolarité", "scolarite", "cursus", "programme scolaire", "académique", "academique"],
        "min_hits": 3,
    },
    {
        "domain": "Informatique",
        "naf_prefix": "62",
        "keywords": ["logiciel", "software", "développeur", "developpeur", "cloud", "saas", "api",
                      "data", "intelligence artificielle", "cybersécurité", "cybersecurite",
                      "hébergement", "hebergement", "serveur", "programmation", "code",
                      "numérique", "numerique", "digital", "startup", "tech"],
        "min_hits": 3,
    },
    {
        "domain": "Banque et assurance",
        "naf_prefix": "64",
        "keywords": ["banque", "crédit", "credit", "épargne", "epargne", "compte bancaire",
                      "prêt", "pret", "placement", "investissement", "livret", "carte bancaire",
                      "virement", "découvert", "assurance", "mutuelle", "sinistre", "cotisation"],
        "min_hits": 3,
    },
    {
        "domain": "Télécommunications",
        "naf_prefix": "61",
        "keywords": ["télécom", "telecom", "opérateur", "operateur", "mobile", "fibre",
                      "internet", "forfait", "réseau", "reseau", "5g", "4g", "box",
                      "abonnement", "data", "débit", "debit", "couverture"],
        "min_hits": 3,
    },
    {
        "domain": "Commerce",
        "naf_prefix": "47",
        "keywords": ["boutique", "magasin", "e-commerce", "panier", "commande", "livraison",
                      "acheter", "achat", "produit", "catalogue", "promo", "soldes",
                      "prix", "réduction", "reduction", "paiement", "checkout"],
        "min_hits": 3,
    },
    {
        "domain": "Santé",
        "naf_prefix": "86",
        "keywords": ["santé", "sante", "médecin", "medecin", "hôpital", "hopital", "clinique",
                      "patient", "consultation", "ordonnance", "pharmacie", "soin",
                      "diagnostic", "thérapie", "therapie", "médical", "medical"],
        "min_hits": 3,
    },
    {
        "domain": "Transport et logistique",
        "naf_prefix": "49",
        "keywords": ["transport", "logistique", "livraison", "colis", "expédition", "expedition",
                      "fret", "routier", "maritime", "aérien", "aerien", "entrepôt", "entrepot",
                      "supply chain", "suivi", "tracking", "transporteur"],
        "min_hits": 3,
    },
    {
        "domain": "Immobilier",
        "naf_prefix": "68",
        "keywords": ["immobilier", "logement", "appartement", "maison", "location", "louer",
                      "acheter", "vendre", "agence immobilière", "agence immobiliere", "syndic",
                      "copropriété", "copropriete", "bail", "propriétaire", "proprietaire"],
        "min_hits": 3,
    },
    {
        "domain": "Énergie",
        "naf_prefix": "35",
        "keywords": ["énergie", "energie", "électricité", "electricite", "gaz", "solaire",
                      "éolien", "eolien", "nucléaire", "nucleaire", "renouvelable",
                      "consommation", "compteur", "tarif", "kwh", "fournisseur"],
        "min_hits": 3,
    },
    {
        "domain": "Hébergement et restauration",
        "naf_prefix": "56",
        "keywords": ["restaurant", "hôtel", "hotel", "réservation", "reservation", "menu",
                      "cuisine", "chef", "chambre", "séjour", "sejour", "gastronomie",
                      "traiteur", "bar", "brasserie", "table"],
        "min_hits": 3,
    },
]


def _detect_activity_sector(text_content):
    """Detect the most likely activity sector from page text content.
    Returns the sector with the most keyword matches, or None.
    """
    best_match = None
    best_hits = 0

    for sector in SECTOR_KEYWORDS:
        hits = 0
        for kw in sector["keywords"]:
            count = text_content.count(kw)
            if count > 0:
                hits += min(count, 3)  # Cap at 3 per keyword to avoid bias from repeated words
        if hits >= sector["min_hits"] and hits > best_hits:
            best_hits = hits
            best_match = sector

    if best_match:
        return {"domain": best_match["domain"], "naf_prefix": best_match["naf_prefix"], "hits": best_hits}
    return None


def run_content_analysis(url):
    """Full content analysis of a page. Returns score, findings, and raw HTML."""
    from typosquatting_detector import detect_typosquatting

    result = {
        "content_score": 0,
        "content_findings": [],
        "page_fetched": False,
        "has_login_form": False,
        "brand_impersonation": None,
        "suspicious_scripts_count": 0,
        "external_domains_count": 0,
        "final_url": url,
        "company_signals": {},
        "raw_html": None,
        "redirect_chain": [],
        "typosquatting": {},
    }

    # Typosquatting detection (before fetching, based on domain only)
    parsed_input = urlparse(url if url.startswith(("http://", "https://")) else "https://" + url)
    input_domain = parsed_input.hostname or ""
    typo_result = detect_typosquatting(input_domain)
    result["typosquatting"] = typo_result

    if typo_result.get("is_typosquatting"):
        result["content_findings"].append({
            "id": "TYPOSQUATTING",
            "severity": "critical",
            "description_fr": f"Ce domaine imite la marque \"{typo_result['target_brand']}\" (technique : {typo_result['technique']}). Le vrai site est : {', '.join(typo_result['legitimate_domains'])}.",
            "description_en": f"This domain mimics the brand \"{typo_result['target_brand']}\" (technique: {typo_result['technique']}). The real site is: {', '.join(typo_result['legitimate_domains'])}.",
            "tip_fr": "Ne saisissez aucune information personnelle. Fermez cette page et accedez au vrai site directement.",
            "tip_en": "Do not enter any personal information. Close this page and access the real site directly.",
        })

    # Fetch page with redirect chain tracking
    html, final_url, status_code, redirect_chain = fetch_page(url)
    result["final_url"] = final_url
    result["redirect_chain"] = redirect_chain

    # Flag suspicious redirect chains
    if len(redirect_chain) >= 3:
        raw_domains = set(hop.get("domain", "") for hop in redirect_chain if hop.get("domain"))
        # Normalize: strip www. prefix for comparison
        domains_in_chain = set(d.replace("www.", "", 1) if d.startswith("www.") else d for d in raw_domains)
        if len(domains_in_chain) >= 2:
            result["content_findings"].append({
                "id": "MULTI_DOMAIN_REDIRECT",
                "severity": "high",
                "description_fr": f"Le lien traverse {len(redirect_chain)} redirections et {len(domains_in_chain)} domaines differents.",
                "description_en": f"The link goes through {len(redirect_chain)} redirects across {len(domains_in_chain)} different domains.",
                "tip_fr": "Les chaines de redirections complexes sont souvent utilisees pour masquer la destination reelle.",
                "tip_en": "Complex redirect chains are often used to hide the real destination.",
            })
    elif len(redirect_chain) >= 4:
        result["content_findings"].append({
            "id": "LONG_REDIRECT_CHAIN",
            "severity": "medium",
            "description_fr": f"Le lien traverse {len(redirect_chain)} redirections avant d'atteindre sa destination.",
            "description_en": f"The link goes through {len(redirect_chain)} redirects before reaching its destination.",
            "tip_fr": "Un nombre eleve de redirections peut indiquer une tentative de masquer l'URL reelle.",
            "tip_en": "A high number of redirects may indicate an attempt to hide the real URL.",
        })

    if not html or status_code == 0:
        return result

    result["page_fetched"] = True
    result["raw_html"] = html

    # Extract company signals from content (pass base_url for mentions légales follow)
    result["company_signals"] = extract_company_signals(html, base_url=final_url)

    # Check if redirected to a different domain
    parsed_final = urlparse(final_url)
    if parsed_input.netloc and parsed_final.netloc:
        orig_domain = parsed_input.netloc.lower().split(":")[0].lstrip("www.")
        final_domain = parsed_final.netloc.lower().split(":")[0].lstrip("www.")
        if orig_domain != final_domain:
            result["content_findings"].append({
                "id": "DOMAIN_REDIRECT",
                "severity": "medium",
                "description_fr": f"Le lien redirige vers un domaine different : {final_domain}.",
                "description_en": f"The link redirects to a different domain: {final_domain}.",
                "tip_fr": "Les redirections vers d'autres domaines peuvent cacher la destination reelle.",
                "tip_en": "Redirects to other domains can hide the real destination.",
            })

    domain = parsed_final.netloc.lower().split(":")[0] if parsed_final.netloc else ""

    # Run all checks
    login_findings, pw_count = check_login_forms(html)
    brand_findings = check_brand_impersonation(html, domain)
    script_findings, script_count = check_suspicious_scripts(html)
    hidden_findings = check_hidden_elements(html)
    meta_findings = check_meta_redirect(html)
    ext_findings, ext_count = check_external_resources(html, domain)

    all_findings = result["content_findings"] + login_findings + brand_findings + script_findings + hidden_findings + meta_findings + ext_findings
    result["content_findings"] = all_findings
    result["has_login_form"] = pw_count > 0
    result["brand_impersonation"] = brand_findings[0]["brand"] if brand_findings else None
    result["suspicious_scripts_count"] = script_count
    result["external_domains_count"] = ext_count

    # Calculate content score (0-100, higher = more suspicious)
    score = 0
    for finding in all_findings:
        sev = finding.get("severity", "low")
        if sev == "critical":
            score += 40
        elif sev == "high":
            score += 25
        elif sev == "medium":
            score += 15
        elif sev == "low":
            score += 5

    result["content_score"] = min(100, score)

    return result
