"""
SecureLink Export Module
Generates CSV and PDF reports for analyses and admin data.
"""
import csv
import io
from datetime import datetime, timezone
from fpdf import FPDF


def generate_analyses_csv(analyses, lang="fr"):
    """Generate CSV of analyses."""
    output = io.StringIO()
    writer = csv.writer(output)

    if lang == "fr":
        writer.writerow(["URL", "Niveau de risque", "Score final", "Score ML", "Score Regles", "Date d'analyse"])
    else:
        writer.writerow(["URL", "Risk Level", "Final Score", "ML Score", "Rules Score", "Analyzed At"])

    for a in analyses:
        writer.writerow([
            a.get("url", ""),
            a.get("risk_level", ""),
            a.get("final_score", ""),
            a.get("ml_score", ""),
            a.get("rules_score", ""),
            a.get("analyzed_at", ""),
        ])

    return output.getvalue()


def generate_users_csv(users, lang="fr"):
    """Generate CSV of users list."""
    output = io.StringIO()
    writer = csv.writer(output)

    if lang == "fr":
        writer.writerow(["Utilisateur", "Email", "XP", "Niveau", "Analyses", "Derniere activite", "Admin"])
    else:
        writer.writerow(["Username", "Email", "XP", "Level", "Analyses", "Last Active", "Admin"])

    for u in users:
        level_name = u.get("level", {})
        level_str = level_name.get("name_fr" if lang == "fr" else "name_en", "") if isinstance(level_name, dict) else str(level_name)
        writer.writerow([
            u.get("username", ""),
            u.get("email", ""),
            u.get("xp", 0),
            level_str,
            u.get("stats", {}).get("analyses_count", 0),
            u.get("last_active_date", ""),
            "Oui" if u.get("is_admin") else "Non" if lang == "fr" else "Yes" if u.get("is_admin") else "No",
        ])

    return output.getvalue()


class SecureLinkPDF(FPDF):
    def __init__(self, title="SecureLink Report", lang="fr"):
        super().__init__()
        self.report_title = title
        self.lang = lang

    def header(self):
        self.set_font("Helvetica", "B", 14)
        self.cell(0, 10, self.report_title, align="C", new_x="LMARGIN", new_y="NEXT")
        self.set_font("Helvetica", "", 8)
        date_str = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
        self.cell(0, 5, f"{'Genere le' if self.lang == 'fr' else 'Generated on'}: {date_str}", align="C", new_x="LMARGIN", new_y="NEXT")
        self.ln(5)

    def footer(self):
        self.set_y(-15)
        self.set_font("Helvetica", "I", 8)
        self.cell(0, 10, f"SecureLink - Page {self.page_no()}/{{nb}}", align="C")


def generate_analyses_pdf(analyses, lang="fr", title=None):
    """Generate PDF of analyses."""
    pdf_title = title or ("Rapport d'analyses SecureLink" if lang == "fr" else "SecureLink Analysis Report")
    pdf = SecureLinkPDF(title=pdf_title, lang=lang)
    pdf.alias_nb_pages()
    pdf.add_page()
    pdf.set_auto_page_break(auto=True, margin=20)

    # Summary
    total = len(analyses)
    safe = sum(1 for a in analyses if a.get("risk_level") == "SAFE")
    suspicious = sum(1 for a in analyses if a.get("risk_level") == "SUSPICIOUS")
    dangerous = sum(1 for a in analyses if a.get("risk_level") == "DANGEROUS")

    pdf.set_font("Helvetica", "B", 11)
    pdf.cell(0, 8, "Synthese" if lang == "fr" else "Summary", new_x="LMARGIN", new_y="NEXT")
    pdf.set_font("Helvetica", "", 9)
    pdf.cell(0, 6, f"Total: {total} | {'Surs' if lang == 'fr' else 'Safe'}: {safe} | {'Suspects' if lang == 'fr' else 'Suspicious'}: {suspicious} | {'Dangereux' if lang == 'fr' else 'Dangerous'}: {dangerous}", new_x="LMARGIN", new_y="NEXT")
    pdf.ln(5)

    # Table header
    pdf.set_font("Helvetica", "B", 8)
    pdf.set_fill_color(240, 240, 240)
    col_widths = [80, 25, 20, 20, 45]
    headers_list = ["URL", "Risque" if lang == "fr" else "Risk", "ML", "Rules" if lang == "fr" else "Rules", "Date"]
    for i, h in enumerate(headers_list):
        pdf.cell(col_widths[i], 7, h, border=1, fill=True)
    pdf.ln()

    # Table rows
    pdf.set_font("Helvetica", "", 7)
    for a in analyses[:200]:  # Limit to 200 for PDF
        url = a.get("url", "")
        if len(url) > 45:
            url = url[:42] + "..."
        risk = a.get("risk_level", "")
        ml = str(a.get("ml_score", ""))
        rules = str(a.get("rules_score", ""))
        date_str = a.get("analyzed_at", "")[:16]

        pdf.cell(col_widths[0], 6, url, border=1)
        pdf.cell(col_widths[1], 6, risk, border=1)
        pdf.cell(col_widths[2], 6, ml, border=1)
        pdf.cell(col_widths[3], 6, rules, border=1)
        pdf.cell(col_widths[4], 6, date_str, border=1)
        pdf.ln()

    return pdf.output()


def generate_admin_report_pdf(stats, lang="fr"):
    """Generate a comprehensive admin report PDF."""
    pdf_title = "Rapport administrateur SecureLink" if lang == "fr" else "SecureLink Admin Report"
    pdf = SecureLinkPDF(title=pdf_title, lang=lang)
    pdf.alias_nb_pages()
    pdf.add_page()
    pdf.set_auto_page_break(auto=True, margin=20)

    # Platform stats
    pdf.set_font("Helvetica", "B", 11)
    pdf.cell(0, 8, "Statistiques de la plateforme" if lang == "fr" else "Platform Statistics", new_x="LMARGIN", new_y="NEXT")
    pdf.ln(3)

    pdf.set_font("Helvetica", "", 9)
    stat_items = [
        ("Utilisateurs" if lang == "fr" else "Users", stats.get("total_users", 0)),
        ("Analyses totales" if lang == "fr" else "Total Analyses", stats.get("total_analyses", 0)),
        ("Contributions" if lang == "fr" else "Contributions", stats.get("total_contributions", 0)),
        ("Feedback" if lang == "fr" else "Feedback", stats.get("total_feedback", 0)),
        ("Precision ML" if lang == "fr" else "ML Accuracy", f"{stats.get('model_accuracy', 0)}%"),
        ("Echantillons" if lang == "fr" else "Training Samples", stats.get("training_samples", 0)),
    ]
    for label, value in stat_items:
        pdf.cell(60, 6, f"{label}:", new_x="RIGHT")
        pdf.set_font("Helvetica", "B", 9)
        pdf.cell(40, 6, str(value), new_x="LMARGIN", new_y="NEXT")
        pdf.set_font("Helvetica", "", 9)

    pdf.ln(5)

    # Risk distribution
    risk = stats.get("analyses_by_risk", {})
    pdf.set_font("Helvetica", "B", 11)
    pdf.cell(0, 8, "Repartition des risques" if lang == "fr" else "Risk Distribution", new_x="LMARGIN", new_y="NEXT")
    pdf.set_font("Helvetica", "", 9)
    pdf.cell(0, 6, f"{'Surs' if lang == 'fr' else 'Safe'}: {risk.get('safe', 0)} | {'Suspects' if lang == 'fr' else 'Suspicious'}: {risk.get('suspicious', 0)} | {'Dangereux' if lang == 'fr' else 'Dangerous'}: {risk.get('dangerous', 0)}", new_x="LMARGIN", new_y="NEXT")

    pdf.ln(5)

    # Weekly activity
    pdf.set_font("Helvetica", "B", 11)
    pdf.cell(0, 8, "Activite hebdomadaire" if lang == "fr" else "Weekly Activity", new_x="LMARGIN", new_y="NEXT")
    pdf.set_font("Helvetica", "", 9)
    pdf.cell(0, 6, f"{'Analyses cette semaine' if lang == 'fr' else 'Analyses this week'}: {stats.get('weekly_analyses', 0)}", new_x="LMARGIN", new_y="NEXT")
    pdf.cell(0, 6, f"{'Utilisateurs actifs' if lang == 'fr' else 'Active users'}: {stats.get('weekly_active_users', 0)}", new_x="LMARGIN", new_y="NEXT")

    return pdf.output()
