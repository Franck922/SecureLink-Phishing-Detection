"""
SecureLink LLM Helper
Interface unifiee pour le chatbot SecureBot via Google Gemini API.
"""
import os
import logging

logger = logging.getLogger(__name__)

_gemini_sessions = {}


async def send_chat_message(message, system_prompt, session_id):
    """Send a chat message to the Gemini LLM.
    Returns the raw text response from the model.
    """
    gemini_key = os.environ.get("GEMINI_API_KEY", "")

    if not gemini_key:
        raise ValueError("GEMINI_API_KEY non configure. Ajoutez votre cle dans backend/.env (https://aistudio.google.com/apikey)")

    return await _send_gemini(message, system_prompt, session_id, gemini_key)


async def _send_gemini(message, system_prompt, session_id, api_key):
    """Send message via Google Gemini SDK."""
    import google.generativeai as genai

    genai.configure(api_key=api_key)

    model = genai.GenerativeModel(
        model_name="gemini-2.5-flash",
        system_instruction=system_prompt,
    )

    if session_id in _gemini_sessions:
        chat = _gemini_sessions[session_id]
    else:
        chat = model.start_chat(history=[])
        _gemini_sessions[session_id] = chat
        if len(_gemini_sessions) > 200:
            oldest = list(_gemini_sessions.keys())[0]
            del _gemini_sessions[oldest]

    response = chat.send_message(message)
    return response.text
