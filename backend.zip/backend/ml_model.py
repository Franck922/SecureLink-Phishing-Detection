"""
SecureLink ML Model for Phishing URL Detection
Self-retraining Random Forest classifier with synthetic dataset generation
"""
import os
import re
import math
import random
import string
import logging
import numpy as np
from pathlib import Path
from urllib.parse import urlparse
import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

logger = logging.getLogger(__name__)

MODEL_PATH = Path(__file__).parent / "phishing_model.joblib"

SUSPICIOUS_TLDS = {'.tk', '.ml', '.ga', '.cf', '.gq', '.xyz', '.top', '.buzz', '.club', '.work', '.click', '.link', '.info', '.site', '.online', '.icu', '.fun', '.space', '.pw', '.cc', '.ws'}
SHORTENED_DOMAINS = {'bit.ly', 'tinyurl.com', 'goo.gl', 't.co', 'ow.ly', 'is.gd', 'buff.ly', 'adf.ly', 'tiny.cc', 'rb.gy', 'cutt.ly'}
LEGITIMATE_DOMAINS = {'google.com', 'facebook.com', 'youtube.com', 'amazon.com', 'wikipedia.org', 'twitter.com', 'instagram.com', 'linkedin.com', 'reddit.com', 'netflix.com', 'microsoft.com', 'apple.com', 'github.com', 'stackoverflow.com', 'paypal.com', 'ebay.com', 'spotify.com', 'zoom.us', 'office.com', 'outlook.com'}


def shannon_entropy(text):
    if not text:
        return 0
    freq = {}
    for c in text:
        freq[c] = freq.get(c, 0) + 1
    length = len(text)
    return -sum((count / length) * math.log2(count / length) for count in freq.values())


def extract_features(url):
    """Extract numerical features from a URL for ML prediction."""
    try:
        if not url.startswith(('http://', 'https://')):
            url = 'http://' + url
        parsed = urlparse(url)
        domain = parsed.netloc.lower().split(':')[0]
        path = parsed.path
        query = parsed.query
    except Exception:
        domain, path, query = '', '', ''

    has_ip = bool(re.match(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$', domain))
    tld = '.' + domain.split('.')[-1] if '.' in domain else ''
    subdomain_count = max(0, domain.count('.') - 1)
    digits_in_domain = sum(c.isdigit() for c in domain)
    has_at = '@' in url
    has_double_slash_redirect = '//' in url[8:]  # after protocol

    features = [
        len(url),                           # 0: url_length
        len(domain),                        # 1: domain_length
        1 if url.startswith('https') else 0,  # 2: has_https
        url.count('.'),                     # 3: num_dots
        url.count('-'),                     # 4: num_hyphens
        1 if has_at else 0,                 # 5: has_at
        digits_in_domain,                   # 6: digits_in_domain
        1 if has_ip else 0,                 # 7: has_ip
        1 if tld in SUSPICIOUS_TLDS else 0,  # 8: suspicious_tld
        shannon_entropy(domain),            # 9: domain_entropy
        len(path),                          # 10: path_length
        len(query),                         # 11: query_length
        1 if re.search(r':\d+', parsed.netloc) else 0,  # 12: has_port
        subdomain_count,                    # 13: subdomain_count
        sum(c in '!#$%^&*()+=[]{}|;:\'",<>?' for c in url),  # 14: special_chars
        1 if has_double_slash_redirect else 0,  # 15: has_redirect
        1 if domain in SHORTENED_DOMAINS else 0,  # 16: shortened_url
        url.count('/'),                     # 17: num_slashes
        sum(c.isdigit() for c in path),     # 18: digits_in_path
        1 if any(kw in url.lower() for kw in ['login', 'signin', 'verify', 'account', 'secure', 'update', 'confirm', 'bank', 'password']) else 0,  # 19: suspicious_keywords
    ]
    return features


FEATURE_NAMES = [
    'url_length', 'domain_length', 'has_https', 'num_dots', 'num_hyphens',
    'has_at', 'digits_in_domain', 'has_ip', 'suspicious_tld', 'domain_entropy',
    'path_length', 'query_length', 'has_port', 'subdomain_count', 'special_chars',
    'has_redirect', 'shortened_url', 'num_slashes', 'digits_in_path', 'suspicious_keywords'
]


def generate_synthetic_dataset(n_samples=3000):
    """Generate a synthetic dataset of phishing and legitimate URLs."""
    urls = []
    labels = []

    legit_domains = [
        'google.com', 'facebook.com', 'youtube.com', 'amazon.com', 'wikipedia.org',
        'twitter.com', 'instagram.com', 'linkedin.com', 'reddit.com', 'netflix.com',
        'microsoft.com', 'apple.com', 'github.com', 'stackoverflow.com', 'paypal.com',
        'ebay.com', 'spotify.com', 'zoom.us', 'office.com', 'outlook.com',
        'bbc.co.uk', 'nytimes.com', 'cnn.com', 'walmart.com', 'target.com',
        'bestbuy.com', 'chase.com', 'wellsfargo.com', 'bankofamerica.com', 'citibank.com'
    ]

    legit_paths = [
        '/search', '/products', '/about', '/contact', '/help', '/support',
        '/news', '/blog', '/articles', '/category/electronics', '/home',
        '/account/settings', '/en/page', '/fr/accueil', '/docs/api', ''
    ]

    # Generate legitimate URLs
    for _ in range(n_samples // 2):
        domain = random.choice(legit_domains)
        path = random.choice(legit_paths)
        https = random.choices(['https://', 'http://'], weights=[0.9, 0.1])[0]
        subdomain = random.choices(['www.', ''], weights=[0.4, 0.6])[0]
        url = f"{https}{subdomain}{domain}{path}"
        urls.append(url)
        labels.append(0)

    # Generate phishing URLs
    phishing_patterns = []
    for _ in range(n_samples // 2):
        pattern_type = random.choice(['typosquat', 'ip', 'suspicious_tld', 'long_subdomain', 'keyword_stuff', 'mixed'])

        if pattern_type == 'typosquat':
            base = random.choice(legit_domains).split('.')[0]
            typos = [base.replace('o', '0'), base.replace('l', '1'), base + 's', base[:-1], 'secure-' + base, base + '-login', base.replace('a', 'e')]
            typo = random.choice(typos)
            tld = random.choice(['.com', '.net', '.org', '.xyz', '.tk', '.ml'])
            url = f"http://{typo}{tld}/login/verify?id={''.join(random.choices(string.hexdigits, k=16))}"

        elif pattern_type == 'ip':
            ip = f"{random.randint(1,255)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(0,255)}"
            url = f"http://{ip}/{''.join(random.choices(string.ascii_lowercase, k=8))}/login.php"

        elif pattern_type == 'suspicious_tld':
            word = ''.join(random.choices(string.ascii_lowercase, k=random.randint(5, 15)))
            tld = random.choice(list(SUSPICIOUS_TLDS))
            url = f"http://{word}{tld}/verify-account/{random.randint(1000,9999)}"

        elif pattern_type == 'long_subdomain':
            base = random.choice(legit_domains)
            subdomains = '.'.join([''.join(random.choices(string.ascii_lowercase, k=random.randint(3, 8))) for _ in range(random.randint(2, 4))])
            url = f"http://{subdomains}.{base}/secure/login/confirm?token={''.join(random.choices(string.hexdigits, k=32))}"

        elif pattern_type == 'keyword_stuff':
            keywords = random.sample(['secure', 'login', 'verify', 'account', 'update', 'confirm', 'bank', 'password'], k=random.randint(2, 4))
            domain = '-'.join(keywords) + random.choice(['.com', '.net', '.xyz', '.tk'])
            url = f"http://{domain}/{''.join(random.choices(string.ascii_lowercase + string.digits, k=20))}"

        else:  # mixed
            base = random.choice(legit_domains).split('.')[0]
            tld = random.choice(list(SUSPICIOUS_TLDS))
            url = f"http://{base}-{''.join(random.choices(string.ascii_lowercase + string.digits, k=5))}{tld}/login?redirect={''.join(random.choices(string.hexdigits, k=24))}"

        phishing_patterns.append(url)
        urls.append(url)
        labels.append(1)

    return urls, labels


class PhishingModel:
    def __init__(self):
        self.model = None
        self.accuracy = 0.0
        self.load_or_train()

    def load_or_train(self):
        if MODEL_PATH.exists():
            try:
                data = joblib.load(MODEL_PATH)
                self.model = data['model']
                self.accuracy = data.get('accuracy', 0.0)
                logger.info(f"Model loaded from disk. Accuracy: {self.accuracy:.2%}")
                return
            except Exception as e:
                logger.warning(f"Failed to load model: {e}")

        self.train_initial()

    def train_initial(self):
        logger.info("Training initial phishing detection model...")
        urls, labels = generate_synthetic_dataset(3000)
        X = [extract_features(url) for url in urls]
        X = np.array(X)
        y = np.array(labels)

        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

        self.model = RandomForestClassifier(
            n_estimators=100,
            max_depth=15,
            min_samples_split=5,
            random_state=42,
            n_jobs=-1
        )
        self.model.fit(X_train, y_train)

        y_pred = self.model.predict(X_test)
        self.accuracy = accuracy_score(y_test, y_pred)
        logger.info(f"Model trained. Accuracy: {self.accuracy:.2%}")

        self.save()

    def save(self):
        joblib.dump({'model': self.model, 'accuracy': self.accuracy}, MODEL_PATH)
        logger.info("Model saved to disk.")

    def predict(self, url):
        """Predict phishing probability for a URL. Returns (probability, features)."""
        features = extract_features(url)
        X = np.array([features])
        proba = self.model.predict_proba(X)[0]
        phishing_prob = proba[1] if len(proba) > 1 else proba[0]
        return float(phishing_prob), features

    def retrain(self, urls, labels):
        """Retrain the model with provided data. Adds synthetic base only if data is small."""
        logger.info(f"Retraining model with {len(urls)} samples...")

        if len(urls) < 500:
            # Supplement with synthetic data for small datasets
            base_urls, base_labels = generate_synthetic_dataset(2000)
            all_urls = base_urls + urls
            all_labels = base_labels + labels
        else:
            # Enough real data, use directly
            all_urls = urls
            all_labels = labels

        X = np.array([extract_features(u) for u in all_urls])
        y = np.array(all_labels)

        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

        self.model = RandomForestClassifier(
            n_estimators=150,
            max_depth=20,
            min_samples_split=5,
            random_state=42,
            n_jobs=-1
        )
        self.model.fit(X_train, y_train)

        y_pred = self.model.predict(X_test)
        self.accuracy = accuracy_score(y_test, y_pred)
        logger.info(f"Model retrained. New accuracy: {self.accuracy:.2%} ({len(all_urls)} samples)")

        self.save()
        return self.accuracy

    def get_feature_importance(self):
        """Get feature importances for explainability."""
        if self.model is None:
            return {}
        importances = self.model.feature_importances_
        return dict(zip(FEATURE_NAMES, [float(x) for x in importances]))


# Singleton
_model_instance = None

def get_model():
    global _model_instance
    if _model_instance is None:
        _model_instance = PhishingModel()
    return _model_instance
