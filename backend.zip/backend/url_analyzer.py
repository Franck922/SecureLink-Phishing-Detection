"""
SecureLink URL Analyzer - Hybrid Rules + ML scoring with pedagogical explanations
"""
import re
import math
import logging
from urllib.parse import urlparse
from ml_model import get_model, SUSPICIOUS_TLDS, SHORTENED_DOMAINS, LEGITIMATE_DOMAINS, shannon_entropy, FEATURE_NAMES
from network_checks import run_network_checks
from content_analyzer import run_content_analysis
from safe_browsing import check_google_safe_browsing, format_safe_browsing_result
from phishing_kit_detector import detect_phishing_kit
from typosquatting_detector import detect_typosquatting as _detect_typo_advanced
from scoring_config import WEIGHTS, THRESHOLDS, OVERRIDES, REDIRECT, SPA, LEGITIMACY, URL_SHORTENERS, OFFLINE_DETECTION

logger = logging.getLogger(__name__)

# ==================== RULE-BASED SCORING ====================

RULES = [
    {
        "id": "NO_HTTPS",
        "name": "No HTTPS",
        "description_fr": "Ce lien n'utilise pas de connexion securisee (HTTPS).",
        "description_en": "This link doesn't use a secure connection (HTTPS).",
        "tip_fr": "Les sites legitimess utilisent presque toujours HTTPS. Mefiance!",
        "tip_en": "Legitimate sites almost always use HTTPS. Be careful!",
        "points": 25,
        "check": lambda f: f[2] == 0,  # has_https
    },
    {
        "id": "SUSPICIOUS_TLD",
        "name": "Suspicious TLD",
        "description_fr": "L'extension du domaine (.tk, .xyz, .ml...) est souvent utilisee par des arnaqueurs.",
        "description_en": "The domain extension (.tk, .xyz, .ml...) is often used by scammers.",
        "tip_fr": "Verifiez toujours l'extension du site. Les sites officiels utilisent .com, .fr, .org...",
        "tip_en": "Always check the site extension. Official sites use .com, .fr, .org...",
        "points": 20,
        "check": lambda f: f[8] == 1,  # suspicious_tld
    },
    {
        "id": "IP_ADDRESS",
        "name": "IP Address Domain",
        "description_fr": "Ce lien utilise une adresse IP au lieu d'un nom de domaine.",
        "description_en": "This link uses an IP address instead of a domain name.",
        "tip_fr": "Les sites legitimes n'utilisent jamais une adresse IP comme adresse.",
        "tip_en": "Legitimate sites never use an IP address as their address.",
        "points": 30,
        "check": lambda f: f[7] == 1,  # has_ip
    },
    {
        "id": "AT_SYMBOL",
        "name": "@ Symbol in URL",
        "description_fr": "Le symbole @ dans l'URL peut cacher la vraie destination du lien.",
        "description_en": "The @ symbol in the URL can hide the real link destination.",
        "tip_fr": "Le @ est une technique classique pour tromper les utilisateurs.",
        "tip_en": "The @ symbol is a classic technique to deceive users.",
        "points": 25,
        "check": lambda f: f[5] == 1,  # has_at
    },
    {
        "id": "LONG_URL",
        "name": "Excessively Long URL",
        "description_fr": "Cette URL est anormalement longue, ce qui peut indiquer une tentative de masquage.",
        "description_en": "This URL is abnormally long, which may indicate an attempt to hide something.",
        "tip_fr": "Les URLs tres longues essaient souvent de cacher l'adresse reelle.",
        "tip_en": "Very long URLs often try to hide the real address.",
        "points": 10,
        "check": lambda f: f[0] > 75,  # url_length
    },
    {
        "id": "MANY_SUBDOMAINS",
        "name": "Many Subdomains",
        "description_fr": "Ce lien a beaucoup de sous-domaines, ce qui est suspect.",
        "description_en": "This link has many subdomains, which is suspicious.",
        "tip_fr": "Les faux sites ajoutent souvent des sous-domaines pour paraitre legitimes (ex: google.secure.fake.com).",
        "tip_en": "Fake sites often add subdomains to appear legitimate (e.g., google.secure.fake.com).",
        "points": 15,
        "check": lambda f: f[13] >= 2,  # subdomain_count
    },
    {
        "id": "HIGH_ENTROPY",
        "name": "High Domain Entropy",
        "description_fr": "Le nom de domaine semble aleatoire et incomprehensible.",
        "description_en": "The domain name appears random and incomprehensible.",
        "tip_fr": "Un domaine avec des caracteres aleatoires est probablement genere automatiquement.",
        "tip_en": "A domain with random characters was probably auto-generated.",
        "points": 15,
        "check": lambda f: f[9] > 4.0 and f[0] > 30,  # domain_entropy high AND url not short
    },
    {
        "id": "DIGITS_IN_DOMAIN",
        "name": "Digits in Domain",
        "description_fr": "Le nom de domaine contient des chiffres suspects (ex: g00gle, paypa1).",
        "description_en": "The domain name contains suspicious digits (e.g., g00gle, paypa1).",
        "tip_fr": "Les arnaqueurs remplacent souvent des lettres par des chiffres similaires.",
        "tip_en": "Scammers often replace letters with similar-looking digits.",
        "points": 15,
        "check": lambda f: f[6] >= 2,  # digits_in_domain
    },
    {
        "id": "SUSPICIOUS_KEYWORDS",
        "name": "Suspicious Keywords",
        "description_fr": "L'URL contient des mots-cles suspects comme 'login', 'verify', 'secure'...",
        "description_en": "The URL contains suspicious keywords like 'login', 'verify', 'secure'...",
        "tip_fr": "Les liens de phishing utilisent des mots urgents pour vous presser.",
        "tip_en": "Phishing links use urgent words to pressure you.",
        "points": 10,
        "check": lambda f: f[19] == 1,  # suspicious_keywords
    },
    {
        "id": "REDIRECT_PATTERN",
        "name": "Redirect Pattern",
        "description_fr": "Ce lien contient un schema de redirection qui peut vous envoyer vers un faux site.",
        "description_en": "This link contains a redirect pattern that could send you to a fake site.",
        "tip_fr": "Les redirections cachees sont une technique frequente de phishing.",
        "tip_en": "Hidden redirects are a common phishing technique.",
        "points": 15,
        "check": lambda f: f[15] == 1,  # has_redirect
    },
    {
        "id": "SHORTENED_URL",
        "name": "Shortened URL",
        "description_fr": "Ce lien utilise un service de raccourcissement d'URL qui cache la destination reelle.",
        "description_en": "This link uses a URL shortening service that hides the real destination.",
        "tip_fr": "Avant de cliquer, utilisez un service de previsualisation pour voir la vraie URL.",
        "tip_en": "Before clicking, use a preview service to see the real URL.",
        "points": 10,
        "check": lambda f: f[16] == 1,  # shortened_url
    },
    {
        "id": "MANY_SPECIAL_CHARS",
        "name": "Many Special Characters",
        "description_fr": "L'URL contient beaucoup de caracteres speciaux, ce qui est inhabituel.",
        "description_en": "The URL contains many special characters, which is unusual.",
        "tip_fr": "Les URLs normales sont generalement simples et lisibles.",
        "tip_en": "Normal URLs are generally simple and readable.",
        "points": 10,
        "check": lambda f: f[14] > 5,  # special_chars
    },
    {
        "id": "HAS_PORT",
        "name": "Non-Standard Port",
        "description_fr": "Ce lien utilise un port non standard, ce qui est suspect.",
        "description_en": "This link uses a non-standard port, which is suspicious.",
        "tip_fr": "Les sites normaux n'affichent pas de numero de port dans leur URL.",
        "tip_en": "Normal sites don't show port numbers in their URLs.",
        "points": 15,
        "check": lambda f: f[12] == 1,  # has_port
    },
    # Negative rules (reduce score for safe indicators)
    {
        "id": "HAS_HTTPS_BONUS",
        "name": "HTTPS Enabled",
        "description_fr": "Ce site utilise une connexion securisee HTTPS.",
        "description_en": "This site uses a secure HTTPS connection.",
        "tip_fr": "HTTPS est un bon signe, mais ne garantit pas que le site est legitime.",
        "tip_en": "HTTPS is a good sign, but it doesn't guarantee the site is legitimate.",
        "points": -10,
        "check": lambda f: f[2] == 1,  # has_https
    },
    {
        "id": "SHORT_CLEAN_URL",
        "name": "Short Clean URL",
        "description_fr": "L'URL est courte et propre, ce qui est rassurant.",
        "description_en": "The URL is short and clean, which is reassuring.",
        "tip_fr": "Les URLs courtes et claires sont generalement plus fiables.",
        "tip_en": "Short, clear URLs are generally more trustworthy.",
        "points": -5,
        "check": lambda f: f[0] < 40,  # url_length
    },
]


def apply_rules(features):
    """Apply rule-based scoring. Returns score and triggered rules."""
    score = 0
    triggered = []
    for rule in RULES:
        try:
            if rule["check"](features):
                score += rule["points"]
                triggered.append({
                    "id": rule["id"],
                    "name": rule["name"],
                    "description_fr": rule["description_fr"],
                    "description_en": rule["description_en"],
                    "tip_fr": rule["tip_fr"],
                    "tip_en": rule["tip_en"],
                    "points": rule["points"],
                })
        except (IndexError, TypeError):
            continue
    return max(0, min(100, score)), triggered


def detect_typosquatting(url):
    """Check if the URL looks like typosquatting of a known domain.
    Uses the advanced detector (Levenshtein, char substitution, Unicode homoglyphs).
    Returns the target domain string or None.
    """
    result = _detect_typo_advanced(url)
    if result.get("is_typosquatting"):
        domains = result.get("legitimate_domains", [])
        return domains[0] if domains else result.get("target_brand")
    return None


def analyze_url(url):
    """Full URL analysis: hybrid ML + rules + network + content checks with explanations."""
    model = get_model()

    # ML prediction
    ml_probability, features = model.predict(url)
    ml_score = ml_probability * 100

    # Rule-based scoring
    rules_score, triggered_rules = apply_rules(features)

    # Network checks (DNS, SSL, WHOIS, rDNS)
    network_data = run_network_checks(url)
    network_score = network_data.get("network_score", 0)

    # Content analysis (HTML scanning)
    content_data = run_content_analysis(url)
    content_score = content_data.get("content_score", 0)

    # === ANGLE MORT 1 & 3: Redirect chain + URL shortener resolution ===
    # If final URL differs from initial, analyze the final destination too
    final_url = content_data.get("final_url", url)
    redirect_chain = content_data.get("redirect_chain", [])
    redirect_penalty = 0

    parsed_initial = urlparse(url)
    parsed_final = urlparse(final_url) if final_url else parsed_initial
    initial_domain = (parsed_initial.hostname or "").replace("www.", "").lower()
    final_domain = (parsed_final.hostname or "").replace("www.", "").lower()

    # Detect URL shortener (bit.ly, t.co, tinyurl.com, etc.)
    is_shortener = initial_domain in URL_SHORTENERS

    # Cross-domain redirect: initial and final domains differ significantly
    if final_domain and initial_domain and final_domain != initial_domain:
        # Extract TLD-less domain names for comparison
        init_parts = initial_domain.split(".")
        final_parts = final_domain.split(".")
        init_name = init_parts[0] if init_parts else ""
        final_name = final_parts[0] if final_parts else ""

        if init_name != final_name:
            if is_shortener:
                # Shortener → analyze the FINAL url with ML too
                ml_prob_final, features_final = model.predict(final_url)
                ml_score_final = ml_prob_final * 100
                if ml_score_final > ml_score:
                    ml_score = ml_score_final
                    features = features_final
                    rules_score, triggered_rules = apply_rules(features)
            else:
                redirect_penalty = REDIRECT["cross_domain_penalty"]

    if len(redirect_chain) >= REDIRECT["multi_hop_threshold"]:
        redirect_penalty += REDIRECT["multi_hop_penalty"]

    # === ANGLE MORT 4: SPA / JavaScript-only pages ===
    # If page was fetched but has minimal HTML content with heavy JS
    spa_penalty = 0
    raw_html = content_data.get("raw_html", "")
    page_fetched = content_data.get("page_fetched", False)
    if page_fetched and raw_html:
        text_content = re.sub(r'<script[^>]*>.*?</script>', '', raw_html, flags=re.S | re.I)
        text_content = re.sub(r'<[^>]+>', '', text_content)
        visible_text = text_content.strip()
        if len(visible_text) < SPA["min_visible_text"] and len(raw_html) > SPA["min_html_size"]:
            spa_penalty = SPA["penalty"]

    # Google Safe Browsing check
    sb_result = check_google_safe_browsing(url)
    sb_formatted = format_safe_browsing_result(sb_result)
    sb_score = 0
    if sb_result.get("is_threat"):
        sb_score = 50  # Major threat signal

    # Phishing Kit Fingerprinting
    raw_html = content_data.get("raw_html", "")
    has_login = content_data.get("has_login_form", False)
    kit_result = detect_phishing_kit(raw_html, url=url, has_login_form=has_login)
    kit_score = kit_result.get("risk_score", 0)

    # === LEGITIMACY BOOST ===
    # When strong trust signals are present, reduce the impact of ambiguous indicators
    # (high entropy, structural patterns on complex pages, etc.)
    legitimacy_bonus = 0
    trust_signals = 0

    whois_data = network_data.get("checks", {}).get("whois", {})
    domain_age = whois_data.get("domain_age_days")
    if domain_age is not None and domain_age > LEGITIMACY["domain_age_strong_days"]:
        trust_signals += 1
        legitimacy_bonus += LEGITIMACY["domain_age_strong_bonus"]
    elif domain_age is not None and domain_age > LEGITIMACY["domain_age_moderate_days"]:
        trust_signals += 1
        legitimacy_bonus += LEGITIMACY["domain_age_moderate_bonus"]

    ssl_data = network_data.get("checks", {}).get("ssl", {})
    if ssl_data.get("valid"):
        trust_signals += 1
        if ssl_data.get("protocol") in ("TLSv1.3", "TLSv1.2"):
            legitimacy_bonus += LEGITIMACY["ssl_tls_bonus"]

    if sb_result.get("checked") and not sb_result.get("is_threat"):
        trust_signals += 1
        legitimacy_bonus += LEGITIMACY["safe_browsing_clean_bonus"]

    if not content_data.get("content_findings"):
        trust_signals += 1

    from phishing_kit_detector import _is_known_legitimate
    if _is_known_legitimate(url):
        trust_signals += LEGITIMACY["whitelist_trust_signals"]
        legitimacy_bonus += LEGITIMACY["whitelist_bonus"]

    final_score = (
        (ml_score * WEIGHTS["ml"]) +
        (rules_score * WEIGHTS["rules"]) +
        (max(0, network_score) * WEIGHTS["network"] * 100 / 40) +
        (content_score * WEIGHTS["content"]) +
        (sb_score * WEIGHTS["safe_browsing"]) +
        (kit_score * WEIGHTS["kit_detection"])
    )

    final_score += redirect_penalty
    final_score += spa_penalty

    if network_score < 0:
        final_score += network_score

    if trust_signals >= LEGITIMACY["min_trust_signals"]:
        final_score += legitimacy_bonus

    if sb_result.get("is_threat"):
        final_score = max(final_score, OVERRIDES["safe_browsing_threat"])

    if kit_result.get("kits") and has_login:
        final_score = max(final_score, OVERRIDES["kit_with_login"])

    final_score = max(0, min(100, final_score))

    typosquat_target = detect_typosquatting(url)
    if typosquat_target:
        final_score = max(final_score, OVERRIDES["typosquatting"])

    # Detection "site inexistant" : DNS echoue sans signal fort de phishing intentionnel
    dns_exists = network_data.get("checks", {}).get("dns", {}).get("exists", True)
    is_offline = False
    if not dns_exists and not typosquat_target:
        has_suspicious_tld = features[8] == 1 if len(features) > 8 else False
        has_phishing_keywords = features[19] == 1 if len(features) > 19 else False
        has_ip_address = features[7] == 1 if len(features) > 7 else False
        has_brand_subdomain = any(
            r["id"] in ("BRAND_SUBDOMAIN",) for r in triggered_rules
        )
        if not has_suspicious_tld and not has_phishing_keywords and not has_ip_address and not has_brand_subdomain:
            is_offline = True

    if is_offline:
        risk_level = "OFFLINE"
        traffic_light = "gray"
        final_score = 0
    elif final_score < THRESHOLDS["suspicious"]:
        risk_level = "SAFE"
        traffic_light = "green"
    elif final_score < THRESHOLDS["dangerous"]:
        risk_level = "SUSPICIOUS"
        traffic_light = "yellow"
    else:
        risk_level = "DANGEROUS"
        traffic_light = "red"

    # Generate explanations
    positive_rules = [r for r in triggered_rules if r["points"] > 0]
    negative_rules = [r for r in triggered_rules if r["points"] < 0]
    top_risks = sorted(positive_rules, key=lambda r: r["points"], reverse=True)[:3]

    # Add network risk factors to top risks
    for nrf in network_data.get("network_risk_factors", []):
        if nrf["severity"] in ("high", "medium"):
            top_risks.append({
                "id": nrf["id"],
                "description_fr": nrf["description_fr"],
                "description_en": nrf["description_en"],
                "tip_fr": "",
                "tip_en": "",
                "points": 0,
            })

    # Build feature details for expert mode
    feature_details = dict(zip(FEATURE_NAMES, features))

    result = {
        "url": url,
        "final_score": round(final_score, 1),
        "risk_level": risk_level,
        "traffic_light": traffic_light,
        "ml_score": round(ml_score, 1),
        "rules_score": rules_score,
        "network_score": network_score,
        "content_score": content_score,
        "safe_browsing": sb_formatted,
        "phishing_kit": {
            "detected": kit_result.get("detected", False),
            "kits": kit_result.get("kits", []),
            "structural_findings": kit_result.get("structural_findings", []),
        },
        "network_checks": network_data.get("checks", {}),
        "network_risk_factors": network_data.get("network_risk_factors", []),
        "content_findings": content_data.get("content_findings", []),
        "content_details": {
            "page_fetched": content_data.get("page_fetched", False),
            "has_login_form": content_data.get("has_login_form", False),
            "brand_impersonation": content_data.get("brand_impersonation"),
            "suspicious_scripts_count": content_data.get("suspicious_scripts_count", 0),
            "external_domains_count": content_data.get("external_domains_count", 0),
            "final_url": content_data.get("final_url", url),
            "company_signals": content_data.get("company_signals", {}),
            "redirect_chain": content_data.get("redirect_chain", []),
            "typosquatting": content_data.get("typosquatting", {}),
        },
        "triggered_rules": triggered_rules,
        "top_risks": top_risks,
        "safe_indicators": negative_rules,
        "typosquatting_target": typosquat_target,
        "feature_details": feature_details,
        "model_accuracy": round(model.accuracy * 100, 1),
    }

    # Simple explanation
    if risk_level == "SAFE":
        result["simple_explanation_fr"] = "Ce lien semble sur. Aucun indicateur majeur de phishing detecte."
        result["simple_explanation_en"] = "This link appears safe. No major phishing indicators detected."
    elif risk_level == "OFFLINE":
        result["simple_explanation_fr"] = "Ce site n'existe pas ou est inaccessible. Le nom de domaine ne resout pas en DNS. Aucune analyse fiable n'est possible."
        result["simple_explanation_en"] = "This site does not exist or is unreachable. The domain name does not resolve in DNS. No reliable analysis is possible."
    elif risk_level == "SUSPICIOUS":
        result["simple_explanation_fr"] = "Ce lien presente quelques elements suspects. Soyez prudent avant de cliquer."
        result["simple_explanation_en"] = "This link has some suspicious elements. Be careful before clicking."
    else:
        result["simple_explanation_fr"] = "ATTENTION! Ce lien est potentiellement dangereux. Ne cliquez pas!"
        result["simple_explanation_en"] = "WARNING! This link is potentially dangerous. Do not click!"

    if typosquat_target:
        result["official_site"] = f"https://www.{typosquat_target}"
        result["typosquatting_explanation_fr"] = f"Ce lien tente d'imiter {typosquat_target}. Utilisez plutot le site officiel."
        result["typosquatting_explanation_en"] = f"This link is trying to imitate {typosquat_target}. Use the official site instead."

    return result
