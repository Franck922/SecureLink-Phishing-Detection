"""
SecureLink Real Dataset Manager
Downloads and manages real phishing URL datasets from PhishTank & URLhaus.
Combines with legitimate domain list for balanced training.
"""
import asyncio
import csv
import io
import logging
import random
import time
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor
from typing import Tuple

import httpx

logger = logging.getLogger(__name__)
executor = ThreadPoolExecutor(max_workers=2)

# ==================== DATA SOURCES ====================

PHISHTANK_URL = "http://data.phishtank.com/data/online-valid.csv"
URLHAUS_URL = "https://urlhaus.abuse.ch/downloads/csv_online/"

# Top legitimate domains (curated, real)
TOP_LEGIT_DOMAINS = [
    "google.com", "youtube.com", "facebook.com", "amazon.com", "wikipedia.org",
    "twitter.com", "instagram.com", "linkedin.com", "reddit.com", "netflix.com",
    "microsoft.com", "apple.com", "github.com", "stackoverflow.com", "paypal.com",
    "ebay.com", "spotify.com", "zoom.us", "office.com", "outlook.com",
    "bbc.co.uk", "nytimes.com", "cnn.com", "walmart.com", "target.com",
    "bestbuy.com", "chase.com", "wellsfargo.com", "bankofamerica.com", "citibank.com",
    "mozilla.org", "python.org", "w3.org", "wordpress.com", "medium.com",
    "dropbox.com", "salesforce.com", "adobe.com", "oracle.com", "ibm.com",
    "samsung.com", "intel.com", "nvidia.com", "amd.com", "cisco.com",
    "hp.com", "dell.com", "lenovo.com", "asus.com", "sony.com",
    "bbc.com", "reuters.com", "theguardian.com", "washingtonpost.com", "forbes.com",
    "bloomberg.com", "techcrunch.com", "wired.com", "arstechnica.com", "theverge.com",
    "who.int", "un.org", "europa.eu", "gov.uk", "whitehouse.gov",
    "nih.gov", "cdc.gov", "nasa.gov", "education.gouv.fr", "service-public.fr",
    "impots.gouv.fr", "ameli.fr", "caf.fr", "pole-emploi.fr", "laposte.fr",
    "sncf.com", "airfrance.fr", "bnpparibas.com", "societegenerale.fr", "lcl.fr",
    "orange.fr", "free.fr", "sfr.fr", "bouyguestelecom.fr", "ovh.com",
    "lemonde.fr", "lefigaro.fr", "liberation.fr", "20minutes.fr", "bfmtv.com",
    "twitch.tv", "discord.com", "slack.com", "notion.so", "figma.com",
    "canva.com", "trello.com", "asana.com", "jira.atlassian.com", "gitlab.com",
    "npmjs.com", "pypi.org", "rubygems.org", "maven.apache.org", "nuget.org",
    "docker.com", "kubernetes.io", "aws.amazon.com", "cloud.google.com", "azure.microsoft.com",
    "stripe.com", "shopify.com", "squarespace.com", "wix.com", "godaddy.com",
    "cloudflare.com", "fastly.com", "akamai.com", "digitalocean.com", "heroku.com",
    "coursera.org", "edx.org", "udemy.com", "khanacademy.org", "duolingo.com",
    "imdb.com", "rottentomatoes.com", "goodreads.com", "tripadvisor.com", "booking.com",
    "airbnb.com", "uber.com", "lyft.com", "doordash.com", "grubhub.com",
    "indeed.com", "glassdoor.com", "monster.com", "ziprecruiter.com", "upwork.com",
    "github.io", "netlify.app", "vercel.app", "pages.dev", "herokuapp.com",
]

LEGIT_PATHS = [
    "", "/", "/search", "/products", "/about", "/contact", "/help", "/support",
    "/news", "/blog", "/login", "/account", "/settings", "/en", "/fr",
    "/docs", "/api", "/pricing", "/features", "/download", "/privacy",
    "/terms", "/faq", "/careers", "/press", "/partners",
]


def _generate_legit_urls(count=1500):
    """Generate realistic legitimate URLs from top domains."""
    urls = []
    for _ in range(count):
        domain = random.choice(TOP_LEGIT_DOMAINS)
        path = random.choice(LEGIT_PATHS)
        https = random.choices(["https://", "http://"], weights=[0.95, 0.05])[0]
        www = random.choices(["www.", ""], weights=[0.4, 0.6])[0]
        urls.append(f"{https}{www}{domain}{path}")
    return urls


def _fetch_phishtank():
    """Download PhishTank verified phishing URLs (synchronous)."""
    urls = []
    try:
        logger.info("Fetching PhishTank dataset...")
        with httpx.Client(timeout=60, follow_redirects=True) as client:
            resp = client.get(PHISHTANK_URL, headers={"User-Agent": "SecureLink/1.0"})
            if resp.status_code == 200:
                reader = csv.DictReader(io.StringIO(resp.text))
                for row in reader:
                    url = row.get("url", "").strip()
                    if url and url.startswith("http"):
                        urls.append(url)
                        if len(urls) >= 3000:
                            break
                logger.info(f"PhishTank: fetched {len(urls)} phishing URLs")
            else:
                logger.warning(f"PhishTank returned status {resp.status_code}")
    except Exception as e:
        logger.warning(f"PhishTank fetch failed: {e}")
    return urls


def _fetch_urlhaus():
    """Download URLhaus active malicious URLs (synchronous)."""
    urls = []
    try:
        logger.info("Fetching URLhaus dataset...")
        with httpx.Client(timeout=60, follow_redirects=True) as client:
            resp = client.get(URLHAUS_URL, headers={"User-Agent": "SecureLink/1.0"})
            if resp.status_code == 200:
                lines = resp.text.split("\n")
                for line in lines:
                    if line.startswith("#") or not line.strip():
                        continue
                    parts = line.split('","')
                    if len(parts) >= 3:
                        url = parts[2].strip('"').strip()
                        if url.startswith("http"):
                            urls.append(url)
                            if len(urls) >= 2000:
                                break
                logger.info(f"URLhaus: fetched {len(urls)} malicious URLs")
            else:
                logger.warning(f"URLhaus returned status {resp.status_code}")
    except Exception as e:
        logger.warning(f"URLhaus fetch failed: {e}")
    return urls


async def fetch_real_datasets() -> dict:
    """Fetch phishing URLs from multiple real sources. Returns stats."""
    loop = asyncio.get_event_loop()

    phishtank_task = loop.run_in_executor(executor, _fetch_phishtank)
    urlhaus_task = loop.run_in_executor(executor, _fetch_urlhaus)

    phishtank_urls, urlhaus_urls = await asyncio.gather(phishtank_task, urlhaus_task)

    # Deduplicate
    all_phishing = list(set(phishtank_urls + urlhaus_urls))
    random.shuffle(all_phishing)

    # Generate legit URLs (balanced dataset)
    legit_count = max(len(all_phishing), 1500)
    legit_urls = _generate_legit_urls(legit_count)

    return {
        "phishing_urls": all_phishing,
        "legit_urls": legit_urls,
        "sources": {
            "phishtank": len(phishtank_urls),
            "urlhaus": len(urlhaus_urls),
            "legit_generated": len(legit_urls),
        },
        "total_phishing": len(all_phishing),
        "total_legit": len(legit_urls),
        "fetched_at": datetime.now(timezone.utc).isoformat(),
    }


async def fetch_and_store(db) -> dict:
    """Fetch datasets and store in MongoDB for persistence."""
    data = await fetch_real_datasets()

    # Store phishing URLs
    if data["phishing_urls"]:
        phishing_docs = [
            {"url": url, "is_phishing": True, "source": "real_dataset", "verified": True}
            for url in data["phishing_urls"]
        ]
        # Clear old real dataset entries and insert new
        await db.real_dataset.delete_many({"source": "real_dataset"})
        # Insert in batches
        batch_size = 500
        for i in range(0, len(phishing_docs), batch_size):
            await db.real_dataset.insert_many(phishing_docs[i:i + batch_size])

    # Store legit URLs
    if data["legit_urls"]:
        legit_docs = [
            {"url": url, "is_phishing": False, "source": "real_dataset", "verified": True}
            for url in data["legit_urls"]
        ]
        for i in range(0, len(legit_docs), batch_size):
            await db.real_dataset.insert_many(legit_docs[i:i + batch_size])

    # Store metadata
    await db.dataset_metadata.update_one(
        {"type": "real_dataset"},
        {"$set": {
            "type": "real_dataset",
            "sources": data["sources"],
            "total_phishing": data["total_phishing"],
            "total_legit": data["total_legit"],
            "total": data["total_phishing"] + data["total_legit"],
            "fetched_at": data["fetched_at"],
        }},
        upsert=True
    )

    logger.info(f"Stored {data['total_phishing']} phishing + {data['total_legit']} legit URLs in DB")
    return {
        "sources": data["sources"],
        "total_phishing": data["total_phishing"],
        "total_legit": data["total_legit"],
        "total": data["total_phishing"] + data["total_legit"],
        "fetched_at": data["fetched_at"],
    }


async def get_training_data(db) -> Tuple[list, list]:
    """Get combined training data: real dataset + user contributions."""
    urls = []
    labels = []

    # Real dataset from DB
    cursor = db.real_dataset.find({"source": "real_dataset"}, {"_id": 0, "url": 1, "is_phishing": 1})
    async for doc in cursor:
        urls.append(doc["url"])
        labels.append(1 if doc["is_phishing"] else 0)

    # User contributions (verified only)
    cursor = db.training_data.find({"verified": True}, {"_id": 0, "url": 1, "is_phishing": 1})
    async for doc in cursor:
        urls.append(doc["url"])
        labels.append(1 if doc["is_phishing"] else 0)

    # User feedback
    cursor = db.training_data.find({"source": "user_feedback"}, {"_id": 0, "url": 1, "is_phishing": 1})
    async for doc in cursor:
        urls.append(doc["url"])
        labels.append(1 if doc["is_phishing"] else 0)

    logger.info(f"Training data: {len(urls)} samples ({sum(labels)} phishing, {len(labels) - sum(labels)} legit)")
    return urls, labels


async def get_dataset_stats(db) -> dict:
    """Get current dataset statistics with balance info."""
    metadata = await db.dataset_metadata.find_one({"type": "real_dataset"}, {"_id": 0})
    real_count = await db.real_dataset.count_documents({})
    user_contributions = await db.training_data.count_documents({})

    # Compute actual balance from training data (same sources as get_training_data)
    real_phishing = await db.real_dataset.count_documents({"source": "real_dataset", "is_phishing": True})
    real_legit = await db.real_dataset.count_documents({"source": "real_dataset", "is_phishing": False})
    user_phishing_verified = await db.training_data.count_documents({"verified": True, "is_phishing": True})
    user_legit_verified = await db.training_data.count_documents({"verified": True, "is_phishing": False})
    user_phishing_feedback = await db.training_data.count_documents({"source": "user_feedback", "is_phishing": True})
    user_legit_feedback = await db.training_data.count_documents({"source": "user_feedback", "is_phishing": False})

    total_phishing = real_phishing + user_phishing_verified + user_phishing_feedback
    total_legit = real_legit + user_legit_verified + user_legit_feedback
    total = total_phishing + total_legit

    if total > 0:
        phishing_ratio = round(total_phishing / total * 100, 1)
        legit_ratio = round(total_legit / total * 100, 1)
        max_ratio = max(phishing_ratio, legit_ratio)
        # Balanced = max class < 65%
        is_balanced = max_ratio <= 65
    else:
        phishing_ratio = 0
        legit_ratio = 0
        max_ratio = 0
        is_balanced = True

    return {
        "real_dataset": metadata or {},
        "real_dataset_count": real_count,
        "user_contributions": user_contributions,
        "total_training_samples": real_count + user_contributions,
        "balance": {
            "total_phishing": total_phishing,
            "total_legit": total_legit,
            "phishing_ratio": phishing_ratio,
            "legit_ratio": legit_ratio,
            "is_balanced": is_balanced,
            "max_ratio": max_ratio,
            "threshold": 65,
        },
    }
