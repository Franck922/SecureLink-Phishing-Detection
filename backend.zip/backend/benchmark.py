"""
SecureLink Benchmark & Weight Calibration Script
Tests the analysis engine against a dataset of known phishing and legitimate URLs.
Generates performance metrics: confusion matrix, precision, recall, F1, accuracy.
Optionally runs grid search on scoring weights to find optimal combination.

Usage:
    python benchmark.py                # Run benchmark with current weights
    python benchmark.py --calibrate    # Run grid search calibration
    python benchmark.py --export       # Export results to CSV
"""
import sys
import os
import json
import time
import logging
import argparse
from datetime import datetime
from itertools import product

# Add parent dir to path
sys.path.insert(0, os.path.dirname(__file__))

logging.basicConfig(level=logging.WARNING)
logger = logging.getLogger(__name__)


# ============================================================
# BENCHMARK DATASET
# Label: 1 = phishing/dangerous, 0 = legitimate/safe
# Sources: PhishTank, OpenPhish, Alexa Top, manual curation
# ============================================================

DATASET = [
    # === LEGITIMATE SITES (label=0) ===
    # Major tech
    {"url": "https://google.com", "label": 0, "category": "tech"},
    {"url": "https://youtube.com", "label": 0, "category": "tech"},
    {"url": "https://facebook.com", "label": 0, "category": "tech"},
    {"url": "https://instagram.com", "label": 0, "category": "tech"},
    {"url": "https://twitter.com", "label": 0, "category": "tech"},
    {"url": "https://linkedin.com", "label": 0, "category": "tech"},
    {"url": "https://github.com", "label": 0, "category": "tech"},
    {"url": "https://stackoverflow.com", "label": 0, "category": "tech"},
    {"url": "https://reddit.com", "label": 0, "category": "tech"},
    {"url": "https://wikipedia.org", "label": 0, "category": "tech"},
    {"url": "https://microsoft.com", "label": 0, "category": "tech"},
    {"url": "https://apple.com", "label": 0, "category": "tech"},
    {"url": "https://amazon.com", "label": 0, "category": "ecommerce"},
    {"url": "https://amazon.fr", "label": 0, "category": "ecommerce"},
    {"url": "https://ebay.com", "label": 0, "category": "ecommerce"},
    {"url": "https://netflix.com", "label": 0, "category": "media"},
    {"url": "https://spotify.com", "label": 0, "category": "media"},
    {"url": "https://twitch.tv", "label": 0, "category": "media"},
    # Finance
    {"url": "https://paypal.com", "label": 0, "category": "finance"},
    {"url": "https://stripe.com", "label": 0, "category": "finance"},
    {"url": "https://chase.com", "label": 0, "category": "finance"},
    {"url": "https://boursorama.com", "label": 0, "category": "finance"},
    # French sites
    {"url": "https://orange.fr", "label": 0, "category": "telecom_fr"},
    {"url": "https://free.fr", "label": 0, "category": "telecom_fr"},
    {"url": "https://sfr.fr", "label": 0, "category": "telecom_fr"},
    {"url": "https://leboncoin.fr", "label": 0, "category": "ecommerce_fr"},
    {"url": "https://fnac.com", "label": 0, "category": "ecommerce_fr"},
    {"url": "https://cdiscount.com", "label": 0, "category": "ecommerce_fr"},
    # Government
    {"url": "https://impots.gouv.fr", "label": 0, "category": "gov_fr"},
    {"url": "https://ameli.fr", "label": 0, "category": "gov_fr"},
    {"url": "https://service-public.fr", "label": 0, "category": "gov_fr"},
    # Tools
    {"url": "https://zoom.us", "label": 0, "category": "tools"},
    {"url": "https://slack.com", "label": 0, "category": "tools"},
    {"url": "https://notion.so", "label": 0, "category": "tools"},
    {"url": "https://figma.com", "label": 0, "category": "tools"},
    {"url": "https://dropbox.com", "label": 0, "category": "tools"},
    {"url": "https://canva.com", "label": 0, "category": "tools"},
    {"url": "https://adobe.com", "label": 0, "category": "tools"},
    # Cloud
    {"url": "https://cloudflare.com", "label": 0, "category": "cloud"},
    {"url": "https://digitalocean.com", "label": 0, "category": "cloud"},
    # URLs with parameters (should NOT be flagged)
    {"url": "https://www.google.com/search?q=test+query&hl=fr", "label": 0, "category": "legit_params"},
    {"url": "https://www.youtube.com/watch?v=dQw4w9WgXcQ", "label": 0, "category": "legit_params"},
    {"url": "https://www.amazon.fr/dp/B09V3KXJPB?ref=cm_sw_r_cp_ud_dp", "label": 0, "category": "legit_params"},
    {"url": "https://fr.wikipedia.org/wiki/Phishing", "label": 0, "category": "legit_params"},
    {"url": "https://github.com/python/cpython/issues?q=is%3Aopen", "label": 0, "category": "legit_params"},

    # === PHISHING / DANGEROUS URLS (label=1) ===
    # Typosquatting
    {"url": "http://g00gle.com", "label": 1, "category": "typosquatting"},
    {"url": "http://faceb00k-verify.com", "label": 1, "category": "typosquatting"},
    {"url": "http://paypal-secure-login.com", "label": 1, "category": "typosquatting"},
    {"url": "http://amaz0n-delivery.com", "label": 1, "category": "typosquatting"},
    {"url": "http://micros0ft-support.com", "label": 1, "category": "typosquatting"},
    {"url": "http://appl3-id-verify.com", "label": 1, "category": "typosquatting"},
    {"url": "http://netfl1x-account.com", "label": 1, "category": "typosquatting"},
    {"url": "http://0range-service.fr", "label": 1, "category": "typosquatting"},
    # IP-based
    {"url": "http://192.168.1.1/login.php", "label": 1, "category": "ip_based"},
    {"url": "http://45.33.32.156/signin", "label": 1, "category": "ip_based"},
    {"url": "http://172.16.0.1/webmail", "label": 1, "category": "ip_based"},
    # Suspicious TLDs + patterns
    {"url": "http://xk3jf9s.xyz/verify-account", "label": 1, "category": "suspicious_tld"},
    {"url": "http://secure-banking.tk/login", "label": 1, "category": "suspicious_tld"},
    {"url": "http://update-your-account.gq/confirm", "label": 1, "category": "suspicious_tld"},
    {"url": "http://free-iphone-winner.ml/claim", "label": 1, "category": "suspicious_tld"},
    {"url": "http://urgent-security-alert.cf/verify", "label": 1, "category": "suspicious_tld"},
    # Keyword-stuffed URLs
    {"url": "http://secure-login-verify-paypal-update.com/signin.php", "label": 1, "category": "keyword_stuffed"},
    {"url": "http://account-verification-service-alert.com/confirm", "label": 1, "category": "keyword_stuffed"},
    {"url": "http://important-security-update-2024.com/login", "label": 1, "category": "keyword_stuffed"},
    # Long suspicious URLs
    {"url": "http://www.bank-security-update.com/login/verify/account?id=abc123&token=xyz", "label": 1, "category": "long_suspicious"},
    {"url": "http://signin-verify-update.com/auth/step1/personal-info.php", "label": 1, "category": "long_suspicious"},
    # Brand in subdomain
    {"url": "http://paypal.account-verify.com/login", "label": 1, "category": "brand_subdomain"},
    {"url": "http://google.security-alert.net/verify", "label": 1, "category": "brand_subdomain"},
    {"url": "http://apple.id-verification.org/confirm", "label": 1, "category": "brand_subdomain"},
    # No HTTPS
    {"url": "http://my-important-bank.com/login", "label": 1, "category": "no_https"},
    {"url": "http://secure-payment-portal.com/checkout", "label": 1, "category": "no_https"},
    # Random domain + login
    {"url": "http://zx9f3k2m.com/signin", "label": 1, "category": "random_domain"},
    {"url": "http://a1b2c3d4e5.net/login.php", "label": 1, "category": "random_domain"},
    {"url": "http://qwerty-asdf.com/verify-identity", "label": 1, "category": "random_domain"},
]


def run_analysis(url):
    """Run the full analysis on a single URL."""
    from url_analyzer import analyze_url
    try:
        result = analyze_url(url)
        return result
    except Exception as e:
        logger.warning(f"Analysis failed for {url}: {e}")
        return None


def classify_result(result, threshold_suspicious=30, threshold_dangerous=60):
    """Classify a result as 0 (safe) or 1 (dangerous) based on score."""
    if result is None:
        return 1  # Error = treat as suspicious
    score = result.get("final_score", 0)
    if score >= threshold_suspicious:
        return 1
    return 0


def compute_metrics(y_true, y_pred):
    """Compute confusion matrix, precision, recall, F1, accuracy."""
    tp = sum(1 for t, p in zip(y_true, y_pred) if t == 1 and p == 1)
    tn = sum(1 for t, p in zip(y_true, y_pred) if t == 0 and p == 0)
    fp = sum(1 for t, p in zip(y_true, y_pred) if t == 0 and p == 1)
    fn = sum(1 for t, p in zip(y_true, y_pred) if t == 1 and p == 0)

    precision = tp / (tp + fp) if (tp + fp) > 0 else 0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0
    accuracy = (tp + tn) / len(y_true) if y_true else 0

    return {
        "tp": tp, "tn": tn, "fp": fp, "fn": fn,
        "precision": round(precision, 4),
        "recall": round(recall, 4),
        "f1": round(f1, 4),
        "accuracy": round(accuracy, 4),
    }


def run_benchmark(threshold=30):
    """Run the full benchmark on the dataset."""
    print(f"\n{'='*60}")
    print(f"  SecureLink Benchmark — {len(DATASET)} URLs")
    print(f"  Seuil de classification: score >= {threshold} = dangereux")
    print(f"{'='*60}\n")

    y_true = []
    y_pred = []
    results = []
    errors = []

    for i, entry in enumerate(DATASET):
        url = entry["url"]
        label = entry["label"]
        cat = entry["category"]

        print(f"  [{i+1}/{len(DATASET)}] {url[:60]:<60} ", end="", flush=True)
        start = time.time()

        result = run_analysis(url)
        elapsed = time.time() - start

        if result:
            pred = classify_result(result, threshold_suspicious=threshold)
            score = result.get("final_score", -1)
            light = result.get("traffic_light", "?")
            typo = result.get("typosquatting_target")

            y_true.append(label)
            y_pred.append(pred)

            status = "OK" if pred == label else "ERREUR"
            if pred != label:
                errors.append({"url": url, "label": label, "predicted": pred, "score": score, "category": cat})

            print(f"score={score:5.1f}  {light:6s}  attendu={label}  predit={pred}  {status}  ({elapsed:.1f}s)")

            results.append({
                "url": url, "label": label, "predicted": pred,
                "score": score, "traffic_light": light,
                "typosquatting": typo, "category": cat,
                "elapsed": round(elapsed, 2),
            })
        else:
            y_true.append(label)
            y_pred.append(1)
            print(f"ERREUR ANALYSE ({elapsed:.1f}s)")

    # Metrics
    metrics = compute_metrics(y_true, y_pred)
    print(f"\n{'='*60}")
    print(f"  RESULTATS")
    print(f"{'='*60}")
    print(f"  URLs testees:   {len(y_true)}")
    print(f"  Accuracy:       {metrics['accuracy']*100:.1f}%")
    print(f"  Precision:      {metrics['precision']*100:.1f}%")
    print(f"  Rappel:         {metrics['recall']*100:.1f}%")
    print(f"  F1-Score:       {metrics['f1']*100:.1f}%")
    print(f"\n  Matrice de confusion:")
    print(f"                  Predit SAFE  Predit DANGER")
    print(f"  Reel SAFE       {metrics['tn']:>10}  {metrics['fp']:>13}")
    print(f"  Reel DANGER     {metrics['fn']:>10}  {metrics['tp']:>13}")

    if errors:
        print(f"\n  Erreurs de classification ({len(errors)}):")
        for e in errors:
            label_str = "PHISHING" if e["label"] == 1 else "LEGITIME"
            pred_str = "DANGER" if e["predicted"] == 1 else "SAFE"
            print(f"    {e['url'][:55]:<55} reel={label_str:<9} predit={pred_str:<6} score={e['score']:.1f} ({e['category']})")

    return metrics, results


def run_calibration(thresholds=None):
    """Run grid search on classification threshold to find optimal value."""
    if thresholds is None:
        thresholds = [20, 25, 30, 35, 40, 45, 50]

    print(f"\n{'='*60}")
    print(f"  CALIBRATION — Test de {len(thresholds)} seuils")
    print(f"{'='*60}\n")

    # Run analysis once
    print("  Analyse des URLs en cours...\n")
    all_results = []
    for i, entry in enumerate(DATASET):
        print(f"  [{i+1}/{len(DATASET)}] {entry['url'][:60]}", flush=True)
        result = run_analysis(entry["url"])
        all_results.append({
            "entry": entry,
            "result": result,
            "score": result.get("final_score", -1) if result else -1,
        })

    print(f"\n  {'Seuil':>6} | {'Accuracy':>8} | {'Precision':>9} | {'Rappel':>6} | {'F1':>6} | {'FP':>3} | {'FN':>3}")
    print(f"  {'-'*6}-+-{'-'*8}-+-{'-'*9}-+-{'-'*6}-+-{'-'*6}-+-{'-'*3}-+-{'-'*3}")

    best_f1 = 0
    best_threshold = 30
    all_metrics = []

    for t in thresholds:
        y_true = [r["entry"]["label"] for r in all_results]
        y_pred = [classify_result(r["result"], threshold_suspicious=t) for r in all_results]
        m = compute_metrics(y_true, y_pred)
        all_metrics.append({"threshold": t, **m})

        marker = " <-- best" if m["f1"] > best_f1 else ""
        if m["f1"] > best_f1:
            best_f1 = m["f1"]
            best_threshold = t

        print(f"  {t:>6} | {m['accuracy']*100:>7.1f}% | {m['precision']*100:>8.1f}% | {m['recall']*100:>5.1f}% | {m['f1']*100:>5.1f}% | {m['fp']:>3} | {m['fn']:>3}{marker}")

    print(f"\n  Seuil optimal: {best_threshold} (F1 = {best_f1*100:.1f}%)")
    return best_threshold, all_metrics


def export_csv(results, filepath="benchmark_results.csv"):
    """Export results to CSV file."""
    import csv
    with open(filepath, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=[
            "url", "label", "predicted", "score", "traffic_light",
            "typosquatting", "category", "elapsed"
        ])
        writer.writeheader()
        writer.writerows(results)
    print(f"\n  Resultats exportes dans {filepath}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="SecureLink Benchmark")
    parser.add_argument("--calibrate", action="store_true", help="Run threshold grid search")
    parser.add_argument("--threshold", type=int, default=30, help="Classification threshold (default: 30)")
    parser.add_argument("--export", action="store_true", help="Export results to CSV")
    args = parser.parse_args()

    if args.calibrate:
        best_t, _ = run_calibration()
        print(f"\n  Relance du benchmark avec le seuil optimal ({best_t})...")
        metrics, results = run_benchmark(threshold=best_t)
    else:
        metrics, results = run_benchmark(threshold=args.threshold)

    if args.export:
        export_csv(results)

    # Save JSON report
    report = {
        "date": datetime.now().isoformat(),
        "dataset_size": len(DATASET),
        "threshold": args.threshold,
        "metrics": metrics,
        "results_count": len(results) if results else 0,
    }
    report_path = os.path.join(os.path.dirname(__file__), "benchmark_report.json")
    with open(report_path, "w") as f:
        json.dump(report, f, indent=2)
    print(f"\n  Rapport sauvegarde dans {report_path}")
